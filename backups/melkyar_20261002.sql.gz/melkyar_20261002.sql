--
-- PostgreSQL database dump
--

\restrict 8svyU3alhCXPrMSje0vYJOrqJhlkxqdkvg1Ys6IMIHHmqJYbcVcKLbWQAZ9zsky

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dealstatus; Type: TYPE; Schema: public; Owner: melkyar_app
--

CREATE TYPE public.dealstatus AS ENUM (
    'pending',
    'finalized',
    'canceled'
);


ALTER TYPE public.dealstatus OWNER TO melkyar_app;

--
-- Name: dealtype; Type: TYPE; Schema: public; Owner: melkyar_app
--

CREATE TYPE public.dealtype AS ENUM (
    'sale',
    'presale',
    'rent',
    'mortgage'
);


ALTER TYPE public.dealtype OWNER TO melkyar_app;

--
-- Name: followupstatus; Type: TYPE; Schema: public; Owner: melkyar_app
--

CREATE TYPE public.followupstatus AS ENUM (
    'pending',
    'done',
    'canceled'
);


ALTER TYPE public.followupstatus OWNER TO melkyar_app;

--
-- Name: propertystatus; Type: TYPE; Schema: public; Owner: melkyar_app
--

CREATE TYPE public.propertystatus AS ENUM (
    'active',
    'inactive',
    'sold',
    'rented'
);


ALTER TYPE public.propertystatus OWNER TO melkyar_app;

--
-- Name: requeststatus; Type: TYPE; Schema: public; Owner: melkyar_app
--

CREATE TYPE public.requeststatus AS ENUM (
    'open',
    'closed',
    'contacted',
    'visited',
    'negotiation',
    'won',
    'lost'
);


ALTER TYPE public.requeststatus OWNER TO melkyar_app;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: melkyar_app
--

CREATE TYPE public.userrole AS ENUM (
    'admin',
    'agent'
);


ALTER TYPE public.userrole OWNER TO melkyar_app;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.activity_logs (
    id integer NOT NULL,
    user_id integer NOT NULL,
    action character varying(64) NOT NULL,
    entity_type character varying(64) NOT NULL,
    entity_id integer,
    detail character varying(500),
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.activity_logs OWNER TO melkyar_app;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_logs_id_seq OWNER TO melkyar_app;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO melkyar_app;

--
-- Name: bot_faq; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.bot_faq (
    id integer NOT NULL,
    question character varying(300) NOT NULL,
    answer text NOT NULL
);


ALTER TABLE public.bot_faq OWNER TO melkyar_app;

--
-- Name: bot_faq_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.bot_faq_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bot_faq_id_seq OWNER TO melkyar_app;

--
-- Name: bot_faq_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.bot_faq_id_seq OWNED BY public.bot_faq.id;


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.chat_messages (
    id integer NOT NULL,
    sender_id integer NOT NULL,
    receiver_id integer NOT NULL,
    body text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.chat_messages OWNER TO melkyar_app;

--
-- Name: chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.chat_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_messages_id_seq OWNER TO melkyar_app;

--
-- Name: chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.chat_messages_id_seq OWNED BY public.chat_messages.id;


--
-- Name: client_requests; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.client_requests (
    id integer NOT NULL,
    owner_agent_id integer NOT NULL,
    customer_name character varying(128) NOT NULL,
    customer_phone character varying(32),
    deal_type character varying(16) NOT NULL,
    city character varying(64),
    district character varying(64),
    min_area double precision,
    max_area double precision,
    min_rooms integer,
    max_price integer,
    notes text,
    status public.requeststatus DEFAULT 'open'::public.requeststatus NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.client_requests OWNER TO melkyar_app;

--
-- Name: client_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.client_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.client_requests_id_seq OWNER TO melkyar_app;

--
-- Name: client_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.client_requests_id_seq OWNED BY public.client_requests.id;


--
-- Name: commission_payments; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.commission_payments (
    id integer NOT NULL,
    deal_id integer NOT NULL,
    amount numeric NOT NULL,
    paid_date date,
    note character varying(500),
    receipt_path character varying(255),
    created_at timestamp with time zone NOT NULL,
    kind character varying(16) DEFAULT 'to_agent'::character varying NOT NULL
);


ALTER TABLE public.commission_payments OWNER TO melkyar_app;

--
-- Name: commission_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.commission_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.commission_payments_id_seq OWNER TO melkyar_app;

--
-- Name: commission_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.commission_payments_id_seq OWNED BY public.commission_payments.id;


--
-- Name: deals; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.deals (
    id integer NOT NULL,
    property_id integer NOT NULL,
    agent_id integer NOT NULL,
    deal_amount numeric NOT NULL,
    commission_percent double precision NOT NULL,
    commission_amount numeric NOT NULL,
    status public.dealstatus DEFAULT 'pending'::public.dealstatus NOT NULL,
    contract_date date,
    finalized_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    agent2_id integer,
    commission_percent_agent2 double precision
);


ALTER TABLE public.deals OWNER TO melkyar_app;

--
-- Name: deals_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.deals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.deals_id_seq OWNER TO melkyar_app;

--
-- Name: deals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.deals_id_seq OWNED BY public.deals.id;


--
-- Name: discovery_listings; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.discovery_listings (
    id integer NOT NULL,
    source character varying(20) NOT NULL,
    external_id character varying(64) NOT NULL,
    title character varying(255),
    raw_address character varying(255),
    price bigint,
    deal_type character varying(20),
    neighborhood_id integer,
    url character varying(500),
    posted_at timestamp with time zone,
    fetched_at timestamp with time zone,
    converted_property_id integer,
    converted_by_user_id integer,
    converted_at timestamp with time zone,
    city character varying(50),
    area_m2 integer,
    rooms integer,
    deposit bigint,
    monthly_rent bigint,
    attributes jsonb,
    dismissed_at timestamp with time zone
);


ALTER TABLE public.discovery_listings OWNER TO melkyar_app;

--
-- Name: discovery_listings_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.discovery_listings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.discovery_listings_id_seq OWNER TO melkyar_app;

--
-- Name: discovery_listings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.discovery_listings_id_seq OWNED BY public.discovery_listings.id;


--
-- Name: discovery_neighborhoods; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.discovery_neighborhoods (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    aliases character varying(255)
);


ALTER TABLE public.discovery_neighborhoods OWNER TO melkyar_app;

--
-- Name: discovery_neighborhoods_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.discovery_neighborhoods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.discovery_neighborhoods_id_seq OWNER TO melkyar_app;

--
-- Name: discovery_neighborhoods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.discovery_neighborhoods_id_seq OWNED BY public.discovery_neighborhoods.id;


--
-- Name: discovery_notification_logs; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.discovery_notification_logs (
    id integer NOT NULL,
    customer_id integer,
    channel character varying(20),
    body text,
    created_at timestamp with time zone
);


ALTER TABLE public.discovery_notification_logs OWNER TO melkyar_app;

--
-- Name: discovery_notification_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.discovery_notification_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.discovery_notification_logs_id_seq OWNER TO melkyar_app;

--
-- Name: discovery_notification_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.discovery_notification_logs_id_seq OWNED BY public.discovery_notification_logs.id;


--
-- Name: filter_presets; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.filter_presets (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    params json NOT NULL,
    requested_by integer NOT NULL,
    approved boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    pending_delete boolean DEFAULT false NOT NULL
);


ALTER TABLE public.filter_presets OWNER TO melkyar_app;

--
-- Name: filter_presets_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.filter_presets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.filter_presets_id_seq OWNER TO melkyar_app;

--
-- Name: filter_presets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.filter_presets_id_seq OWNED BY public.filter_presets.id;


--
-- Name: follow_ups; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.follow_ups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    property_id integer,
    deal_id integer,
    title character varying(200) NOT NULL,
    description text,
    due_date date,
    status public.followupstatus DEFAULT 'pending'::public.followupstatus NOT NULL,
    reminded boolean DEFAULT false NOT NULL,
    done_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    due_time character varying(5)
);


ALTER TABLE public.follow_ups OWNER TO melkyar_app;

--
-- Name: follow_ups_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.follow_ups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.follow_ups_id_seq OWNER TO melkyar_app;

--
-- Name: follow_ups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.follow_ups_id_seq OWNED BY public.follow_ups.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(200) NOT NULL,
    body text,
    entity_type character varying(32),
    entity_id integer,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.notifications OWNER TO melkyar_app;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO melkyar_app;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: properties; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.properties (
    id integer NOT NULL,
    owner_agent_id integer NOT NULL,
    deal_type public.dealtype NOT NULL,
    status public.propertystatus NOT NULL,
    city character varying(64) NOT NULL,
    district character varying(64),
    address character varying(255),
    area_m2 double precision,
    rooms integer,
    has_elevator boolean NOT NULL,
    has_parking boolean NOT NULL,
    owner_name character varying(128),
    owner_phone character varying(32),
    contract_end_date date,
    details jsonb NOT NULL,
    notes character varying(2000),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    amenities json,
    expire_notified_at timestamp with time zone,
    expire_review_at date,
    property_types json,
    urgent_until date,
    location_url character varying(500),
    build_year integer,
    total_units integer,
    convertible_note character varying(500),
    deleted_at timestamp with time zone
);


ALTER TABLE public.properties OWNER TO melkyar_app;

--
-- Name: properties_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.properties_id_seq OWNER TO melkyar_app;

--
-- Name: properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.properties_id_seq OWNED BY public.properties.id;


--
-- Name: property_favorites; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.property_favorites (
    id integer NOT NULL,
    user_id integer NOT NULL,
    property_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.property_favorites OWNER TO melkyar_app;

--
-- Name: property_favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.property_favorites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.property_favorites_id_seq OWNER TO melkyar_app;

--
-- Name: property_favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.property_favorites_id_seq OWNED BY public.property_favorites.id;


--
-- Name: property_images; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.property_images (
    id integer NOT NULL,
    property_id integer NOT NULL,
    stored_filename character varying(128) NOT NULL,
    original_filename character varying(255),
    content_type character varying(64) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.property_images OWNER TO melkyar_app;

--
-- Name: property_images_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.property_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.property_images_id_seq OWNER TO melkyar_app;

--
-- Name: property_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.property_images_id_seq OWNED BY public.property_images.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    full_name character varying(128) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    role public.userrole NOT NULL,
    is_active boolean NOT NULL,
    token_version integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    phone character varying(32),
    failed_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    commission_rates json
);


ALTER TABLE public.users OWNER TO melkyar_app;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO melkyar_app;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: bot_faq id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.bot_faq ALTER COLUMN id SET DEFAULT nextval('public.bot_faq_id_seq'::regclass);


--
-- Name: chat_messages id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.chat_messages ALTER COLUMN id SET DEFAULT nextval('public.chat_messages_id_seq'::regclass);


--
-- Name: client_requests id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.client_requests ALTER COLUMN id SET DEFAULT nextval('public.client_requests_id_seq'::regclass);


--
-- Name: commission_payments id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.commission_payments ALTER COLUMN id SET DEFAULT nextval('public.commission_payments_id_seq'::regclass);


--
-- Name: deals id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.deals ALTER COLUMN id SET DEFAULT nextval('public.deals_id_seq'::regclass);


--
-- Name: discovery_listings id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.discovery_listings ALTER COLUMN id SET DEFAULT nextval('public.discovery_listings_id_seq'::regclass);


--
-- Name: discovery_neighborhoods id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.discovery_neighborhoods ALTER COLUMN id SET DEFAULT nextval('public.discovery_neighborhoods_id_seq'::regclass);


--
-- Name: discovery_notification_logs id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.discovery_notification_logs ALTER COLUMN id SET DEFAULT nextval('public.discovery_notification_logs_id_seq'::regclass);


--
-- Name: filter_presets id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.filter_presets ALTER COLUMN id SET DEFAULT nextval('public.filter_presets_id_seq'::regclass);


--
-- Name: follow_ups id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.follow_ups ALTER COLUMN id SET DEFAULT nextval('public.follow_ups_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: properties id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.properties ALTER COLUMN id SET DEFAULT nextval('public.properties_id_seq'::regclass);


--
-- Name: property_favorites id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.property_favorites ALTER COLUMN id SET DEFAULT nextval('public.property_favorites_id_seq'::regclass);


--
-- Name: property_images id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.property_images ALTER COLUMN id SET DEFAULT nextval('public.property_images_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.activity_logs (id, user_id, action, entity_type, entity_id, detail, created_at) FROM stdin;
1	1	login	user	1	\N	2026-09-07 15:28:04.875737+00
2	1	create	property	1	تهران — رغفرانیه ۱	2026-09-07 15:39:00.978183+00
3	1	update	property	1	تهران — رغفرانیه ۱	2026-09-07 15:42:22.348461+00
4	1	create	property	2	بذذذ — ببببببب	2026-09-07 15:44:18.684597+00
5	1	login	user	1	\N	2026-09-08 13:55:53.847504+00
6	1	login	user	1	\N	2026-09-08 14:02:56.806094+00
7	1	login	user	1	\N	2026-09-08 14:04:07.371103+00
8	1	deactivate	property	1	تهران — رغفرانیه ۱	2026-09-08 14:20:10.927176+00
9	1	login	user	1	\N	2026-09-08 15:24:27.565288+00
10	1	login	user	1	\N	2026-09-08 15:35:16.653276+00
11	1	create	property	3	ttt — tttt	2026-09-08 15:37:02.636083+00
12	1	create	property	4	غغغغ — 	2026-09-08 15:38:09.572795+00
13	1	update	property	3	ttt — tttt	2026-09-08 15:38:23.449544+00
14	1	reactivate	property	1	تهران — رغفرانیه ۱	2026-09-08 15:39:16.235022+00
15	1	import_excel	property	\N	5 فایل ثبت شد، 0 خطا، 0 تکراری نادیده گرفته شد	2026-09-08 16:10:03.235389+00
16	1	import_excel	property	\N	2 فایل ثبت شد، 0 خطا، 3 تکراری نادیده گرفته شد	2026-09-08 16:10:05.542955+00
17	1	login	user	1	\N	2026-09-08 16:44:00.299096+00
18	1	login	user	1	\N	2026-09-08 16:47:09.905539+00
19	1	upload_image	property	11	3 عکس اضافه شد	2026-09-08 16:47:38.588803+00
20	1	update	property	11	uuuuu — 	2026-09-08 16:47:45.862625+00
21	1	delete_image	property	11	Screenshot 2026-08-30 193337.png	2026-09-08 16:48:07.697343+00
22	1	update	property	11	uuuuu — 	2026-09-08 16:48:11.783722+00
23	1	update	property	11	uuuuu — 	2026-09-08 16:50:29.713764+00
24	1	deactivate	property	9	uuuتت — 	2026-09-08 16:52:05.988974+00
25	1	reactivate	property	9	uuuتت — 	2026-09-08 16:52:27.527859+00
26	1	create	user	2	تینا (agent)	2026-09-08 16:54:26.765233+00
27	1	reset_password	user	2	تینا	2026-09-08 16:54:42.069901+00
28	1	update_phone	user	2	تینا	2026-09-08 16:54:46.474313+00
29	1	update_phone	user	2	تینا	2026-09-08 16:54:48.590039+00
30	1	update	user	2	درصد پورسانت تینا	2026-09-08 16:55:13.015069+00
31	1	create	user	3	ضضض (agent)	2026-09-08 16:55:26.781207+00
32	1	deactivate	user	3	ضضض	2026-09-08 16:55:30.910505+00
33	1	create	deal	1	معامله 22,222,222 تومان	2026-09-08 17:01:18.516035+00
34	1	finalize	deal	1	قطعی — پورسانت 9,333,333	2026-09-08 17:01:28.972389+00
35	1	activate	user	3	ضضض	2026-09-08 17:02:43.891903+00
36	1	create	deal	2	معامله 44,444 تومان	2026-09-08 17:03:15.134153+00
37	1	create	deal_payment	2	پرداخت 22,222,222 تومان	2026-09-08 17:03:45.597842+00
38	1	login	user	1	\N	2026-09-09 16:23:27.647553+00
39	1	login	user	1	\N	2026-09-09 16:43:15.346991+00
40	1	login	user	1	\N	2026-09-09 17:01:11.350372+00
41	1	login	user	1	\N	2026-09-09 17:01:21.964334+00
42	1	login	user	1	\N	2026-09-09 17:10:53.390275+00
43	1	finalize	deal	2	قطعی — پورسانت 18,666	2026-09-09 17:20:13.925377+00
44	1	finalize	deal	1	قطعی — پورسانت 9,333,333	2026-09-09 17:20:17.118648+00
45	1	create	client_request	1	ض	2026-09-09 17:31:02.893819+00
46	1	login	user	1	\N	2026-09-09 17:41:08.672381+00
47	1	login	user	1	\N	2026-09-09 19:48:58.432007+00
48	1	login	user	1	\N	2026-09-09 20:13:00.296952+00
49	1	login	user	1	\N	2026-09-09 20:16:12.613973+00
50	1	create	user	4	jjj (agent)	2026-09-09 20:16:52.667335+00
51	1	create	follow_up	1	;;;;;;;;	2026-09-09 20:17:17.81619+00
52	1	create	follow_up	2	jjjjj	2026-09-09 20:17:26.504052+00
53	1	create	follow_up	3	jjjj	2026-09-09 20:17:42.146862+00
54	1	create	follow_up	4	.......من	2026-09-09 20:22:35.118882+00
55	1	create	follow_up	5	مممم	2026-09-09 20:22:51.326948+00
56	1	create	client_request	2	د	2026-09-09 20:23:20.387162+00
57	1	deactivate	property	9	uuuتت — 	2026-09-09 20:26:18.841017+00
58	1	deactivate	property	8	uuuuu — 	2026-09-09 20:26:40.836183+00
59	1	login	user	1	\N	2026-09-09 20:55:32.742159+00
60	1	create	follow_up	6	تتتتت	2026-09-09 20:58:04.440146+00
61	1	login	user	1	\N	2026-09-10 20:25:41.978252+00
62	1	login	user	1	\N	2026-09-11 12:08:39.690396+00
63	1	create	user	5	sss (agent)	2026-09-11 12:09:15.368486+00
64	1	create	follow_up	7	ssss	2026-09-11 12:09:31.125748+00
65	1	create	follow_up	8	zzzz	2026-09-11 12:09:38.544475+00
66	1	login	user	1	\N	2026-09-11 12:16:48.694662+00
67	1	create	deal	3	معامله 22,222,222 تومان	2026-09-11 12:19:52.979116+00
68	1	create	deal_payment	2	پرداخت 222 تومان	2026-09-11 12:21:30.355344+00
69	1	create	follow_up	9	ثثثثث	2026-09-11 12:25:20.974357+00
70	1	login	user	1	\N	2026-09-11 12:39:18.426195+00
71	1	create	deal	4	معامله 333,333,333 تومان	2026-09-11 12:39:52.564146+00
72	1	create	deal	5	معامله 3,333,333 تومان	2026-09-11 12:40:08.730412+00
73	1	finalize	deal	4	قطعی — پورسانت 333,333,333	2026-09-11 12:41:23.688977+00
74	1	login	user	1	\N	2026-09-11 12:49:21.571829+00
75	1	login	user	1	\N	2026-09-11 13:13:38.416682+00
76	1	login	user	1	\N	2026-09-11 13:15:02.288789+00
77	1	login	user	1	\N	2026-09-11 13:31:14.313899+00
78	1	login	user	1	\N	2026-09-11 13:57:17.040921+00
79	1	create	deal	6	معامله 22,222,222 تومان	2026-09-11 13:58:18.318438+00
80	1	finalize	deal	6	قطعی — پورسانت 4,888,889	2026-09-11 14:00:16.517463+00
81	1	update	deal	6	بازگشت از قطعی به در جریان	2026-09-11 14:00:19.170993+00
82	1	finalize	deal	6	قطعی — پورسانت 4,888,889	2026-09-11 14:00:29.008879+00
83	1	create	deal_payment	6	پرداخت 2,222 تومان	2026-09-11 14:00:38.719949+00
84	1	create	deal_payment	6	پرداخت 22 تومان	2026-09-11 14:00:45.218337+00
85	1	update	deal_payment	6	رسید پرداخت ثبت/تعویض شد	2026-09-11 14:01:04.906329+00
86	1	create	follow_up	10	333	2026-09-11 14:01:34.465151+00
87	1	login	user	1	\N	2026-09-11 14:12:47.184611+00
88	1	reset_password	user	5	sss	2026-09-11 14:14:11.733502+00
89	5	login	user	5	\N	2026-09-11 14:14:29.765329+00
90	5	create	property	12	aaa — aaaaaa	2026-09-11 14:15:32.037122+00
91	5	upload_image	property	12	1 عکس اضافه شد	2026-09-11 14:15:39.921509+00
92	5	import_excel	property	\N	5 فایل ثبت شد، 1 خطا، 0 تکراری نادیده گرفته شد	2026-09-11 14:17:30.689695+00
93	5	create	follow_up	11	ttt	2026-09-11 14:19:23.783724+00
94	5	create	client_request	3	ققق	2026-09-11 14:19:38.4935+00
95	5	create	property	18	ببب — بببببببب	2026-09-11 14:23:11.091372+00
96	1	login	user	1	\N	2026-09-11 14:23:44.409491+00
97	1	login	user	1	\N	2026-09-11 14:45:01.311853+00
98	1	login	user	1	\N	2026-09-12 12:31:49.875655+00
99	1	login	user	1	\N	2026-09-12 15:59:41.406461+00
100	1	login	user	1	\N	2026-09-13 10:46:12.629238+00
101	1	login	user	1	\N	2026-09-13 11:37:54.606665+00
102	1	login	user	1	\N	2026-09-13 11:42:21.32521+00
103	1	login	user	1	\N	2026-09-13 11:50:20.989751+00
104	1	login	user	1	\N	2026-09-13 11:54:24.344398+00
105	1	login	user	1	\N	2026-09-13 12:01:59.935308+00
106	1	login	user	1	\N	2026-09-13 12:12:11.705141+00
107	5	login	user	5	\N	2026-09-13 12:20:50.724011+00
108	1	login	user	1	\N	2026-09-13 12:21:45.725489+00
109	1	login	user	1	\N	2026-09-13 12:39:19.625311+00
110	1	login	user	1	\N	2026-09-14 13:19:01.23842+00
111	1	login	user	1	\N	2026-09-15 15:04:50.699284+00
112	1	create	client_request	4	gggggggggggggggggggggggggggggggg	2026-09-15 15:33:18.542505+00
113	1	reactivate	property	11	uuuuu — 	2026-09-15 15:39:27.809819+00
114	1	login	user	1	\N	2026-09-16 16:23:53.060258+00
115	1	login	user	1	\N	2026-09-16 16:50:30.421465+00
116	1	login	user	1	\N	2026-09-16 17:02:53.030154+00
117	1	login	user	1	\N	2026-09-16 18:06:45.894145+00
118	1	login	user	1	\N	2026-09-16 18:07:38.076189+00
119	1	login	user	1	\N	2026-09-16 18:22:58.532581+00
120	1	login	user	1	\N	2026-09-16 18:27:30.211504+00
121	1	login	user	1	\N	2026-09-16 18:33:20.286944+00
122	1	login	user	1	\N	2026-09-16 19:55:52.008994+00
123	1	update	property	18	ببب — بببببببب	2026-09-16 20:14:54.594968+00
124	1	update	deal	6	بازگشت از قطعی به در جریان	2026-09-16 20:18:50.570983+00
125	1	login	user	1	\N	2026-09-16 21:22:53.208099+00
126	1	login	user	1	\N	2026-09-17 07:44:28.344174+00
127	1	login	user	1	\N	2026-09-17 07:46:51.022963+00
128	1	create	property	19	قققققق — ققققققققق	2026-09-17 07:57:51.734862+00
129	1	upload_image	property	19	1 عکس اضافه شد	2026-09-17 07:58:01.622141+00
130	1	login	user	1	\N	2026-09-17 08:16:46.186904+00
131	1	login	user	1	\N	2026-09-17 08:58:33.336824+00
132	1	login	user	1	\N	2026-09-17 09:09:01.760923+00
133	1	login	user	1	\N	2026-09-17 09:22:59.841635+00
134	1	login	user	1	\N	2026-09-17 09:34:28.424707+00
135	1	login	user	1	\N	2026-09-17 15:03:44.309194+00
136	1	login	user	1	\N	2026-09-17 15:13:36.543913+00
137	1	login	user	1	\N	2026-09-17 16:45:10.327362+00
138	1	login	user	1	\N	2026-09-17 17:07:17.862441+00
139	1	login	user	1	\N	2026-09-17 18:08:32.698662+00
140	1	create	client_request	5	قققققق	2026-09-17 18:10:00.343597+00
141	1	create	follow_up	12	عععععععع	2026-09-17 18:10:43.465365+00
142	1	create	deal	7	معامله 55,555,555 تومان	2026-09-17 18:11:47.78589+00
143	1	create	deal_payment	5	پرداخت 333,333 تومان	2026-09-17 18:15:27.433764+00
144	1	login	user	1	\N	2026-09-18 15:00:55.675469+00
145	1	login	user	1	\N	2026-09-18 15:09:06.164+00
146	1	create	deal	8	معامله 4,444,444,444,444,444 تومان	2026-09-18 15:09:24.544194+00
147	1	finalize	deal	8	قطعی — پورسانت 1,955,555,555,555,555	2026-09-18 15:09:29.65947+00
148	1	create	client_request	6	ثثث	2026-09-18 15:13:40.689248+00
149	1	login	user	1	\N	2026-09-18 15:16:41.192271+00
150	1	create	deal	9	معامله 44,444,444,444,444,444 تومان	2026-09-18 15:19:09.242519+00
151	1	create	deal_payment	9	پرداخت 333 تومان	2026-09-18 15:19:51.64749+00
152	1	create	follow_up	13	333	2026-09-18 15:20:43.918032+00
153	1	create	follow_up	14	بببب	2026-09-18 15:20:55.680102+00
154	1	login	user	1	\N	2026-09-18 15:27:25.996489+00
155	5	login	user	5	\N	2026-09-18 15:29:10.568639+00
156	5	create	client_request	7	44444	2026-09-18 15:30:59.513582+00
157	5	login	user	5	\N	2026-09-18 15:52:25.084362+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.alembic_version (version_num) FROM stdin;
bb22cc33dd44
\.


--
-- Data for Name: bot_faq; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.bot_faq (id, question, answer) FROM stdin;
1	فایل جدید ثبت کنم چطور فایل اضافه	از تب «فهرست فایل‌ها» دکمهٔ «افزودن فایل جدید» را بزنید. وارد کردن «شهر» الزامی است؛ بقیهٔ فیلدها اختیاری‌اند. بعد از ذخیره، پنجرهٔ گالری عکس باز می‌شود تا عکس اضافه کنید. تاریخ‌ها شمسی هستند و می‌توانید با کیبورد فارسی تایپ کنید.
2	عکس فایل گالری تصویر آپلود	برای فایل ذخیره‌شده، فرم ویرایش را باز کنید و «گالری تصاویر» را بزنید. تا ۱۰ عکس در هر بار آپلود، هر عکس حداکثر ۸ مگابایت. عکس اول به‌صورت خودکار بندانگشتی کنار فایل در فهرست نمایش داده می‌شود.
3	قیمت هر متر محاسبه	در فرم فایل با نوع معاملهٔ «فروش»: بعد از وارد کردن قیمت و متراژ، «قیمت هر متر» به‌صورت خودکار محاسبه و نمایش داده می‌شود. در اکسل هم ستون قیمت_هر_متر را خالی بگذارید تا خودکار پر شود.
4	امکانات دلخواه استخر سند بالکن چیپ	در فرم فایل، کادر «امکانات دلخواه»: مورد را تایپ کنید و Enter بزنید — به‌شکل چیپ اضافه می‌شود و فعال است. برای حذف، چیپ را انتخاب و «حذف چیپ‌های انتخاب‌شده» را بزنید. آسانسور و پارکینگ جداگانه تیک دارند.
5	تکراری مشابه دو بار	قبل از ذخیره، اگر تلفن مالک یا شهر+آدرس مشابه فایل موجود باشد، هشدار «فایل‌های مشابه» می‌بینید با نام مشاورِ ثبت‌کننده. اگر واقعاً فایل جدید است (مثلاً همان مالک دو ملک دارد)، «Yes» بزنید تا ثبت شود. این هشدار مسدودکننده نیست.
6	غیرفعال حذف فایل آرشیو بازگردانی	فایل‌ها حذف قطعی ندارند! «غیرفعال کردن» یعنی رفتن به بایگانی. در تب «بایگانی» می‌توانید فایل‌های غیرفعال و فروخته‌شده را ببینید و با «بازگردانی» دوباره فعالشان کنید.
7	جستجو سرچ پیدا Ctrl	در فهرست فایل‌ها، کادر «جستجوی آزاد» بالای صفحه: با هر حرف، نتایج زنده آپدیت می‌شوند و متن پیدا شده رنگی هایلایت می‌شود. با Ctrl+F هم می‌توانید مستقیم به کادر بپرید. جست‌وجو در آدرس، توضیحات، نام و تلفن مالک انجام می‌شود.
8	معامله قولنامه ثبت پورسانت حسابداری	در تب «حسابداری پورسانت» (فقط مدیر): «ثبت معامله جدید» ← فایل ملکی + مشاور + مبلغ. درصد پورسانت اگر وارد نشود از درصد پیش‌فرض مشاور خوانده می‌شود. پورسانت فقط بعد از «قطعی‌کردن معامله» رسمی می‌شود.
9	قطعی نهایی بستن معامله	معامله را انتخاب کنید ← «قطعی‌کردن معامله» ← تأیید. فایل ملکی به بایگانی «فروخته‌شده» می‌رود و پورسانت به کارکرد مشاور اضافه می‌شود. معاملهٔ قطعی‌شده قابل ویرایش نیست؛ اگر اشتباه بود، «بازگشت به در جریان» بزنید، اصلاح کنید و دوباره قطعی کنید.
10	پرداخت رسید پول واریز تسویه	معامله را انتخاب کنید ← «پرداخت‌ها» ← «افزودن پرداخت»: مبلغ، تاریخ شمسی، توضیح، و عکس رسید (اختیاری). دو نوع داریم: «پرداخت به مشاور» (بدهی به او) و «دریافت از مشاور» (اگر بیشتر از حقش داده شده). رسید را بعداً هم می‌توانید با «افزودن/تعویض رسید» اضافه کنید.
11	مانده بدهی کارکرد مشاور چقدر	پایین صفحهٔ حسابداری، جدول «مانده پورسانت مشاوران»: کارکرد = مجموع پورسانت معامله‌های قطعی‌شده، پرداخت‌شده = خالص پرداخت‌ها، و مانده = کارکرد منهای پرداخت. خروجی PDF همین جدول هم موجود است.
12	درصد پورسانت تنظیم مشاور درصدش	مدیر: تب «مشاوران و مدیریت» ← کاربر را انتخاب ← «درصد پورسانت» ← برای هر نوع معامله (فروش/اجاره/پیش‌خرید/رهن) درصد جدا بدهید. مثلاً فروش ۴۵٪ و اجاره ۱۰٪. این درصد هنگام ثبت معامله به‌صورت پیش‌فرض پیشنهاد می‌شود ولی قابل تغییر است.
13	قرارداد تمام شود رو به اتمام پایان یادآوری فوری	تب «قراردادهای رو‌به‌اتمام» قراردادهای زیر ۳۰ روز تا پایان را نشان می‌دهد (فوری‌ها زیر ۷ روز با رنگ هشدار). دابل‌کلیک روی هر ردیف = باز شدن فایل برای تماس/تمدید. بعد از ورود به برنامه هم اگر قرارداد فوری داشته باشید، هشدار خودکار می‌بینید.
14	پیگیری روزمره کار یادآوری وظیفه	تب «پیگیری روزمره»: کارهای روزانه‌تان با تاریخ شمسی و ساعت. «پیگیری جدید» بزنید: عنوان، سررسید، ساعت (اختیاری)، و فایل مرتبط. با هر باز شدن برنامه، کارهای امروز و عقب‌افتاده به‌صورت اطلاع‌یه هم می‌آیند. کار تمام‌شده را «✔ انجام شد» بزنید.
15	رمز فراموش کردم ریست پسورد عبور	از مدیر بخواهید: «مشاوران و مدیریت» ← انتخاب حساب شما ← «ریست رمز عبور» ← رمز جدید را به شما می‌گوید. بعد از ریست، باید دوباره وارد شوید.
16	قفل حساب اشتباه تلاش سه بار	اگر ۳ بار رمز اشتباه بزنید، حساب ۲ دقیقه قفل می‌شود و پیام زمان باقی‌مانده می‌بینید. بعد از آن دوباره تلاش کنید. حساب مدیر محدودیتی ندارد.
17	مشاور جدید کاربر حساب بساز	فقط مدیر: تب «مشاوران و مدیریت» ← «افزودن حساب جدید» ← نام کاربری (انگلیسی، بدون فاصله)، نام کامل، رمز اولیه، و تلفن (برای یادآوری پیامکی، اختیاری).
18	درخواست مشتری مشتری دنبال تطبیق منطبق	تب «درخواست مشتری‌ها»: مشتری‌ای که دنبال ملک است را ثبت کنید (نوع معامله، شهر، متراژ، بودجه). بعد دکمهٔ «فایل‌های منطبق» به‌صورت خودکار فایل‌های فعالِ منطبق با شرایطش را نشان می‌دهد. مشاور فقط درخواست‌ها و فایل‌های خودش را می‌بیند؛ مدیر همه را.
19	گزارش خروجی pdf اکسل چاپ	دکمه‌های «خروجی PDF» و «خروجی اکسل» در تب فایل‌ها دقیقاً همان فیلترهای فعلی شما را خروجی می‌دهند. برای قرارداد رسمی: در حسابداری، «چاپ قولنامه رسمی PDF» — متن قرارداد از فایل contract_template.txt خوانده می‌شود که مدیر می‌تواند ویرایشش کند.
21	فیلتر آماده چیپ سایر پیشنهاد	بالای فهرست فایل‌ها، چیپ‌های آماده (فروش، اجاره، متراژ ۱۰۰+ و…). با «سایر +» می‌توانید فیلتر دلخواه بسازید: مدیر مستقیم اضافه می‌کند؛ مشاور پیشنهاد می‌دهد و بعد از تأیید مدیر برای همه نمایش داده می‌شود. حذف چیپ هم با تأیید مدیر است.
22	انقضا فایل قدیمی منقضی	مدیر با «اسکن فایل‌های قدیمی» (در بایگانی) فایل‌های فعالِ قدیمی را پیدا می‌کند؛ به مالکِ هر فایل اطلاع‌یه می‌رود تا خودش تصمیم بگیرد: «تأیید انقضا» (به بایگانی می‌رود) یا «فایل را نگه دار» (۹۰ روز دیگر دوباره پرسیده می‌شود).
23	سلام درود وقت بخیر	سلام! 👋 خوش آمدید. دربارهٔ ملک‌یار هر سؤالی دارید بپرسید — مثلاً بنویسید «فایل جدید» یا «پورسانت» یا «قرارداد». اگر همکاری نیاز به تماس داشت، از لیست مخاطبان انتخابش کنید.
24	ممنوع تشکر مرسی ممنونم عالی	خواهش می‌کنم! 🌷 خوشحالم که کمک کرد. سؤال دیگری بود در خدمتم.
20	چت پیام گفتگو همکار همکارم	همین تب «گفت‌وگو»: از لیست «مخاطبان» همکار را انتخاب کنید و پیام بدهید — همه می‌توانند به همه پیام بدهند. پیام جدید در زنگ اطلاع‌یه‌ها 🔔 بالا-سمت شمارش می‌شود. برای سؤالات متداول، مخاطب «🤖 چت‌بات» را انتخاب کنید.
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.chat_messages (id, sender_id, receiver_id, body, is_read, created_at) FROM stdin;
1	1	4	صصصصص	f	2026-09-13 12:20:30.088201+00
2	1	5	صصصص	t	2026-09-13 12:20:37.17674+00
3	5	1	ضضض	t	2026-09-13 12:21:15.638895+00
4	1	2	یبر	f	2026-09-17 08:18:23.179593+00
5	1	2	یبز	f	2026-09-17 08:24:44.047808+00
6	1	2	اااااا	f	2026-09-17 09:09:20.266018+00
7	1	3	ااااااا	f	2026-09-17 09:09:25.191179+00
10	1	2	صصصصصصص	f	2026-09-17 09:34:54.287525+00
11	1	3	ییی4	f	2026-09-17 09:35:04.147171+00
12	1	3	خخح	f	2026-09-17 09:35:05.53573+00
13	1	4	۶۶۶۶۶۶۶۶	f	2026-09-17 18:11:04.885078+00
14	1	4	۶۶۶۶۶۶	f	2026-09-17 18:11:07.074526+00
8	1	5	ااااااا	t	2026-09-17 09:09:30.592814+00
9	1	5	صصصص	t	2026-09-17 09:34:48.994633+00
15	5	2	فففففف	f	2026-09-18 15:31:29.613542+00
\.


--
-- Data for Name: client_requests; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.client_requests (id, owner_agent_id, customer_name, customer_phone, deal_type, city, district, min_area, max_area, min_rooms, max_price, notes, status, created_at) FROM stdin;
1	1	ض	ض	sale	ض	ض	3	33	\N	4444444	لللللل	open	2026-09-09 17:31:02.878147+00
3	5	ققق	\N	sale	\N	\N	22	222	\N	\N	\N	open	2026-09-11 14:19:38.484827+00
4	1	gggggggggggggggggggggggggggggggg	\N	sale	\N	\N	\N	\N	\N	\N	\N	open	2026-09-15 15:33:18.530758+00
5	1	قققققق	2222222222	sale	ققققق	\N	\N	\N	\N	\N	\N	open	2026-09-17 18:10:00.320278+00
6	1	ثثث	3333333333	sale	ثثثثثث	\N	\N	\N	\N	\N	\N	open	2026-09-18 15:13:40.672361+00
7	5	44444	4444444444	sale	\N	\N	\N	\N	\N	\N	\N	open	2026-09-18 15:30:59.501123+00
\.


--
-- Data for Name: commission_payments; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.commission_payments (id, deal_id, amount, paid_date, note, receipt_path, created_at, kind) FROM stdin;
1	2	22222222	\N	ببببببب	media/receipts/399ebb6afe854398a1b8d356fc9d7467.png	2026-09-08 17:03:45.58695+00	to_agent
2	2	222	2026-08-31	ثثثثثث	\N	2026-09-11 12:21:30.34342+00	from_agent
3	6	2222	\N	\N	\N	2026-09-11 14:00:38.71234+00	to_agent
4	6	22	\N	\N	media/receipts/f5c98d1c206e47dab8f599b6c8aaad52.png	2026-09-11 14:00:45.210033+00	from_agent
5	5	333333	\N	\N	\N	2026-09-17 18:15:27.419613+00	to_agent
6	9	333	\N	\N	\N	2026-09-18 15:19:51.633931+00	to_agent
\.


--
-- Data for Name: deals; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.deals (id, property_id, agent_id, deal_amount, commission_percent, commission_amount, status, contract_date, finalized_at, notes, created_at, updated_at, agent2_id, commission_percent_agent2) FROM stdin;
1	11	2	22222222	42	9333333	finalized	\N	2026-09-09 17:20:17.113804+00	ببببب	2026-09-08 17:01:18.50864+00	2026-09-09 17:20:17.115074+00	\N	\N
3	4	5	22222222	33	7333333	pending	2026-07-22	\N	ثثث	2026-09-11 12:19:52.972371+00	2026-09-11 12:19:52.972375+00	\N	\N
5	1	5	3333333	42	1400000	pending	\N	\N	aaaa	2026-09-11 12:40:08.725397+00	2026-09-11 12:40:08.725401+00	\N	\N
4	1	1	333333333	100	333333333	finalized	\N	2026-09-11 12:41:23.679833+00	aaaaaa	2026-09-11 12:39:52.554676+00	2026-09-11 12:41:23.682011+00	\N	\N
2	10	3	444445555	33	146667033	finalized	2026-09-09	2026-09-09 17:20:13.904227+00	بببببصص	2026-09-08 17:03:15.126601+00	2026-09-11 12:42:34.7787+00	\N	\N
6	4	5	22222222	22	4888889	canceled	2025-09-11	\N	\N	2026-09-11 13:58:18.307113+00	2026-09-16 20:27:07.336628+00	\N	\N
7	19	5	55555555	33	18333333	pending	2026-09-20	\N	\N	2026-09-17 18:11:47.750293+00	2026-09-17 18:11:47.750297+00	\N	\N
8	19	5	4444444444444444	44	1955555555555555	finalized	\N	2026-09-18 15:09:29.539633+00	\N	2026-09-18 15:09:24.533899+00	2026-09-18 15:09:29.541302+00	\N	\N
9	18	5	44444444444444444	44	19555555555555555	pending	\N	\N	\N	2026-09-18 15:19:09.23231+00	2026-09-18 15:19:09.232317+00	\N	\N
\.


--
-- Data for Name: discovery_listings; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.discovery_listings (id, source, external_id, title, raw_address, price, deal_type, neighborhood_id, url, posted_at, fetched_at, converted_property_id, converted_by_user_id, converted_at, city, area_m2, rooms, deposit, monthly_rent, attributes, dismissed_at) FROM stdin;
1	divar	ga3eaaeq	400ویلایی دهانه 15 جنوبی ملکی	شریف	85000000000	sale	\N	https://divar.ir/v/_/ga3eaaeq	2026-09-26 11:15:07.272298+00	2026-09-27 14:19:03.027582+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2	divar	ga6tx4SK	یک واحد ۹۰ متری طبقه همکف راه جدا قولنامه ای تمیز	سمزقند	5200000000	sale	\N	https://divar.ir/v/_/ga6tx4SK	2026-09-27 14:18:58.063365+00	2026-09-27 14:19:03.034122+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3	divar	ga3Sl6HO	فروش آپارتمان ۱۵۲ متری خوش‌نقشه / قبل از معلم	فرهنگ	24000000000	sale	\N	https://divar.ir/v/_/ga3Sl6HO	2026-09-27 14:18:57.214308+00	2026-09-27 14:19:03.036429+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4	divar	gaA-hq4W	هاشمیه ۴۱/دوخواب/صدمتر/فول امکانات/شیک	هنرستان	14200000000	sale	11	https://divar.ir/v/_/gaA-hq4W	2026-09-27 14:18:50.936868+00	2026-09-27 14:19:03.03852+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5	divar	gaiKXW8O	آپارتمان فروشی طبقه دوم ۷۰ متری کاغذ دیواری	حضرت حجت	2150000000	sale	\N	https://divar.ir/v/_/gaiKXW8O	2026-09-27 14:18:15.916274+00	2026-09-27 14:19:03.040832+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6	divar	ga5WSLXH	گلشن  ۲۰۵ متر   باشگاه  روف  لابی  بیزینس روم  صفر	هنرستان	65600000000	sale	11	https://divar.ir/v/_/ga5WSLXH	2026-09-27 14:16:26.688783+00	2026-09-27 14:19:03.042804+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7	divar	gau6VxDA	حاشیه فکوری/طبقه پنجم/۸۰ متر	هفت تیر (آب و برق)	9200000000	sale	\N	https://divar.ir/v/_/gau6VxDA	2026-09-27 14:16:24.471276+00	2026-09-27 14:19:03.045013+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8	divar	gayW6iSd	105متر / سندملکی / دونبش / کارمندان دوم	کارمندان دوم	12400000000	sale	\N	https://divar.ir/v/_/gayW6iSd	2026-09-27 14:16:18.903043+00	2026-09-27 14:19:03.046897+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9	divar	ga5WyGJi	اپارتمان ۱۷۰ متر/ تک واحدی	رضاشهر	26000000000	sale	\N	https://divar.ir/v/_/ga5WyGJi	2026-09-27 14:16:07.107644+00	2026-09-27 14:19:03.048503+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10	divar	gabO8eYP	90متر دو خواب سعادت زوج طبقه دوم شیک	شهرک امام هادی (شهرک غرب)	4700000000	sale	38	https://divar.ir/v/_/gabO8eYP	2026-09-27 14:29:10.200438+00	2026-09-27 14:29:19.756583+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11	divar	ga5ey74z	آپارتمان هم کف کریمی ۳۰	عامل	2150000000	sale	\N	https://divar.ir/v/_/ga5ey74z	2026-09-27 14:29:09.93224+00	2026-09-27 14:29:19.770226+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12	divar	gaWmX3wT	اپارتمان ۴۵ متری / همکف/سپاه ۴۴	کوی المهدی	1800000000	sale	\N	https://divar.ir/v/_/gaWmX3wT	2026-09-27 14:29:05.248753+00	2026-09-27 14:29:19.779265+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13	divar	ga5iyBPh	آپارتمان۸۰متری مطهری۱۶سردونبش حسین زاده۱۸طبقه۳ملکی	شهید مطهری	7000000000	sale	28	https://divar.ir/v/_/ga5iyBPh	2026-09-27 14:28:35.004205+00	2026-09-27 14:29:19.786466+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14	divar	ga3SI6Pm	آپارتمان 100متری محمدیه 5 فوری	جاهد شهر	11400000000	sale	41	https://divar.ir/v/_/ga3SI6Pm	2026-09-27 14:28:30.235604+00	2026-09-27 14:29:19.792152+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15	divar	ga5eC4p_	۲۸۰ متر / لوکیشن خاص و تکرار نشدنی ویو ابدی / سجاد	سجاد شهر	78000000000	sale	21	https://divar.ir/v/_/ga5eC4p_	2026-09-27 14:28:14.32095+00	2026-09-27 14:29:19.799446+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16	divar	gaRSLGHd	فروش فوری منزل ویلایی	هفده شهریور	22500000000	sale	\N	https://divar.ir/v/_/gaRSLGHd	2026-09-27 14:28:06.81649+00	2026-09-27 14:29:19.805405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
17	divar	gahu5H6q	۲۰۳ متر / کوثر ۱ / بهترین لوکیشن منطقه / بسیار شیک	کوثر	40000000000	sale	13	https://divar.ir/v/_/gahu5H6q	2026-09-27 14:28:01.992589+00	2026-09-27 14:29:19.811203+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
18	divar	ga5eikau	خانه آپارتمانی طبقه پایین ۵۵ متری	همت آباد	985000000	sale	\N	https://divar.ir/v/_/ga5eikau	2026-09-27 14:27:55.303014+00	2026-09-27 14:29:19.816004+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
19	divar	gax6Qa_R	۱۵۰متر/ رضا /عرض استثنایی ۱۲	احمدآباد	32500000000	sale	\N	https://divar.ir/v/_/gax6Qa_R	2026-09-27 14:27:44.426628+00	2026-09-27 14:29:19.821264+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
20	divar	ga4mbZbc	باهنر/فول/ بازسازی لاکچری/۱۵۵متر	کوثر	29000000000	sale	13	https://divar.ir/v/_/ga4mbZbc	2026-09-27 14:27:27.750646+00	2026-09-27 14:29:19.826582+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
21	divar	ga3O_xTR	120متر،سه خواب،رحمانیه،اکازیون	جاهد شهر	13190000000	sale	41	https://divar.ir/v/_/ga3O_xTR	2026-09-26 19:47:44.344725+00	2026-09-27 14:39:43.976874+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
22	divar	gare8nE0	65 متری یک خواب	تلگرد	3300000000	sale	\N	https://divar.ir/v/_/gare8nE0	2026-09-27 14:39:39.272812+00	2026-09-27 14:39:43.984239+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
23	divar	ga5qyn4h	90متر/دوخواب/تک واحدی/حاشیه12متری/هدایت	شفا	5400000000	sale	\N	https://divar.ir/v/_/ga5qyn4h	2026-09-27 14:39:35.613783+00	2026-09-27 14:39:43.988272+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
24	divar	ga5qSk6-	فوری و خوش قیمت زیر فی منطقه قدس فلسطین	فلسطین	23000000000	sale	19	https://divar.ir/v/_/ga5qSk6-	2026-09-27 14:39:27.988826+00	2026-09-27 14:39:43.99178+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
25	divar	ga5qSVj0	آپارتمان ۱۱۰ متری فروشی معاوضه میکنم	حضرت حجت	7200000000	sale	\N	https://divar.ir/v/_/ga5qSVj0	2026-09-27 14:38:46.483554+00	2026-09-27 14:39:43.995398+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
26	divar	gauKaJWM	۸۰ متـر فــول بدون مشرفـ ویو دار  سنـد۶دانگ  فلاحی	فرهنگیان (شهرک غرب)	8950000000	sale	37	https://divar.ir/v/_/gauKaJWM	2026-09-27 14:37:24.840022+00	2026-09-27 14:39:43.99833+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
27	divar	gaLKwFmF	فروش نقدی یا معاوضه یکجا ۶ واحد تفکیکی * جلال	آزادشهر	221000000000	sale	\N	https://divar.ir/v/_/gaLKwFmF	2026-09-27 14:37:16.143962+00	2026-09-27 14:39:44.001539+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
28	divar	ga5mS1Mj	105 متر اوایل اقبال لاهوری نزدیک وکیل آباد	اقبال	13950000000	sale	1	https://divar.ir/v/_/ga5mS1Mj	2026-09-27 14:37:06.282153+00	2026-09-27 14:39:44.003849+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
29	divar	ga5myvpo	زمین ویلایی فول امتیاز سند ملکی	سازمان آب	8000000000	sale	\N	https://divar.ir/v/_/ga5myvpo	2026-09-27 14:36:24.848786+00	2026-09-27 14:39:44.006056+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
30	divar	gavqY5NU	مجموعه 4 واحدی 150 متری خیابان امام خمینی	امام خمینی	80000000000	sale	\N	https://divar.ir/v/_/gavqY5NU	2026-09-20 07:27:47.440044+00	2026-09-27 14:49:50.756622+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
31	divar	ga42L2TK	۱۲۰متر  دونبش دوطرف‌‌خیابان۲۰متری ۲ماه تحویل	جانباز	7590000000	sale	\N	https://divar.ir/v/_/ga42L2TK	2026-09-27 14:49:43.546401+00	2026-09-27 14:49:50.768498+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
32	divar	ga5yy1mR	۳خواب فول صفرتکواحدی	رضاشهر	21700000000	sale	\N	https://divar.ir/v/_/ga5yy1mR	2026-09-27 14:49:32.033619+00	2026-09-27 14:49:50.772799+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
33	divar	ga5OSd4L	۱۵۰متر ۲پارکینگ‌اختصاصی. کوچه۲۰متری فول	جانباز	14250000000	sale	\N	https://divar.ir/v/_/ga5OSd4L	2026-09-27 14:49:26.342619+00	2026-09-27 14:49:50.776421+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
34	divar	ga5yC4j-	آپارتمان۱۳۵متر۳خواب مطهری۷منوچهری۱۷با۵۰مترتراس فول	سعد آباد	15000000000	sale	\N	https://divar.ir/v/_/ga5yC4j-	2026-09-27 14:49:19.620364+00	2026-09-27 14:49:50.778499+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
35	divar	ga5yiaej	فروش	علی آباد	2400000000	sale	\N	https://divar.ir/v/_/ga5yiaej	2026-09-27 14:49:13.747102+00	2026-09-27 14:49:50.780452+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
36	divar	ga5yS2Id	104 متر اقبال قبل از پیروزی شخصی ساز	کوثر	13900000000	sale	13	https://divar.ir/v/_/ga5yS2Id	2026-09-27 14:49:07.385136+00	2026-09-27 14:49:50.78214+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
37	divar	ga5yS1i5	۱۶۰مترشمالی،پشت وکیل اباد،سرمایه گذاری،دانش آموزیک	دانشجو	25800000000	sale	39	https://divar.ir/v/_/ga5yS1i5	2026-09-27 14:49:05.621442+00	2026-09-27 14:49:50.78408+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
38	divar	ga5yiSrO	زمین ویلای جاده کلات منطقه سرسبز اندروخ	گاز	300000000	sale	\N	https://divar.ir/v/_/ga5yiSrO	2026-09-27 14:48:20.643023+00	2026-09-27 14:49:50.785786+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
39	divar	gaeS1vvp	اپارتمان الهیه  ۱۰۰ متری	جاهد شهر	12000000000	sale	41	https://divar.ir/v/_/gaeS1vvp	2026-09-27 14:47:57.633166+00	2026-09-27 14:49:50.787393+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
40	divar	ga5yiPUc	300 متر زمین با 140 متر زیربنا سفتکاری	میان ولایت	5980000000	sale	\N	https://divar.ir/v/_/ga5yiPUc	2026-09-27 14:47:18.248731+00	2026-09-27 14:49:50.78901+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
41	divar	gapyxLm3	منزل ویلایی شاهنامه ۶۹ملاصدرا	توس فردوسی	2900000000	sale	\N	https://divar.ir/v/_/gapyxLm3	2026-09-15 10:25:35.869784+00	2026-09-27 15:00:02.1632+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
42	divar	QaL66MAU	باغ زمین ۵۶۰ متری درمجموعه ویلایی بانگهبانی۲۴ساعته	جانباز	180000000	sale	\N	https://divar.ir/v/_/QaL66MAU	2026-09-27 14:59:39.703303+00	2026-09-27 15:00:02.171079+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
43	divar	gaTWrqgj	آپارتمان 135 متری 3خوابه امام رضا5 شمس	دانش	26400000000	sale	\N	https://divar.ir/v/_/gaTWrqgj	2026-09-27 14:59:15.349068+00	2026-09-27 15:00:02.174711+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
44	divar	ga5-yC25	آپارتمان250متری 160متربنافوق لوکس توس97	صیدآباد	5000000000	sale	\N	https://divar.ir/v/_/ga5-yC25	2026-09-27 14:59:11.881787+00	2026-09-27 15:00:02.179738+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
45	divar	ga59aWb8	خانه و مغازه ۲۳۰ متری روستای بهارستان کورده سابق	میان ولایت	10000000000	sale	\N	https://divar.ir/v/_/ga59aWb8	2026-09-27 14:59:03.184532+00	2026-09-27 15:00:02.183782+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
46	divar	gazGJ7yD	زمین دو نبش/ تجاری دار/حاشیه/ساختمان پزشکان	ده دی	75000000000	sale	\N	https://divar.ir/v/_/gazGJ7yD	2026-09-27 14:58:52.21937+00	2026-09-27 15:00:02.18722+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
47	divar	ga75Vx6J	خانه ویلایی 100 متری دوبلکس گلبو	شهید آوینی	4000000000	sale	\N	https://divar.ir/v/_/ga75Vx6J	2026-09-27 14:58:30.057936+00	2026-09-27 15:00:02.19125+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
48	divar	ga56CUiq	آپارتمان ۹۳ متری بهورز	فرهنگیان (شهرک غرب)	9700000000	sale	37	https://divar.ir/v/_/ga56CUiq	2026-09-27 14:58:28.787121+00	2026-09-27 15:00:02.197681+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
49	divar	ga4y8E_2	ویلایی چهارصد متری جنوبی عرض 15فی 87	شریف	87000000000	sale	\N	https://divar.ir/v/_/ga4y8E_2	2026-09-27 07:59:18.490116+00	2026-09-27 15:20:41.017677+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
50	divar	ga5ODfCN	ویلایی(زمین)انتهای هاشمیه بامجوز	نیروی هوایی	23800000000	sale	\N	https://divar.ir/v/_/ga5ODfCN	2026-09-27 15:20:17.33991+00	2026-09-27 15:20:41.025829+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
51	divar	ga5Ozank	اپارتمان	هنرستان	21000000000	sale	11	https://divar.ir/v/_/ga5Ozank	2026-09-27 15:20:11.783624+00	2026-09-27 15:20:41.029677+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
52	divar	ga5SDGnC	وکیل آباد / مجتمع پردیس / فول امکانات / ۷۵ متر	پردیس	7850000000	sale	\N	https://divar.ir/v/_/ga5SDGnC	2026-09-27 15:20:03.780394+00	2026-09-27 15:20:41.035173+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
53	divar	ga5ODzFN	۱۱۵ متر فول منزل آباد حاشیه صاحب الزمان	منزل آباد	5000000000	sale	\N	https://divar.ir/v/_/ga5ODzFN	2026-09-27 15:19:47.44937+00	2026-09-27 15:20:41.039476+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
54	divar	ga5OzwGw	۹۰متر پیامبر۱۳ حمامی امام هادی	شهرک امام هادی (شهرک غرب)	3600000000	sale	38	https://divar.ir/v/_/ga5OzwGw	2026-09-27 15:19:30.844738+00	2026-09-27 15:20:41.043754+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
55	divar	gagGAbQX	زمین فروشی شاهنامه 80	توس فردوسی	1469000000	sale	\N	https://divar.ir/v/_/gagGAbQX	2026-09-27 15:19:24.490233+00	2026-09-27 15:20:41.048237+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
56	divar	gar-ILDB	هتل 6000 متری/35واحد/سند آستان	امام رضا (ع)	380000000000	sale	\N	https://divar.ir/v/_/gar-ILDB	2026-09-17 06:56:53.739966+00	2026-09-27 15:30:48.464294+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
57	divar	gaKlhjno	فروش آپارتمان ۲۳۵ متری صفر ۱۴۰۵	فرهنگ	46000000000	sale	\N	https://divar.ir/v/_/gaKlhjno	2026-09-27 15:30:18.936942+00	2026-09-27 15:30:48.476615+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
58	divar	gax-TGQs	باغ تکمیل  نوساز	درزآب	3290000000	sale	\N	https://divar.ir/v/_/gax-TGQs	2026-09-27 15:28:03.281117+00	2026-09-27 15:30:48.479613+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
59	divar	ga5WT8ID	۱۸۰ متر/الهیه/تک واحدی/فستیوال نور/فول مدرن	الهیه	19800000000	sale	44	https://divar.ir/v/_/ga5WT8ID	2026-09-27 15:27:59.754764+00	2026-09-27 15:30:48.48171+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
60	divar	ga3eTB3q	فروش آپارتمان ۱۲۰متری ۲خوابه	توس (بلوار توس)	5420000000	sale	\N	https://divar.ir/v/_/ga3eTB3q	2026-09-27 15:27:39.783279+00	2026-09-27 15:30:48.483599+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
61	divar	gavmqjKl	فروش اپارتمان آزادشهر	آزادشهر	23000000000	sale	\N	https://divar.ir/v/_/gavmqjKl	2026-09-27 15:26:41.310831+00	2026-09-27 15:30:48.485432+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
62	divar	gad-TLjw	خانه فروشی	دانشجو	9900000000	sale	39	https://divar.ir/v/_/gad-TLjw	2026-09-26 15:38:00.963525+00	2026-09-27 15:40:56.091553+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
63	divar	gaqOGw4d	فروش اپارتمان ۱۲۰متری معلم ۶۵ کم واحد	تربیت (صدف)	12500000000	sale	\N	https://divar.ir/v/_/gaqOGw4d	2026-09-19 03:52:57.859826+00	2026-09-27 15:40:56.097377+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
64	divar	ga5iT4Kd	آپارتمان ۱۲۵متر تک واحدی در صدف قبل معلم بازسازی	شریف	12000000000	sale	\N	https://divar.ir/v/_/ga5iT4Kd	2026-09-27 15:40:46.1391+00	2026-09-27 15:40:56.101358+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
65	divar	ga5aT3w0	خانه پیش فروش منزل آباد	منزل آباد	3750000000	sale	\N	https://divar.ir/v/_/ga5aT3w0	2026-09-27 15:39:30.123921+00	2026-09-27 15:40:56.104754+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
66	divar	ga5izY56	اپارتمان فروشی ۸۵ متری پارکینگ آسانسور هدایت	شفا	5770000000	sale	\N	https://divar.ir/v/_/ga5izY56	2026-09-27 15:39:14.571195+00	2026-09-27 15:40:56.107798+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
67	divar	gaqSXfaO	اپارتمان 50 متری	نوده	1170000000	sale	\N	https://divar.ir/v/_/gaqSXfaO	2026-09-27 15:39:01.259108+00	2026-09-27 15:40:56.111352+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
68	divar	ga5iDZBh	اپارتمان 85متری  نوساز	نوده	2050000000	sale	\N	https://divar.ir/v/_/ga5iDZBh	2026-09-27 15:38:30.254207+00	2026-09-27 15:40:56.115576+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
69	divar	ga0WztMw	اتفاقی نادر ۹۰ متری تک واحدی صفر	الهیه	9680000000	sale	44	https://divar.ir/v/_/ga0WztMw	2026-09-27 15:38:16.355352+00	2026-09-27 15:40:56.119997+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
70	divar	ga3ubssI	باغ 500 متری بنا دار	تبادکان	1300000000	sale	\N	https://divar.ir/v/_/ga3ubssI	2026-09-27 15:38:01.89222+00	2026-09-27 15:40:56.123643+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
71	divar	gaAyi8O-	291 متر ویلایی طبرسی جنوبی رسالت	طلاب	28500000000	sale	\N	https://divar.ir/v/_/gaAyi8O-	2026-09-27 15:37:57.717485+00	2026-09-27 15:40:56.127276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
72	divar	gan-Z4AV	زمین ۲۹۰ متر /شمالی مجوز ۶سقف /زیرفی و خوش‌قواره	امیریه	24650000000	sale	\N	https://divar.ir/v/_/gan-Z4AV	2026-09-19 07:01:12.860059+00	2026-09-27 15:57:59.294395+00	\N	\N	\N	mashhad	290	\N	\N	\N	{"mid": "۲۴,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن صبوری در امیریه", "amounts": {"raw_amount": 24650000000}}	\N
73	divar	ga5yjjfD	نوید دوبلکس	نوید	4200000000	sale	\N	https://divar.ir/v/_/ga5yjjfD	2026-09-27 15:57:52.814559+00	2026-09-27 15:57:59.305928+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در نوید", "amounts": {"raw_amount": 4200000000}}	\N
74	divar	ga5yzILO	۶۵ متر نبش قائم مقام ۴۴	تربیت (صدف)	6800000000	sale	\N	https://divar.ir/v/_/ga5yzILO	2026-09-27 15:57:47.755028+00	2026-09-27 15:57:59.309641+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۶,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در تربیت (صدف)", "amounts": {"raw_amount": 6800000000}}	\N
75	divar	ga5yz7dB	زمین های فاز2الهیه	جاهد شهر	750000000	sale	41	https://divar.ir/v/_/ga5yz7dB	2026-09-27 15:57:46.692706+00	2026-09-27 15:57:59.313418+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 750000000}}	\N
76	divar	ga5yD7ol	آپارتمان180متری/3خواب/ابتدای کوثر	کوثر	34000000000	sale	13	https://divar.ir/v/_/ga5yD7ol	2026-09-27 15:57:41.590342+00	2026-09-27 15:57:59.319111+00	\N	\N	\N	mashhad	180	3	\N	\N	{"mid": "۳۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوثر", "amounts": {"raw_amount": 34000000000}}	\N
77	divar	ga5yD5Tx	یه خونه شیک در رسالت ۱۲۶	همت آباد	1080000000	sale	\N	https://divar.ir/v/_/ga5yD5Tx	2026-09-27 15:57:38.162013+00	2026-09-27 15:57:59.323166+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۰۸۰,۰۰۰,۰۰۰ تومان", "bottom": "در همت آباد", "amounts": {"raw_amount": 1080000000}}	\N
78	divar	ga4aO3CR	کوثر آپارتمان ۱۵۶ متر	چهارچشمه	22000000000	sale	\N	https://divar.ir/v/_/ga4aO3CR	2026-09-27 15:57:35.773582+00	2026-09-27 15:57:59.326715+00	\N	\N	\N	mashhad	156	\N	\N	\N	{"mid": "۲۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در چهارچشمه", "amounts": {"raw_amount": 22000000000}}	\N
79	divar	ga5yjy2q	۹۶ متر / ۲ خواب / کلا ۶ واحد / منجم	الهیه	10500000000	sale	44	https://divar.ir/v/_/ga5yjy2q	2026-09-27 15:57:09.411871+00	2026-09-27 15:57:59.330836+00	\N	\N	\N	mashhad	96	2	\N	\N	{"mid": "۱۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن آراد در الهیه", "amounts": {"raw_amount": 10500000000}}	\N
80	divar	ga5yji4j	خونه ویلایی تک برگ سند فروش فوری	فریزی	3561000000	sale	\N	https://divar.ir/v/_/ga5yji4j	2026-09-27 15:56:56.580809+00	2026-09-27 15:57:59.334205+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۵۶۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فریزی", "amounts": {"raw_amount": 3561000000}}	\N
81	divar	ga1OlJV0	خانه ویلای شیک سند دار داخل بافت ،ماریان	درزآب	3300000000	sale	\N	https://divar.ir/v/_/ga1OlJV0	2026-09-27 15:55:58.510067+00	2026-09-27 15:57:59.349632+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 3300000000}}	\N
82	divar	gaSap9ny	۳خواب، تک واحدی، ابتدای قائم، صفر	کوی المهدی	11800000000	sale	\N	https://divar.ir/v/_/gaSap9ny	2026-09-27 15:55:39.90476+00	2026-09-27 15:57:59.352966+00	\N	\N	\N	mashhad	\N	3	\N	\N	{"mid": "۱۱,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوی المهدی", "amounts": {"raw_amount": 11800000000}}	\N
83	divar	ga5yDUxG	110متری/سندآماده/شیک/8واحدی/الهیه	جاهد شهر	9500000000	sale	41	https://divar.ir/v/_/ga5yDUxG	2026-09-27 15:55:12.648733+00	2026-09-27 15:57:59.356079+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن میرشکاری در جاهد شهر", "amounts": {"raw_amount": 9500000000}}	\N
84	divar	ga4113dW	۶۰۰مترباغ کناربافت سند ۶دانگ	درزآب	950000000	sale	\N	https://divar.ir/v/_/ga4113dW	2026-09-27 15:54:48.805634+00	2026-09-27 15:57:59.369454+00	\N	\N	\N	mashhad	600	\N	\N	\N	{"mid": "۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 950000000}}	\N
85	divar	ga5uTXEy	ویلایی جنوبی ، نشیمن ، هم برای ساخت	هدایت	22000000000	sale	26	https://divar.ir/v/_/ga5uTXEy	2026-09-27 15:54:22.195289+00	2026-09-27 15:57:59.373919+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هدایت", "amounts": {"raw_amount": 22000000000}}	\N
86	divar	ga5yDBcW	۸۳ متر کم واحد چهارراه صیاد	هفت تیر (آب و برق)	9200000000	sale	\N	https://divar.ir/v/_/ga5yDBcW	2026-09-27 15:53:57.306624+00	2026-09-27 15:57:59.38161+00	\N	\N	\N	mashhad	83	\N	\N	\N	{"mid": "۹,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (آب و برق)", "amounts": {"raw_amount": 9200000000}}	\N
87	divar	ga5yj0wE	اجاره آپارتمان 135 متری نوساز در شریعتی 58/14	حسابی جنوبی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga5yj0wE	2026-09-27 15:57:14.405215+00	2026-09-27 15:57:59.386103+00	\N	\N	\N	mashhad	135	\N	\N	\N	{"mid": "رهن کامل", "bottom": "لحظاتی پیش در حسابی جنوبی (شهرک غرب)", "amounts": {}}	\N
88	divar	ga5yjbB8	رهن کامل و رهن واجاره مجیدیه	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga5yjbB8	2026-09-27 15:56:22.20208+00	2026-09-27 15:57:59.389411+00	\N	\N	\N	mashhad	\N	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"اجاره": 20000000}}	\N
89	divar	ga5yTnoY	آپارتمان رهن و اجاره ۱۲۵ متری	چهنو	\N	rent	\N	https://divar.ir/v/_/ga5yTnoY	2026-09-27 15:56:22.179193+00	2026-09-27 15:57:59.392345+00	\N	\N	\N	mashhad	125	\N	\N	22000000	{"mid": "اجاره: ۲۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهنو", "amounts": {"اجاره": 22000000}}	\N
90	divar	ga5OShqX	دربست ویلایی	طلاب	\N	rent	\N	https://divar.ir/v/_/ga5OShqX	2026-09-27 15:56:08.184872+00	2026-09-27 15:57:59.39731+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طلاب", "amounts": {"اجاره": 15000000}}	\N
91	divar	ga5yjXi5	ویلایی* ۵۰۰ متر* فول بازسازی	سجاد شهر	\N	rent	21	https://divar.ir/v/_/ga5yjXi5	2026-09-27 15:56:02.381605+00	2026-09-27 15:57:59.402095+00	\N	\N	\N	mashhad	500	\N	\N	300000000	{"mid": "اجاره: ۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سجاد شهر", "amounts": {"اجاره": 300000000}}	\N
92	divar	ga5WCBf8	۱۸۵متر/معاد/DREAM HOME/لابی مجلل/فراتر از تصور	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga5WCBf8	2026-09-27 15:54:16.448039+00	2026-09-27 15:57:59.408192+00	\N	\N	\N	mashhad	185	\N	\N	80000000	{"mid": "اجاره: ۸۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن ایفل بین جلال ۱۶ وتقاطع فرهنگ در فرهنگ", "amounts": {"اجاره": 80000000}}	\N
93	divar	ga5ujr0h	600متر / ویلایی / دوبلکس / سجاد	ملک‌آباد	\N	rent	\N	https://divar.ir/v/_/ga5ujr0h	2026-09-27 15:52:22.088648+00	2026-09-27 15:57:59.41126+00	\N	\N	\N	mashhad	600	\N	\N	390000000	{"mid": "اجاره: ۳۹۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ملک‌آباد", "amounts": {"اجاره": 390000000}}	\N
94	divar	ga5uzUA9	رهن و اجاره برج ونوس شاهد	فرهنگیان (شهرک غرب)	\N	rent	37	https://divar.ir/v/_/ga5uzUA9	2026-09-27 15:51:31.367727+00	2026-09-27 15:57:59.41425+00	\N	\N	\N	mashhad	\N	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگیان (شهرک غرب)", "amounts": {"اجاره": 25000000}}	\N
95	divar	ga5uDOiN	خانه اجاره ای	هنرور	\N	rent	\N	https://divar.ir/v/_/ga5uDOiN	2026-09-27 15:50:27.396457+00	2026-09-27 15:57:59.418157+00	\N	\N	\N	mashhad	\N	\N	\N	11000000	{"mid": "اجاره: ۱۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"اجاره": 11000000}}	\N
96	divar	ga5qzzUX	رهن و اجاره اپارتمان ۸۵ متری ویژه جهیزیه عروس	سعد آباد	\N	rent	\N	https://divar.ir/v/_/ga5qzzUX	2026-09-27 15:48:43.003729+00	2026-09-27 15:57:59.424206+00	\N	\N	\N	mashhad	85	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "دقایقی پیش در سعد آباد", "amounts": {"اجاره": 1000}}	\N
97	divar	ga5qjN5_	همخونه(خ) اقاهستم	شهید بهشتی	\N	rent	18	https://divar.ir/v/_/ga5qjN5_	2026-09-27 15:46:04.015373+00	2026-09-27 15:57:59.436081+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید بهشتی", "amounts": {"اجاره": 10000000}}	\N
98	divar	ga5mzqXE	آپارتمان تجهیزشده	عنصری	\N	rent	\N	https://divar.ir/v/_/ga5mzqXE	2026-09-27 15:45:36.676825+00	2026-09-27 15:57:59.43948+00	\N	\N	\N	mashhad	\N	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در عنصری", "amounts": {"اجاره": 30000000}}	\N
99	divar	ga5qzEEI	آپارتمان سه خواب تک‌واحدی دوسر نور اول هاشمیه ۶۲	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga5qzEEI	2026-09-27 15:45:31.590665+00	2026-09-27 15:57:59.446116+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهارچشمه", "amounts": {"اجاره": 15000000}}	\N
100	divar	gazKdWTr	آپارتمان 70متری خوش نقشه ومدرن کف سرامیک کابینتMDF	ایثارگران	3490000000	sale	\N	https://divar.ir/v/_/gazKdWTr	2026-09-23 13:22:45.379508+00	2026-09-27 15:58:10.410202+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۳,۴۹۰,۰۰۰,۰۰۰ تومان", "bottom": "در ایثارگران", "amounts": {"raw_amount": 3490000000}}	\N
101	divar	ga5yj-NN	۱۱۷ متر ۲ خواب مستر ، سندملکی ، ۵ دقیقه تا حرم	آیت الله خامنه‌ای	25700000000	sale	\N	https://divar.ir/v/_/ga5yj-NN	2026-09-27 15:58:07.165727+00	2026-09-27 15:58:10.419941+00	\N	\N	\N	mashhad	117	2	\N	\N	{"mid": "۲۵,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در آیت الله خامنه‌ای", "amounts": {"raw_amount": 25700000000}}	\N
102	divar	gazuOesa	خونه دربست ویلایی فقط امروز این قیمت	فریزی	2500000000	sale	\N	https://divar.ir/v/_/gazuOesa	2026-09-27 15:58:03.037467+00	2026-09-27 15:58:10.423722+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فریزی", "amounts": {"raw_amount": 2500000000}}	\N
103	divar	ga5uj_yI	فروش باغ سفتکاری در مجتمع بوستان شرکت برق کاهو	میان ولایت	7500000000	sale	\N	https://divar.ir/v/_/ga5uj_yI	2026-09-27 15:57:58.402728+00	2026-09-27 15:58:10.427221+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در میان ولایت", "amounts": {"raw_amount": 7500000000}}	\N
104	divar	gaZGxWYq	آپارتمان  ۱۲۴متری سند دار	امیر	11160000000	sale	\N	https://divar.ir/v/_/gaZGxWYq	2026-09-27 15:57:57.827198+00	2026-09-27 15:58:10.43072+00	\N	\N	\N	mashhad	124	\N	\N	\N	{"mid": "۱۱,۱۶۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیر", "amounts": {"raw_amount": 11160000000}}	\N
116	divar	garaUc4N	۱۰۰ متر /دونبش /غرق نور	الهیه	\N	rent	44	https://divar.ir/v/_/garaUc4N	2026-09-17 01:46:49.666428+00	2026-09-27 15:58:10.463049+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در الهیه", "amounts": {}}	\N
130	divar	ga2ay4Fm	فروش ۱۰۵ متری رضاشهر خاقانی	رضاشهر	21000000000	sale	\N	https://divar.ir/v/_/ga2ay4Fm	2026-09-25 07:48:12.531629+00	2026-09-27 16:08:20.43953+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۲۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رضاشهر", "amounts": {"raw_amount": 21000000000}}	\N
131	divar	gahC41iu	آپارتمان 81 متری آسانسور دار در صیاد	هفت تیر (نه دره)	8700000000	sale	\N	https://divar.ir/v/_/gahC41iu	2026-09-27 16:07:30.378955+00	2026-09-27 16:08:20.446393+00	\N	\N	\N	mashhad	81	\N	\N	\N	{"mid": "۸,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن نیکان نبش هاشمیه۶۵ در هفت تیر (نه دره)", "amounts": {"raw_amount": 8700000000}}	\N
132	divar	ga5-zMds	۱۶۰متری/امامت/طبقه اول/صفر کلید نخورده	آزادشهر	38500000000	sale	\N	https://divar.ir/v/_/ga5-zMds	2026-09-27 16:07:27.794299+00	2026-09-27 16:08:20.4502+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۳۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "اژانس اریا در آزادشهر", "amounts": {"raw_amount": 38500000000}}	\N
133	divar	ga56Ttp6	فروش آپارتمان تک واحدی ،مجیدیه خیابان مرشدلولو	جاهد شهر	16500000000	sale	41	https://divar.ir/v/_/ga56Ttp6	2026-09-27 16:06:57.774511+00	2026-09-27 16:08:20.454181+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"raw_amount": 16500000000}}	\N
134	divar	gavC4Xw0	باغ ویلا هزار یک متری  داخل مجتمع ملکی	درزآب	1780000000	sale	\N	https://divar.ir/v/_/gavC4Xw0	2026-09-27 16:06:56.935579+00	2026-09-27 16:08:20.458325+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۷۸۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 1780000000}}	\N
135	divar	ga56zelJ	زمین‌فروشی‌همت‌آباد‌گوندوک	تبادکان	250000000	sale	\N	https://divar.ir/v/_/ga56zelJ	2026-09-27 16:06:01.15983+00	2026-09-27 16:08:20.461471+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در تبادکان", "amounts": {"raw_amount": 250000000}}	\N
136	divar	ga56jq0V	فرشته هاشمیه / ۲۳۰ متر / جنوبی / ۳ خواب / مستر	کوثر	56500000000	sale	13	https://divar.ir/v/_/ga56jq0V	2026-09-27 16:05:21.673954+00	2026-09-27 16:08:20.464891+00	\N	\N	\N	mashhad	230	3	\N	\N	{"mid": "۵۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن والی در کوثر", "amounts": {"raw_amount": 56500000000}}	\N
137	divar	gaySuw8Y	فروش طبقه 4روی پولت	طبرسی شمالی	910000000	sale	42	https://divar.ir/v/_/gaySuw8Y	2026-09-27 16:05:15.080234+00	2026-09-27 16:08:20.467769+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در طبرسی شمالی", "amounts": {"raw_amount": 910000000}}	\N
138	divar	gahSBezm	حـاشیه مـعلـم ویـو پـارک مــلت سند آماده	آزادشهر	34000000000	sale	\N	https://divar.ir/v/_/gahSBezm	2026-09-27 16:04:55.065926+00	2026-09-27 16:08:20.471548+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بامک بین امامت ۳۶و۳۸ در آزادشهر", "amounts": {"raw_amount": 34000000000}}	\N
139	divar	ga5WSQ2g	آپارتمان165متر/فول امکانات/مشابه صفر/صیاد 27	هفت تیر (آب و برق)	21300000000	sale	\N	https://divar.ir/v/_/ga5WSQ2g	2026-09-27 16:04:23.136433+00	2026-09-27 16:08:20.473962+00	\N	\N	\N	mashhad	165	\N	\N	\N	{"mid": "۲۱,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (آب و برق)", "amounts": {"raw_amount": 21300000000}}	\N
140	divar	ga52TnAX	۱۲۸متر صفر فول شمالی سر جلو معاوضه با واحد کوچک	شهرک لشکر (شهرک غرب)	16000000000	sale	38	https://divar.ir/v/_/ga52TnAX	2026-09-27 16:03:36.144507+00	2026-09-27 16:08:20.476445+00	\N	\N	\N	mashhad	128	\N	\N	\N	{"mid": "۱۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن کیان نبش هاشمی مهنه ۱۳ در شهرک لشکر (شهرک غرب)", "amounts": {"raw_amount": 16000000000}}	\N
141	divar	ga4ac1P2	آپارتمان فروشی۶۰متری سندملکی جنت گلستان	جنت	6200000000	sale	\N	https://divar.ir/v/_/ga4ac1P2	2026-09-27 16:03:20.96244+00	2026-09-27 16:08:20.478848+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۶,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جنت", "amounts": {"raw_amount": 6200000000}}	\N
142	divar	gaZeJsyc	خانه ویلایی شهرک حجت	حضرت حجت	4500000000	sale	\N	https://divar.ir/v/_/gaZeJsyc	2026-09-27 16:02:55.474871+00	2026-09-27 16:08:20.482156+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در حضرت حجت", "amounts": {"raw_amount": 4500000000}}	\N
143	divar	garmOxVG	۱۵۰ متر فول نوساز اوایل هاشمیه	کوثر	\N	rent	13	https://divar.ir/v/_/garmOxVG	2026-09-19 08:34:03.916624+00	2026-09-27 16:08:20.48502+00	\N	\N	\N	mashhad	150	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در کوثر", "amounts": {}}	\N
144	divar	ga0ZdJV7	اجاره آپارتمان ۱۵۰ متری فول امکانات  هاشمیه	کوثر	\N	rent	13	https://divar.ir/v/_/ga0ZdJV7	2026-09-20 06:37:42.551092+00	2026-09-27 16:08:20.487841+00	\N	\N	\N	mashhad	150	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوثر", "amounts": {"اجاره": 10000000}}	\N
145	divar	ga5-DBWT	رهن واجاره ویلای	هفت تیر (نه دره)	\N	rent	\N	https://divar.ir/v/_/ga5-DBWT	2026-09-27 16:06:42.026001+00	2026-09-27 16:08:20.490909+00	\N	\N	\N	mashhad	\N	\N	\N	13000000	{"mid": "اجاره: ۱۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (نه دره)", "amounts": {"اجاره": 13000000}}	\N
146	divar	ga56za2n	آپارتمان ۷۰ متری یک خواب طبقه اول	ابوذر	\N	rent	24	https://divar.ir/v/_/ga56za2n	2026-09-27 16:05:26.777388+00	2026-09-27 16:08:20.494157+00	\N	\N	\N	mashhad	70	\N	\N	9000000	{"mid": "اجاره: ۹,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ابوذر", "amounts": {"اجاره": 9000000}}	\N
147	divar	ga56TqgR	200متر / کوثر فرشته / صفر / فول مشاعات	کوثر	\N	rent	13	https://divar.ir/v/_/ga56TqgR	2026-09-27 16:05:04.035914+00	2026-09-27 16:08:20.496837+00	\N	\N	\N	mashhad	200	\N	\N	150000000	{"mid": "اجاره: ۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 150000000}}	\N
148	divar	ga56jMfN	۶۵متر ویلایی رهن کامل خواجه ربیع بهمن ۱۶	بهمن	\N	rent	43	https://divar.ir/v/_/ga56jMfN	2026-09-27 16:04:38.954322+00	2026-09-27 16:08:20.499992+00	\N	\N	\N	mashhad	65	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهمن", "amounts": {"اجاره": 100000}}	\N
149	divar	ga56Texo	آپارتمان صفر مدرن تک واحدی پشت حاشیه وکیل آباد	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga56Texo	2026-09-27 16:04:16.28528+00	2026-09-27 16:08:20.502793+00	\N	\N	\N	mashhad	\N	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگ", "amounts": {"اجاره": 30000000}}	\N
150	divar	ga4-vCMZ	۱۳۰ متری حیاط دار	شاهد (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga4-vCMZ	2026-09-27 16:03:22.047377+00	2026-09-27 16:08:20.506066+00	\N	\N	\N	mashhad	130	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "در شاهد (شهرک غرب)", "amounts": {"اجاره": 25000000}}	\N
151	divar	ga3m-8io	واحدصفر ۱۶۰ متری امام رضا ۳۱	امام رضا (ع)	\N	rent	\N	https://divar.ir/v/_/ga3m-8io	2026-09-27 16:01:25.716225+00	2026-09-27 16:08:20.509003+00	\N	\N	\N	mashhad	160	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "در امام رضا (ع)", "amounts": {"اجاره": 1000000}}	\N
152	divar	ga52jckY	آپارتمان ۱۷۵متری صفر تکواحدی مدرس فرهنگ	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga52jckY	2026-09-27 15:59:53.411137+00	2026-09-27 16:08:20.511825+00	\N	\N	\N	mashhad	175	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگ", "amounts": {"اجاره": 15000000}}	\N
153	divar	ga52DU1L	رهن و اجاره	رستگار	\N	rent	\N	https://divar.ir/v/_/ga52DU1L	2026-09-27 15:59:18.176843+00	2026-09-27 16:08:20.514104+00	\N	\N	\N	mashhad	\N	\N	\N	13000000	{"mid": "اجاره: ۱۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رستگار", "amounts": {"اجاره": 13000000}}	\N
154	divar	ga4elJTg	همخونه همخونه	جوادیه	\N	rent	\N	https://divar.ir/v/_/ga4elJTg	2026-09-27 15:59:09.061735+00	2026-09-27 16:08:20.51655+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جوادیه", "amounts": {"اجاره": 5000000}}	\N
155	divar	ga5yT_d-	آپارتمان ۱۵۵متری طبقه اول کوثر شمالی	کوثر	\N	rent	13	https://divar.ir/v/_/ga5yT_d-	2026-09-27 15:58:56.116416+00	2026-09-27 16:08:20.518819+00	\N	\N	\N	mashhad	155	\N	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 35000000}}	\N
156	divar	ga5eylMJ	۱۶۰متر/دانش آموز قبل فرهنگ/FULL BMS/شاهکار معماری	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga5eylMJ	2026-09-27 15:58:51.930538+00	2026-09-27 16:08:20.520957+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن ایفل بین جلال ۱۶ وتقاطع فرهنگ در فرهنگ", "amounts": {}}	\N
157	divar	ga52TJC6	آپارتمان،۸۲ متری،گاز،مسلم	گاز	\N	rent	\N	https://divar.ir/v/_/ga52TJC6	2026-09-27 15:58:41.210956+00	2026-09-27 16:08:20.523681+00	\N	\N	\N	mashhad	82	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گاز", "amounts": {"اجاره": 20000000}}	\N
158	divar	ga52jEwN	۹۰متری فول شیک	شهرک لشکر (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga52jEwN	2026-09-27 15:58:16.723417+00	2026-09-27 16:08:20.526523+00	\N	\N	\N	mashhad	90	\N	\N	16000000	{"mid": "اجاره: ۱۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک لشکر (شهرک غرب)", "amounts": {"اجاره": 16000000}}	\N
161	divar	ga5C0jeX	آپارتمان فروشی	نوده	2000000000	sale	\N	https://divar.ir/v/_/ga5C0jeX	2026-09-27 16:18:11.684441+00	2026-09-27 16:18:29.42641+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در نوده", "amounts": {"raw_amount": 2000000000}}	\N
162	divar	gafmbFbr	منزل حیاط دار دو طبقه سفت کاری شده	همت آباد	1850000000	sale	\N	https://divar.ir/v/_/gafmbFbr	2026-09-27 16:17:56.945109+00	2026-09-27 16:18:29.434776+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در همت آباد", "amounts": {"raw_amount": 1850000000}}	\N
163	divar	ga5C0zK1	آپارتمان فروشی	شهید قربانی	2990000000	sale	\N	https://divar.ir/v/_/ga5C0zK1	2026-09-27 16:17:56.627508+00	2026-09-27 16:18:29.443891+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۹۹۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهید قربانی", "amounts": {"raw_amount": 2990000000}}	\N
164	divar	ga5GkeVg	آپارتمان ۸۰ متر / اقبال / زیر پیروزی	اقبال	8500000000	sale	1	https://divar.ir/v/_/ga5GkeVg	2026-09-27 16:17:51.564377+00	2026-09-27 16:18:29.451746+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در اقبال", "amounts": {"raw_amount": 8500000000}}	\N
165	divar	gapOzWL6	آپارتمان95متر یک خواب/نوساز/طبقه اول/کشف/یاسمن	کشف	2850000000	sale	\N	https://divar.ir/v/_/gapOzWL6	2026-09-27 16:17:14.730072+00	2026-09-27 16:18:29.458238+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۲,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در کشف", "amounts": {"raw_amount": 2850000000}}	\N
166	divar	ga5GkQ4Y	۱۶۰ متر صفر طبقه ۶ (( امامت فرد )) فروشنده واقعی	آزادشهر	25600000000	sale	\N	https://divar.ir/v/_/ga5GkQ4Y	2026-09-27 16:16:14.652112+00	2026-09-27 16:18:29.465056+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۲۵,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بامک بین امامت ۳۶و۳۸ در آزادشهر", "amounts": {"raw_amount": 25600000000}}	\N
167	divar	gayCpyCW	متـ250ــری دوبلکس شیکــ / هنرستان	هنرستان	\N	rent	11	https://divar.ir/v/_/gayCpyCW	2026-09-26 14:33:51.100161+00	2026-09-27 16:18:29.47114+00	\N	\N	\N	mashhad	\N	\N	\N	80000000	{"mid": "اجاره: ۸۰,۰۰۰,۰۰۰ تومان", "bottom": "در هنرستان", "amounts": {"اجاره": 80000000}}	\N
168	divar	ga5GEx32	130مترهفت تیر28	نیروی هوایی	\N	rent	\N	https://divar.ir/v/_/ga5GEx32	2026-09-27 16:18:19.285795+00	2026-09-27 16:18:29.478137+00	\N	\N	\N	mashhad	130	\N	\N	32000000	{"mid": "اجاره: ۳۲,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در نیروی هوایی", "amounts": {"اجاره": 32000000}}	\N
169	divar	gauWGRhl	105متری  مجتمع شیک وتمیز	الهیه	\N	rent	44	https://divar.ir/v/_/gauWGRhl	2026-09-27 16:15:08.968866+00	2026-09-27 16:18:29.483183+00	\N	\N	\N	mashhad	105	\N	\N	23000000	{"mid": "اجاره: ۲۳,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"اجاره": 23000000}}	\N
170	divar	gaYqUkC3	رهن/اجاره فوری سه خواب زیر فی منطقه غرق نور	الهیه	\N	rent	44	https://divar.ir/v/_/gaYqUkC3	2026-09-27 16:14:39.846365+00	2026-09-27 16:18:29.490806+00	\N	\N	\N	mashhad	\N	\N	\N	27000000	{"mid": "اجاره: ۲۷,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"اجاره": 27000000}}	\N
171	divar	ga5C0Xjm	خانه اجاره ای رودکی ۸(پارس ۵)،۱۵۰ ودیعه، ۱۴ اجاره	شهید بهشتی	\N	rent	18	https://divar.ir/v/_/ga5C0Xjm	2026-09-27 16:12:25.542848+00	2026-09-27 16:18:29.496112+00	\N	\N	\N	mashhad	\N	\N	\N	14000000	{"mid": "اجاره: ۱۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید بهشتی", "amounts": {"اجاره": 14000000}}	\N
177	divar	gaw2hBcZ	فروش اقساطی زمین تجاری مسکونی مشهد	فردوسی	630000000000	sale	\N	https://divar.ir/v/_/gaw2hBcZ	2026-09-21 10:42:14.939386+00	2026-09-27 16:28:38.506522+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶۳۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "شرکت گسترش ساختمانی لوتوس پارسیان در فردوسی", "amounts": {"raw_amount": 630000000000}}	\N
178	divar	gabNmMJn	واحد ۱۰۰ متری بازسازی ۱۰۰٪ طبقه اول غرق نور دائمی	بهاران	10250000000	sale	17	https://divar.ir/v/_/gabNmMJn	2026-09-27 15:34:52.234353+00	2026-09-27 16:28:38.513474+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۰,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهاران", "amounts": {"raw_amount": 10250000000}}	\N
179	divar	Qay2b1aj	باغ فروشی  مشهدعسکریه مناسب زندگی تفریح فول  ملک	میان ولایت	16000000000	sale	\N	https://divar.ir/v/_/Qay2b1aj	2026-09-27 16:28:28.848888+00	2026-09-27 16:28:38.517699+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 16000000000}}	\N
180	divar	ga5OEEOY	فروش فوری آپارتمان۶۰متری یک‌خوابه در بلوار طبرسی	طبرسی شمالی	2350000000	sale	42	https://divar.ir/v/_/ga5OEEOY	2026-09-27 16:28:12.849695+00	2026-09-27 16:28:38.52151+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۲,۳۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در طبرسی شمالی", "amounts": {"raw_amount": 2350000000}}	\N
181	divar	gak2ZxMm	زمین باوام آب برق در زعفرانیه بدون ضا  من گوارشک	دهشک	293000000	sale	\N	https://divar.ir/v/_/gak2ZxMm	2026-09-27 16:27:01.102142+00	2026-09-27 16:28:38.525133+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۹۳,۰۰۰,۰۰۰ تومان", "bottom": "مجموعه باغی ویلایی خراسانی در دهشک", "amounts": {"raw_amount": 293000000}}	\N
182	divar	ga5Okbnl	آپارتمان ۱۳۰متری فرشته	کوثر	18500000000	sale	13	https://divar.ir/v/_/ga5Okbnl	2026-09-27 16:26:04.364423+00	2026-09-27 16:28:38.529644+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "۱۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"raw_amount": 18500000000}}	\N
183	divar	garqKJYe	ویلایی ۲طبقه جنوبی عبادی مجلسی مقابل باغ راه‌آهن	فاطمیه	12700000000	sale	30	https://divar.ir/v/_/garqKJYe	2026-09-27 16:26:03.729553+00	2026-09-27 16:28:38.533659+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فاطمیه", "amounts": {"raw_amount": 12700000000}}	\N
184	divar	ga5OkgeY	145 متر / صفر/ اول رحمانیه/ شیک و مدرن	الهیه	16000000000	sale	44	https://divar.ir/v/_/ga5OkgeY	2026-09-27 16:25:53.075358+00	2026-09-27 16:28:38.537716+00	\N	\N	\N	mashhad	145	\N	\N	\N	{"mid": "۱۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری بزرگ رویال در الهیه", "amounts": {"raw_amount": 16000000000}}	\N
185	divar	ga56zetY	خانه ویلایی	کوی دروی	1350000000	sale	\N	https://divar.ir/v/_/ga56zetY	2026-09-27 16:25:36.613532+00	2026-09-27 16:28:38.54135+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۳۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی دروی", "amounts": {"raw_amount": 1350000000}}	\N
186	divar	ga4-4_a4	هشدار به خریداران محترم	زمرد	7200000000	sale	\N	https://divar.ir/v/_/ga4-4_a4	2026-09-27 16:25:17.704842+00	2026-09-27 16:28:38.545931+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در زمرد", "amounts": {"raw_amount": 7200000000}}	\N
187	divar	ga5O0OLm	۸۰مترطبقه۱باآسانسورفابریک/سیدرضی قبل مهران	سید رضی	11000000000	sale	\N	https://divar.ir/v/_/ga5O0OLm	2026-09-27 16:24:52.25138+00	2026-09-27 16:28:38.55007+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سید رضی", "amounts": {"raw_amount": 11000000000}}	\N
188	divar	ga5KEz6b	اپارتمان ۱۶۸ متر ۳خوابه شهرک صبا	پنجتن	7220000000	sale	\N	https://divar.ir/v/_/ga5KEz6b	2026-09-27 16:24:38.381439+00	2026-09-27 16:28:38.552839+00	\N	\N	\N	mashhad	168	3	\N	\N	{"mid": "۷,۲۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پنجتن", "amounts": {"raw_amount": 7220000000}}	\N
189	divar	ga5Kktuu	آپارتمان شیرودی	کارگران	15000000000	sale	40	https://divar.ir/v/_/ga5Kktuu	2026-09-27 16:24:29.84897+00	2026-09-27 16:28:38.555782+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کارگران", "amounts": {"raw_amount": 15000000000}}	\N
190	divar	ga5-zIeR	همکف حیاط دار نزدیک میدان حافظ بازسازی شده	هفت تیر (آب و برق)	11600000000	sale	\N	https://divar.ir/v/_/ga5-zIeR	2026-09-27 16:24:05.042834+00	2026-09-27 16:28:38.558083+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۱,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (آب و برق)", "amounts": {"raw_amount": 11600000000}}	\N
191	divar	gaaKshmW	۱۰۵متر /خوش نقشه/ دونبش / ویو ابدی	الهیه	10400000000	sale	44	https://divar.ir/v/_/gaaKshmW	2026-09-27 16:23:30.233772+00	2026-09-27 16:28:38.561259+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۰,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سلین در الهیه", "amounts": {"raw_amount": 10400000000}}	\N
192	divar	ga56j7Rs	همخونه نیازمندم	هنرستان	\N	rent	11	https://divar.ir/v/_/ga56j7Rs	2026-09-27 16:27:11.235999+00	2026-09-27 16:28:38.564602+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرستان", "amounts": {"اجاره": 100000}}	\N
193	divar	ga5OU1Wd	همکف ۸۰ متری / هاشمیه قبل از پیروزی	کوثر	\N	rent	13	https://divar.ir/v/_/ga5OU1Wd	2026-09-27 16:27:08.245289+00	2026-09-27 16:28:38.567865+00	\N	\N	\N	mashhad	80	\N	\N	22000000	{"mid": "اجاره: ۲۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 22000000}}	\N
194	divar	galOB67D	اجاره خانه در بلوار توس	مشهدقلی	\N	rent	\N	https://divar.ir/v/_/galOB67D	2026-09-27 16:24:25.587574+00	2026-09-27 16:28:38.571279+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "در مشهدقلی", "amounts": {"اجاره": 8000000}}	\N
195	divar	ga3K-49x	سه خواب ۱۹۰ متری در حد صفر	شهید فرامرز عباسی	\N	rent	\N	https://divar.ir/v/_/ga3K-49x	2026-09-27 16:23:37.159505+00	2026-09-27 16:28:38.574139+00	\N	\N	\N	mashhad	190	\N	\N	80000000	{"mid": "اجاره: ۸۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید فرامرز عباسی", "amounts": {"اجاره": 80000000}}	\N
196	divar	ga5KEugs	آپارتمان 110متری طبقه دوم روی همکف	انقلاب	\N	rent	\N	https://divar.ir/v/_/ga5KEugs	2026-09-27 16:23:18.248265+00	2026-09-27 16:28:38.576416+00	\N	\N	\N	mashhad	110	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در انقلاب", "amounts": {"اجاره": 100000}}	\N
197	divar	ga5Kktrq	اجاره یک سویت مستقل با وسایل	جوادیه	\N	rent	\N	https://divar.ir/v/_/ga5Kktrq	2026-09-27 16:22:20.678238+00	2026-09-27 16:28:38.579634+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جوادیه", "amounts": {"اجاره": 10000000}}	\N
198	divar	ga5KUi9k	۱۷۵ متر صارمی ۱۰	کوثر	\N	rent	13	https://divar.ir/v/_/ga5KUi9k	2026-09-27 16:21:40.1318+00	2026-09-27 16:28:38.582829+00	\N	\N	\N	mashhad	175	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در کوثر", "amounts": {}}	\N
199	divar	gavy-QrU	همخونه	هفت تیر (آب و برق)	\N	rent	\N	https://divar.ir/v/_/gavy-QrU	2026-09-27 16:20:57.880588+00	2026-09-27 16:28:38.586002+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (آب و برق)", "amounts": {"اجاره": 10000000}}	\N
200	divar	ga5KUD1D	طبقه 110متری	هفده شهریور	\N	rent	\N	https://divar.ir/v/_/ga5KUD1D	2026-09-27 16:20:30.307526+00	2026-09-27 16:28:38.58864+00	\N	\N	\N	mashhad	110	\N	\N	23000000	{"mid": "اجاره: ۲۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفده شهریور", "amounts": {"اجاره": 23000000}}	\N
205	divar	gaU-zV9c	تماس بگیر راهنماییت کنم‌ زمین جلدک میخوای بخری	جاهد شهر	760000000	sale	41	https://divar.ir/v/_/gaU-zV9c	2026-09-26 17:32:02.893839+00	2026-09-27 16:35:40.857807+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷۶۰,۰۰۰,۰۰۰ تومان", "bottom": "مهندس فخیم زاده حسین اباد جلدک خرید فروش  در جاهد شهر", "amounts": {"raw_amount": 760000000}}	\N
206	divar	gazuIfJg	یک واحد اپارتمان	طبرسی شمالی	2100000000	sale	42	https://divar.ir/v/_/gazuIfJg	2026-09-24 08:54:25.279667+00	2026-09-27 16:35:40.866006+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در طبرسی شمالی", "amounts": {"raw_amount": 2100000000}}	\N
207	divar	ga5Wkl0b	آپارتمان۱۲۵متری  هاشمیه طبقه اول تکواحدی	کوثر	18500000000	sale	13	https://divar.ir/v/_/ga5Wkl0b	2026-09-27 16:35:08.454178+00	2026-09-27 16:35:40.870797+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۱۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در کوثر", "amounts": {"raw_amount": 18500000000}}	\N
208	divar	ga5WUds8	باغ با درختان قدیمی.مجتمع پاتریس	میان ولایت	6500000000	sale	\N	https://divar.ir/v/_/ga5WUds8	2026-09-27 16:34:13.967292+00	2026-09-27 16:35:40.875169+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 6500000000}}	\N
209	divar	ga5WEGC2	همکف راه جدا ماشین رو95 متری پنچ تن صادقیه	پنجتن	4950000000	sale	\N	https://divar.ir/v/_/ga5WEGC2	2026-09-27 16:34:00.081372+00	2026-09-27 16:35:40.87929+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۴,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پنجتن", "amounts": {"raw_amount": 4950000000}}	\N
210	divar	ga5WkN0Y	۱۱۵ متر فول // پارکینگ اختصاصی بدون مزاحمت // صفر	شهید مطهری	9000000000	sale	28	https://divar.ir/v/_/ga5WkN0Y	2026-09-27 16:33:27.01596+00	2026-09-27 16:35:40.882861+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن غفرانی راهبری ارشد مروی در شهید مطهری", "amounts": {"raw_amount": 9000000000}}	\N
211	divar	ga56TGR7	تهاتر ویلای منطقه ۱۱ با دو واحد آپارتمان منطقه ۱	فرهنگ	82000000000	sale	\N	https://divar.ir/v/_/ga56TGR7	2026-09-27 16:32:57.256048+00	2026-09-27 16:35:40.886504+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگ", "amounts": {"raw_amount": 82000000000}}	\N
212	divar	gafdys_K	۱۰۰ متر    آپارتمان.     صفر         امامت	آزادشهر	18000000000	sale	\N	https://divar.ir/v/_/gafdys_K	2026-09-27 16:30:53.407699+00	2026-09-27 16:35:40.890012+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در آزادشهر", "amounts": {"raw_amount": 18000000000}}	\N
213	divar	ga5SEH9l	150متر ابتدای مهدی / پلان مهندسی / نورگیر	فردوسی	20500000000	sale	\N	https://divar.ir/v/_/ga5SEH9l	2026-09-27 16:30:47.159255+00	2026-09-27 16:35:40.893329+00	\N	\N	\N	mashhad	150	\N	\N	\N	{"mid": "۲۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فردوسی", "amounts": {"raw_amount": 20500000000}}	\N
214	divar	ga5SUaHL	آپارتمان ۸۵ متری	نکاح	3900000000	sale	\N	https://divar.ir/v/_/ga5SUaHL	2026-09-27 16:30:25.778565+00	2026-09-27 16:35:40.896152+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۳,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نکاح", "amounts": {"raw_amount": 3900000000}}	\N
215	divar	ga5SEYt4	آپارتمان ۱۰۸ متر سندشش دانگ	هنرور	8700000000	sale	\N	https://divar.ir/v/_/ga5SEYt4	2026-09-27 16:30:21.539256+00	2026-09-27 16:35:40.898649+00	\N	\N	\N	mashhad	108	\N	\N	\N	{"mid": "۸,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"raw_amount": 8700000000}}	\N
216	divar	ga5SkXyk	منزل ۸۵ متری انتهای جانباز ۹	جانباز	14000000000	sale	\N	https://divar.ir/v/_/ga5SkXyk	2026-09-27 16:30:19.91727+00	2026-09-27 16:35:40.901134+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۱۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جانباز", "amounts": {"raw_amount": 14000000000}}	\N
217	divar	ga4K9xTT	آپارتمان 120 متری ، قائم مقام ، دو قدمی وکیل آباد	شریف	\N	rent	\N	https://divar.ir/v/_/ga4K9xTT	2026-09-27 13:48:27.819313+00	2026-09-27 16:35:40.903279+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در شریف", "amounts": {}}	\N
218	divar	ga5WkwTM	۸۰ متر آپارتمان شیک  هاشمیه ۵۱	نیروی هوایی	\N	rent	\N	https://divar.ir/v/_/ga5WkwTM	2026-09-27 16:35:22.140107+00	2026-09-27 16:35:40.905579+00	\N	\N	\N	mashhad	80	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در نیروی هوایی", "amounts": {"اجاره": 40000000}}	\N
219	divar	ga5WAB-x	رهن و اجاره خانه ۷۵ متری	بهمن	\N	rent	43	https://divar.ir/v/_/ga5WAB-x	2026-09-27 16:35:13.570138+00	2026-09-27 16:35:40.907957+00	\N	\N	\N	mashhad	75	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در بهمن", "amounts": {"اجاره": 6000000}}	\N
220	divar	ga5SErzD	رهایی/ ۶۵ متر / یک خواب	سرافرازان	\N	rent	22	https://divar.ir/v/_/ga5SErzD	2026-09-27 16:31:29.945884+00	2026-09-27 16:35:40.910638+00	\N	\N	\N	mashhad	65	\N	\N	15500000	{"mid": "اجاره: ۱۵,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سرافرازان", "amounts": {"اجاره": 15500000}}	\N
221	divar	ga5OUw_D	رهن آپارتمان جلال160متر2خواب	شهید رضوی	\N	rent	\N	https://divar.ir/v/_/ga5OUw_D	2026-09-27 16:30:19.939909+00	2026-09-27 16:35:40.913149+00	\N	\N	\N	mashhad	160	2	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید رضوی", "amounts": {"اجاره": 100000}}	\N
222	divar	ga5K0Uiq	۱۷۰متر فوق‌العاده نورگیر / طبقه ۵ / لوکیشن خاص	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga5K0Uiq	2026-09-27 16:28:55.92552+00	2026-09-27 16:35:40.915643+00	\N	\N	\N	mashhad	170	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در فرهنگ", "amounts": {}}	\N
232	divar	ga0qOagQ	مصلی طالبی خونه ویلایی دوطبقه 141متر سند ششدانگ	کارمندان دوم	21500000000	sale	\N	https://divar.ir/v/_/ga0qOagQ	2026-09-24 09:17:03.609041+00	2026-09-27 16:35:51.749918+00	\N	\N	\N	mashhad	141	\N	\N	\N	{"mid": "۲۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کارمندان دوم", "amounts": {"raw_amount": 21500000000}}	\N
233	divar	gaxCxKzV	200 متری لوکس ۳ خوابه امام خمینی	امام خمینی	28000000000	sale	\N	https://divar.ir/v/_/gaxCxKzV	2026-09-21 11:10:34.029051+00	2026-09-27 16:35:51.756759+00	\N	\N	\N	mashhad	200	3	\N	\N	{"mid": "۲۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امام خمینی", "amounts": {"raw_amount": 28000000000}}	\N
258	divar	ga5ikCxY	آپارتمان شهرک حجت دونبش حاشیه خیابان اصلی سراسرنور	حضرت حجت	4250000000	sale	\N	https://divar.ir/v/_/ga5ikCxY	2026-09-27 16:45:43.021144+00	2026-09-27 16:46:01.117987+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در حضرت حجت", "amounts": {"raw_amount": 4250000000}}	\N
259	divar	gan-t2a9	فروش یک باب خانه ویلایی ۱۰۰ متری شیک نوساز	علی آباد	2650000000	sale	\N	https://divar.ir/v/_/gan-t2a9	2026-09-27 16:45:32.666456+00	2026-09-27 16:46:01.128708+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۲,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در علی آباد", "amounts": {"raw_amount": 2650000000}}	\N
260	divar	ga5eUo_r	آپارتمان110 متری 2خواب خیابان امام رضا نزدیک حرم	سلام	22000000000	sale	\N	https://divar.ir/v/_/ga5eUo_r	2026-09-27 16:43:27.339999+00	2026-09-27 16:46:01.134125+00	\N	\N	\N	mashhad	110	2	\N	\N	{"mid": "۲۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در سلام", "amounts": {"raw_amount": 22000000000}}	\N
261	divar	gadixqXi	158 متر امامت 3 آپارتمان با ابهت 200 متری	آزادشهر	38000000000	sale	\N	https://divar.ir/v/_/gadixqXi	2026-09-27 16:43:24.178645+00	2026-09-27 16:46:01.139236+00	\N	\N	\N	mashhad	158	\N	\N	\N	{"mid": "۳۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در آزادشهر", "amounts": {"raw_amount": 38000000000}}	\N
262	divar	ga0Bnatr	فروش آپارتمان۱۳۰متر/صفر/۳نبش/الهیه	الهیه	14000000000	sale	44	https://divar.ir/v/_/ga0Bnatr	2026-09-27 16:43:04.841867+00	2026-09-27 16:46:01.144926+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "۱۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری حافظ رتبه اول الهیه در الهیه", "amounts": {"raw_amount": 14000000000}}	\N
263	divar	ga5eESB6	آپارتمان احمداباد	احمدآباد	18500000000	sale	\N	https://divar.ir/v/_/ga5eESB6	2026-09-27 16:43:02.866954+00	2026-09-27 16:46:01.148736+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در احمدآباد", "amounts": {"raw_amount": 18500000000}}	\N
264	divar	gaeStFzV	140متر تک واحدی حاشیه 20متری زیر فی منطقه	شهرک امام هادی (شهرک غرب)	4800000000	sale	38	https://divar.ir/v/_/gaeStFzV	2026-09-27 16:42:50.069728+00	2026-09-27 16:46:01.152763+00	\N	\N	\N	mashhad	140	\N	\N	\N	{"mid": "۴,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک امام هادی (شهرک غرب)", "amounts": {"raw_amount": 4800000000}}	\N
265	divar	ga5ekUqE	آپارتمان فوق لوکس امام رضا ع	امام رضا (ع)	28000000000	sale	\N	https://divar.ir/v/_/ga5ekUqE	2026-09-27 16:42:39.75304+00	2026-09-27 16:46:01.156171+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امام رضا (ع)", "amounts": {"raw_amount": 28000000000}}	\N
266	divar	gaQ6jV0C	ملک مناسب سالن مطالعه و یا یکجا مسکونی	جانباز	\N	rent	\N	https://divar.ir/v/_/gaQ6jV0C	2026-09-27 10:20:08.487917+00	2026-09-27 16:46:01.159765+00	\N	\N	\N	mashhad	\N	\N	\N	2000	{"mid": "اجاره: ۲,۰۰۰ تومان", "bottom": "در جانباز", "amounts": {"اجاره": 2000}}	\N
267	divar	ga5ek_L6	خونه و باغ از شما اجازه روزانه اقامتگاه با ما	حرم مطهر رضوی	\N	rent	\N	https://divar.ir/v/_/ga5ek_L6	2026-09-27 16:44:55.006613+00	2026-09-27 16:46:01.162696+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حرم مطهر رضوی", "amounts": {"اجاره": 1000000}}	\N
268	divar	ga5eUix9	اجاره منزل	بهمن	\N	rent	43	https://divar.ir/v/_/ga5eUix9	2026-09-27 16:43:21.024984+00	2026-09-27 16:46:01.166687+00	\N	\N	\N	mashhad	\N	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهمن", "amounts": {"اجاره": 12000000}}	\N
269	divar	ga5a0GRY	رهن و اجاره آپارتمان	هفت تیر (آب و برق)	\N	rent	\N	https://divar.ir/v/_/ga5a0GRY	2026-09-27 16:36:49.994539+00	2026-09-27 16:46:01.16996+00	\N	\N	\N	mashhad	\N	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (آب و برق)", "amounts": {"اجاره": 40000000}}	\N
270	divar	ga5W0JYk	۱۳۵ متر / صفر / برج ارمغان	فارغ التحصیلان	\N	rent	\N	https://divar.ir/v/_/ga5W0JYk	2026-09-27 16:36:39.852196+00	2026-09-27 16:46:01.172955+00	\N	\N	\N	mashhad	135	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "مسکن امکان بین جلال۳۷و۳۹ در فارغ التحصیلان", "amounts": {"اجاره": 10000}}	\N
271	divar	gaveMFOt	همخونه یاهمخانه میشم آقا هستم خانه ندارم	حضرت حجت	\N	rent	\N	https://divar.ir/v/_/gaveMFOt	2026-09-27 16:36:17.38982+00	2026-09-27 16:46:01.176075+00	\N	\N	\N	mashhad	\N	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "در حضرت حجت", "amounts": {"اجاره": 7000000}}	\N
279	divar	ga5-heug	فرصت سرمایه‌گذاری در پروژه هتلی با مجوز گردشگری	ده دی	250000000000	sale	\N	https://divar.ir/v/_/ga5-heug	2026-09-27 13:52:04.798666+00	2026-09-27 16:56:10.07574+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۵۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در ده دی", "amounts": {"raw_amount": 250000000000}}	\N
280	divar	ga5qkjvE	باغ ویلا اماده سکونت وتفریح	درزآب	6000000000	sale	\N	https://divar.ir/v/_/ga5qkjvE	2026-09-27 16:56:02.037733+00	2026-09-27 16:56:10.080157+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در درزآب", "amounts": {"raw_amount": 6000000000}}	\N
281	divar	ga5q0haZ	۱۱۰ متر / ۲خواب / رحمانیه / لوکیشن قوی	الهیه	12300000000	sale	44	https://divar.ir/v/_/ga5q0haZ	2026-09-27 16:55:45.890499+00	2026-09-27 16:56:10.083534+00	\N	\N	\N	mashhad	110	2	\N	\N	{"mid": "۱۲,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 12300000000}}	\N
282	divar	ga5qkaWL	120متر*دونبش*بدون مشــرف/الهـیـه	الهیه	12300000000	sale	44	https://divar.ir/v/_/ga5qkaWL	2026-09-27 16:55:22.079426+00	2026-09-27 16:56:10.089625+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۱۲,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 12300000000}}	\N
338	divar	ga56kLgA	۱۰۹متر	امیریه	\N	rent	\N	https://divar.ir/v/_/ga56kLgA	2026-09-27 17:11:20.351574+00	2026-09-27 17:16:28.146268+00	\N	\N	\N	mashhad	109	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن باران رتبه یک مشهد در امیریه", "amounts": {}}	\N
283	divar	ga5q0bC4	۹۵متر۲خواب دانشجووکیل آباد/سندتک برگ/بازسازی شده	دانشجو	13500000000	sale	39	https://divar.ir/v/_/ga5q0bC4	2026-09-27 16:55:22.063375+00	2026-09-27 16:56:10.094332+00	\N	\N	\N	mashhad	95	2	\N	\N	{"mid": "۱۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در دانشجو", "amounts": {"raw_amount": 13500000000}}	\N
284	divar	ga5q0MIJ	۶۵ متری طبقه چهارم	طبرسی شمالی	2050000000	sale	42	https://divar.ir/v/_/ga5q0MIJ	2026-09-27 16:55:08.957247+00	2026-09-27 16:56:10.098188+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۲,۰۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در طبرسی شمالی", "amounts": {"raw_amount": 2050000000}}	\N
285	divar	ga5qEShW	122متر/آشپزخانه نورگیر*مدرن*الهیه	الهیه	11950000000	sale	44	https://divar.ir/v/_/ga5qEShW	2026-09-27 16:54:47.747369+00	2026-09-27 16:56:10.102797+00	\N	\N	\N	mashhad	122	\N	\N	\N	{"mid": "۱۱,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 11950000000}}	\N
286	divar	ga5qkHLx	۱۰۵متر فول بازسازی ، قیمت مدت محدود	دانشجو	14100000000	sale	39	https://divar.ir/v/_/ga5qkHLx	2026-09-27 16:54:04.62911+00	2026-09-27 16:56:10.105481+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۴,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رضا الهی نبش فرهنگ یک در دانشجو", "amounts": {"raw_amount": 14100000000}}	\N
287	divar	gaa-2Yg9	باغ ویلا با امتیاز و سنددار	درزآب	1250000000	sale	\N	https://divar.ir/v/_/gaa-2Yg9	2026-09-27 16:54:04.087527+00	2026-09-27 16:56:10.108159+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 1250000000}}	\N
288	divar	ga5mk6pd	اپارتمان۹۵متری هنرستان ۲۳ یا هفت تیر۲۴آکواریوم نور	هنرستان	9500000000	sale	11	https://divar.ir/v/_/ga5mk6pd	2026-09-27 16:53:42.485881+00	2026-09-27 16:56:10.110219+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرستان", "amounts": {"raw_amount": 9500000000}}	\N
290	divar	ga5iUKFa	یک واحد ۹۰ متری اقتصادی رهن و اجاره	وکیل‌آباد	\N	rent	\N	https://divar.ir/v/_/ga5iUKFa	2026-09-27 16:54:43.375938+00	2026-09-27 16:56:10.114564+00	\N	\N	\N	mashhad	90	\N	\N	9000000	{"mid": "اجاره: ۹,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در وکیل‌آباد", "amounts": {"اجاره": 9000000}}	\N
291	divar	ga5qEFn7	۹۵متر آپارتمان طبقه همکف ۱ سال ساخت ( اوکازیون )	شهید بهشتی	\N	rent	18	https://divar.ir/v/_/ga5qEFn7	2026-09-27 16:54:12.63911+00	2026-09-27 16:56:10.117342+00	\N	\N	\N	mashhad	95	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید بهشتی", "amounts": {"اجاره": 100000}}	\N
292	divar	ga5qEFFq	۷۰۰ متر دوبلکس اوایل هاشمیه ،مناسب مشاغل	کوثر	\N	rent	13	https://divar.ir/v/_/ga5qEFFq	2026-09-27 16:53:50.748443+00	2026-09-27 16:56:10.120397+00	\N	\N	\N	mashhad	700	\N	\N	280000000	{"mid": "اجاره: ۲۸۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 280000000}}	\N
293	divar	ga5C0rJS	۱۲۰متر دوخواب ط اول شریعتی شهرک غرب	حسابی جنوبی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga5C0rJS	2026-09-27 16:53:48.779756+00	2026-09-27 16:56:10.124006+00	\N	\N	\N	mashhad	120	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حسابی جنوبی (شهرک غرب)", "amounts": {"اجاره": 10000000}}	\N
294	divar	ga5ik4ZM	اجاره منزل آ‌پارتمانی	خواجه ربیع	\N	rent	\N	https://divar.ir/v/_/ga5ik4ZM	2026-09-27 16:49:50.674951+00	2026-09-27 16:56:10.126967+00	\N	\N	\N	mashhad	\N	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در خواجه ربیع", "amounts": {"اجاره": 12000000}}	\N
295	divar	ga5aEFuo	160 متر/ تک واحدی/ کلید نخورده	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga5aEFuo	2026-09-27 16:49:27.295856+00	2026-09-27 16:56:10.129346+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در چهارچشمه", "amounts": {}}	\N
296	divar	ga5ikm-z	آپارتمان۱۲۰متری فول بازسازی مناسب جهیزیه هفت تیر۱۳	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/ga5ikm-z	2026-09-27 16:48:07.123782+00	2026-09-27 16:56:10.131422+00	\N	\N	\N	mashhad	120	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (حافظ)", "amounts": {"اجاره": 10000}}	\N
297	divar	ga5ikFVX	85متری شیک فول لوکیشن تاپ	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga5ikFVX	2026-09-27 16:46:17.515278+00	2026-09-27 16:56:10.135094+00	\N	\N	\N	mashhad	85	\N	\N	38500000	{"mid": "اجاره: ۳۸,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهارچشمه", "amounts": {"اجاره": 38500000}}	\N
301	divar	gaXeFn4E	فروش آپارتمان ۱۰۱متر توس ۸۷ حاشیه اصلی نارنجیان	شهید بصیر	5500000000	sale	\N	https://divar.ir/v/_/gaXeFn4E	2026-09-27 05:04:38.279394+00	2026-09-27 17:06:19.24255+00	\N	\N	\N	mashhad	101	\N	\N	\N	{"mid": "۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید بصیر", "amounts": {"raw_amount": 5500000000}}	\N
302	divar	ga5yEE7q	فروش آپارتمان	هنرور	5000000000	sale	\N	https://divar.ir/v/_/ga5yEE7q	2026-09-27 17:05:48.55283+00	2026-09-27 17:06:19.250759+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در هنرور", "amounts": {"raw_amount": 5000000000}}	\N
303	divar	ga0a_OiY	صبحان ۷۵ متری	کوی ولیعصر	3300000000	sale	\N	https://divar.ir/v/_/ga0a_OiY	2026-09-27 17:05:27.03048+00	2026-09-27 17:06:19.254946+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۳,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوی ولیعصر", "amounts": {"raw_amount": 3300000000}}	\N
304	divar	ga5ykDAf	ملک دو معبر / عرض 10	انقلاب	7750000000	sale	\N	https://divar.ir/v/_/ga5ykDAf	2026-09-27 17:05:06.868529+00	2026-09-27 17:06:19.260009+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در انقلاب", "amounts": {"raw_amount": 7750000000}}	\N
305	divar	ga5yEjkn	190متر/تک واحدی/محمدیه2/سند آماده	الهیه	23700000000	sale	44	https://divar.ir/v/_/ga5yEjkn	2026-09-27 17:04:24.385345+00	2026-09-27 17:06:19.264349+00	\N	\N	\N	mashhad	190	\N	\N	\N	{"mid": "۲۳,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 23700000000}}	\N
306	divar	gaY6Wj-8	ویلا شیک و مهندسی/مجتمع شرکت برق /کاهو	میان ولایت	12800000000	sale	\N	https://divar.ir/v/_/gaY6Wj-8	2026-09-27 17:04:00.682168+00	2026-09-27 17:06:19.267935+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 12800000000}}	\N
307	divar	ga3yHQzV	فروش منزل ویلایی	شهرک مهر آباد	8000000000	sale	\N	https://divar.ir/v/_/ga3yHQzV	2026-09-27 17:03:38.270361+00	2026-09-27 17:06:19.271012+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک مهر آباد", "amounts": {"raw_amount": 8000000000}}	\N
309	divar	gauCaOpR	۹۰ متر /دونبش /تمام نور	الهیه	\N	rent	44	https://divar.ir/v/_/gauCaOpR	2026-09-19 14:47:36.507265+00	2026-09-27 17:06:19.276686+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در الهیه", "amounts": {}}	\N
310	divar	ga5ajfYs	لادن 41 ( ۱۰۵ متری، تخلیه)	شهرآرا	\N	rent	3	https://divar.ir/v/_/ga5ajfYs	2026-09-27 17:04:11.719695+00	2026-09-27 17:06:19.280058+00	\N	\N	\N	mashhad	105	\N	\N	26000000	{"mid": "اجاره: ۲۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرآرا", "amounts": {"اجاره": 26000000}}	\N
311	divar	ga5u0qm_	۱۲۰منر /صفر/سه نبش	الهیه	\N	rent	44	https://divar.ir/v/_/ga5u0qm_	2026-09-27 17:03:41.345168+00	2026-09-27 17:06:19.283026+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در الهیه", "amounts": {}}	\N
312	divar	ga5yEKfZ	آپارتمان 65 متری یک خوابه تمیز	هدایت	\N	rent	26	https://divar.ir/v/_/ga5yEKfZ	2026-09-27 17:02:42.780929+00	2026-09-27 17:06:19.286349+00	\N	\N	\N	mashhad	65	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هدایت", "amounts": {"اجاره": 10000000}}	\N
313	divar	ga5ukf9_	رهن خانه در رسالت 138	همت آباد	\N	rent	\N	https://divar.ir/v/_/ga5ukf9_	2026-09-27 17:02:42.456362+00	2026-09-27 17:06:19.289349+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "دقایقی پیش در همت آباد", "amounts": {"اجاره": 10000}}	\N
314	divar	ga1ql2Wg	320 متر/مجموعه ابی ورزشی/ سجاد بنفشه	سجاد شهر	\N	rent	21	https://divar.ir/v/_/ga1ql2Wg	2026-09-27 17:02:42.179984+00	2026-09-27 17:06:19.29196+00	\N	\N	\N	mashhad	320	\N	\N	200000000	{"mid": "اجاره: ۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در سجاد شهر", "amounts": {"اجاره": 200000000}}	\N
315	divar	gaZKmpd5	آپارتمان ۳ خواب/تراس بزرگ/نوساز/اقدسیه	الهیه	\N	rent	44	https://divar.ir/v/_/gaZKmpd5	2026-09-27 16:58:45.402218+00	2026-09-27 17:06:19.295128+00	\N	\N	\N	mashhad	\N	3	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"اجاره": 30000000}}	\N
316	divar	ga5qE-e0	یک واحد آپارتمان ۴۵ متری نوساز ویک خواب طبقه۳	کارگران	\N	rent	40	https://divar.ir/v/_/ga5qE-e0	2026-09-27 16:57:47.145725+00	2026-09-27 17:06:19.298004+00	\N	\N	\N	mashhad	45	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کارگران", "amounts": {"اجاره": 3000000}}	\N
317	divar	ga5qkHgg	خانه دررسالت ۹۱	سیس‌آباد	\N	rent	\N	https://divar.ir/v/_/ga5qkHgg	2026-09-27 16:56:41.39408+00	2026-09-27 17:06:19.300982+00	\N	\N	\N	mashhad	\N	\N	\N	300000000	{"mid": "اجاره: ۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سیس‌آباد", "amounts": {"اجاره": 300000000}}	\N
324	divar	ga5-kCNi	واحد همکف 85 متری آزاده 32	یوسفیه (شهرک غرب)	3500000000	sale	38	https://divar.ir/v/_/ga5-kCNi	2026-09-27 17:16:02.191319+00	2026-09-27 17:16:28.095357+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در یوسفیه (شهرک غرب)", "amounts": {"raw_amount": 3500000000}}	\N
325	divar	gavWXScz	آپارتمان 50 متری صفر،ویو دلباز،لوکیشن قوی،زیر قیمت	گلبرگ	2600000000	sale	\N	https://divar.ir/v/_/gavWXScz	2026-09-27 17:15:38.468614+00	2026-09-27 17:16:28.104076+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۲,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در گلبرگ", "amounts": {"raw_amount": 2600000000}}	\N
326	divar	ga56EyhQ	ویلایی ۱۷۰ متری شهرک امام سجاد	شهرک امام سجاد	6800000000	sale	21	https://divar.ir/v/_/ga56EyhQ	2026-09-27 17:15:11.910736+00	2026-09-27 17:16:28.108027+00	\N	\N	\N	mashhad	170	\N	\N	\N	{"mid": "۶,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک امام سجاد", "amounts": {"raw_amount": 6800000000}}	\N
327	divar	ga52EBNw	منزل فروشی  کشمیری جاده سیمان	شهید علی محمدی	1600000000	sale	\N	https://divar.ir/v/_/ga52EBNw	2026-09-27 17:14:20.296026+00	2026-09-27 17:16:28.111926+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید علی محمدی", "amounts": {"raw_amount": 1600000000}}	\N
328	divar	ga3icA8i	۲۴۰ متر زمین با پروانه اماده در۳ طبقه ۵ واحد مجاز	کشف	5800000000	sale	\N	https://divar.ir/v/_/ga3icA8i	2026-09-27 17:12:43.640892+00	2026-09-27 17:16:28.116197+00	\N	\N	\N	mashhad	240	\N	\N	\N	{"mid": "۵,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کشف", "amounts": {"raw_amount": 5800000000}}	\N
329	divar	ga56UZ0u	۷۰ متری ۲ خواب مستر ، ۵ دقیقه تا حرم ، فول متریال	آیت الله خامنه‌ای	17500000000	sale	\N	https://divar.ir/v/_/ga56UZ0u	2026-09-27 17:12:34.618866+00	2026-09-27 17:16:28.120531+00	\N	\N	\N	mashhad	70	2	\N	\N	{"mid": "۱۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آیت الله خامنه‌ای", "amounts": {"raw_amount": 17500000000}}	\N
330	divar	ga5yEGas	کوهسنگی ..رودکی 18..	شهید بهشتی	11500000000	sale	18	https://divar.ir/v/_/ga5yEGas	2026-09-27 17:11:11.167937+00	2026-09-27 17:16:28.124395+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید بهشتی", "amounts": {"raw_amount": 11500000000}}	\N
331	divar	gapNbG_L	هوم یار/آپارتمان ۱۴۰متری/تکواحدی	الهیه	14200000000	sale	44	https://divar.ir/v/_/gapNbG_L	2026-09-27 17:10:43.608759+00	2026-09-27 17:16:28.127755+00	\N	\N	\N	mashhad	140	\N	\N	\N	{"mid": "۱۴,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 14200000000}}	\N
332	divar	gabKAEp4	آپارتمان 110متری اول رحمانیه/10 واحدی/کار مدرن	الهیه	14500000000	sale	44	https://divar.ir/v/_/gabKAEp4	2026-09-27 17:10:34.335662+00	2026-09-27 17:16:28.131088+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۱۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 14500000000}}	\N
333	divar	gaTqw7JX	فروش آپارتمان بی رقیب در اوایل سیدرضی	فرهنگ	23000000000	sale	\N	https://divar.ir/v/_/gaTqw7JX	2026-09-27 17:09:40.818512+00	2026-09-27 17:16:28.134149+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فرهنگ", "amounts": {"raw_amount": 23000000000}}	\N
334	divar	galOaLis	رهن کامل	سیس‌آباد	\N	rent	\N	https://divar.ir/v/_/galOaLis	2026-09-26 17:23:16.17728+00	2026-09-27 17:16:28.136892+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "در سیس‌آباد", "amounts": {"اجاره": 10000}}	\N
335	divar	gaseG7WA	رهن کامل اپارتمان مبله	عیدگاه	\N	rent	\N	https://divar.ir/v/_/gaseG7WA	2026-09-19 04:45:38.505306+00	2026-09-27 17:16:28.139409+00	\N	\N	\N	mashhad	\N	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "در عیدگاه", "amounts": {"اجاره": 2000000}}	\N
336	divar	ga56EiMV	اجاره آپارتمان مسکونی	رسالت	\N	rent	32	https://divar.ir/v/_/ga56EiMV	2026-09-27 17:12:53.737247+00	2026-09-27 17:16:28.141952+00	\N	\N	\N	mashhad	\N	\N	\N	17000000	{"mid": "اجاره: ۱۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رسالت", "amounts": {"اجاره": 17000000}}	\N
337	divar	ga4tS4oG	کوهسنگی همت رهن.اجاره اپ۱۰۰متر۲خواب ط اول تراس دار	شهید بهشتی	\N	rent	18	https://divar.ir/v/_/ga4tS4oG	2026-09-27 17:11:26.570741+00	2026-09-27 17:16:28.144172+00	\N	\N	\N	mashhad	100	2	\N	16500000	{"mid": "اجاره: ۱۶,۵۰۰,۰۰۰ تومان", "bottom": "در شهید بهشتی", "amounts": {"اجاره": 16500000}}	\N
339	divar	ga5aktNI	رهن واجاره درمجتمع طاش /اقدسیه	الهیه	\N	rent	44	https://divar.ir/v/_/ga5aktNI	2026-09-27 17:11:16.819571+00	2026-09-27 17:16:28.148735+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"اجاره": 10000000}}	\N
340	divar	ga520oEN	آپارتمان ۷۰ متری	هفت تیر (نه دره)	\N	rent	\N	https://divar.ir/v/_/ga520oEN	2026-09-27 17:09:02.250838+00	2026-09-27 17:16:28.152036+00	\N	\N	\N	mashhad	70	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (نه دره)", "amounts": {"اجاره": 12000000}}	\N
341	divar	ga52kVCU	رهن کامل آپارتمان ۸۰ متری	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga52kVCU	2026-09-27 17:07:41.796766+00	2026-09-27 17:16:28.155336+00	\N	\N	\N	mashhad	80	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"اجاره": 10000}}	\N
342	divar	ga52EFqs	اجاره واحداپارتمان دوخوابه رضاشهر	رضاشهر	\N	rent	\N	https://divar.ir/v/_/ga52EFqs	2026-09-27 17:06:41.674287+00	2026-09-27 17:16:28.158493+00	\N	\N	\N	mashhad	\N	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاشهر", "amounts": {"اجاره": 6000000}}	\N
345	divar	gar6fzeL	هتل 1040 متری/6 طبقه 15 واحدی/سندآستانه	امام رضا (ع)	230000000000	sale	\N	https://divar.ir/v/_/gar6fzeL	2026-09-17 14:53:09.806025+00	2026-09-27 17:26:36.789301+00	\N	\N	\N	mashhad	1040	\N	\N	\N	{"mid": "۲۳۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 230000000000}}	\N
346	divar	gazaJol-	فروش آپارتمان خیابان امام رضا ۱۱۳ متر	کوشش	33900000000	sale	\N	https://divar.ir/v/_/gazaJol-	2026-09-27 17:25:09.655485+00	2026-09-27 17:26:36.796467+00	\N	\N	\N	mashhad	113	\N	\N	\N	{"mid": "۳۳,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوشش", "amounts": {"raw_amount": 33900000000}}	\N
347	divar	ga5GVYb7	۱۱۸متر / شمالی سرجلو / روبه فضای سبز	شهرک لشکر (شهرک غرب)	12800000000	sale	38	https://divar.ir/v/_/ga5GVYb7	2026-09-27 17:25:02.303218+00	2026-09-27 17:26:36.799409+00	\N	\N	\N	mashhad	118	\N	\N	\N	{"mid": "۱۲,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه مهندسی ساختمانی دیان در شهرک لشکر (شهرک غرب)", "amounts": {"raw_amount": 12800000000}}	\N
348	divar	ga1aqjcV	فروش خانه ۵۰متری ویلای بلوارتوس توس ۶۵ نجف ۲۴	نوده	1400000000	sale	\N	https://divar.ir/v/_/ga1aqjcV	2026-09-27 17:24:16.682158+00	2026-09-27 17:26:36.802494+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۱,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوده", "amounts": {"raw_amount": 1400000000}}	\N
349	divar	ga5CF_LJ	آپارتمان	راهنمایی	9900000000	sale	\N	https://divar.ir/v/_/ga5CF_LJ	2026-09-27 17:24:05.652885+00	2026-09-27 17:26:36.805335+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در راهنمایی", "amounts": {"raw_amount": 9900000000}}	\N
350	divar	galCKPIM	یک واحد آپارتمان۱۰۰متری با پارکینگ و آسانسور	حضرت حجت	5250000000	sale	\N	https://divar.ir/v/_/galCKPIM	2026-09-27 17:23:48.701302+00	2026-09-27 17:26:36.809609+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۵,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در حضرت حجت", "amounts": {"raw_amount": 5250000000}}	\N
351	divar	gay2lEHE	ویلایی 100 متر سه طبقه چهارراه گاز رسالت31 -المهدی	حیدرآباد	15600000000	sale	\N	https://divar.ir/v/_/gay2lEHE	2026-09-27 17:22:56.573372+00	2026-09-27 17:26:36.813108+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۵,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در حیدرآباد", "amounts": {"raw_amount": 15600000000}}	\N
353	divar	ga5GVVY7	هم خونه بدون حاشیه میخوام	الهیه	\N	rent	44	https://divar.ir/v/_/ga5GVVY7	2026-09-27 17:25:19.815212+00	2026-09-27 17:26:36.821963+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"اجاره": 5000000}}	\N
354	divar	ga5CFG88	منزل دروی	کوی دروی	\N	rent	\N	https://divar.ir/v/_/ga5CFG88	2026-09-27 17:19:33.716909+00	2026-09-27 17:26:36.825709+00	\N	\N	\N	mashhad	\N	\N	\N	1500000	{"mid": "اجاره: ۱,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی دروی", "amounts": {"اجاره": 1500000}}	\N
355	divar	ga5-kyRG	اجاره یک طبقه در نسترن یاران	هفده شهریور	\N	rent	\N	https://divar.ir/v/_/ga5-kyRG	2026-09-27 17:18:11.541379+00	2026-09-27 17:26:36.829617+00	\N	\N	\N	mashhad	\N	\N	\N	22000000	{"mid": "اجاره: ۲۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفده شهریور", "amounts": {"اجاره": 22000000}}	\N
363	divar	ga5O1DUT	خانه 80متر دو طبقه	نیزه	6500000000	sale	\N	https://divar.ir/v/_/ga5O1DUT	2026-09-27 17:36:29.149809+00	2026-09-27 17:36:46.046069+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در نیزه", "amounts": {"raw_amount": 6500000000}}	\N
364	divar	gaAKIixq	۲۵۰متر صفر/الهیه/خوش نقشه/مدرن/لوکسvip	الهیه	23000000000	sale	44	https://divar.ir/v/_/gaAKIixq	2026-09-27 17:36:22.717437+00	2026-09-27 17:36:46.050243+00	\N	\N	\N	mashhad	250	\N	\N	\N	{"mid": "۲۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 23000000000}}	\N
365	divar	ganCKSUB	۱۰۰ مترصفر/برند آرین/روف گاردن مدرن/لابی مجلل	الهیه	18000000000	sale	44	https://divar.ir/v/_/ganCKSUB	2026-09-27 17:36:06.571798+00	2026-09-27 17:36:46.053493+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 18000000000}}	\N
366	divar	gaeaOdXg	زمین در کشمیری سمت مهرگان	شهرک مهرگان	2700000000	sale	\N	https://divar.ir/v/_/gaeaOdXg	2026-09-27 17:36:02.451427+00	2026-09-27 17:36:46.055723+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک مهرگان", "amounts": {"raw_amount": 2700000000}}	\N
367	divar	gaTUkAl_	۱۲۰ متر صفر/برند آرین/حیاط مرکزی /سند آماده	الهیه	19900000000	sale	44	https://divar.ir/v/_/gaTUkAl_	2026-09-27 17:35:35.88117+00	2026-09-27 17:36:46.058724+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۱۹,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 19900000000}}	\N
368	divar	gazuPXvE	شکار واقعی جلال + قبل فرهنگ + زیرقیمتِ چشمگیر	آزادشهر	36800000000	sale	\N	https://divar.ir/v/_/gazuPXvE	2026-09-27 17:35:08.94427+00	2026-09-27 17:36:46.060975+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳۶,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری عالیجناب در آزادشهر", "amounts": {"raw_amount": 36800000000}}	\N
369	divar	ga5OVuUC	۱۹۵متر تک واحدی مجیدیه ۳	الهیه	24000000000	sale	44	https://divar.ir/v/_/ga5OVuUC	2026-09-27 17:35:00.179733+00	2026-09-27 17:36:46.06308+00	\N	\N	\N	mashhad	195	\N	\N	\N	{"mid": "۲۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در الهیه", "amounts": {"raw_amount": 24000000000}}	\N
470	divar	ga1CUBN3	همخانه/باهم خونه بگیریم	فلسطین	\N	rent	19	https://divar.ir/v/_/ga1CUBN3	2026-09-28 12:33:34.411523+00	2026-09-28 12:46:16.597983+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "در فلسطین", "amounts": {"اجاره": 5000000}}	\N
370	divar	gazGbB8C	مدرس قبل فرهنگ خاص‌تر از چیزی که در آگهی می‌بینید	آزادشهر	39000000000	sale	\N	https://divar.ir/v/_/gazGbB8C	2026-09-27 17:34:28.344053+00	2026-09-27 17:36:46.065141+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری عالیجناب در آزادشهر", "amounts": {"raw_amount": 39000000000}}	\N
371	divar	gawlqX-w	مدرس‌قبل‌فرهنگ/قطعا مثلشو نمی‌بینی اونم بااین قیمت	آزادشهر	44000000000	sale	\N	https://divar.ir/v/_/gawlqX-w	2026-09-27 17:33:51.28759+00	2026-09-27 17:36:46.067591+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری عالیجناب در آزادشهر", "amounts": {"raw_amount": 44000000000}}	\N
372	divar	ga5OFIWA	آپارتمان ۱۱۰ متری توس۳۳،نسترن	کشف	5000000000	sale	\N	https://divar.ir/v/_/ga5OFIWA	2026-09-27 17:33:15.83068+00	2026-09-27 17:36:46.069588+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کشف", "amounts": {"raw_amount": 5000000000}}	\N
373	divar	gaV2jKYD	زمین خالی ۱۷۰۰ متری در گوارشک	توس فردوسی	1700000000	sale	\N	https://divar.ir/v/_/gaV2jKYD	2026-09-27 17:33:01.799981+00	2026-09-27 17:36:46.071628+00	\N	\N	\N	mashhad	1700	\N	\N	\N	{"mid": "۱,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس فردوسی", "amounts": {"raw_amount": 1700000000}}	\N
374	divar	gafxgrnJ	باغ ۱۲۰۰متر	بهار	5200000000	sale	\N	https://divar.ir/v/_/gafxgrnJ	2026-09-27 17:31:23.77594+00	2026-09-27 17:36:46.073616+00	\N	\N	\N	mashhad	1200	\N	\N	\N	{"mid": "۵,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهار", "amounts": {"raw_amount": 5200000000}}	\N
375	divar	ga3WnNRB	رهن /اجاره/ دانش آموز /	دانشجو	\N	rent	39	https://divar.ir/v/_/ga3WnNRB	2026-09-27 15:04:49.9098+00	2026-09-27 17:36:46.075597+00	\N	\N	\N	mashhad	\N	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "در دانشجو", "amounts": {"اجاره": 6000000}}	\N
376	divar	ga5Olvy-	واحد ۹۰ متری  ، خوش نقشه و نوساز در حسابی	فرهنگیان (شهرک غرب)	\N	rent	37	https://divar.ir/v/_/ga5Olvy-	2026-09-27 17:35:28.508962+00	2026-09-27 17:36:46.078187+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در فرهنگیان (شهرک غرب)", "amounts": {}}	\N
377	divar	ga5KFURu	آپترتمان۷۰متری دوخواب صفرکلیدنخورده	سرافرازان	\N	rent	22	https://divar.ir/v/_/ga5KFURu	2026-09-27 17:35:02.185064+00	2026-09-27 17:36:46.080272+00	\N	\N	\N	mashhad	70	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سرافرازان", "amounts": {"اجاره": 15000000}}	\N
378	divar	ga5K17jO	آپارتمان  ۵۵ متری رهن واجاره	شفا	\N	rent	\N	https://divar.ir/v/_/ga5K17jO	2026-09-27 17:31:35.254013+00	2026-09-27 17:36:46.082496+00	\N	\N	\N	mashhad	55	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شفا", "amounts": {"اجاره": 8000000}}	\N
379	divar	ga5K16aW	رهن کامل	پورسینا	\N	rent	\N	https://divar.ir/v/_/ga5K16aW	2026-09-27 17:31:31.833853+00	2026-09-27 17:36:46.084737+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در پورسینا", "amounts": {}}	\N
380	divar	ga5KlS0B	آپارتمان ۱۷۰متری ۳خوابه فول امکانات	کوثر	\N	rent	13	https://divar.ir/v/_/ga5KlS0B	2026-09-27 17:29:44.414973+00	2026-09-27 17:36:46.086754+00	\N	\N	\N	mashhad	170	3	\N	60000000	{"mid": "اجاره: ۶۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 60000000}}	\N
381	divar	ga5GFBKq	اجاره آپارتمان 80متری دوخوابه توس 65	نوده	\N	rent	\N	https://divar.ir/v/_/ga5GFBKq	2026-09-27 17:29:13.617046+00	2026-09-27 17:36:46.088917+00	\N	\N	\N	mashhad	80	\N	\N	10500000	{"mid": "اجاره: ۱۰,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوده", "amounts": {"اجاره": 10500000}}	\N
390	divar	gayO288w	همکف ۱۰۰ متر با پارکینگ اختصاصی	ایثارگران	8500000000	sale	\N	https://divar.ir/v/_/gayO288w	2026-09-22 11:19:33.056456+00	2026-09-27 17:46:55.305532+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در ایثارگران", "amounts": {"raw_amount": 8500000000}}	\N
391	divar	ga5Wlp4k	حدود ۷۵ متر خوش نقشه دوخواب سند دار نزدیک صد متری	پنجتن	4350000000	sale	\N	https://divar.ir/v/_/ga5Wlp4k	2026-09-27 17:45:40.551186+00	2026-09-27 17:46:55.310512+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۴,۳۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پنجتن", "amounts": {"raw_amount": 4350000000}}	\N
392	divar	ga5WVwEo	آپارتمان ۵۸ متری همکف مطهری شمالی	هنرور	3200000000	sale	\N	https://divar.ir/v/_/ga5WVwEo	2026-09-27 17:44:42.453035+00	2026-09-27 17:46:55.314482+00	\N	\N	\N	mashhad	58	\N	\N	\N	{"mid": "۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"raw_amount": 3200000000}}	\N
393	divar	gazuJQqK	فروش واحد مسکونی	شهید معقول	1300000000	sale	\N	https://divar.ir/v/_/gazuJQqK	2026-09-27 17:44:25.256683+00	2026-09-27 17:46:55.319106+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید معقول", "amounts": {"raw_amount": 1300000000}}	\N
394	divar	ga5W1EDz	هنرور ۵ انتظاری ۱۷ معاوضه با خودرو	هنرور	6000000000	sale	\N	https://divar.ir/v/_/ga5W1EDz	2026-09-27 17:41:02.408896+00	2026-09-27 17:46:55.323752+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"raw_amount": 6000000000}}	\N
395	divar	gag6DKJY	85متری شمالی سرجلو تهاتربا اسانسور یا کابینت	میعاد (شهرک غرب)	9900000000	sale	38	https://divar.ir/v/_/gag6DKJY	2026-09-27 17:40:35.666289+00	2026-09-27 17:46:55.328025+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۹,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در میعاد (شهرک غرب)", "amounts": {"raw_amount": 9900000000}}	\N
396	divar	ga5WlBlk	۷۵ متر امامت زوج بعدازآموزگار مسکن الهی مهندس دانش	زیبا شهر	10500000000	sale	\N	https://divar.ir/v/_/ga5WlBlk	2026-09-27 17:40:32.503876+00	2026-09-27 17:46:55.331955+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۱۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن   الهی    نبش امامت ۴۶ در زیبا شهر", "amounts": {"raw_amount": 10500000000}}	\N
397	divar	ga5SV0AY	آپارتمان ۱۰۵ متری / مجیدیه/آفتابگیر	جاهد شهر	10800000000	sale	41	https://divar.ir/v/_/ga5SV0AY	2026-09-27 17:40:22.688894+00	2026-09-27 17:46:55.340023+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۰,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"raw_amount": 10800000000}}	\N
398	divar	gaRGW_Sn	۱۱۸ متر / سند دار/ نوساز / مدرن / رحمانیه	الهیه	13750000000	sale	44	https://divar.ir/v/_/gaRGW_Sn	2026-09-27 17:40:19.559973+00	2026-09-27 17:46:55.345826+00	\N	\N	\N	mashhad	118	\N	\N	\N	{"mid": "۱۳,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 13750000000}}	\N
399	divar	gay2O9RH	زمین دو نبش ۳۰۰ متری  با حاشیه۱۲متر	امیریه	19100000000	sale	\N	https://divar.ir/v/_/gay2O9RH	2026-09-27 17:40:07.735582+00	2026-09-27 17:46:55.354431+00	\N	\N	\N	mashhad	300	\N	\N	\N	{"mid": "۱۹,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در امیریه", "amounts": {"raw_amount": 19100000000}}	\N
400	divar	ga5SVcJe	فروش آپارتمان جلال/125متری/زیرفی	زیبا شهر	16150000000	sale	\N	https://divar.ir/v/_/ga5SVcJe	2026-09-27 17:38:42.019549+00	2026-09-27 17:46:55.360791+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۱۶,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "بورس خریدوفروش مشهدملک در زیبا شهر", "amounts": {"raw_amount": 16150000000}}	\N
401	divar	ga5OVxNt	آپارتمان فروشی شریعتی ۱۰۲متر	حسابی جنوبی (شهرک غرب)	11200000000	sale	38	https://divar.ir/v/_/ga5OVxNt	2026-09-27 17:38:14.837845+00	2026-09-27 17:46:55.3661+00	\N	\N	\N	mashhad	102	\N	\N	\N	{"mid": "۱۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حسابی جنوبی (شهرک غرب)", "amounts": {"raw_amount": 11200000000}}	\N
402	divar	ga2CgQhm	آپارتمان بهترین نقطه دانشسراشمالی خ مانی	سعد آباد	\N	rent	\N	https://divar.ir/v/_/ga2CgQhm	2026-09-26 12:24:32.374418+00	2026-09-27 17:46:55.370147+00	\N	\N	\N	mashhad	\N	\N	\N	33000000	{"mid": "اجاره: ۳۳,۰۰۰,۰۰۰ تومان", "bottom": "در سعد آباد", "amounts": {"اجاره": 33000000}}	\N
403	divar	gaqu6-93	رهن و اجاره/۱۸۰متر/تخلیه/حاشیه اقدسیه/مالک هستم	جاهد شهر	\N	rent	41	https://divar.ir/v/_/gaqu6-93	2026-09-25 16:16:45.619812+00	2026-09-27 17:46:55.37378+00	\N	\N	\N	mashhad	180	\N	\N	21000000	{"mid": "اجاره: ۲۱,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"اجاره": 21000000}}	\N
405	divar	ga5Wl7G8	آپارتمان 80 متری رهن و اجاره	فارغ التحصیلان	\N	rent	\N	https://divar.ir/v/_/ga5Wl7G8	2026-09-27 17:44:43.741147+00	2026-09-27 17:46:55.379474+00	\N	\N	\N	mashhad	80	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن مبینی در فارغ التحصیلان", "amounts": {"اجاره": 10000000}}	\N
406	divar	ga5Wllxq	انوری ۱۶۰ متری صفر ۳ خواب نورگیر	رضاشهر	\N	rent	\N	https://divar.ir/v/_/ga5Wllxq	2026-09-27 17:43:45.362624+00	2026-09-27 17:46:55.382442+00	\N	\N	\N	mashhad	160	3	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاشهر", "amounts": {"اجاره": 100000}}	\N
407	divar	ga5WVNXP	خانه ۵۵ متری چاهشک قیمت مناسب رهن کامل	چاهشک	\N	rent	\N	https://divar.ir/v/_/ga5WVNXP	2026-09-27 17:41:20.398515+00	2026-09-27 17:46:55.385133+00	\N	\N	\N	mashhad	55	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در چاهشک", "amounts": {}}	\N
408	divar	ga2GjN-A	همخونه میشم	احمدآباد	\N	rent	\N	https://divar.ir/v/_/ga2GjN-A	2026-09-27 17:39:41.770049+00	2026-09-27 17:46:55.38775+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در احمدآباد", "amounts": {"اجاره": 10000000}}	\N
409	divar	ga5SVlYl	۱۵۵ متری امامت/طبقه ۳	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga5SVlYl	2026-09-27 17:38:41.023672+00	2026-09-27 17:46:55.390888+00	\N	\N	\N	mashhad	155	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "اژانس اریا در آزادشهر", "amounts": {"اجاره": 10000000}}	\N
410	divar	ga5SlNUh	اجاره آپارتمان	محمدآباد	\N	rent	\N	https://divar.ir/v/_/ga5SlNUh	2026-09-27 17:37:02.298341+00	2026-09-27 17:46:55.393646+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در محمدآباد", "amounts": {"اجاره": 10000000}}	\N
421	divar	QaRN08BI	محله زشک 400زمین اقساط ویلا سازی	باغون آباد	1200000000	sale	\N	https://divar.ir/v/_/QaRN08BI	2026-09-27 17:55:06.025717+00	2026-09-27 17:57:05.117806+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در باغون آباد", "amounts": {"raw_amount": 1200000000}}	\N
422	divar	ga0aUnqq	آپارتمان ۶۰متر صفر نزدیک حرم فوری	هفده شهریور	9300000000	sale	\N	https://divar.ir/v/_/ga0aUnqq	2026-09-27 17:54:34.076736+00	2026-09-27 17:57:05.122735+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۹,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفده شهریور", "amounts": {"raw_amount": 9300000000}}	\N
423	divar	ga5SjOKG	معاوضه باغ ویلا با آپارتمان محدوده میثاق	میان ولایت	3500000000	sale	\N	https://divar.ir/v/_/ga5SjOKG	2026-09-27 17:53:39.434559+00	2026-09-27 17:57:05.125878+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 3500000000}}	\N
424	divar	gayWSiss	220 متر منزل ویلایی 310 متر کل زمین،	میان ولایت	5900000000	sale	\N	https://divar.ir/v/_/gayWSiss	2026-09-27 17:52:21.841904+00	2026-09-27 17:57:05.128899+00	\N	\N	\N	mashhad	220	\N	\N	\N	{"mid": "۵,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 5900000000}}	\N
425	divar	ga5eFPeL	زمین گلبهار محله 12	هنرستان	20000000000	sale	11	https://divar.ir/v/_/ga5eFPeL	2026-09-27 17:51:01.863489+00	2026-09-27 17:57:05.131469+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرستان", "amounts": {"raw_amount": 20000000000}}	\N
426	divar	ga5eVLLp	یک خانه دررسالت  ۹۱	سیس‌آباد	250000000	sale	\N	https://divar.ir/v/_/ga5eVLLp	2026-09-27 17:50:37.908759+00	2026-09-27 17:57:05.134806+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سیس‌آباد", "amounts": {"raw_amount": 250000000}}	\N
427	divar	ga5e1HsP	۱۰۰ متر / ۲ خواب / طبقه طلایی / لوکیشن طلایی	الهیه	10000000000	sale	44	https://divar.ir/v/_/ga5e1HsP	2026-09-27 17:49:58.069067+00	2026-09-27 17:57:05.137335+00	\N	\N	\N	mashhad	100	2	\N	\N	{"mid": "۱۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پامچال در الهیه", "amounts": {"raw_amount": 10000000000}}	\N
429	divar	gahGRcLC	واحد ۷۰ متری توس ۳۰	شهرک امام هادی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/gahGRcLC	2026-09-27 17:56:56.584842+00	2026-09-27 17:57:05.142005+00	\N	\N	\N	mashhad	70	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک امام هادی (شهرک غرب)", "amounts": {"اجاره": 8000000}}	\N
430	divar	ga3KbhAs	همخونه خانم	بهشت	\N	rent	18	https://divar.ir/v/_/ga3KbhAs	2026-09-27 17:56:40.981114+00	2026-09-27 17:57:05.144186+00	\N	\N	\N	mashhad	\N	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهشت", "amounts": {"اجاره": 20000000}}	\N
431	divar	ga5i1TzP	همخونه هم خانه	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga5i1TzP	2026-09-27 17:54:30.393772+00	2026-09-27 17:57:05.146787+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگ", "amounts": {"اجاره": 1000000}}	\N
432	divar	ga5iVFWj	خانه ویلایی تمیز با حیاط بزرگ رسالت ۹۱	سیس‌آباد	\N	rent	\N	https://divar.ir/v/_/ga5iVFWj	2026-09-27 17:53:49.663513+00	2026-09-27 17:57:05.149018+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در سیس‌آباد", "amounts": {}}	\N
433	divar	ga5KF-TI	واحد ۵۰ متری تمیز و شیک حاشیه ابرار ۸.۳	یوسفیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga5KF-TI	2026-09-27 17:53:39.438285+00	2026-09-27 17:57:05.151258+00	\N	\N	\N	mashhad	50	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در یوسفیه (شهرک غرب)", "amounts": {"اجاره": 8000000}}	\N
434	divar	ga5alusn	خانه ی زیبا در محدوده ابوطالب	ایثارگران	\N	rent	\N	https://divar.ir/v/_/ga5alusn	2026-09-27 17:49:19.316316+00	2026-09-27 17:57:05.153798+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثارگران", "amounts": {"اجاره": 8000000}}	\N
449	divar	gaiG7JEO	اپارتمان  ثنایی	توس (بلوار توس)	2230000000	sale	\N	https://divar.ir/v/_/gaiG7JEO	2026-09-28 12:45:46.976809+00	2026-09-28 12:46:16.528273+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۲۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس (بلوار توس)", "amounts": {"raw_amount": 2230000000}}	\N
450	divar	ga6G2XPw	110 متری / برند قصر / 2 واحدی / طبقه سوم	جاهد شهر	13000000000	sale	41	https://divar.ir/v/_/ga6G2XPw	2026-09-28 12:45:28.694382+00	2026-09-28 12:46:16.543646+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۱۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 13000000000}}	\N
451	divar	ga6CGxJz	۱۰۶متر آپارتمان تک واحدی	حسین‌آباد	7500000000	sale	\N	https://divar.ir/v/_/ga6CGxJz	2026-09-28 12:42:55.740753+00	2026-09-28 12:46:16.547312+00	\N	\N	\N	mashhad	106	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری سراسری سلیمانی در حسین‌آباد", "amounts": {"raw_amount": 7500000000}}	\N
452	divar	gaxKVK9k	آپارتمان سه خواب/ ۱۴۲ مترصفر/نورگیر /دونبش/ کامیاب	شهید مطهری	11900000000	sale	28	https://divar.ir/v/_/gaxKVK9k	2026-09-28 12:42:37.55547+00	2026-09-28 12:46:16.550183+00	\N	\N	\N	mashhad	142	\N	\N	\N	{"mid": "۱۱,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید مطهری", "amounts": {"raw_amount": 11900000000}}	\N
453	divar	ga6CmZ8y	80 متر با پارکینگ اختصاصی* اندیشه *	مشکینی (شهرک غرب)	4800000000	sale	38	https://divar.ir/v/_/ga6CmZ8y	2026-09-28 12:42:14.452293+00	2026-09-28 12:46:16.552736+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۴,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مشکینی (شهرک غرب)", "amounts": {"raw_amount": 4800000000}}	\N
454	divar	gazq3gwh	فروش آپارتمان۵۶ متری بازسازی شده سندآماده درالهیه	الهیه	5300000000	sale	44	https://divar.ir/v/_/gazq3gwh	2026-09-28 12:41:38.591485+00	2026-09-28 12:46:16.555499+00	\N	\N	\N	mashhad	56	\N	\N	\N	{"mid": "۵,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن وکارگزاری پارسا در الهیه", "amounts": {"raw_amount": 5300000000}}	\N
455	divar	gazOI3Rz	واحد نوساز و کلید نخورده ۲ خواب ۷۵ متر	طبرسی شمالی	3600000000	sale	42	https://divar.ir/v/_/gazOI3Rz	2026-09-28 12:41:07.374234+00	2026-09-28 12:46:16.557874+00	\N	\N	\N	mashhad	75	2	\N	\N	{"mid": "۳,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "محمدرضا مبینی در طبرسی شمالی", "amounts": {"raw_amount": 3600000000}}	\N
456	divar	gaz-oD4Y	فروش آپارتمان ۱۶۰متری سه(۳)خواب تک واحدی در امیریه	امیریه	15100000000	sale	\N	https://divar.ir/v/_/gaz-oD4Y	2026-09-28 12:40:54.841349+00	2026-09-28 12:46:16.559991+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۱۵,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن وکارگزاری پارسا در امیریه", "amounts": {"raw_amount": 15100000000}}	\N
457	divar	gaq2U9lt	۸۰ متر فول امکانات /دونبش غرق نور/صیاد	هفت تیر (آب و برق)	9500000000	sale	\N	https://divar.ir/v/_/gaq2U9lt	2026-09-28 12:40:46.604114+00	2026-09-28 12:46:16.562787+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (آب و برق)", "amounts": {"raw_amount": 9500000000}}	\N
458	divar	gapKzzfx	آپارتمان	حضرت حجت	4100000000	sale	\N	https://divar.ir/v/_/gapKzzfx	2026-09-28 12:40:30.275663+00	2026-09-28 12:46:16.565067+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در حضرت حجت", "amounts": {"raw_amount": 4100000000}}	\N
459	divar	gauSHRt8	اجاره آپارتمان ۱۰۵ مترشخصی ساز صفر حاشیه اقدسیه	الهیه	\N	rent	44	https://divar.ir/v/_/gauSHRt8	2026-09-25 14:13:17.390145+00	2026-09-28 12:46:16.568572+00	\N	\N	\N	mashhad	105	\N	\N	26000000	{"mid": "اجاره: ۲۶,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سراسری آزموده ۴راه ورزش شریعتی بین ۵۴و۵۲ در الهیه", "amounts": {"اجاره": 26000000}}	\N
460	divar	ga6GWNtq	اجاره اپارتمان	کشف	\N	rent	\N	https://divar.ir/v/_/ga6GWNtq	2026-09-28 12:44:45.694625+00	2026-09-28 12:46:16.571247+00	\N	\N	\N	mashhad	\N	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کشف", "amounts": {"اجاره": 12000000}}	\N
461	divar	ga6CWN3H	آپارتمان رهن کامل	نظام دوست	\N	rent	\N	https://divar.ir/v/_/ga6CWN3H	2026-09-28 12:41:42.422901+00	2026-09-28 12:46:16.573571+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نظام دوست", "amounts": {"اجاره": 100000}}	\N
462	divar	ga6-VaRU	اجاره اپارتمان	شهید هاشمی نژاد	\N	rent	\N	https://divar.ir/v/_/ga6-VaRU	2026-09-28 12:40:12.224428+00	2026-09-28 12:46:16.576385+00	\N	\N	\N	mashhad	\N	\N	\N	2100000	{"mid": "اجاره: ۲,۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید هاشمی نژاد", "amounts": {"اجاره": 2100000}}	\N
463	divar	ga6-FWUf	۱۰۰متری/امامت/تخلیه/آسانسور دار	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga6-FWUf	2026-09-28 12:38:44.698524+00	2026-09-28 12:46:16.57888+00	\N	\N	\N	mashhad	100	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آزادشهر", "amounts": {"اجاره": 15000000}}	\N
464	divar	ga6-VpJ7	اجاره خانه همکف	خرمشهر	\N	rent	\N	https://divar.ir/v/_/ga6-VpJ7	2026-09-28 12:38:16.413619+00	2026-09-28 12:46:16.581691+00	\N	\N	\N	mashhad	\N	\N	\N	17000000	{"mid": "اجاره: ۱۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در خرمشهر", "amounts": {"اجاره": 17000000}}	\N
465	divar	ga6-1Gls	اجاره آپارتمان ۲۰۰ متری ۳ خوابه حاشیه بلوار شاهد	شاهد (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6-1Gls	2026-09-28 12:35:47.536771+00	2026-09-28 12:46:16.584419+00	\N	\N	\N	mashhad	200	3	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در شاهد (شهرک غرب)", "amounts": {}}	\N
466	divar	ga66Vq3t	اجاره آپارتمان طبقه همکف	شهرک مهر آباد	\N	rent	\N	https://divar.ir/v/_/ga66Vq3t	2026-09-28 12:35:14.636181+00	2026-09-28 12:46:16.586705+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک مهر آباد", "amounts": {"اجاره": 5000000}}	\N
467	divar	ga661uGh	اجاره آپارتمان ارمغان همکف	ارمغان	\N	rent	\N	https://divar.ir/v/_/ga661uGh	2026-09-28 12:35:00.11404+00	2026-09-28 12:46:16.589585+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ارمغان", "amounts": {"اجاره": 15000000}}	\N
468	divar	ga66V2N-	۲۶۰متر سجاد / پلان مهندسی / ۲ پارکینگ	سجاد شهر	\N	rent	21	https://divar.ir/v/_/ga66V2N-	2026-09-28 12:34:41.656206+00	2026-09-28 12:46:16.592044+00	\N	\N	\N	mashhad	260	\N	\N	112000000	{"mid": "اجاره: ۱۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سجاد شهر", "amounts": {"اجاره": 112000000}}	\N
469	divar	ga6610yN	اجاره و رهن منزل	انصار	\N	rent	\N	https://divar.ir/v/_/ga6610yN	2026-09-28 12:34:35.90295+00	2026-09-28 12:46:16.594815+00	\N	\N	\N	mashhad	\N	\N	\N	6500000	{"mid": "اجاره: ۶,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در انصار", "amounts": {"اجاره": 6500000}}	\N
471	divar	gam6un2b	۷۰ متراجاره اپارتمان طبقه همکف غفاری۷ پلاک۵۳  نظام	نظام دوست	\N	rent	\N	https://divar.ir/v/_/gam6un2b	2026-09-28 12:33:32.48739+00	2026-09-28 12:46:16.600622+00	\N	\N	\N	mashhad	70	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "در نظام دوست", "amounts": {"اجاره": 5000000}}	\N
472	divar	ga62F38J	یک واحد ۵۵متری دربست راه جدا	یوسفیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga62F38J	2026-09-28 12:30:26.420981+00	2026-09-28 12:46:16.603757+00	\N	\N	\N	mashhad	55	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در یوسفیه (شهرک غرب)", "amounts": {"اجاره": 12000000}}	\N
473	divar	ga6uVbtc	رهن خانه	رده	\N	rent	\N	https://divar.ir/v/_/ga6uVbtc	2026-09-28 12:30:17.286714+00	2026-09-28 12:46:16.60727+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "یک ربع پیش در رده", "amounts": {}}	\N
474	divar	gapqDw-6	رهن و اجاره توس ۱۱۷ خانه ویلایی یک خوابه	دوست آباد	\N	rent	\N	https://divar.ir/v/_/gapqDw-6	2026-09-28 12:28:33.572429+00	2026-09-28 12:46:16.610719+00	\N	\N	\N	mashhad	\N	\N	\N	8500000	{"mid": "اجاره: ۸,۵۰۰,۰۰۰ تومان", "bottom": "در دوست آباد", "amounts": {"اجاره": 8500000}}	\N
475	divar	ga621RIc	90متری محمدیه	الهیه	\N	rent	44	https://divar.ir/v/_/ga621RIc	2026-09-28 12:28:13.281414+00	2026-09-28 12:46:16.613376+00	\N	\N	\N	mashhad	90	\N	\N	14500000	{"mid": "اجاره: ۱۴,۵۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در الهیه", "amounts": {"اجاره": 14500000}}	\N
476	divar	ga62lU4N	آپارتمان ۱۶۰متری صفر	فارغ التحصیلان	\N	rent	\N	https://divar.ir/v/_/ga62lU4N	2026-09-28 12:28:10.804322+00	2026-09-28 12:46:16.615548+00	\N	\N	\N	mashhad	160	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در فارغ التحصیلان", "amounts": {"اجاره": 30000000}}	\N
477	divar	ga6qFz91	اجاره خانه خواجه ربیع بلوار بهمن	خواجه ربیع	\N	rent	\N	https://divar.ir/v/_/ga6qFz91	2026-09-28 12:27:22.582483+00	2026-09-28 12:46:16.618271+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در خواجه ربیع", "amounts": {"اجاره": 8000000}}	\N
478	divar	ga1C0bBP	هنرستان،نسترن۳	نیروی هوایی	12500000000	sale	\N	https://divar.ir/v/_/ga1C0bBP	2026-09-28 12:56:07.687506+00	2026-09-28 12:56:29.287479+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در نیروی هوایی", "amounts": {"raw_amount": 12500000000}}	\N
479	divar	gaiSKx1L	باغ ویلا ۷۰۰ متری شاهنامه ۱۸ معاوضه تهاتر با خودرو	کلاته برفی	3900000000	sale	\N	https://divar.ir/v/_/gaiSKx1L	2026-09-28 12:56:06.973066+00	2026-09-28 12:56:29.296294+00	\N	\N	\N	mashhad	700	\N	\N	\N	{"mid": "۳,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کلاته برفی", "amounts": {"raw_amount": 3900000000}}	\N
480	divar	ga6OWqlL	۵۰متری ویلایی	کوی ولیعصر	2580000000	sale	\N	https://divar.ir/v/_/ga6OWqlL	2026-09-28 12:56:01.079698+00	2026-09-28 12:56:29.299241+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۲,۵۸۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در کوی ولیعصر", "amounts": {"raw_amount": 2580000000}}	\N
481	divar	ga6CmHyL	اپارتمان 50متری نوساز	کوی ولیعصر	2300000000	sale	\N	https://divar.ir/v/_/ga6CmHyL	2026-09-28 12:55:02.922134+00	2026-09-28 12:56:29.301576+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۲,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی ولیعصر", "amounts": {"raw_amount": 2300000000}}	\N
482	divar	gankg2qG	آپارتمان ۸۰ متری توس ۴۱ قابل معاوضه با سمت هدایت و	حضرت حجت	3200000000	sale	\N	https://divar.ir/v/_/gankg2qG	2026-09-28 12:54:39.354405+00	2026-09-28 12:56:29.303804+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در حضرت حجت", "amounts": {"raw_amount": 3200000000}}	\N
483	divar	ga6O2Mm0	منزل ویلایی	نظام دوست	2400000000	sale	\N	https://divar.ir/v/_/ga6O2Mm0	2026-09-28 12:53:46.312264+00	2026-09-28 12:56:29.305837+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نظام دوست", "amounts": {"raw_amount": 2400000000}}	\N
484	divar	gaZ-aMTA	دوطبقه ونیم	شهرک بهارستان	7100000000	sale	\N	https://divar.ir/v/_/gaZ-aMTA	2026-09-28 12:53:36.845385+00	2026-09-28 12:56:29.308016+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک بهارستان", "amounts": {"raw_amount": 7100000000}}	\N
485	divar	ga4ux-DU	باغ ویلای قدمت دار اوایل شاهنامه	کلاته برفی	3500000000	sale	\N	https://divar.ir/v/_/ga4ux-DU	2026-09-28 12:52:55.949753+00	2026-09-28 12:56:29.310239+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "خرید و فروش باغ آپارتمان سوله در کلاته برفی", "amounts": {"raw_amount": 3500000000}}	\N
486	divar	ga5CRQ5x	۲نبش/ابتدای رحمانیه/خاص شیک/بدون مشابه	الهیه	11900000000	sale	44	https://divar.ir/v/_/ga5CRQ5x	2026-09-28 12:52:14.178077+00	2026-09-28 12:56:29.312281+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۱,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مزینانی در الهیه", "amounts": {"raw_amount": 11900000000}}	\N
487	divar	ga6KW6L2	۱۰۵ متر برند آرین عکس واقعی /  ۲ نبش / سند آماده	جاهد شهر	13500000000	sale	41	https://divar.ir/v/_/ga6KW6L2	2026-09-28 12:52:12.162176+00	2026-09-28 12:56:29.314224+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در جاهد شهر", "amounts": {"raw_amount": 13500000000}}	\N
488	divar	ga6K2teG	۱۲۸متر/سند آماده/۸واحدی/دوخواب نور/ارتفاع سقف ۳و۲۰	جاهد شهر	13590000000	sale	41	https://divar.ir/v/_/ga6K2teG	2026-09-28 12:51:17.370286+00	2026-09-28 12:56:29.316248+00	\N	\N	\N	mashhad	128	\N	\N	\N	{"mid": "۱۳,۵۹۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن میرشکاری در جاهد شهر", "amounts": {"raw_amount": 13590000000}}	\N
489	divar	gaTymqwN	باغ610 متر استخر بزرگ کوچیک 40درخت سندتکبرگ	توس فردوسی	685000000	sale	\N	https://divar.ir/v/_/gaTymqwN	2026-09-28 12:50:47.226361+00	2026-09-28 12:56:29.318371+00	\N	\N	\N	mashhad	610	\N	\N	\N	{"mid": "۶۸۵,۰۰۰,۰۰۰ تومان", "bottom": "مجموعه باغی ویلایی خراسانی در توس فردوسی", "amounts": {"raw_amount": 685000000}}	\N
490	divar	ga6KGNb4	۸۲ متر همکف لوکس تک واحدی/اول صیاد شیرازی	صیاد شیرازی	10300000000	sale	4	https://divar.ir/v/_/ga6KGNb4	2026-09-28 12:49:02.388328+00	2026-09-28 12:56:29.320375+00	\N	\N	\N	mashhad	82	\N	\N	\N	{"mid": "۱۰,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در صیاد شیرازی", "amounts": {"raw_amount": 10300000000}}	\N
491	divar	ga2uy9o-	آپارتمان هاشمیه زیر قیمت پول لازم	کوثر	5000000000	sale	13	https://divar.ir/v/_/ga2uy9o-	2026-09-28 12:48:20.334609+00	2026-09-28 12:56:29.322771+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوثر", "amounts": {"raw_amount": 5000000000}}	\N
494	divar	ga65ixeR	سویت اجازه	هفده شهریور	\N	rent	\N	https://divar.ir/v/_/ga65ixeR	2026-09-28 12:53:33.62114+00	2026-09-28 12:56:29.328268+00	\N	\N	\N	mashhad	\N	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "در هفده شهریور", "amounts": {"اجاره": 6000000}}	\N
495	divar	ga6KWb5E	اجاره منزل همکف ۵۰ متری	امام خمینی	\N	rent	\N	https://divar.ir/v/_/ga6KWb5E	2026-09-28 12:49:59.199837+00	2026-09-28 12:56:29.33035+00	\N	\N	\N	mashhad	50	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امام خمینی", "amounts": {"اجاره": 5000000}}	\N
496	divar	ga6KGIQ_	۸۰متر یک خوابه طبقه اول در پاستور	بهشت	\N	rent	18	https://divar.ir/v/_/ga6KGIQ_	2026-09-28 12:49:15.79531+00	2026-09-28 12:56:29.332858+00	\N	\N	\N	mashhad	80	\N	\N	18000000	{"mid": "اجاره: ۱۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهشت", "amounts": {"اجاره": 18000000}}	\N
497	divar	gaeStdZ3	۸۰مترآپارتمان۷تیر۵ روبروی برج آرمیتاج بدون واسطه	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/gaeStdZ3	2026-09-28 12:48:56.563345+00	2026-09-28 12:56:29.33473+00	\N	\N	\N	mashhad	80	\N	\N	23000000	{"mid": "اجاره: ۲۳,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (حافظ)", "amounts": {"اجاره": 23000000}}	\N
498	divar	ga6GG3ed	آپارتمان جهت رهن	خواجه ربیع	\N	rent	\N	https://divar.ir/v/_/ga6GG3ed	2026-09-28 12:47:32.542114+00	2026-09-28 12:56:29.336603+00	\N	\N	\N	mashhad	\N	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در خواجه ربیع", "amounts": {"اجاره": 2000000}}	\N
513	divar	ga6aWI55	آپارتمان طبقه سوم،واحد صفر شیک پارکینگ‌	مشکینی (شهرک غرب)	5050000000	sale	38	https://divar.ir/v/_/ga6aWI55	2026-09-28 13:06:30.016016+00	2026-09-28 13:06:41.304607+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۰۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در مشکینی (شهرک غرب)", "amounts": {"raw_amount": 5050000000}}	\N
514	divar	gas6xz4g	60مترویلایی دربست،آماده سکونت رسالت۱۲۸	همت آباد	1790000000	sale	\N	https://divar.ir/v/_/gas6xz4g	2026-09-28 13:06:18.793489+00	2026-09-28 13:06:41.317428+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۱,۷۹۰,۰۰۰,۰۰۰ تومان", "bottom": "در همت آباد", "amounts": {"raw_amount": 1790000000}}	\N
515	divar	ga6amNer	آپارتمان ۱۱۰متری/کلید نخورده فول /نزدیک حرم	حرم مطهر رضوی	22000000000	sale	\N	https://divar.ir/v/_/ga6amNer	2026-09-28 13:06:12.275275+00	2026-09-28 13:06:41.321126+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۲۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در حرم مطهر رضوی", "amounts": {"raw_amount": 22000000000}}	\N
516	divar	ga6WWt3v	سلام پنجتن 48 قربانی 23 ماشین رو فروشی	شهید قربانی	3000000000	sale	\N	https://divar.ir/v/_/ga6WWt3v	2026-09-28 13:05:37.974639+00	2026-09-28 13:06:41.323947+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهید قربانی", "amounts": {"raw_amount": 3000000000}}	\N
517	divar	ga6WGtQC	۱۰۰ متری دو خوابه موقعیت عالی ودسترسی بی‌نظیر	شهید معقول	4000000000	sale	\N	https://divar.ir/v/_/ga6WGtQC	2026-09-28 13:04:04.868602+00	2026-09-28 13:06:41.326437+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید معقول", "amounts": {"raw_amount": 4000000000}}	\N
518	divar	ga6W2dty	آپارتمان ۹۸ متر مجد ۲۸	سعد آباد	7800000000	sale	\N	https://divar.ir/v/_/ga6W2dty	2026-09-28 13:04:01.387972+00	2026-09-28 13:06:41.328696+00	\N	\N	\N	mashhad	98	\N	\N	\N	{"mid": "۷,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سعد آباد", "amounts": {"raw_amount": 7800000000}}	\N
519	divar	gaTiDK61	به قمیت دو خواب/ سه خواب صفر سند آماده	الهیه	12600000000	sale	44	https://divar.ir/v/_/gaTiDK61	2026-09-28 13:03:26.721274+00	2026-09-28 13:06:41.330851+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پلاک در الهیه", "amounts": {"raw_amount": 12600000000}}	\N
520	divar	ganKcqV6	گوارشک 1000 متری ، 60متر بنا نما شده	درزآب	1850000000	sale	\N	https://divar.ir/v/_/ganKcqV6	2026-09-28 13:03:02.663273+00	2026-09-28 13:06:41.333176+00	\N	\N	\N	mashhad	1000	\N	\N	\N	{"mid": "۱,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 1850000000}}	\N
521	divar	ga6WmCFr	۹۰متر همکف با پارکینگ هدایت ۱ صفدری نژاد زوج	شفا	5300000000	sale	\N	https://divar.ir/v/_/ga6WmCFr	2026-09-28 13:02:14.431006+00	2026-09-28 13:06:41.335193+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۵,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن نجفی نبش صفدری نژاد ۱۴ در شفا", "amounts": {"raw_amount": 5300000000}}	\N
522	divar	gaUi4pIF	آپارتمان 100متر/تهاترباخودرو/ سندملکی دوقدمی حرم	دانش	25000000000	sale	\N	https://divar.ir/v/_/gaUi4pIF	2026-09-28 13:02:12.974453+00	2026-09-28 13:06:41.337885+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۲۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در دانش", "amounts": {"raw_amount": 25000000000}}	\N
523	divar	ga6eA2Oo	116متری.غرق نور خوش نقشه.عکسها واقعی(الهیه)	الهیه	12800000000	sale	44	https://divar.ir/v/_/ga6eA2Oo	2026-09-28 13:01:39.923952+00	2026-09-28 13:06:41.340144+00	\N	\N	\N	mashhad	116	\N	\N	\N	{"mid": "۱۲,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 12800000000}}	\N
524	divar	ga66AM7R	آپارتمان+۲تک خواب65متر۳۱۰۰بلوارطبرسی وحید۲۱	وحید	3100000000	sale	33	https://divar.ir/v/_/ga66AM7R	2026-09-28 13:01:29.473605+00	2026-09-28 13:06:41.342129+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۳,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "ساخت و ساز ملک  در وحید", "amounts": {"raw_amount": 3100000000}}	\N
525	divar	ga6SG3ab	خانه ویلایی فروشی	مصطفی خمینی	2480000000	sale	\N	https://divar.ir/v/_/ga6SG3ab	2026-09-28 13:01:12.629191+00	2026-09-28 13:06:41.344252+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۴۸۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مصطفی خمینی", "amounts": {"raw_amount": 2480000000}}	\N
526	divar	gaiWJODy	رهن و اجاره آپارتمان نوساز ۱۲۵ متر فکوری نسترن ۳	نیروی هوایی	\N	rent	\N	https://divar.ir/v/_/gaiWJODy	2026-09-28 08:48:18.951723+00	2026-09-28 13:06:41.346367+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در نیروی هوایی", "amounts": {}}	\N
528	divar	ga6WmNXW	۱۶۵متر/سه خواب/تکواحدی/صفرکلید نخورده	فرهنگیان (شهرک غرب)	\N	rent	37	https://divar.ir/v/_/ga6WmNXW	2026-09-28 13:05:27.027316+00	2026-09-28 13:06:41.349595+00	\N	\N	\N	mashhad	165	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه مهندسی ساختمانی دیان در فرهنگیان (شهرک غرب)", "amounts": {"اجاره": 10000000}}	\N
529	divar	ga6W2uvo	۱۲۰ متری لوکس با پارکینگ اختصاصی کوی امیر خیام	فدک	\N	rent	\N	https://divar.ir/v/_/ga6W2uvo	2026-09-28 13:04:37.0409+00	2026-09-28 13:06:41.351614+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در فدک", "amounts": {}}	\N
530	divar	ga6C2GOH	آپارتمان	شهرک لشکر (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6C2GOH	2026-09-28 13:03:53.604537+00	2026-09-28 13:06:41.353752+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در شهرک لشکر (شهرک غرب)", "amounts": {}}	\N
531	divar	garKaZ5x	میدان محمدیه/ ۱۱۰ متر بدون مشرف	الهیه	\N	rent	44	https://divar.ir/v/_/garKaZ5x	2026-09-28 13:03:09.902724+00	2026-09-28 13:06:41.355682+00	\N	\N	\N	mashhad	110	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "مسکن پلاک در الهیه", "amounts": {"اجاره": 100000}}	\N
532	divar	ga6SGrvy	اجاره مسکونی رایگان	کارده	\N	rent	\N	https://divar.ir/v/_/ga6SGrvy	2026-09-28 13:01:11.649123+00	2026-09-28 13:06:41.357869+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کارده", "amounts": {"اجاره": 10000000}}	\N
543	divar	gaxi0yYp	آپارتمان نقلی روبکوه هاشمیه	نیروی هوایی	7500000000	sale	\N	https://divar.ir/v/_/gaxi0yYp	2026-09-28 13:16:43.955437+00	2026-09-28 13:16:53.982178+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در نیروی هوایی", "amounts": {"raw_amount": 7500000000}}	\N
544	divar	ga6iGpxR	۸۵ متر بازسازی صفر /نزدیک حاشیه صیاد	هفت تیر (آب و برق)	9250000000	sale	\N	https://divar.ir/v/_/ga6iGpxR	2026-09-28 13:16:30.868543+00	2026-09-28 13:16:53.987565+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۹,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در هفت تیر (آب و برق)", "amounts": {"raw_amount": 9250000000}}	\N
545	divar	ga62CUjO	83 متـر ـ سـند تک برگ ـ غرق نـور ـ زیر فـی منطقه	حجاب (شهرک غرب)	5160000000	sale	38	https://divar.ir/v/_/ga62CUjO	2026-09-28 13:16:22.280894+00	2026-09-28 13:16:53.990817+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۱۶۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در حجاب (شهرک غرب)", "amounts": {"raw_amount": 5160000000}}	\N
546	divar	ga6iWawY	آپارتمان ۱۰۰ متری سرجلو شیک فول قائم ۲۴	کوی المهدی	7650000000	sale	\N	https://divar.ir/v/_/ga6iWawY	2026-09-28 13:16:21.372213+00	2026-09-28 13:16:53.994314+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۷,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در کوی المهدی", "amounts": {"raw_amount": 7650000000}}	\N
547	divar	gaqhPTsz	آپارتمان هاشمیه/۱۳۶ متر/۳ خواب/ بعد چهارراه صارمی	هنرستان	17500000000	sale	11	https://divar.ir/v/_/gaqhPTsz	2026-09-28 13:16:20.886707+00	2026-09-28 13:16:53.996908+00	\N	\N	\N	mashhad	136	3	\N	\N	{"mid": "۱۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هنرستان", "amounts": {"raw_amount": 17500000000}}	\N
548	divar	ga6iGdE2	۱۰۰ متر، دو خواب، نورگیر و دلباز	شهید معقول	4000000000	sale	\N	https://divar.ir/v/_/ga6iGdE2	2026-09-28 13:15:43.852771+00	2026-09-28 13:16:53.99973+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید معقول", "amounts": {"raw_amount": 4000000000}}	\N
549	divar	ga6aWm9B	دو واحد آپارتمان۶۵متری و ۷۵ متری	رسالت	4100000000	sale	32	https://divar.ir/v/_/ga6aWm9B	2026-09-28 13:15:37.247223+00	2026-09-28 13:16:54.00193+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۴,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رسالت", "amounts": {"raw_amount": 4100000000}}	\N
550	divar	ga6iWPa5	آپارتمان 3 خواب الهیه فروشی	جاهد شهر	17000000000	sale	41	https://divar.ir/v/_/ga6iWPa5	2026-09-28 13:15:28.879625+00	2026-09-28 13:16:54.004366+00	\N	\N	\N	mashhad	\N	3	\N	\N	{"mid": "۱۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"raw_amount": 17000000000}}	\N
551	divar	ga6e2rVh	آپارتمان سه خواب عرصه بالا	حجاب (شهرک غرب)	9600000000	sale	38	https://divar.ir/v/_/ga6e2rVh	2026-09-28 13:14:46.124279+00	2026-09-28 13:16:54.006769+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حجاب (شهرک غرب)", "amounts": {"raw_amount": 9600000000}}	\N
552	divar	gafq75cC	آپارتمان بلوار طبرسی جنوبی	رسالت	3200000000	sale	32	https://divar.ir/v/_/gafq75cC	2026-09-28 13:14:33.765511+00	2026-09-28 13:16:54.009113+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رسالت", "amounts": {"raw_amount": 3200000000}}	\N
553	divar	ga36n6of	فکوری۱۳ کوچه اول ۷۵متر طبقه دوم	هفت تیر (آب و برق)	6950000000	sale	\N	https://divar.ir/v/_/ga36n6of	2026-09-28 13:14:30.78108+00	2026-09-28 13:16:54.011809+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۶,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (آب و برق)", "amounts": {"raw_amount": 6950000000}}	\N
554	divar	gama5th1	ملک حاشیه شاهنامه ۲۹	کلاته برفی	5750000000	sale	\N	https://divar.ir/v/_/gama5th1	2026-09-28 13:14:13.731241+00	2026-09-28 13:16:54.014058+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در کلاته برفی", "amounts": {"raw_amount": 5750000000}}	\N
555	divar	gaf6rHRJ	آپارتمان بلوار طبرسی جنوبی	رسالت	7400000000	sale	32	https://divar.ir/v/_/gaf6rHRJ	2026-09-28 13:13:43.160607+00	2026-09-28 13:16:54.016138+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رسالت", "amounts": {"raw_amount": 7400000000}}	\N
556	divar	gadeh3wi	85متری اوایل امیریه	امیریه	6500000000	sale	\N	https://divar.ir/v/_/gadeh3wi	2026-09-28 13:13:04.352958+00	2026-09-28 13:16:54.018282+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیریه", "amounts": {"raw_amount": 6500000000}}	\N
557	divar	gali1U9d	حاشیه فکوری۸۰متر آسانسور،پارکینگ،	صیاد شیرازی	9200000000	sale	4	https://divar.ir/v/_/gali1U9d	2026-09-28 13:13:03.244176+00	2026-09-28 13:16:54.020573+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۹,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در صیاد شیرازی", "amounts": {"raw_amount": 9200000000}}	\N
558	divar	ga6e2iKt	ویلایی در منطقه دنج کارمندان	مصلی (کارمندان اول)	15500000000	sale	\N	https://divar.ir/v/_/ga6e2iKt	2026-09-28 13:12:21.276132+00	2026-09-28 13:16:54.022612+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مصلی (کارمندان اول)", "amounts": {"raw_amount": 15500000000}}	\N
560	divar	ga6iGbGg	رهن ۱میلیارد کامل اجاره ۴ت	دانشجو	\N	rent	39	https://divar.ir/v/_/ga6iGbGg	2026-09-28 13:16:13.931792+00	2026-09-28 13:16:54.028048+00	\N	\N	\N	mashhad	\N	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در دانشجو", "amounts": {"اجاره": 4000000}}	\N
561	divar	ga6iWAn9	رهن و اجاره ۷۵متری همکف یک خواب امامت	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga6iWAn9	2026-09-28 13:15:01.88175+00	2026-09-28 13:16:54.030291+00	\N	\N	\N	mashhad	75	\N	\N	16000000	{"mid": "اجاره: ۱۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آزادشهر", "amounts": {"اجاره": 16000000}}	\N
562	divar	ga6eWReb	ویلایی ۱۱۰ متری	گلشور	\N	rent	\N	https://divar.ir/v/_/ga6eWReb	2026-09-28 13:10:37.484371+00	2026-09-28 13:16:54.032699+00	\N	\N	\N	mashhad	110	\N	\N	13000000	{"mid": "اجاره: ۱۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گلشور", "amounts": {"اجاره": 13000000}}	\N
563	divar	ga6a2xCr	آپارتمان ۷۵متری	شهید قربانی	\N	rent	\N	https://divar.ir/v/_/ga6a2xCr	2026-09-28 13:10:17.847+00	2026-09-28 13:16:54.035576+00	\N	\N	\N	mashhad	75	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید قربانی", "amounts": {"اجاره": 3000000}}	\N
564	divar	ga6a22IT	۵۰ متر یوسفیه آزاده همکف	یوسفیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6a22IT	2026-09-28 13:09:42.039195+00	2026-09-28 13:16:54.037695+00	\N	\N	\N	mashhad	50	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در یوسفیه (شهرک غرب)", "amounts": {"اجاره": 8000000}}	\N
565	divar	ga3lFOSS	اجاره خانه ماهانه سوییت شخصی ماهی ۱۵میلیون	کوی راد	\N	rent	\N	https://divar.ir/v/_/ga3lFOSS	2026-09-28 13:08:20.09948+00	2026-09-28 13:16:54.041359+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "در کوی راد", "amounts": {"اجاره": 15000000}}	\N
571	divar	ga62Csxx	آپارتمان های 300 متری منطقه 1	احمدآباد	91000000000	sale	\N	https://divar.ir/v/_/ga62Csxx	2026-09-28 13:26:48.445225+00	2026-09-28 13:27:04.9456+00	\N	\N	\N	mashhad	300	\N	\N	\N	{"mid": "۹۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن والی در احمدآباد", "amounts": {"raw_amount": 91000000000}}	\N
572	divar	ga6qWir2	برج نیایش ۱۳۵متر تراس بزرگ	آبادگران	13500000000	sale	\N	https://divar.ir/v/_/ga6qWir2	2026-09-28 13:26:10.547532+00	2026-09-28 13:27:04.955123+00	\N	\N	\N	mashhad	135	\N	\N	\N	{"mid": "۱۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارشناس منطقه ابادگران قهرمانلو در آبادگران", "amounts": {"raw_amount": 13500000000}}	\N
573	divar	gamK2hnw	آپارتمان جلال ۵۰ جنوبی خوش نقشه طبقه دوم	سید رضی	13500000000	sale	\N	https://divar.ir/v/_/gamK2hnw	2026-09-28 13:26:10.194198+00	2026-09-28 13:27:04.957899+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در سید رضی", "amounts": {"raw_amount": 13500000000}}	\N
574	divar	ga6KxWD0	۱۰۰ متر  اواسط اقدسیه تاپ لوکیشن	الهیه	10500000000	sale	44	https://divar.ir/v/_/ga6KxWD0	2026-09-28 13:25:29.022109+00	2026-09-28 13:27:04.960037+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 10500000000}}	\N
575	divar	ga6uSy3G	۵۴متر آپارتمان.فقط۴ دقیقه تا حرم.شرایط پرداخت	امام رضا (ع)	14500000000	sale	\N	https://divar.ir/v/_/ga6uSy3G	2026-09-28 13:25:07.417607+00	2026-09-28 13:27:04.962228+00	\N	\N	\N	mashhad	54	\N	\N	\N	{"mid": "۱۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 14500000000}}	\N
576	divar	ga6myc8z	هاشمیه 53/ ویلایی	الهیه	60000000000	sale	44	https://divar.ir/v/_/ga6myc8z	2026-09-28 13:24:59.389259+00	2026-09-28 13:27:04.964444+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 60000000000}}	\N
577	divar	ga6Gy_bB	۱۶۰مترآپارتمان چشم‌نوازباطراحی روز.خیابان امام رضا	امام رضا (ع)	31200000000	sale	\N	https://divar.ir/v/_/ga6Gy_bB	2026-09-28 13:24:50.414158+00	2026-09-28 13:27:04.966397+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۳۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 31200000000}}	\N
578	divar	ga6qGQ1Q	۲۲۰ متر  ،  ویو ابدی  ، عکس واقعی  ، منحصر به فرد	جاهد شهر	27000000000	sale	41	https://divar.ir/v/_/ga6qGQ1Q	2026-09-28 13:23:27.59271+00	2026-09-28 13:27:04.968553+00	\N	\N	\N	mashhad	220	\N	\N	\N	{"mid": "۲۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در جاهد شهر", "amounts": {"raw_amount": 27000000000}}	\N
579	divar	gazeuGcc	همخونه بدون رهن	بهاران	\N	rent	17	https://divar.ir/v/_/gazeuGcc	2026-09-23 14:55:08.418736+00	2026-09-28 13:27:04.970647+00	\N	\N	\N	mashhad	\N	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "در بهاران", "amounts": {"اجاره": 2000000}}	\N
580	divar	ga62UQSo	صارمی/97 متر/2 خواب/جنوبی	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/ga62UQSo	2026-09-28 13:26:39.32783+00	2026-09-28 13:27:04.972908+00	\N	\N	\N	mashhad	97	2	\N	11000000	{"mid": "اجاره: ۱۱,۰۰۰,۰۰۰ تومان", "bottom": "مسکن والی در هفت تیر (حافظ)", "amounts": {"اجاره": 11000000}}	\N
581	divar	ga6mkd1-	هاشمیه/90 متر/2 خواب/شمالی	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga6mkd1-	2026-09-28 13:26:31.239015+00	2026-09-28 13:27:04.975403+00	\N	\N	\N	mashhad	90	2	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن والی در چهارچشمه", "amounts": {"اجاره": 35000000}}	\N
582	divar	ga6q275K	هاشمیه/80 متر/2خواب/شیک	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga6q275K	2026-09-28 13:26:17.969666+00	2026-09-28 13:27:04.977599+00	\N	\N	\N	mashhad	80	2	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن والی در چهارچشمه", "amounts": {"اجاره": 40000000}}	\N
583	divar	gavmfabF	۷۵متر/امامت۴۰/بازسازی/۲خواب/بدون مالک	آزادشهر	\N	rent	\N	https://divar.ir/v/_/gavmfabF	2026-09-28 13:23:49.559103+00	2026-09-28 13:27:04.979622+00	\N	\N	\N	mashhad	75	2	\N	18000000	{"mid": "اجاره: ۱۸,۰۰۰,۰۰۰ تومان", "bottom": "در آزادشهر", "amounts": {"اجاره": 18000000}}	\N
584	divar	ga6mkn7X	واحد غرق نور/فول بازسازی/۲واحدی/مجتمع فرش مشهد	امیریه	\N	rent	\N	https://divar.ir/v/_/ga6mkn7X	2026-09-28 13:23:34.93791+00	2026-09-28 13:27:04.981505+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در امیریه", "amounts": {}}	\N
585	divar	ga6qmKOR	آپارتمان نوساز  لوکس تحویل یک ماهه	بهاران	\N	rent	17	https://divar.ir/v/_/ga6qmKOR	2026-09-28 13:23:21.958381+00	2026-09-28 13:27:04.983376+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهاران", "amounts": {"اجاره": 1000000}}	\N
586	divar	gau2UvAb	ویلایی دربست. دفتر کار حاشیه بلوار اصلی	ادیب نیشابوری (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/gau2UvAb	2026-09-28 13:21:44.80948+00	2026-09-28 13:27:04.985594+00	\N	\N	\N	mashhad	\N	\N	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "در ادیب نیشابوری (شهرک غرب)", "amounts": {"اجاره": 35000000}}	\N
587	divar	gaoiRS9I	آپارتمان 70 متری توس 44 غفوری	شهرک امام هادی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/gaoiRS9I	2026-09-28 13:21:42.831645+00	2026-09-28 13:27:04.987743+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در شهرک امام هادی (شهرک غرب)", "amounts": {}}	\N
588	divar	ga6mG3G7	واحد آپارتمانی شیک و تمیز . طبقه اول ایثارگران 26	ایثارگران	\N	rent	\N	https://divar.ir/v/_/ga6mG3G7	2026-09-28 13:21:40.628292+00	2026-09-28 13:27:04.989938+00	\N	\N	\N	mashhad	\N	\N	\N	13000000	{"mid": "اجاره: ۱۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثارگران", "amounts": {"اجاره": 13000000}}	\N
595	divar	ga268jdF	آپارتمان ۶۷ متری / نزدیک به حرم مطهر /سرایداری/صفر	سلام	12100000000	sale	\N	https://divar.ir/v/_/ga268jdF	2026-09-28 13:36:49.344339+00	2026-09-28 13:37:15.769128+00	\N	\N	\N	mashhad	67	\N	\N	\N	{"mid": "۱۲,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در سلام", "amounts": {"raw_amount": 12100000000}}	\N
596	divar	gaVS46S1	آپارتمان 145 متری/صفر کلید نخورده/معبر 20 متری	امام رضا (ع)	24500000000	sale	\N	https://divar.ir/v/_/gaVS46S1	2026-09-28 13:34:10.98155+00	2026-09-28 13:37:15.772346+00	\N	\N	\N	mashhad	145	\N	\N	\N	{"mid": "۲۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 24500000000}}	\N
597	divar	ga4WdBpk	آپارتمان ۱۳۰متری/تک واحدی/۳خواب/سهم العرصه زیاد	رضاشهر	18200000000	sale	\N	https://divar.ir/v/_/ga4WdBpk	2026-09-28 13:34:04.710777+00	2026-09-28 13:37:15.775837+00	\N	\N	\N	mashhad	130	3	\N	\N	{"mid": "۱۸,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رضاشهر", "amounts": {"raw_amount": 18200000000}}	\N
598	divar	gaUWn6fn	فروش باغ استخر  دار	لقمانی	6000000000	sale	\N	https://divar.ir/v/_/gaUWn6fn	2026-09-28 13:33:37.186744+00	2026-09-28 13:37:15.77829+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در لقمانی", "amounts": {"raw_amount": 6000000000}}	\N
599	divar	ga6qmUIm	اپارتمان 150متری در طبرسی شمالی 6سر نبش شفائی4	نظام دوست	11000000000	sale	\N	https://divar.ir/v/_/ga6qmUIm	2026-09-28 13:33:36.379565+00	2026-09-28 13:37:15.780314+00	\N	\N	\N	mashhad	150	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نظام دوست", "amounts": {"raw_amount": 11000000000}}	\N
600	divar	ga6yzJ4i	آپارتمان ۵۵ متری با۲۰ متر حیاط اختصاصی	یوسفیه (شهرک غرب)	2490000000	sale	38	https://divar.ir/v/_/ga6yzJ4i	2026-09-28 13:33:33.674079+00	2026-09-28 13:37:15.782848+00	\N	\N	\N	mashhad	55	\N	\N	\N	{"mid": "۲,۴۹۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در یوسفیه (شهرک غرب)", "amounts": {"raw_amount": 2490000000}}	\N
601	divar	ga6yWSF5	فروش ویلایی ۹۰ متر در دوطبقه	چهنو	10000000000	sale	\N	https://divar.ir/v/_/ga6yWSF5	2026-09-28 13:33:24.53253+00	2026-09-28 13:37:15.785337+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۱۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهنو", "amounts": {"raw_amount": 10000000000}}	\N
602	divar	ga6KT6vf	آپارتمان دربست دو واحد ۱۱۵ متری	رضاییه	\N	rent	\N	https://divar.ir/v/_/ga6KT6vf	2026-09-28 13:35:18.744447+00	2026-09-28 13:37:15.787708+00	\N	\N	\N	mashhad	115	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "در رضاییه", "amounts": {"اجاره": 1000}}	\N
603	divar	ga6ym1Z9	اجاره تک خواب دو واحدی	هنرور	\N	rent	\N	https://divar.ir/v/_/ga6ym1Z9	2026-09-28 13:34:20.347177+00	2026-09-28 13:37:15.790215+00	\N	\N	\N	mashhad	\N	\N	\N	13000000	{"mid": "اجاره: ۱۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"اجاره": 13000000}}	\N
604	divar	gazC4w5z	اجاره آپارتمان 125متر نوساز	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/gazC4w5z	2026-09-28 13:34:17.839184+00	2026-09-28 13:37:15.792201+00	\N	\N	\N	mashhad	125	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن هنرستان واقع در نبش هنرستان بیست در هفت تیر (حافظ)", "amounts": {"اجاره": 30000000}}	\N
605	divar	ga6y2lpK	310متر اپارتمان نوساز 4خواب مستر گلشن 1	سجاد شهر	\N	rent	21	https://divar.ir/v/_/ga6y2lpK	2026-09-28 13:33:19.790435+00	2026-09-28 13:37:15.794761+00	\N	\N	\N	mashhad	310	4	\N	90000000	{"mid": "اجاره: ۹۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سجاد شهر", "amounts": {"اجاره": 90000000}}	\N
606	divar	gaxOWAhz	140متر /دوخواب/طبقه دوم	هدایت	\N	rent	26	https://divar.ir/v/_/gaxOWAhz	2026-09-28 13:32:53.395463+00	2026-09-28 13:37:15.797145+00	\N	\N	\N	mashhad	140	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "در هدایت", "amounts": {"اجاره": 20000000}}	\N
607	divar	ga6y2R9Z	رهن و اجاره آپارتمان	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga6y2R9Z	2026-09-28 13:31:56.912633+00	2026-09-28 13:37:15.79911+00	\N	\N	\N	mashhad	\N	\N	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"اجاره": 35000000}}	\N
608	divar	ga6um9Jd	۱۳۵ متری فول طبقه اول	استاد یوسفی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6um9Jd	2026-09-28 13:31:17.088384+00	2026-09-28 13:37:15.801321+00	\N	\N	\N	mashhad	135	\N	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در استاد یوسفی (شهرک غرب)", "amounts": {"اجاره": 35000000}}	\N
609	divar	ga6u2vnQ	بلوارفکوری بین ۹و۱۱  اجاره یک خواب	صیاد شیرازی	\N	rent	4	https://divar.ir/v/_/ga6u2vnQ	2026-09-28 13:30:21.527698+00	2026-09-28 13:37:15.803699+00	\N	\N	\N	mashhad	\N	\N	\N	22000000	{"mid": "اجاره: ۲۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در صیاد شیرازی", "amounts": {"اجاره": 22000000}}	\N
610	divar	ga6umoxT	رهن کامل طبقه اول	توس (بلوار توس)	\N	rent	\N	https://divar.ir/v/_/ga6umoxT	2026-09-28 13:29:12.642495+00	2026-09-28 13:37:15.805797+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {}}	\N
616	divar	gaeSXBL9	خانه ۱۵۰ متری صفر بهترین لوکیشن فارغ التحصیلان	فارغ التحصیلان	25000000000	sale	\N	https://divar.ir/v/_/gaeSXBL9	2026-09-26 07:48:58.610551+00	2026-09-28 13:47:26.67645+00	\N	\N	\N	mashhad	150	\N	\N	\N	{"mid": "۲۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فارغ التحصیلان", "amounts": {"raw_amount": 25000000000}}	\N
617	divar	gadqp8JT	آپارتمان ۸۰ متری دو خواب رحمانیه ۳۰	جاهد شهر	6590000000	sale	41	https://divar.ir/v/_/gadqp8JT	2026-09-28 12:58:01.515711+00	2026-09-28 13:47:26.681799+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۶,۵۹۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 6590000000}}	\N
618	divar	ga6-Wg5x	پنت هاوس 150 متری حیاط دار	تلگرد	10500000000	sale	\N	https://divar.ir/v/_/ga6-Wg5x	2026-09-28 13:46:32.41413+00	2026-09-28 13:47:26.684781+00	\N	\N	\N	mashhad	150	\N	\N	\N	{"mid": "۱۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در تلگرد", "amounts": {"raw_amount": 10500000000}}	\N
619	divar	ga6yml_S	۱۰۰ متر /۵۶۰۰ تومان / حرم مطهر / مسکن الماس /	گلشور	5600000000	sale	\N	https://divar.ir/v/_/ga6yml_S	2026-09-28 13:46:03.367423+00	2026-09-28 13:47:26.690853+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۵,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن الماس(پاشا)بین ایثار۱۷و۱۹ در گلشور", "amounts": {"raw_amount": 5600000000}}	\N
620	divar	ga6-GgGp	۱۱۰ متر آپارتمان لوکس و مدرن برند توانا	نرگس (شهرک غرب)	15400000000	sale	38	https://divar.ir/v/_/ga6-GgGp	2026-09-28 13:45:49.892084+00	2026-09-28 13:47:26.694656+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۱۵,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نرگس (شهرک غرب)", "amounts": {"raw_amount": 15400000000}}	\N
621	divar	gar-zcx6	آپارتمان ۷۵ متری به انضمام ۲۷ متر تراس	شریف	12500000000	sale	\N	https://divar.ir/v/_/gar-zcx6	2026-09-28 13:45:47.973408+00	2026-09-28 13:47:26.697704+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شریف", "amounts": {"raw_amount": 12500000000}}	\N
622	divar	ga6q0Ju0	الهیه 800متر 2نبش مناسب ساخت تراکم زیاد قابل تهاتر	جاهد شهر	120000000000	sale	41	https://divar.ir/v/_/ga6q0Ju0	2026-09-28 13:45:44.279451+00	2026-09-28 13:47:26.701336+00	\N	\N	\N	mashhad	800	\N	\N	\N	{"mid": "۱۲۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "تالار معاملات ملکی سجادی در جاهد شهر", "amounts": {"raw_amount": 120000000000}}	\N
623	divar	ga6-mKaW	آپارتمان توس۴۱(شهرک حجت)۸۵متر طبقه اول	حضرت حجت	2750000000	sale	\N	https://divar.ir/v/_/ga6-mKaW	2026-09-28 13:45:12.266405+00	2026-09-28 13:47:26.704454+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۲,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حضرت حجت", "amounts": {"raw_amount": 2750000000}}	\N
624	divar	gaWCubkq	250 متر. آپارتمان نوساز ابوذر 35 تومان	احمدآباد	35000000000	sale	\N	https://divar.ir/v/_/gaWCubkq	2026-09-28 13:45:06.072261+00	2026-09-28 13:47:26.706765+00	\N	\N	\N	mashhad	250	\N	\N	\N	{"mid": "۳۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "پارثاوا ، تالار معاملات ملکی در احمدآباد", "amounts": {"raw_amount": 35000000000}}	\N
625	divar	gabNIyDb	فروش زمین دو نبش تجاری دار اقدسیه ۲۰ متر بر	جاهد شهر	24000000000	sale	41	https://divar.ir/v/_/gabNIyDb	2026-09-28 13:44:57.741765+00	2026-09-28 13:47:26.709124+00	\N	\N	\N	mashhad	20	\N	\N	\N	{"mid": "۲۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پلاک در جاهد شهر", "amounts": {"raw_amount": 24000000000}}	\N
626	divar	ga66m6cV	آپارتمان توس۴۳(شهرک حجت)۵۵متر طبقه همکف	حضرت حجت	1600000000	sale	\N	https://divar.ir/v/_/ga66m6cV	2026-09-28 13:43:51.619286+00	2026-09-28 13:47:26.711452+00	\N	\N	\N	mashhad	55	\N	\N	\N	{"mid": "۱,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حضرت حجت", "amounts": {"raw_amount": 1600000000}}	\N
627	divar	QapFoEVG	معاوضه خودرو با زمین فاز۲ الهیه(سلطانی)نبش الهیه۴۳	الهیه	550000000	sale	44	https://divar.ir/v/_/QapFoEVG	2026-09-28 13:43:47.038938+00	2026-09-28 13:47:26.714698+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵۵۰,۰۰۰,۰۰۰ تومان", "bottom": "نبش الهیه ۴۳ دفتر مرکزی اراضی فاز۲ الهیه  در الهیه", "amounts": {"raw_amount": 550000000}}	\N
628	divar	gane635J	۷۰ متری تک واحدی حاشیه ۲۰ متری هدایت ۲۱	یاس	4000000000	sale	\N	https://divar.ir/v/_/gane635J	2026-09-28 13:43:38.600188+00	2026-09-28 13:47:26.716981+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در یاس", "amounts": {"raw_amount": 4000000000}}	\N
629	divar	ga66W2gz	خانه ویلایی 55 متری در دوطبقه توس 97	امیرآباد	1790000000	sale	\N	https://divar.ir/v/_/ga66W2gz	2026-09-28 13:43:33.79652+00	2026-09-28 13:47:26.719202+00	\N	\N	\N	mashhad	55	\N	\N	\N	{"mid": "۱,۷۹۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیرآباد", "amounts": {"raw_amount": 1790000000}}	\N
630	divar	ga66mlKl	زمین ۲۳۵ متری	كنويست	650000000	sale	\N	https://divar.ir/v/_/ga66mlKl	2026-09-28 13:43:25.528115+00	2026-09-28 13:47:26.721922+00	\N	\N	\N	mashhad	235	\N	\N	\N	{"mid": "۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در كنويست", "amounts": {"raw_amount": 650000000}}	\N
631	divar	ga66movY	منزل ویلایی بزرگ ماشین رو	همت آباد	2540000000	sale	\N	https://divar.ir/v/_/ga66movY	2026-09-28 13:43:13.116663+00	2026-09-28 13:47:26.724839+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۵۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در همت آباد", "amounts": {"raw_amount": 2540000000}}	\N
632	divar	ga3a_tpq	75 متری آخر سیدرضی	شهید رضوی	\N	rent	\N	https://divar.ir/v/_/ga3a_tpq	2026-09-26 16:46:31.047731+00	2026-09-28 13:47:26.727562+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در شهید رضوی", "amounts": {}}	\N
633	divar	ga6-mppl	125متر اپارتمان با 50متر حیاط نوساز رضوی 2	رضاشهر	\N	rent	\N	https://divar.ir/v/_/ga6-mppl	2026-09-28 13:46:21.401859+00	2026-09-28 13:47:26.730132+00	\N	\N	\N	mashhad	125	\N	\N	45000000	{"mid": "اجاره: ۴۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاشهر", "amounts": {"اجاره": 45000000}}	\N
634	divar	ga66Gkfa	۸۵متری بازسازی کامل	امیریه	\N	rent	\N	https://divar.ir/v/_/ga66Gkfa	2026-09-28 13:46:16.564012+00	2026-09-28 13:47:26.732597+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در امیریه", "amounts": {}}	\N
635	divar	ga6-Wh7v	سویت مناسب برای یک یا دو نفر	کوشش	\N	rent	\N	https://divar.ir/v/_/ga6-Wh7v	2026-09-28 13:45:46.511275+00	2026-09-28 13:47:26.735224+00	\N	\N	\N	mashhad	\N	\N	\N	8500000	{"mid": "اجاره: ۸,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوشش", "amounts": {"اجاره": 8500000}}	\N
636	divar	gaxuUczd	فلسطین صفر تک واحدی لوکس 210 متری	فلسطین	\N	rent	19	https://divar.ir/v/_/gaxuUczd	2026-09-28 13:44:33.064871+00	2026-09-28 13:47:26.737537+00	\N	\N	\N	mashhad	210	\N	\N	90000000	{"mid": "اجاره: ۹۰,۰۰۰,۰۰۰ تومان", "bottom": "پارثاوا ، تالار معاملات ملکی در فلسطین", "amounts": {"اجاره": 90000000}}	\N
637	divar	ga6-2JVw	175متر اپارتمان نوساز بخارایی 9 مدرن	راهنمایی	\N	rent	\N	https://divar.ir/v/_/ga6-2JVw	2026-09-28 13:44:13.735292+00	2026-09-28 13:47:26.739816+00	\N	\N	\N	mashhad	175	\N	\N	90000000	{"mid": "اجاره: ۹۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در راهنمایی", "amounts": {"اجاره": 90000000}}	\N
638	divar	ga662m56	اجاره اپارتمان	الهیه	\N	rent	44	https://divar.ir/v/_/ga662m56	2026-09-28 13:43:38.513023+00	2026-09-28 13:47:26.742241+00	\N	\N	\N	mashhad	\N	\N	\N	27000000	{"mid": "اجاره: ۲۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"اجاره": 27000000}}	\N
639	divar	ga5-lPyM	100مترقابل تبدیل،مجیدیه،موارداجاره مشابه داخل آگهی	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga5-lPyM	2026-09-28 13:40:45.374022+00	2026-09-28 13:47:26.744302+00	\N	\N	\N	mashhad	100	\N	\N	28000000	{"mid": "اجاره: ۲۸,۰۰۰,۰۰۰ تومان", "bottom": "شهرمشهد نبش رحمانیه۵ در جاهد شهر", "amounts": {"اجاره": 28000000}}	\N
640	divar	ga66WQzB	آپارتمان 80 متری با پارکینگ راه جدا توس 95	امیرآباد	\N	rent	\N	https://divar.ir/v/_/ga66WQzB	2026-09-28 13:40:28.847884+00	2026-09-28 13:47:26.746446+00	\N	\N	\N	mashhad	80	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیرآباد", "amounts": {"اجاره": 100000}}	\N
641	divar	ga6ymoVd	فرامرز ۱۵ نزدیک حاشیه/ 160متر /صفر/بدون مالک	شهید فرامرز عباسی	\N	rent	\N	https://divar.ir/v/_/ga6ymoVd	2026-09-28 13:39:02.374131+00	2026-09-28 13:47:26.748871+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "رهن کامل", "bottom": "سید احسان سیدی در شهید فرامرز عباسی", "amounts": {}}	\N
642	divar	gafSrLGk	۲۰۰ رهن ۷/۵اجاره	تلگرد	\N	rent	\N	https://divar.ir/v/_/gafSrLGk	2026-09-28 13:38:52.297401+00	2026-09-28 13:47:26.75097+00	\N	\N	\N	mashhad	\N	\N	\N	7500000	{"mid": "اجاره: ۷,۵۰۰,۰۰۰ تومان", "bottom": "در تلگرد", "amounts": {"اجاره": 7500000}}	\N
643	divar	ga62GdVi	جلال ۴۸ طبقه اول.۲خواب	سید رضی	\N	rent	\N	https://divar.ir/v/_/ga62GdVi	2026-09-28 13:37:55.14003+00	2026-09-28 13:47:26.753429+00	\N	\N	\N	mashhad	\N	2	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سید رضی", "amounts": {"اجاره": 20000000}}	\N
644	divar	gazuN_q_	اپارتمان ۱۰۵ متری شکری ۱۲ با پارکینگ و اسانسور	حضرت حجت	4750000000	sale	\N	https://divar.ir/v/_/gazuN_q_	2026-09-28 13:57:26.861961+00	2026-09-28 13:57:37.507055+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۴,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در حضرت حجت", "amounts": {"raw_amount": 4750000000}}	\N
645	divar	ga6Gn9aE	آپارتمان116مترصیاد23فول امکانات دوممر ریز فی	هفت تیر (آب و برق)	11500000000	sale	\N	https://divar.ir/v/_/ga6Gn9aE	2026-09-28 13:57:04.915303+00	2026-09-28 13:57:37.518255+00	\N	\N	\N	mashhad	116	\N	\N	\N	{"mid": "۱۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در هفت تیر (آب و برق)", "amounts": {"raw_amount": 11500000000}}	\N
646	divar	ga6KnA_g	۱۱۰ متری شخصی ( فول بازسازی )	نرگس (شهرک غرب)	8800000000	sale	38	https://divar.ir/v/_/ga6KnA_g	2026-09-28 13:56:45.601152+00	2026-09-28 13:57:37.524063+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۸,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در نرگس (شهرک غرب)", "amounts": {"raw_amount": 8800000000}}	\N
647	divar	ga5-xFsU	فروش خانه	خلق آباد سفلی	3300000000	sale	\N	https://divar.ir/v/_/ga5-xFsU	2026-09-28 13:56:37.822545+00	2026-09-28 13:57:37.530408+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در خلق آباد سفلی", "amounts": {"raw_amount": 3300000000}}	\N
648	divar	ga3W4Wfv	۱۶۲متراوایل امامت پشت معلم سندآماده*مسکن الهی	آزادشهر	27000000000	sale	\N	https://divar.ir/v/_/ga3W4Wfv	2026-09-28 13:56:36.888795+00	2026-09-28 13:57:37.535801+00	\N	\N	\N	mashhad	162	\N	\N	\N	{"mid": "۲۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن   الهی    نبش امامت ۴۶ در آزادشهر", "amounts": {"raw_amount": 27000000000}}	\N
649	divar	gam2GeyW	زمین ۵۲۰متری در مجتمع زعفرانیه باامتیاز آب برق	توس فردوسی	200000000	sale	\N	https://divar.ir/v/_/gam2GeyW	2026-09-28 13:55:35.465873+00	2026-09-28 13:57:37.541193+00	\N	\N	\N	mashhad	520	\N	\N	\N	{"mid": "۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دفتر فروش۰ویلاسازان سرمدی  در توس فردوسی", "amounts": {"raw_amount": 200000000}}	\N
651	divar	ga6GXglU	130/ هنرستان 19	هنرستان	\N	rent	11	https://divar.ir/v/_/ga6GXglU	2026-09-28 13:57:08.163722+00	2026-09-28 13:57:37.550181+00	\N	\N	\N	mashhad	\N	\N	\N	45000000	{"mid": "اجاره: ۴۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رضا هنرستان در هنرستان", "amounts": {"اجاره": 45000000}}	\N
652	divar	ga3KaWoq	آپارتمان اجاره ای	کوی سیدی	\N	rent	\N	https://divar.ir/v/_/ga3KaWoq	2026-09-28 13:56:21.94378+00	2026-09-28 13:57:37.555105+00	\N	\N	\N	mashhad	\N	\N	\N	7500000	{"mid": "اجاره: ۷,۵۰۰,۰۰۰ تومان", "bottom": "در کوی سیدی", "amounts": {"اجاره": 7500000}}	\N
653	divar	ga6GnR-8	۹۶ متر حاشیه بلوار قانع/دو خواب/فول باسازی	تربیت (صدف)	\N	rent	\N	https://divar.ir/v/_/ga6GnR-8	2026-09-28 13:56:06.818731+00	2026-09-28 13:57:37.560195+00	\N	\N	\N	mashhad	96	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در تربیت (صدف)", "amounts": {"اجاره": 30000000}}	\N
655	divar	gakqoTMv	همخونه نیازمندم	کوی سیدی	\N	rent	\N	https://divar.ir/v/_/gakqoTMv	2026-09-28 13:55:04.488052+00	2026-09-28 13:57:37.570408+00	\N	\N	\N	mashhad	\N	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "در کوی سیدی", "amounts": {"اجاره": 6000000}}	\N
656	divar	ga6GXetk	آپارتمان 55متر نوساز نقلی	نظام دوست	\N	rent	\N	https://divar.ir/v/_/ga6GXetk	2026-09-28 13:55:01.135617+00	2026-09-28 13:57:37.576027+00	\N	\N	\N	mashhad	55	\N	\N	7500000	{"mid": "اجاره: ۷,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نظام دوست", "amounts": {"اجاره": 7500000}}	\N
658	divar	ga6GHT1M	خانه ویلایی  دربست	طبرسی شمالی	\N	rent	42	https://divar.ir/v/_/ga6GHT1M	2026-09-28 13:53:23.995475+00	2026-09-28 13:57:37.585031+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {"اجاره": 5000000}}	\N
659	divar	ga6G3ImR	اجاره واحد ۱۱۰ متری دو خواب واقع در خواجه پور	طبرسی شمالی	\N	rent	42	https://divar.ir/v/_/ga6G3ImR	2026-09-28 13:53:12.655963+00	2026-09-28 13:57:37.593002+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {}}	\N
660	divar	ga6G3CK3	155متر آپارتمان امامت 36 تخلیه بازسازی	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga6G3CK3	2026-09-28 13:52:24.622472+00	2026-09-28 13:57:37.598215+00	\N	\N	\N	mashhad	155	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "اژانس اریا در آزادشهر", "amounts": {"اجاره": 10000000}}	\N
661	divar	gazWtDYS	فرامرز عباسی 24 قطعه دوم 185متر صفر/بدون مالک	شهید فرامرز عباسی	\N	rent	\N	https://divar.ir/v/_/gazWtDYS	2026-09-28 13:51:52.593537+00	2026-09-28 13:57:37.603578+00	\N	\N	\N	mashhad	185	\N	\N	\N	{"mid": "رهن کامل", "bottom": "سید احسان سیدی در شهید فرامرز عباسی", "amounts": {}}	\N
662	divar	ga3m6ZAY	همخانه خانم نیازمندم	کوی المهدی	\N	rent	\N	https://divar.ir/v/_/ga3m6ZAY	2026-09-28 13:51:39.47715+00	2026-09-28 13:57:37.60952+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "در کوی المهدی", "amounts": {"اجاره": 5000000}}	\N
663	divar	ga6Cn3ac	125متر اپارتمان با 50متر حیاط نوساز رضوی 2	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga6Cn3ac	2026-09-28 13:51:34.26892+00	2026-09-28 13:57:37.614986+00	\N	\N	\N	mashhad	125	\N	\N	45000000	{"mid": "اجاره: ۴۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگ", "amounts": {"اجاره": 45000000}}	\N
664	divar	ga6Cny2V	منزل دربست جهت انبار	میعاد (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6Cny2V	2026-09-28 13:51:12.579468+00	2026-09-28 13:57:37.62045+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میعاد (شهرک غرب)", "amounts": {"اجاره": 15000000}}	\N
665	divar	gaE-AR10	زمین شصت متر تجاری صنعتی اقدسیه رزم/ زیر فی	الهیه	13500000000	sale	44	https://divar.ir/v/_/gaE-AR10	2026-09-15 09:19:02.203225+00	2026-09-28 14:07:48.352426+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن صبوری در الهیه", "amounts": {"raw_amount": 13500000000}}	\N
666	divar	ga6SXmAw	۱۹۲متری/قلب الهیه/۱۳۵متر حیاط دلنشین/سوپرفول	الهیه	23000000000	sale	44	https://divar.ir/v/_/ga6SXmAw	2026-09-28 14:07:37.598247+00	2026-09-28 14:07:48.362636+00	\N	\N	\N	mashhad	192	\N	\N	\N	{"mid": "۲۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 23000000000}}	\N
667	divar	ga6S3loi	۱۶۳متری*قلب امامت*احمدی ۳۰ سال مشاور املاک	آزادشهر	22500000000	sale	\N	https://divar.ir/v/_/ga6S3loi	2026-09-28 14:07:36.301718+00	2026-09-28 14:07:48.368022+00	\N	\N	\N	mashhad	163	\N	\N	\N	{"mid": "۲۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در آزادشهر", "amounts": {"raw_amount": 22500000000}}	\N
668	divar	ga6SHmWZ	۱۰۰ متری دوخواب/حاشیه/ملکی/خوش نقشه	جاهد شهر	12280000000	sale	41	https://divar.ir/v/_/ga6SHmWZ	2026-09-28 14:07:35.964651+00	2026-09-28 14:07:48.371219+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۲,۲۸۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 12280000000}}	\N
669	divar	ga6SHWx0	آپارتمان فروشی کشاورز	نوید	4800000000	sale	\N	https://divar.ir/v/_/ga6SHWx0	2026-09-28 14:07:30.297779+00	2026-09-28 14:07:48.374028+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در نوید", "amounts": {"raw_amount": 4800000000}}	\N
670	divar	gaeacTCY	آپارتمان 75متری همکف اسکلت پارکینگ دار توس 97	امیرآباد	1420000000	sale	\N	https://divar.ir/v/_/gaeacTCY	2026-09-28 14:07:20.332492+00	2026-09-28 14:07:48.378611+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۱,۴۲۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیرآباد", "amounts": {"raw_amount": 1420000000}}	\N
671	divar	ga6S3hmX	فروش خونه ویلایی 330متری	اقبال	55000000000	sale	1	https://divar.ir/v/_/ga6S3hmX	2026-09-28 14:07:15.032407+00	2026-09-28 14:07:48.382221+00	\N	\N	\N	mashhad	330	\N	\N	\N	{"mid": "۵۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن بابری در اقبال", "amounts": {"raw_amount": 55000000000}}	\N
672	divar	ga6yTMH3	آپارتمان 60متری/تک خواب/حاشیه سجادیه	جاهد شهر	5850000000	sale	41	https://divar.ir/v/_/ga6yTMH3	2026-09-28 14:05:44.288796+00	2026-09-28 14:07:48.385727+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۵,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگذاری مسکن فرهاد در جاهد شهر", "amounts": {"raw_amount": 5850000000}}	\N
673	divar	ga1qzBO4	۱۰۹متری/حاشیه اقدسیه/سند اماده/دونبش	الهیه	11700000000	sale	44	https://divar.ir/v/_/ga1qzBO4	2026-09-28 14:05:25.731782+00	2026-09-28 14:07:48.389172+00	\N	\N	\N	mashhad	109	\N	\N	\N	{"mid": "۱۱,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 11700000000}}	\N
674	divar	ga6O3sHp	باغ ویلا شاهنامه 14	میان ولایت	8500000000	sale	\N	https://divar.ir/v/_/ga6O3sHp	2026-09-28 14:04:50.029597+00	2026-09-28 14:07:48.391959+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 8500000000}}	\N
675	divar	gaym0UUd	۱۵۰ متر هاشمیه فول امکانات اوایل هاشمیه	کوثر	\N	rent	13	https://divar.ir/v/_/gaym0UUd	2026-09-26 09:00:24.979081+00	2026-09-28 14:07:48.393974+00	\N	\N	\N	mashhad	150	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوثر", "amounts": {"اجاره": 20000000}}	\N
676	divar	ga5CDPGo	139متر خوش نقشه صفر فول	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/ga5CDPGo	2026-09-28 14:07:34.796483+00	2026-09-28 14:07:48.395985+00	\N	\N	\N	mashhad	139	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "مسکن طاهرنیا در هفت تیر (حافظ)", "amounts": {"اجاره": 100000}}	\N
677	divar	gat24f6i	ویلایی 100 متری ماشین رو توس 65	نوده	\N	rent	\N	https://divar.ir/v/_/gat24f6i	2026-09-28 14:07:13.110723+00	2026-09-28 14:07:48.398053+00	\N	\N	\N	mashhad	100	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "در نوده", "amounts": {"اجاره": 2000000}}	\N
678	divar	ga6SXUnN	مهدی 1 / 160متر نوساز / مدرن	فردوسی	\N	rent	\N	https://divar.ir/v/_/ga6SXUnN	2026-09-28 14:06:49.332578+00	2026-09-28 14:07:48.399916+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "رهن کامل", "bottom": "سید احسان سیدی در فردوسی", "amounts": {}}	\N
679	divar	ga3WOV89	125 متری/طبقه 4/خواب 3	نیروی هوایی	\N	rent	\N	https://divar.ir/v/_/ga3WOV89	2026-09-28 14:06:30.341933+00	2026-09-28 14:07:48.401783+00	\N	\N	\N	mashhad	125	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "مسکن والی در نیروی هوایی", "amounts": {"اجاره": 1000}}	\N
680	divar	ga6S3TuV	برج بهارستان/طبقه ۷/فول بازسازی/ویو دار	هنرستان	\N	rent	11	https://divar.ir/v/_/ga6S3TuV	2026-09-28 14:06:19.80269+00	2026-09-28 14:07:48.403768+00	\N	\N	\N	mashhad	\N	\N	\N	44000000	{"mid": "اجاره: ۴۴,۰۰۰,۰۰۰ تومان", "bottom": "بورس آپارتمان و ویلایی مسکن ماندگار در هنرستان", "amounts": {"اجاره": 44000000}}	\N
682	divar	ga6C31Rb	رهن کامل رفیعی ۸۵ متر	شاهد (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6C31Rb	2026-09-28 14:03:14.957901+00	2026-09-28 14:07:48.407665+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در شاهد (شهرک غرب)", "amounts": {}}	\N
683	divar	ga6O3RB1	خونه ویلایی دو طبقه دربست  طبقه همکف	کوی سیدی	\N	rent	\N	https://divar.ir/v/_/ga6O3RB1	2026-09-28 14:03:02.752921+00	2026-09-28 14:07:48.410441+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی سیدی", "amounts": {"اجاره": 100000}}	\N
684	divar	ga6Onhrh	155متر اپارتمان صفر مدرن رضاشهر دهخدا 6	رضاشهر	\N	rent	\N	https://divar.ir/v/_/ga6Onhrh	2026-09-28 14:02:55.776374+00	2026-09-28 14:07:48.413917+00	\N	\N	\N	mashhad	155	\N	\N	75000000	{"mid": "اجاره: ۷۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاشهر", "amounts": {"اجاره": 75000000}}	\N
685	divar	ga6OXJDp	اپارتمان اجاره	شهید بهشتی	\N	rent	18	https://divar.ir/v/_/ga6OXJDp	2026-09-28 14:02:25.733889+00	2026-09-28 14:07:48.417513+00	\N	\N	\N	mashhad	\N	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید بهشتی", "amounts": {"اجاره": 25000000}}	\N
686	divar	ga6Kn5Pg	۱۲۰ متری اقبال قبل پیروزی ویو حاشیه پیروزی ۳خواب	اقبال	\N	rent	1	https://divar.ir/v/_/ga6Kn5Pg	2026-09-28 14:01:50.487381+00	2026-09-28 14:07:48.421001+00	\N	\N	\N	mashhad	120	3	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "مهدی مرتضی نیا در اقبال", "amounts": {"اجاره": 20000000}}	\N
687	divar	ga6K3LCI	90متری امامت 62	زیبا شهر	\N	rent	\N	https://divar.ir/v/_/ga6K3LCI	2026-09-28 13:59:50.865058+00	2026-09-28 14:07:48.42444+00	\N	\N	\N	mashhad	90	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در زیبا شهر", "amounts": {"اجاره": 15000000}}	\N
688	divar	ga6K3oHc	اجاره اپارتمان ۱۰۰متری	سجادیه	\N	rent	21	https://divar.ir/v/_/ga6K3oHc	2026-09-28 13:59:09.412788+00	2026-09-28 14:07:48.427102+00	\N	\N	\N	mashhad	100	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سجادیه", "amounts": {"اجاره": 2000000}}	\N
689	divar	ga6KXbgz	اجاره اپارتمان	شهرک بهارستان	\N	rent	\N	https://divar.ir/v/_/ga6KXbgz	2026-09-28 13:58:21.561427+00	2026-09-28 14:07:48.429479+00	\N	\N	\N	mashhad	\N	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک بهارستان", "amounts": {"اجاره": 3000000}}	\N
692	divar	gamhGzLX	خانه ویلایی دو طبقه	رستگار	12000000000	sale	\N	https://divar.ir/v/_/gamhGzLX	2026-09-27 20:50:46.27459+00	2026-09-28 14:38:01.810494+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رستگار", "amounts": {"raw_amount": 12000000000}}	\N
693	divar	ga6uXoLk	اپارتمان۱۶۰متری تک واحدی کریمی۵ برند منطقه	نکاح	14400000000	sale	\N	https://divar.ir/v/_/ga6uXoLk	2026-09-28 14:37:53.809179+00	2026-09-28 14:38:01.821263+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۱۴,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در نکاح", "amounts": {"raw_amount": 14400000000}}	\N
694	divar	ga6unp62	فروش واحدآپارتمان محمدیه ۲۴	الهیه	12200000000	sale	44	https://divar.ir/v/_/ga6unp62	2026-09-28 14:37:45.968917+00	2026-09-28 14:38:01.826193+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 12200000000}}	\N
695	divar	ga6uXrGc	آپارتمان ۱۰۵ متری تازه تحویل	الهیه	12500000000	sale	44	https://divar.ir/v/_/ga6uXrGc	2026-09-28 14:37:44.523411+00	2026-09-28 14:38:01.830969+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 12500000000}}	\N
696	divar	gamm0r3R	آپارتمان سند ملکی/دوخوابه/بسیار خوش نقشه/دسترسی	عبادی	7350000000	sale	\N	https://divar.ir/v/_/gamm0r3R	2026-09-28 14:37:07.734841+00	2026-09-28 14:38:01.834092+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۳۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در عبادی", "amounts": {"raw_amount": 7350000000}}	\N
697	divar	ga6uXHFq	فروش زمین ۳۰۰۰ متری در چهچهه بانیم ساعت آب	میان ولایت	4500000000	sale	\N	https://divar.ir/v/_/ga6uXHFq	2026-09-28 14:36:14.997994+00	2026-09-28 14:38:01.83682+00	\N	\N	\N	mashhad	3000	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 4500000000}}	\N
698	divar	gaZCxyju	ویلایی 125متری جنوبی	پروین اعتصامی	13200000000	sale	\N	https://divar.ir/v/_/gaZCxyju	2026-09-28 14:35:47.808231+00	2026-09-28 14:38:01.839259+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۱۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در پروین اعتصامی", "amounts": {"raw_amount": 13200000000}}	\N
699	divar	ga6qX6MZ	ویلایی صد متری مناسب ساخت ونشستن	یوسفیه (شهرک غرب)	7200000000	sale	38	https://divar.ir/v/_/ga6qX6MZ	2026-09-28 14:35:34.12185+00	2026-09-28 14:38:01.842406+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در یوسفیه (شهرک غرب)", "amounts": {"raw_amount": 7200000000}}	\N
700	divar	gai67ycP	خونه ویلایی یا ویلا نقلی لوکس	چاهشک	14500000000	sale	\N	https://divar.ir/v/_/gai67ycP	2026-09-28 14:35:23.29392+00	2026-09-28 14:38:01.844867+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در چاهشک", "amounts": {"raw_amount": 14500000000}}	\N
701	divar	ga4SNMan	آپارتمان 70متری شیک و تمیز / کوثر ، دانشگاه فردوسی	کوثر	\N	rent	13	https://divar.ir/v/_/ga4SNMan	2026-09-27 08:33:56.402562+00	2026-09-28 14:38:01.846854+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در کوثر", "amounts": {}}	\N
702	divar	ga6u3pjh	۱۳۰متر/فول امکانات/۳خواب/الهیه ۲۵	الهیه	\N	rent	44	https://divar.ir/v/_/ga6u3pjh	2026-09-28 14:37:35.791014+00	2026-09-28 14:38:01.84898+00	\N	\N	\N	mashhad	130	3	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"اجاره": 30000000}}	\N
703	divar	gaxiSkC1	هم خونه	ابوذر	\N	rent	24	https://divar.ir/v/_/gaxiSkC1	2026-09-28 14:36:42.948433+00	2026-09-28 14:38:01.851097+00	\N	\N	\N	mashhad	\N	\N	\N	2500000	{"mid": "اجاره: ۲,۵۰۰,۰۰۰ تومان", "bottom": "در ابوذر", "amounts": {"اجاره": 2500000}}	\N
704	divar	ga5SSFYX	103متر/دوخواب/غرق نور	شهرک لشکر (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga5SSFYX	2026-09-28 14:36:20.523257+00	2026-09-28 14:38:01.858294+00	\N	\N	\N	mashhad	103	\N	\N	9000000	{"mid": "اجاره: ۹,۰۰۰,۰۰۰ تومان", "bottom": "گروه مهندسی ساختمانی دیان در شهرک لشکر (شهرک غرب)", "amounts": {"اجاره": 9000000}}	\N
705	divar	gaTS-L7R	رهن و اجاره	دانشجو	\N	rent	39	https://divar.ir/v/_/gaTS-L7R	2026-09-28 14:35:47.565772+00	2026-09-28 14:38:01.861491+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "در دانشجو", "amounts": {"اجاره": 1000000}}	\N
706	divar	ga6qXyg-	آپارتمان 65 متری یک خوابه تمیز	هدایت	\N	rent	26	https://divar.ir/v/_/ga6qXyg-	2026-09-28 14:34:24.295442+00	2026-09-28 14:38:01.86445+00	\N	\N	\N	mashhad	65	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هدایت", "amounts": {"اجاره": 10000000}}	\N
707	divar	ga6qH4SC	۶۵متری تک خواب	هفت تیر (نه دره)	\N	rent	\N	https://divar.ir/v/_/ga6qH4SC	2026-09-28 14:34:20.934113+00	2026-09-28 14:38:01.867266+00	\N	\N	\N	mashhad	65	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (نه دره)", "amounts": {"اجاره": 1000000}}	\N
708	divar	ga6qnnQE	۱۰۰ متر صارمی ۵۶ فول امکانات	هنرستان	\N	rent	11	https://divar.ir/v/_/ga6qnnQE	2026-09-28 14:33:48.221422+00	2026-09-28 14:38:01.870228+00	\N	\N	\N	mashhad	100	\N	\N	11000000	{"mid": "اجاره: ۱۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرستان", "amounts": {"اجاره": 11000000}}	\N
709	divar	ga5OzJLw	۱۶۰متر/قلب جلال/سروش/FULL BMS/شاهکار معماری مدرن	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga5OzJLw	2026-09-28 14:33:13.504855+00	2026-09-28 14:38:01.87418+00	\N	\N	\N	mashhad	160	\N	\N	60000000	{"mid": "اجاره: ۶۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن ایفل بین جلال ۱۶ وتقاطع فرهنگ در فرهنگ", "amounts": {"اجاره": 60000000}}	\N
710	divar	gaxiDe_-	آپارتمان ۸۵ متری ۲ خواب کم واحد	جاهد شهر	\N	rent	41	https://divar.ir/v/_/gaxiDe_-	2026-09-28 14:32:56.227006+00	2026-09-28 14:38:01.877434+00	\N	\N	\N	mashhad	85	2	\N	500000	{"mid": "اجاره: ۵۰۰,۰۰۰ تومان", "bottom": "سرزمین در جاهد شهر", "amounts": {"اجاره": 500000}}	\N
711	divar	ga6q3Rw9	(پلاکِ سجاد) 165متر درحدصفر تاپ لوکیشن وکیل آباد	اقبال	\N	rent	1	https://divar.ir/v/_/ga6q3Rw9	2026-09-28 14:32:39.918417+00	2026-09-28 14:38:01.880316+00	\N	\N	\N	mashhad	165	\N	\N	67000000	{"mid": "اجاره: ۶۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در اقبال", "amounts": {"اجاره": 67000000}}	\N
712	divar	gaqOaVQc	آپارتمان دوخواب دانشجو قبل فرهنگ	دانشجو	8200000000	sale	39	https://divar.ir/v/_/gaqOaVQc	2026-09-16 14:11:01.829311+00	2026-09-28 14:48:13.509629+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در دانشجو", "amounts": {"raw_amount": 8200000000}}	\N
713	divar	gaKtClUZ	۱۴۸متری/الهیه/مدرن و مجلل/اخرین واحد موجود	الهیه	16000000000	sale	44	https://divar.ir/v/_/gaKtClUZ	2026-09-28 14:47:39.860414+00	2026-09-28 14:48:13.516854+00	\N	\N	\N	mashhad	148	\N	\N	\N	{"mid": "۱۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 16000000000}}	\N
714	divar	ga2R_5Y1	آپارتمان۲۱۰متری/الهیه/چهارخواب/مطبخ دار/لوکس	الهیه	23000000000	sale	44	https://divar.ir/v/_/ga2R_5Y1	2026-09-28 14:47:24.191578+00	2026-09-28 14:48:13.52059+00	\N	\N	\N	mashhad	210	\N	\N	\N	{"mid": "۲۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 23000000000}}	\N
715	divar	gahWzb0R	ویلایی شیک و مدرن دوممر	شهرآرا	17300000000	sale	3	https://divar.ir/v/_/gahWzb0R	2026-09-28 14:47:04.291686+00	2026-09-28 14:48:13.523879+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۷,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرآرا", "amounts": {"raw_amount": 17300000000}}	\N
716	divar	ga623vAb	زمین اقامتی مسکونی	نوغان	118000000000	sale	\N	https://divar.ir/v/_/ga623vAb	2026-09-28 14:46:55.603851+00	2026-09-28 14:48:13.526544+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۱۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوغان", "amounts": {"raw_amount": 118000000000}}	\N
717	divar	ga4JCbAy	آپارتمان۲۰۵متری/الهیه/مجلل/لوکس/مدرن	الهیه	17900000000	sale	44	https://divar.ir/v/_/ga4JCbAy	2026-09-28 14:46:51.545102+00	2026-09-28 14:48:13.529448+00	\N	\N	\N	mashhad	205	\N	\N	\N	{"mid": "۱۷,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 17900000000}}	\N
718	divar	ga623yD_	۲۲۰متر نوساز / تک واحدی / دنج ترین در الهیه	الهیه	31800000000	sale	44	https://divar.ir/v/_/ga623yD_	2026-09-28 14:46:48.483718+00	2026-09-28 14:48:13.531603+00	\N	\N	\N	mashhad	220	\N	\N	\N	{"mid": "۳۱,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن ممتاز ایران در الهیه", "amounts": {"raw_amount": 31800000000}}	\N
719	divar	gaeqFgRv	زمین ۲۰۰ متری در الهیه امیریه	امیریه	17500000000	sale	\N	https://divar.ir/v/_/gaeqFgRv	2026-09-28 14:46:47.848148+00	2026-09-28 14:48:13.534276+00	\N	\N	\N	mashhad	200	\N	\N	\N	{"mid": "۱۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیریه", "amounts": {"raw_amount": 17500000000}}	\N
720	divar	gab2PE3A	آپارتمان ۲ونیم طبقه شهرک عسکریه	عسگریه	7700000000	sale	\N	https://divar.ir/v/_/gab2PE3A	2026-09-28 14:46:44.872479+00	2026-09-28 14:48:13.536533+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در عسگریه", "amounts": {"raw_amount": 7700000000}}	\N
721	divar	gaqCG-xP	استثنایی بلوارمعلم/حاشیه دانش آموز/بین معلم وفرهنگ	فرهنگ	10000000000	sale	\N	https://divar.ir/v/_/gaqCG-xP	2026-09-28 14:46:36.84804+00	2026-09-28 14:48:13.538474+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فرهنگ", "amounts": {"raw_amount": 10000000000}}	\N
722	divar	ga62HoSm	زمین سنددار قطعی شوراب	تبادکان	850000000	sale	\N	https://divar.ir/v/_/ga62HoSm	2026-09-28 14:46:33.591547+00	2026-09-28 14:48:13.540457+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در تبادکان", "amounts": {"raw_amount": 850000000}}	\N
723	divar	ga62HmeS	آپارتمان ۱۵۵ متری تک واحدی  نزدیک به چهارراه ورزش	شاهد (شهرک غرب)	19300000000	sale	38	https://divar.ir/v/_/ga62HmeS	2026-09-28 14:46:17.372413+00	2026-09-28 14:48:13.542478+00	\N	\N	\N	mashhad	155	\N	\N	\N	{"mid": "۱۹,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شاهد (شهرک غرب)", "amounts": {"raw_amount": 19300000000}}	\N
724	divar	ga62HcMi	۷۴ متری/فول امکانات/بهورز/تخلیه/سند اماده	فرهنگیان (شهرک غرب)	8500000000	sale	37	https://divar.ir/v/_/ga62HcMi	2026-09-28 14:46:04.001833+00	2026-09-28 14:48:13.544695+00	\N	\N	\N	mashhad	74	\N	\N	\N	{"mid": "۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 8500000000}}	\N
726	divar	ga66HAcm	هنرستان۱۹ ۱۳۰متر فول برج هنرستان	هنرستان	\N	rent	11	https://divar.ir/v/_/ga66HAcm	2026-09-28 14:47:42.459192+00	2026-09-28 14:48:13.548524+00	\N	\N	\N	mashhad	130	\N	\N	50000000	{"mid": "اجاره: ۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در هنرستان", "amounts": {"اجاره": 50000000}}	\N
727	divar	ga62X2Kx	رهن  و اجاره 68 متری مشاور زینلی	فدک	\N	rent	\N	https://divar.ir/v/_/ga62X2Kx	2026-09-28 14:47:04.261887+00	2026-09-28 14:48:13.550743+00	\N	\N	\N	mashhad	68	\N	\N	\N	{"mid": "رهن کامل", "bottom": "خانه لوکس جانباز ۷ نبش تلاش۲۷ در فدک", "amounts": {}}	\N
728	divar	ga623eW8	120متری/دوخواب/طبقه اول /امامیه	ادیب نیشابوری (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga623eW8	2026-09-28 14:46:19.15234+00	2026-09-28 14:48:13.552633+00	\N	\N	\N	mashhad	120	\N	\N	23000000	{"mid": "اجاره: ۲۳,۰۰۰,۰۰۰ تومان", "bottom": "مسکن برتر در ادیب نیشابوری (شهرک غرب)", "amounts": {"اجاره": 23000000}}	\N
729	divar	ga66ERVB	مجتمع نیکان/بازار محله قوی/پشت ایستگاه اتوبوس	الهیه	\N	rent	44	https://divar.ir/v/_/ga66ERVB	2026-09-28 14:45:54.130199+00	2026-09-28 14:48:13.555504+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در الهیه", "amounts": {}}	\N
730	divar	ga623fLp	۱۰۰متر /امیریه ۲۴/شخص ساز /تخلیه آخر ماه	الهیه	\N	rent	44	https://divar.ir/v/_/ga623fLp	2026-09-28 14:45:30.692891+00	2026-09-28 14:48:13.558105+00	\N	\N	\N	mashhad	100	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"اجاره": 10000000}}	\N
731	divar	ga6y3ojS	اجاره ورهن طبقه همکف راه جدا واقع در میثم 21	ابوذر	\N	rent	24	https://divar.ir/v/_/ga6y3ojS	2026-09-28 14:45:04.899734+00	2026-09-28 14:48:13.56039+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ابوذر", "amounts": {"اجاره": 8000000}}	\N
732	divar	garWanTE	۱۰۰ متر شیک اقدسیه ۵۳	امیریه	\N	rent	\N	https://divar.ir/v/_/garWanTE	2026-09-28 14:44:08.676405+00	2026-09-28 14:48:13.562603+00	\N	\N	\N	mashhad	100	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیریه", "amounts": {"اجاره": 30000000}}	\N
733	divar	gaom2Xet	70 متر/ تک خواب/ توس 15/ نوساز	جانباز	\N	rent	\N	https://divar.ir/v/_/gaom2Xet	2026-09-28 14:43:20.879914+00	2026-09-28 14:48:13.564659+00	\N	\N	\N	mashhad	70	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "خانه لوکس جانباز ۷ نبش تلاش۲۷ در جانباز", "amounts": {"اجاره": 7000000}}	\N
734	divar	ga6yXbww	۵۰مترخوش نقشه سامان۱غرق نور	الهیه	\N	rent	44	https://divar.ir/v/_/ga6yXbww	2026-09-28 14:42:56.635209+00	2026-09-28 14:48:13.566648+00	\N	\N	\N	mashhad	50	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"اجاره": 15000000}}	\N
735	divar	ga6ynbRY	آپارتمان رهن و اجاره	ابوذر	\N	rent	24	https://divar.ir/v/_/ga6ynbRY	2026-09-28 14:42:23.601542+00	2026-09-28 14:48:13.568777+00	\N	\N	\N	mashhad	\N	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ابوذر", "amounts": {"اجاره": 20000000}}	\N
736	divar	ga6yHsYI	170مترکوثر شمالی  ابتدا صارمی//دوسال ساخت لوکس	کوثر	\N	rent	13	https://divar.ir/v/_/ga6yHsYI	2026-09-28 14:42:00.668962+00	2026-09-28 14:48:13.57075+00	\N	\N	\N	mashhad	170	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در کوثر", "amounts": {}}	\N
737	divar	ga6yXmtk	۱۵۰متر *لوکس صفر کلید نخورده* محمدیه ۱۰	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga6yXmtk	2026-09-28 14:41:41.17077+00	2026-09-28 14:48:13.5728+00	\N	\N	\N	mashhad	150	\N	\N	52000000	{"mid": "اجاره: ۵۲,۰۰۰,۰۰۰ تومان", "bottom": "مسکن طبس گلشن در جاهد شهر", "amounts": {"اجاره": 52000000}}	\N
738	divar	ga6un8QK	۶۵متر/دوخواب/محدوده مفتح/	ایثار	\N	rent	\N	https://divar.ir/v/_/ga6un8QK	2026-09-28 14:40:56.944506+00	2026-09-28 14:48:13.574779+00	\N	\N	\N	mashhad	65	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثار", "amounts": {"اجاره": 1000}}	\N
739	divar	ga3GnpPw	واحد مستغلاتی*امامت نزدیک حاشیه*مسکن الهی پژوهیان	زیبا شهر	\N	rent	\N	https://divar.ir/v/_/ga3GnpPw	2026-09-28 14:40:28.312148+00	2026-09-28 14:48:13.576738+00	\N	\N	\N	mashhad	\N	\N	\N	46000000	{"mid": "اجاره: ۴۶,۰۰۰,۰۰۰ تومان", "bottom": "مسکن   الهی    نبش امامت ۴۶ در زیبا شهر", "amounts": {"اجاره": 46000000}}	\N
742	divar	ga6-nyo1	ویلایی ۱۲۵ متری دونبش خیابان ۲۰ متری	شهید مطهری	17200000000	sale	28	https://divar.ir/v/_/ga6-nyo1	2026-09-28 14:57:46.846308+00	2026-09-28 14:58:24.39957+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۱۷,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "محمد قره باغی در شهید مطهری", "amounts": {"raw_amount": 17200000000}}	\N
743	divar	gaUNqbz1	115متری / طبقه 7 /  آماده تحویل / املاک راد	جانباز	7240000000	sale	\N	https://divar.ir/v/_/gaUNqbz1	2026-09-28 14:57:42.660052+00	2026-09-28 14:58:24.403345+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۷,۲۴۰,۰۰۰,۰۰۰ تومان", "bottom": "در جانباز", "amounts": {"raw_amount": 7240000000}}	\N
744	divar	ga6-3Thl	160 متری صـفـر* دانـش آمـوز * /  محدوده مـعلم	سید رضی	24500000000	sale	\N	https://divar.ir/v/_/ga6-3Thl	2026-09-28 14:57:39.415788+00	2026-09-28 14:58:24.40672+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۲۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مهندس ضیائی  در سید رضی", "amounts": {"raw_amount": 24500000000}}	\N
745	divar	ga6CYVex	زمین صفی اباد / چاهشک / جلدک فی روز	الهیه	1200000000	sale	44	https://divar.ir/v/_/ga6CYVex	2026-09-28 14:57:35.583665+00	2026-09-28 14:58:24.410902+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دفتر مرکزی فاز ۲ الهیه محمدی در الهیه", "amounts": {"raw_amount": 1200000000}}	\N
746	divar	gauCEEhx	اپارتمان‌شیک‌۱۱۲متری‌حاشیه‌خیابان‌کشف	حضرت حجت	4700000000	sale	\N	https://divar.ir/v/_/gauCEEhx	2026-09-28 14:57:20.090084+00	2026-09-28 14:58:24.414909+00	\N	\N	\N	mashhad	112	\N	\N	\N	{"mid": "۴,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در حضرت حجت", "amounts": {"raw_amount": 4700000000}}	\N
747	divar	ga6C4FQp	110 متر / دو خواب / طبقه 3 / ویو باغ / املاک راد	جانباز	6800000000	sale	\N	https://divar.ir/v/_/ga6C4FQp	2026-09-28 14:57:01.176637+00	2026-09-28 14:58:24.418546+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۶,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جانباز", "amounts": {"raw_amount": 6800000000}}	\N
748	divar	gaeiZjlL	182متر ویو بی وقفه اول جلال  معاوضه هم میشود	فرهنگ	45500000000	sale	\N	https://divar.ir/v/_/gaeiZjlL	2026-09-28 14:56:58.419015+00	2026-09-28 14:58:24.42153+00	\N	\N	\N	mashhad	182	\N	\N	\N	{"mid": "۴۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فرهنگ", "amounts": {"raw_amount": 45500000000}}	\N
749	divar	ga6CICGd	۱۵۵ متر آپارتمان ۳ خواب عید تحویل  پیش فروش	شهید فرامرز عباسی	22500000000	sale	\N	https://divar.ir/v/_/ga6CICGd	2026-09-28 14:56:42.814801+00	2026-09-28 14:58:24.42475+00	\N	\N	\N	mashhad	155	3	\N	\N	{"mid": "۲۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید فرامرز عباسی", "amounts": {"raw_amount": 22500000000}}	\N
750	divar	gaJi1ypk	۷۴ متر	هفت تیر (آب و برق)	8400000000	sale	\N	https://divar.ir/v/_/gaJi1ypk	2026-09-28 14:56:41.587506+00	2026-09-28 14:58:24.427397+00	\N	\N	\N	mashhad	74	\N	\N	\N	{"mid": "۸,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (آب و برق)", "amounts": {"raw_amount": 8400000000}}	\N
752	divar	ga6C4BFn	اپارتمان۱۰۵متری/صفر/سند اماده/مدرن/شخصی ساز	الهیه	11000000000	sale	44	https://divar.ir/v/_/ga6C4BFn	2026-09-28 14:56:16.859844+00	2026-09-28 14:58:24.431081+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن میرشکاری در الهیه", "amounts": {"raw_amount": 11000000000}}	\N
753	divar	galqm6A0	240 متری / 3 خواب  / حاشیه جانباز 9 / املاک راد	جانباز	16800000000	sale	\N	https://divar.ir/v/_/galqm6A0	2026-09-28 14:56:04.18038+00	2026-09-28 14:58:24.432914+00	\N	\N	\N	mashhad	240	3	\N	\N	{"mid": "۱۶,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جانباز", "amounts": {"raw_amount": 16800000000}}	\N
754	divar	ga66XxlY	۱۶۰ متر استخر، سونا، روف‌گاردن	الهیه	22400000000	sale	44	https://divar.ir/v/_/ga66XxlY	2026-09-28 14:56:02.143773+00	2026-09-28 14:58:24.435263+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۲۲,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 22400000000}}	\N
755	divar	ga0-0Lq4	معاوضه صد درصد با چندآپارتمان یا۱۰ تومن  باغ	سید رضی	42500000000	sale	\N	https://divar.ir/v/_/ga0-0Lq4	2026-09-28 14:55:59.782571+00	2026-09-28 14:58:24.437318+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در سید رضی", "amounts": {"raw_amount": 42500000000}}	\N
756	divar	ga6Cocbl	96متری/نوساز/مدرن/8واحدی/مستغلاتی	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga6Cocbl	2026-09-28 14:58:07.289234+00	2026-09-28 14:58:24.439027+00	\N	\N	\N	mashhad	96	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "مسکن میرشکاری در جاهد شهر", "amounts": {"اجاره": 1000000}}	\N
757	divar	gapG1hkI	اول جلال*دوقدمی وکیل آباد و مترو*مسکن الهی پژوهیان	فرهنگ	\N	rent	\N	https://divar.ir/v/_/gapG1hkI	2026-09-28 14:57:11.661806+00	2026-09-28 14:58:24.440793+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن   الهی    نبش امامت ۴۶ در فرهنگ", "amounts": {}}	\N
758	divar	ga6-XyN2	واحد 100متری فول / بلوار صارمی (حافظ)	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/ga6-XyN2	2026-09-28 14:56:40.533636+00	2026-09-28 14:58:24.442683+00	\N	\N	\N	mashhad	100	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (حافظ)", "amounts": {"اجاره": 15000000}}	\N
759	divar	ga6-nnCn	100متر،دوخواب،اول محمدیه	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga6-nnCn	2026-09-28 14:54:34.424355+00	2026-09-28 14:58:24.444814+00	\N	\N	\N	mashhad	100	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "شهرمشهد نبش رحمانیه۵ در جاهد شهر", "amounts": {"اجاره": 30000000}}	\N
760	divar	ga6-XbPm	رهن و اجاره	کوثر	\N	rent	13	https://divar.ir/v/_/ga6-XbPm	2026-09-28 14:53:46.640057+00	2026-09-28 14:58:24.446804+00	\N	\N	\N	mashhad	\N	\N	\N	90000000	{"mid": "اجاره: ۹۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 90000000}}	\N
761	divar	ga66H57M	اپارتمان ۱۲۰ متری برای اجاره در افتابی	هنرور	\N	rent	\N	https://divar.ir/v/_/ga66H57M	2026-09-28 14:52:12.415073+00	2026-09-28 14:58:24.448819+00	\N	\N	\N	mashhad	120	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"اجاره": 12000000}}	\N
762	divar	gad65_VN	رهن آپارتمان در سیدی	کوی ولیعصر	\N	rent	\N	https://divar.ir/v/_/gad65_VN	2026-09-28 14:50:42.415947+00	2026-09-28 14:58:24.450847+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "در کوی ولیعصر", "amounts": {"اجاره": 10000}}	\N
763	divar	ga62XZLo	اپارتمان ۶۰ متری	سرافرازان	\N	rent	22	https://divar.ir/v/_/ga62XZLo	2026-09-28 14:48:49.121934+00	2026-09-28 14:58:24.453281+00	\N	\N	\N	mashhad	60	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سرافرازان", "amounts": {"اجاره": 10000000}}	\N
765	divar	ga4uUoE0	فروش منزل 155 متر ویلایی عبدالمطلب 10 دوطبقه	شهید مطهری	21000000000	sale	28	https://divar.ir/v/_/ga4uUoE0	2026-09-26 22:48:58.289433+00	2026-09-28 15:08:34.938656+00	\N	\N	\N	mashhad	155	\N	\N	\N	{"mid": "۲۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید مطهری", "amounts": {"raw_amount": 21000000000}}	\N
766	divar	ga0OE1ni	ویلایی تا حرم 1دقیقه پیاده 5دقیقه فقط پول ساخت	رضاییه	12500000000	sale	\N	https://divar.ir/v/_/ga0OE1ni	2026-09-23 21:37:30.305385+00	2026-09-28 15:08:34.944501+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رضاییه", "amounts": {"raw_amount": 12500000000}}	\N
767	divar	ga6KIVWE	آپارتمان ۶۰متری طبقه سوم پیامبر اعظم ۲۳	شهرک امام هادی (شهرک غرب)	3200000000	sale	38	https://divar.ir/v/_/ga6KIVWE	2026-09-28 15:08:03.266284+00	2026-09-28 15:08:34.946962+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهرک امام هادی (شهرک غرب)", "amounts": {"raw_amount": 3200000000}}	\N
768	divar	ga6GYyVB	۷۵ متری حسابی شمالی ۳ سه نبش	فرهنگیان (شهرک غرب)	7500000000	sale	37	https://divar.ir/v/_/ga6GYyVB	2026-09-28 15:07:24.847288+00	2026-09-28 15:08:34.949382+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 7500000000}}	\N
769	divar	gaX6tCsH	باغ ۸۰۰ملیونی رو ۳۵۰ملیون بخر داخل بافت بامجوزساخت	حجاب (شهرک غرب)	350000000	sale	38	https://divar.ir/v/_/gaX6tCsH	2026-09-28 15:07:20.88295+00	2026-09-28 15:08:34.951576+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در حجاب (شهرک غرب)", "amounts": {"raw_amount": 350000000}}	\N
770	divar	ga6KYIIf	۱۰۰مترهاشمیه-فول امکانات-طبقه چهارم-زیرقیمت منطقه	چهارچشمه	12000000000	sale	\N	https://divar.ir/v/_/ga6KYIIf	2026-09-28 15:06:54.353949+00	2026-09-28 15:08:34.953685+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهارچشمه", "amounts": {"raw_amount": 12000000000}}	\N
771	divar	ga6KoSm1	85 متری/ بهورز / دوکله/خوش نقشه	فرهنگیان (شهرک غرب)	11450000000	sale	37	https://divar.ir/v/_/ga6KoSm1	2026-09-28 15:06:34.115315+00	2026-09-28 15:08:34.955714+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۱۱,۴۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سپهر فلاحی ۱۳ در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 11450000000}}	\N
772	divar	ga6KIG2K	برج صبا ۱ واحد ۹۵متری	امیریه	9200000000	sale	\N	https://divar.ir/v/_/ga6KIG2K	2026-09-28 15:06:25.570367+00	2026-09-28 15:08:34.957787+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۹,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیریه", "amounts": {"raw_amount": 9200000000}}	\N
773	divar	ga6KIQSw	رضاشهر دعبل خزائی( آپارتمان ۱۶۸ متر ) فرصت محدود	رضاشهر	33000000000	sale	\N	https://divar.ir/v/_/ga6KIQSw	2026-09-28 15:06:17.154379+00	2026-09-28 15:08:34.959764+00	\N	\N	\N	mashhad	168	\N	\N	\N	{"mid": "۳۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاشهر", "amounts": {"raw_amount": 33000000000}}	\N
774	divar	ga6KYE8P	70 متر ویلایی توس	شهرک امام هادی (شهرک غرب)	3000000000	sale	38	https://divar.ir/v/_/ga6KYE8P	2026-09-28 15:05:46.202226+00	2026-09-28 15:08:34.96164+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک امام هادی (شهرک غرب)", "amounts": {"raw_amount": 3000000000}}	\N
776	divar	ga6KIYU-	مورد اجاره شکار هاشمیه قبل فکوری تخلیه باپارکینگ	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga6KIYU-	2026-09-28 15:08:30.427133+00	2026-09-28 15:08:34.965329+00	\N	\N	\N	mashhad	\N	\N	\N	21000000	{"mid": "اجاره: ۲۱,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در چهارچشمه", "amounts": {"اجاره": 21000000}}	\N
777	divar	ga6KoeBw	اپارتمان۲۶۰متر برج	هنرستان	\N	rent	11	https://divar.ir/v/_/ga6KoeBw	2026-09-28 15:08:12.445773+00	2026-09-28 15:08:34.967244+00	\N	\N	\N	mashhad	260	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در هنرستان", "amounts": {"اجاره": 30000000}}	\N
778	divar	ga6G40NB	اجاره بلند مدت واحد یکخواب و دوخواب	سناباد	\N	rent	\N	https://divar.ir/v/_/ga6G40NB	2026-09-28 15:08:01.201848+00	2026-09-28 15:08:34.969541+00	\N	\N	\N	mashhad	\N	\N	\N	21000000	{"mid": "اجاره: ۲۱,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در سناباد", "amounts": {"اجاره": 21000000}}	\N
779	divar	ga6K4qF1	رهن و اجاره وفروش	طبرسی شمالی	\N	rent	42	https://divar.ir/v/_/ga6K4qF1	2026-09-28 15:07:30.062136+00	2026-09-28 15:08:34.97219+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {"اجاره": 10000000}}	\N
780	divar	ga3mJ5bT	160متر/ امامت / تمدید سالیانه / مسکن الهی	زیبا شهر	\N	rent	\N	https://divar.ir/v/_/ga3mJ5bT	2026-09-28 15:07:18.066428+00	2026-09-28 15:08:34.974569+00	\N	\N	\N	mashhad	160	\N	\N	46000000	{"mid": "اجاره: ۴۶,۰۰۰,۰۰۰ تومان", "bottom": "مسکن   الهی    نبش امامت ۴۶ در زیبا شهر", "amounts": {"اجاره": 46000000}}	\N
781	divar	ga6KYanU	آپارتمان 2خواب نوساز،شهرک نوید	نوید	\N	rent	\N	https://divar.ir/v/_/ga6KYanU	2026-09-28 15:07:03.544128+00	2026-09-28 15:08:34.97665+00	\N	\N	\N	mashhad	\N	2	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در نوید", "amounts": {}}	\N
782	divar	ga6CoaHO	130متر/طبقه3/اسانسور	سجاد شهر	\N	rent	21	https://divar.ir/v/_/ga6CoaHO	2026-09-28 15:06:32.399649+00	2026-09-28 15:08:34.978658+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "رهن کامل", "bottom": "محمدی در سجاد شهر", "amounts": {}}	\N
783	divar	ga6K4G7p	رهن کامل خانه	نوده	\N	rent	\N	https://divar.ir/v/_/ga6K4G7p	2026-09-28 15:05:47.451148+00	2026-09-28 15:08:34.980631+00	\N	\N	\N	mashhad	\N	\N	\N	500000000	{"mid": "اجاره: ۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوده", "amounts": {"اجاره": 500000000}}	\N
784	divar	ga6GI3Sp	برج اپارتمان های فجر ، فول امکانات	حسابی جنوبی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6GI3Sp	2026-09-28 15:05:27.24614+00	2026-09-28 15:08:34.982525+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حسابی جنوبی (شهرک غرب)", "amounts": {"اجاره": 1000000}}	\N
785	divar	ga6K4D7c	اپارتمان ۱۲۰ متری شیک در هنرور	هنرور	\N	rent	\N	https://divar.ir/v/_/ga6K4D7c	2026-09-28 15:05:27.232514+00	2026-09-28 15:08:34.984687+00	\N	\N	\N	mashhad	120	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"اجاره": 12000000}}	\N
786	divar	ga6G4lEC	آپارتمان رهن و اجاره	رسالت	\N	rent	32	https://divar.ir/v/_/ga6G4lEC	2026-09-28 15:05:12.830271+00	2026-09-28 15:08:34.986779+00	\N	\N	\N	mashhad	\N	\N	\N	50000	{"mid": "اجاره: ۵۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رسالت", "amounts": {"اجاره": 50000}}	\N
787	divar	ga6GY3dt	همخونه نیازمندم	کوثر	\N	rent	13	https://divar.ir/v/_/ga6GY3dt	2026-09-28 15:05:12.68105+00	2026-09-28 15:08:34.989329+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 100000}}	\N
788	divar	ga6GY45W	160متر / صفر / سازه مدرن	فردوسی	\N	rent	\N	https://divar.ir/v/_/ga6GY45W	2026-09-28 15:04:46.804974+00	2026-09-28 15:08:34.991246+00	\N	\N	\N	mashhad	160	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فردوسی", "amounts": {"اجاره": 10000}}	\N
789	divar	ga6Go_H2	آپارتمان ۸۵ متری / ادیب / بازسازی شده	استاد یوسفی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6Go_H2	2026-09-28 15:04:36.318705+00	2026-09-28 15:08:34.993061+00	\N	\N	\N	mashhad	85	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در استاد یوسفی (شهرک غرب)", "amounts": {"اجاره": 20000000}}	\N
790	divar	ga6G46BC	۹۰ متر خوش‌نقشه/ پارکینگ بدون مزاحمت /آسانسور	نیروی هوایی	\N	rent	\N	https://divar.ir/v/_/ga6G46BC	2026-09-28 15:04:22.93116+00	2026-09-28 15:08:34.995088+00	\N	\N	\N	mashhad	90	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نیروی هوایی", "amounts": {"اجاره": 30000000}}	\N
791	divar	ga6GokHU	اجاره آپارتمان نوفل (۴۴ متر تراس)	نوفل لوشاتو	\N	rent	\N	https://divar.ir/v/_/ga6GokHU	2026-09-28 15:03:45.801833+00	2026-09-28 15:08:34.997022+00	\N	\N	\N	mashhad	44	\N	\N	53000000	{"mid": "اجاره: ۵۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوفل لوشاتو", "amounts": {"اجاره": 53000000}}	\N
792	divar	ga6Gojk9	فروش رهن اجاره	نظام دوست	\N	rent	\N	https://divar.ir/v/_/ga6Gojk9	2026-09-28 15:03:02.269359+00	2026-09-28 15:08:34.998933+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نظام دوست", "amounts": {"اجاره": 10000}}	\N
793	divar	ga6G4jei	۱۴۷ متری لوکیشن قوی	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga6G4jei	2026-09-28 15:02:57.882141+00	2026-09-28 15:08:35.001716+00	\N	\N	\N	mashhad	147	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {}}	\N
794	divar	ga5WkUz8	310 متر 4 خواب سجاد	سجاد شهر	60000000000	sale	21	https://divar.ir/v/_/ga5WkUz8	2026-09-28 15:18:06.367752+00	2026-09-28 15:18:46.462077+00	\N	\N	\N	mashhad	310	4	\N	\N	{"mid": "۶۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن والی در سجاد شهر", "amounts": {"raw_amount": 60000000000}}	\N
795	divar	ga6Soyon	105 متری*با آسانسور*اول فرامرز	شهید فرامرز عباسی	15000000000	sale	\N	https://divar.ir/v/_/ga6Soyon	2026-09-28 15:17:34.011049+00	2026-09-28 15:18:46.472775+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "جواد رحیمی در شهید فرامرز عباسی", "amounts": {"raw_amount": 15000000000}}	\N
796	divar	ga6SIsdf	واحد ۱۶۰ متری	ایثارگران	10000000000	sale	\N	https://divar.ir/v/_/ga6SIsdf	2026-09-28 15:17:32.941227+00	2026-09-28 15:18:46.477833+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۱۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثارگران", "amounts": {"raw_amount": 10000000000}}	\N
797	divar	ga6SYk_i	آپارتمان ۸۷ متری	الهیه	7500000000	sale	44	https://divar.ir/v/_/ga6SYk_i	2026-09-28 15:17:19.271369+00	2026-09-28 15:18:46.481132+00	\N	\N	\N	mashhad	87	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 7500000000}}	\N
798	divar	gaxmUhTp	۹۵متر دوخواب / همکف / ابتدای جلال	فرهنگ	13900000000	sale	\N	https://divar.ir/v/_/gaxmUhTp	2026-09-28 15:17:13.981422+00	2026-09-28 15:18:46.483298+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۱۳,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "جمال بهبودی در فرهنگ", "amounts": {"raw_amount": 13900000000}}	\N
799	divar	ga6Soq2w	خانه ویلایی ۶۵ متری در شهید معقول	شهید معقول	2050000000	sale	\N	https://divar.ir/v/_/ga6Soq2w	2026-09-28 15:17:10.444246+00	2026-09-28 15:18:46.485366+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۲,۰۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید معقول", "amounts": {"raw_amount": 2050000000}}	\N
800	divar	ga6SoyU2	102 متری/ 2 خوب/ غرق نور/ دو واحدی/ صفر تحویل	الهیه	11600000000	sale	44	https://divar.ir/v/_/ga6SoyU2	2026-09-28 15:16:39.003348+00	2026-09-28 15:18:46.489491+00	\N	\N	\N	mashhad	102	\N	\N	\N	{"mid": "۱۱,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن میرشکاری در الهیه", "amounts": {"raw_amount": 11600000000}}	\N
801	divar	ga6S4sYL	۱۱۴ متر / صفر / غرق نور / لوکیشن بی‌نظیر	الهیه	17700000000	sale	44	https://divar.ir/v/_/ga6S4sYL	2026-09-28 15:16:17.318705+00	2026-09-28 15:18:46.491731+00	\N	\N	\N	mashhad	114	\N	\N	\N	{"mid": "۱۷,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن ممتاز ایران در الهیه", "amounts": {"raw_amount": 17700000000}}	\N
802	divar	ga3q_FWm	آپارتمان ۸۶ متری  عبدالمطلب	رستگار	5300000000	sale	\N	https://divar.ir/v/_/ga3q_FWm	2026-09-28 15:15:48.240498+00	2026-09-28 15:18:46.493858+00	\N	\N	\N	mashhad	86	\N	\N	\N	{"mid": "۵,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رستگار", "amounts": {"raw_amount": 5300000000}}	\N
803	divar	ga6SolWj	طبقه اول ۷۵متر ۲خواب سرنبش کوچه نزدیک حرم	عبادی	7250000000	sale	\N	https://divar.ir/v/_/ga6SolWj	2026-09-28 15:15:46.785786+00	2026-09-28 15:18:46.495916+00	\N	\N	\N	mashhad	75	2	\N	\N	{"mid": "۷,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در عبادی", "amounts": {"raw_amount": 7250000000}}	\N
804	divar	ga6Soleo	برج نسیم 95 متری 2 خواب	امیریه	8800000000	sale	\N	https://divar.ir/v/_/ga6Soleo	2026-09-28 15:15:43.822281+00	2026-09-28 15:18:46.498415+00	\N	\N	\N	mashhad	95	2	\N	\N	{"mid": "۸,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در امیریه", "amounts": {"raw_amount": 8800000000}}	\N
805	divar	gadWX9-j	منزل ویلایی ۵۰متری	همت آباد	850000000	sale	\N	https://divar.ir/v/_/gadWX9-j	2026-09-28 15:15:35.080439+00	2026-09-28 15:18:46.500396+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در همت آباد", "amounts": {"raw_amount": 850000000}}	\N
806	divar	ga6WoLvi	آپارتمان صفر سه خواب تک واحدی در صیاد شیرازی	هفت تیر (آب و برق)	\N	rent	\N	https://divar.ir/v/_/ga6WoLvi	2026-09-28 15:18:13.238985+00	2026-09-28 15:18:46.502294+00	\N	\N	\N	mashhad	\N	\N	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در هفت تیر (آب و برق)", "amounts": {"اجاره": 35000000}}	\N
807	divar	ga6WIAY4	اپارتمان ۷۵ متری گلریز۵/۶	توس (بلوار توس)	\N	rent	\N	https://divar.ir/v/_/ga6WIAY4	2026-09-28 15:17:29.393232+00	2026-09-28 15:18:46.50508+00	\N	\N	\N	mashhad	75	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {"اجاره": 10000000}}	\N
808	divar	ga6SIPmp	دربست دوبلکس نقلی در شقایق۸	هفت تیر (نه دره)	\N	rent	\N	https://divar.ir/v/_/ga6SIPmp	2026-09-28 15:14:57.372733+00	2026-09-28 15:18:46.507282+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (نه دره)", "amounts": {"اجاره": 10000000}}	\N
809	divar	ga6OYnFm	اپارتمان اجاره ای۵۰متری	الهیه	\N	rent	44	https://divar.ir/v/_/ga6OYnFm	2026-09-28 15:11:31.16704+00	2026-09-28 15:18:46.509825+00	\N	\N	\N	mashhad	50	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"اجاره": 10000000}}	\N
810	divar	ga6Ooa_1	رهن واجاره	بهاران	\N	rent	17	https://divar.ir/v/_/ga6Ooa_1	2026-09-28 15:10:41.735879+00	2026-09-28 15:18:46.511981+00	\N	\N	\N	mashhad	\N	\N	\N	36000000	{"mid": "اجاره: ۳۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهاران", "amounts": {"اجاره": 36000000}}	\N
811	divar	ga6OIFg2	125متری صفر	گلشور	\N	rent	\N	https://divar.ir/v/_/ga6OIFg2	2026-09-28 15:09:46.383179+00	2026-09-28 15:18:46.513966+00	\N	\N	\N	mashhad	125	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گلشور", "amounts": {"اجاره": 15000000}}	\N
812	divar	gayWpbpT	آپارتمان 85متر هفت تیر اوایل	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/gayWpbpT	2026-09-28 15:09:18.989218+00	2026-09-28 15:18:46.515889+00	\N	\N	\N	mashhad	85	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (حافظ)", "amounts": {"اجاره": 30000000}}	\N
816	divar	ga6eIo6a	۲۴۰ متر /سه‌نبش حاشیه/ ویوابدی/ تراس چیدمان	الهیه	30000000000	sale	44	https://divar.ir/v/_/ga6eIo6a	2026-09-28 15:28:44.879916+00	2026-09-28 15:28:57.62499+00	\N	\N	\N	mashhad	240	\N	\N	\N	{"mid": "۳۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 30000000000}}	\N
817	divar	ga6e4ntR	ویلایی قبل معلم/جلال زوج/جنوبی	فرهنگ	81000000000	sale	\N	https://divar.ir/v/_/ga6e4ntR	2026-09-28 15:28:39.538452+00	2026-09-28 15:28:57.632892+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فرهنگ", "amounts": {"raw_amount": 81000000000}}	\N
818	divar	ga6eIdBK	آپارتمان بدون مشابه *فلاحی *بدون مشرفیت	شهرک لشکر (شهرک غرب)	8845000000	sale	38	https://divar.ir/v/_/ga6eIdBK	2026-09-28 15:28:32.237191+00	2026-09-28 15:28:57.635942+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۸۴۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهرک لشکر (شهرک غرب)", "amounts": {"raw_amount": 8845000000}}	\N
819	divar	ga6SoVSD	آپارتمان ۱۴۳ متری‌ بازسازی شده تک واحدی‌ سر دونبش	امام رضا (ع)	20000000000	sale	\N	https://divar.ir/v/_/ga6SoVSD	2026-09-28 15:28:24.533742+00	2026-09-28 15:28:57.638458+00	\N	\N	\N	mashhad	143	\N	\N	\N	{"mid": "۲۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در امام رضا (ع)", "amounts": {"raw_amount": 20000000000}}	\N
820	divar	ga6eYSWN	منزل ویلایی ۵۰ متری  یک خواب	مهدی آباد	2250000000	sale	\N	https://divar.ir/v/_/ga6eYSWN	2026-09-28 15:27:30.751107+00	2026-09-28 15:28:57.640586+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۲,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مهدی آباد", "amounts": {"raw_amount": 2250000000}}	\N
821	divar	ga6SoVez	فروش آپارتمان چراغچی 23	بلال	3100000000	sale	\N	https://divar.ir/v/_/ga6SoVez	2026-09-28 15:27:19.513184+00	2026-09-28 15:28:57.642649+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بلال", "amounts": {"raw_amount": 3100000000}}	\N
822	divar	ga6eoMjD	آپارتمان ۱۲۵ متر/با نمایی خاص و بدون تکرار	الهیه	12000000000	sale	44	https://divar.ir/v/_/ga6eoMjD	2026-09-28 15:27:02.69229+00	2026-09-28 15:28:57.644669+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۱۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن ممتاز ایران در الهیه", "amounts": {"raw_amount": 12000000000}}	\N
823	divar	ga6e4Inf	(پلاکِ سجاد) فروش آپارتمانهای 165متر3مستر صفرمدرن	سجاد شهر	49500000000	sale	21	https://divar.ir/v/_/ga6e4Inf	2026-09-28 15:26:37.979813+00	2026-09-28 15:28:57.646525+00	\N	\N	\N	mashhad	165	\N	\N	\N	{"mid": "۴۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "پلاکِ سجاد در سجاد شهر", "amounts": {"raw_amount": 49500000000}}	\N
824	divar	gaumklc1	آپارتمان ۲ طبقه دربست با حیاط	طبرسی شمالی	3200000000	sale	42	https://divar.ir/v/_/gaumklc1	2026-09-28 15:26:18.575927+00	2026-09-28 15:28:57.648883+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در طبرسی شمالی", "amounts": {"raw_amount": 3200000000}}	\N
826	divar	ga6eoTXq	اجاره آپارتمان	سعد آباد	\N	rent	\N	https://divar.ir/v/_/ga6eoTXq	2026-09-28 15:27:19.839225+00	2026-09-28 15:28:57.652388+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سعد آباد", "amounts": {"اجاره": 100000}}	\N
827	divar	ga6SYK9f	آپارتمان ۱۲۰ متری رهن و اجاره	شهید بهشتی	\N	rent	18	https://divar.ir/v/_/ga6SYK9f	2026-09-28 15:27:05.839274+00	2026-09-28 15:28:57.654667+00	\N	\N	\N	mashhad	120	\N	\N	37000000	{"mid": "اجاره: ۳۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید بهشتی", "amounts": {"اجاره": 37000000}}	\N
829	divar	ga6a4q2r	امیریه 3 شیکـ 150متر 3 خواب (تک واحدی) فول امکانات	امیریه	\N	rent	\N	https://divar.ir/v/_/ga6a4q2r	2026-09-28 15:24:37.772516+00	2026-09-28 15:28:57.65859+00	\N	\N	\N	mashhad	150	3	\N	28000000	{"mid": "اجاره: ۲۸,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال لو در امیریه", "amounts": {"اجاره": 28000000}}	\N
830	divar	ga6WoC7R	آپارتمان 180مترطبقه2سه خواب فول4سال ساخت	سید رضی	\N	rent	\N	https://divar.ir/v/_/ga6WoC7R	2026-09-28 15:24:10.795281+00	2026-09-28 15:28:57.661052+00	\N	\N	\N	mashhad	180	\N	\N	45000000	{"mid": "اجاره: ۴۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سید رضی", "amounts": {"اجاره": 45000000}}	\N
831	divar	ga6aYZWm	ویلایی ۲۵۰ متری دانش آموز۱۶	دانشجو	\N	rent	39	https://divar.ir/v/_/ga6aYZWm	2026-09-28 15:24:08.519015+00	2026-09-28 15:28:57.663693+00	\N	\N	\N	mashhad	250	\N	\N	28000000	{"mid": "اجاره: ۲۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در دانشجو", "amounts": {"اجاره": 28000000}}	\N
832	divar	ga6a4dRX	اپارتمان ۸۵ متر طبقه ششم فول حبیب مظاهر(گاز)	گاز	\N	rent	\N	https://divar.ir/v/_/ga6a4dRX	2026-09-28 15:23:56.127656+00	2026-09-28 15:28:57.666307+00	\N	\N	\N	mashhad	85	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دفتر معاملات شبانی در گاز", "amounts": {"اجاره": 10000000}}	\N
833	divar	ga6aYfNK	آپارتمان 240مدرن با 30 مترتراس صفر ارتفاع سقف بلند	نیروی هوایی	\N	rent	\N	https://divar.ir/v/_/ga6aYfNK	2026-09-28 15:23:49.798586+00	2026-09-28 15:28:57.668562+00	\N	\N	\N	mashhad	30	\N	\N	120000000	{"mid": "اجاره: ۱۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نیروی هوایی", "amounts": {"اجاره": 120000000}}	\N
834	divar	ga6aII7L	اجاره منزل ویلایی	پنجتن	\N	rent	\N	https://divar.ir/v/_/ga6aII7L	2026-09-28 15:22:17.231618+00	2026-09-28 15:28:57.670604+00	\N	\N	\N	mashhad	\N	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پنجتن", "amounts": {"اجاره": 4000000}}	\N
835	divar	ga52EGvq	محمدیه ۲ / سند آماده/ ۲نبش	الهیه	10650000000	sale	44	https://divar.ir/v/_/ga52EGvq	2026-09-27 17:06:45.312636+00	2026-09-28 15:39:13.108416+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۰,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در الهیه", "amounts": {"raw_amount": 10650000000}}	\N
836	divar	gatOQMdB	آپارتمان ۷۵ متر یک خواب	بهمن	4000000000	sale	43	https://divar.ir/v/_/gatOQMdB	2026-09-28 15:39:07.684496+00	2026-09-28 15:39:13.115438+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهمن", "amounts": {"raw_amount": 4000000000}}	\N
837	divar	ga5eFh-q	۲خواب‌بازسازی‌شده/اول هاشمیه	کوثر	13900000000	sale	13	https://divar.ir/v/_/ga5eFh-q	2026-09-28 15:38:56.669562+00	2026-09-28 15:39:13.117798+00	\N	\N	\N	mashhad	\N	2	\N	\N	{"mid": "۱۳,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن هنرستان واقع در نبش هنرستان بیست در کوثر", "amounts": {"raw_amount": 13900000000}}	\N
838	divar	ga6eo0h4	خونه نوساز و تمیز	انصار	4500000000	sale	\N	https://divar.ir/v/_/ga6eo0h4	2026-09-28 15:38:31.146891+00	2026-09-28 15:39:13.119952+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در انصار", "amounts": {"raw_amount": 4500000000}}	\N
839	divar	ga6m4UY5	آپارتمان۵۰متری طبقه همکف	کوی دروی	2250000000	sale	\N	https://divar.ir/v/_/ga6m4UY5	2026-09-28 15:38:09.120381+00	2026-09-28 15:39:13.122194+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۲,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی دروی", "amounts": {"raw_amount": 2250000000}}	\N
840	divar	ga6iYco6	سهیل جاهد/ 155 متری 3 خواب / امام خمینی 44	امام رضا (ع)	23250000000	sale	\N	https://divar.ir/v/_/ga6iYco6	2026-09-28 15:37:58.820003+00	2026-09-28 15:39:13.12418+00	\N	\N	\N	mashhad	155	3	\N	\N	{"mid": "۲۳,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امام رضا (ع)", "amounts": {"raw_amount": 23250000000}}	\N
841	divar	ga6moUNY	۳۰۰مترباغ،مجتمع اختصاصی،موقعیت مناسبِ سرمایه‌گذاری	کاظم آباد	1900000000	sale	\N	https://divar.ir/v/_/ga6moUNY	2026-09-28 15:37:48.2179+00	2026-09-28 15:39:13.126203+00	\N	\N	\N	mashhad	300	\N	\N	\N	{"mid": "۱,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کاظم آباد", "amounts": {"raw_amount": 1900000000}}	\N
842	divar	ga6mIhPs	کاظمیه ۹ آپارتمان ۹۵ متری نوساز	امیریه	10450000000	sale	\N	https://divar.ir/v/_/ga6mIhPs	2026-09-28 15:37:31.496094+00	2026-09-28 15:39:13.128023+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۱۰,۴۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیریه", "amounts": {"raw_amount": 10450000000}}	\N
843	divar	ga6moWUd	اپارتمان ۶۵ متری/ شیک/داخل حاشیه	حضرت حجت	2700000000	sale	\N	https://divar.ir/v/_/ga6moWUd	2026-09-28 15:37:10.133602+00	2026-09-28 15:39:13.129871+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۲,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حضرت حجت", "amounts": {"raw_amount": 2700000000}}	\N
845	divar	ga6i42P1	امیریه 37 لوکس شیکـ متریال برند 140 متر اتاق مستر	الهیه	\N	rent	44	https://divar.ir/v/_/ga6i42P1	2026-09-28 15:38:55.130007+00	2026-09-28 15:39:13.134254+00	\N	\N	\N	mashhad	140	\N	\N	45000000	{"mid": "اجاره: ۴۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال لو در الهیه", "amounts": {"اجاره": 45000000}}	\N
846	divar	ga6mIy9-	آپارتمان اجاره	هنرور	\N	rent	\N	https://divar.ir/v/_/ga6mIy9-	2026-09-28 15:38:44.287678+00	2026-09-28 15:39:13.136253+00	\N	\N	\N	mashhad	\N	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در هنرور", "amounts": {"اجاره": 6000000}}	\N
847	divar	ga6mYgEt	آپارتمان ۱۰۰متری  باباطاهر	جنت	\N	rent	\N	https://divar.ir/v/_/ga6mYgEt	2026-09-28 15:38:21.369355+00	2026-09-28 15:39:13.138151+00	\N	\N	\N	mashhad	100	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در جنت", "amounts": {"اجاره": 100000}}	\N
848	divar	ga6mo15J	۱۳۰ متر ویلایی	رضاییه	\N	rent	\N	https://divar.ir/v/_/ga6mo15J	2026-09-28 15:38:06.861303+00	2026-09-28 15:39:13.139959+00	\N	\N	\N	mashhad	130	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاییه", "amounts": {"اجاره": 40000000}}	\N
849	divar	gan6JrR2	اپارتمان ۱۵۰متری نوسازمناسب جهیزیه اول جلال	فرهنگ	\N	rent	\N	https://divar.ir/v/_/gan6JrR2	2026-09-28 15:37:56.537257+00	2026-09-28 15:39:13.142153+00	\N	\N	\N	mashhad	150	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "در فرهنگ", "amounts": {"اجاره": 1000000}}	\N
850	divar	ga6m4Qud	آپارتمان سه خواب تک واحدی درحد هاشمیه ۱۸	کوثر	\N	rent	13	https://divar.ir/v/_/ga6m4Qud	2026-09-28 15:35:38.004231+00	2026-09-28 15:39:13.144897+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در کوثر", "amounts": {}}	\N
851	divar	gal-hHwb	آپارتمان ۱۱۵ متری صیاد ۱۴	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/gal-hHwb	2026-09-28 15:35:23.139551+00	2026-09-28 15:39:13.147069+00	\N	\N	\N	mashhad	115	\N	\N	32000000	{"mid": "اجاره: ۳۲,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (حافظ)", "amounts": {"اجاره": 32000000}}	\N
852	divar	ga6i4lW1	رهن اجاره اپارتمان ۵۵ متری	ایثارگران	\N	rent	\N	https://divar.ir/v/_/ga6i4lW1	2026-09-28 15:32:48.343029+00	2026-09-28 15:39:13.149398+00	\N	\N	\N	mashhad	55	\N	\N	5600000	{"mid": "اجاره: ۵,۶۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثارگران", "amounts": {"اجاره": 5600000}}	\N
853	divar	gahiQo8K	رهن ملک ۶۵متری ،طبقه دوم ،توس 39،موسوی پور ۱۰	حضرت حجت	\N	rent	\N	https://divar.ir/v/_/gahiQo8K	2026-09-28 15:31:38.016356+00	2026-09-28 15:39:13.151577+00	\N	\N	\N	mashhad	65	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "در حضرت حجت", "amounts": {"اجاره": 3000000}}	\N
854	divar	ga6i4IEP	170متر اپـارتـمـان  تک واحدی بـاهـنـر 6	کوثر	\N	rent	13	https://divar.ir/v/_/ga6i4IEP	2026-09-28 15:31:19.552426+00	2026-09-28 15:39:13.153738+00	\N	\N	\N	mashhad	170	\N	\N	55000000	{"mid": "اجاره: ۵۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 55000000}}	\N
855	divar	ga6iYBTf	آپارتمان ۸۵ متری ۲ خوابه	فردوسی	\N	rent	\N	https://divar.ir/v/_/ga6iYBTf	2026-09-28 15:31:18.966295+00	2026-09-28 15:39:13.155937+00	\N	\N	\N	mashhad	85	2	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فردوسی", "amounts": {"اجاره": 12000000}}	\N
856	divar	ga6eo327	آپارتمان سه خواب تک‌واحدی دوسر نور اول هاشمیه ۶۲	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga6eo327	2026-09-28 15:29:40.206212+00	2026-09-28 15:39:13.158026+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهارچشمه", "amounts": {"اجاره": 15000000}}	\N
857	divar	ga6eoiKx	رهن اجاره واحد ۱۵۰ متری دوخواب/ جاهدشهر/بدون مشابه	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga6eoiKx	2026-09-28 15:28:57.011178+00	2026-09-28 15:39:13.160533+00	\N	\N	\N	mashhad	150	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"اجاره": 20000000}}	\N
858	divar	gahSdHgb	آپارتمان /لوکس خواص پسند /کوثر ۱	کوثر	40000000000	sale	13	https://divar.ir/v/_/gahSdHgb	2026-09-26 05:40:39.723862+00	2026-09-28 15:49:25.384055+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوثر", "amounts": {"raw_amount": 40000000000}}	\N
859	divar	ga6uYqdX	فروش واحد ۶۰ متری/ نوساز فول /چند قدمی چهل بازه	یوسفیه (شهرک غرب)	2999000000	sale	38	https://divar.ir/v/_/ga6uYqdX	2026-09-28 15:48:33.308815+00	2026-09-28 15:49:25.393511+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۲,۹۹۹,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در یوسفیه (شهرک غرب)", "amounts": {"raw_amount": 2999000000}}	\N
860	divar	gaeOntMJ	ویلایی ۲۵۰ متری	ادیب نیشابوری (شهرک غرب)	34000000000	sale	38	https://divar.ir/v/_/gaeOntMJ	2026-09-28 15:48:14.965595+00	2026-09-28 15:49:25.397758+00	\N	\N	\N	mashhad	250	\N	\N	\N	{"mid": "۳۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در ادیب نیشابوری (شهرک غرب)", "amounts": {"raw_amount": 34000000000}}	\N
861	divar	ga6yoIjx	105متری/سندآماده/اول الهیه/تماس بگیرید	جاهد شهر	10800000000	sale	41	https://divar.ir/v/_/ga6yoIjx	2026-09-28 15:48:00.772553+00	2026-09-28 15:49:25.401543+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۰,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن میرشکاری در جاهد شهر", "amounts": {"raw_amount": 10800000000}}	\N
862	divar	ga6yIG84	آپارتمان ۱۶۰ متری / تک واحدی / تقاطع اول/جنوبی/صفر	امام رضا (ع)	25600000000	sale	\N	https://divar.ir/v/_/ga6yIG84	2026-09-28 15:47:51.617435+00	2026-09-28 15:49:25.404617+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۲۵,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 25600000000}}	\N
863	divar	ga6uIIe_	یک واحد آپارتمان در منطقه ی سیدی	کوی المهدی	2850000000	sale	\N	https://divar.ir/v/_/ga6uIIe_	2026-09-28 15:46:55.239995+00	2026-09-28 15:49:25.407268+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی المهدی", "amounts": {"raw_amount": 2850000000}}	\N
864	divar	ga6mIroe	واحدهمکف‌‌۱۰۰متری‌باحیاط	هفت تیر (آب و برق)	11800000000	sale	\N	https://divar.ir/v/_/ga6mIroe	2026-09-28 15:46:42.659155+00	2026-09-28 15:49:25.409418+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۱,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (آب و برق)", "amounts": {"raw_amount": 11800000000}}	\N
865	divar	ga1eIgzJ	الهیه آپارتمان۳خواب صفر نقدی یا معاوضه با خودرو	الهیه	17000000000	sale	44	https://divar.ir/v/_/ga1eIgzJ	2026-09-28 15:46:37.504812+00	2026-09-28 15:49:25.411615+00	\N	\N	\N	mashhad	\N	3	\N	\N	{"mid": "۱۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 17000000000}}	\N
866	divar	ga6uIxRR	آپارتمان ۱۲۵متر/صفر/دو واحدی/سند آماده/رحمانیه	الهیه	15000000000	sale	44	https://divar.ir/v/_/ga6uIxRR	2026-09-28 15:46:31.586064+00	2026-09-28 15:49:25.41505+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 15000000000}}	\N
867	divar	gauqKHvX	۴ خواب، ۲ مستر، ۲ پارکینگ، الهیه	جاهد شهر	26750000000	sale	41	https://divar.ir/v/_/gauqKHvX	2026-09-28 15:46:27.069777+00	2026-09-28 15:49:25.417661+00	\N	\N	\N	mashhad	\N	4	\N	\N	{"mid": "۲۶,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 26750000000}}	\N
868	divar	gaxOlxVp	70 متری / شیک و تمیز / کوثر قبلِ صارمی	کوثر	\N	rent	13	https://divar.ir/v/_/gaxOlxVp	2026-09-21 15:57:00.692647+00	2026-09-28 15:49:25.42008+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در کوثر", "amounts": {}}	\N
870	divar	gao4Sozl	سویت با لوازم ۱۰۰ رهن کامل	نوغان	\N	rent	\N	https://divar.ir/v/_/gao4Sozl	2026-09-28 15:47:59.149593+00	2026-09-28 15:49:25.423984+00	\N	\N	\N	mashhad	\N	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "در نوغان", "amounts": {"اجاره": 4000000}}	\N
871	divar	ga6uY7WQ	رهن کامل  واحد ۳ خاب الهیه، نبش محمدیه۲۱	الهیه	\N	rent	44	https://divar.ir/v/_/ga6uY7WQ	2026-09-28 15:47:52.707258+00	2026-09-28 15:49:25.426327+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"اجاره": 5000000}}	\N
872	divar	ga6eYawq	آپارتمان ۸۵ متری ، ۲ خواب شیک	ایثارگران	\N	rent	\N	https://divar.ir/v/_/ga6eYawq	2026-09-28 15:47:08.851637+00	2026-09-28 15:49:25.428907+00	\N	\N	\N	mashhad	85	2	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "مسکن ثانوی نبش کریمی۱۰ در ایثارگران", "amounts": {"اجاره": 6000000}}	\N
873	divar	ga6u4s5t	آپارتمان فوق العاده نوساز	حسین‌آباد	\N	rent	\N	https://divar.ir/v/_/ga6u4s5t	2026-09-28 15:46:53.391144+00	2026-09-28 15:49:25.431106+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حسین‌آباد", "amounts": {"اجاره": 100000}}	\N
874	divar	ga6uYUAK	آپارتمان ۲خواب ۱۴۵متری	ایثار	\N	rent	\N	https://divar.ir/v/_/ga6uYUAK	2026-09-28 15:46:22.179065+00	2026-09-28 15:49:25.43317+00	\N	\N	\N	mashhad	145	2	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثار", "amounts": {"اجاره": 30000000}}	\N
875	divar	ga6uIfS2	170متر اپارتمان تک واحدی باهنر 6	کوثر	\N	rent	13	https://divar.ir/v/_/ga6uIfS2	2026-09-28 15:45:06.698135+00	2026-09-28 15:49:25.435626+00	\N	\N	\N	mashhad	170	\N	\N	55000000	{"mid": "اجاره: ۵۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 55000000}}	\N
876	divar	ga6uoeeX	ویلایی حاشیه اصلی دو طبقه مجزا مناسب مشاغل	کوثر	\N	rent	13	https://divar.ir/v/_/ga6uoeeX	2026-09-28 15:45:05.945703+00	2026-09-28 15:49:25.437664+00	\N	\N	\N	mashhad	\N	\N	\N	130000000	{"mid": "اجاره: ۱۳۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 130000000}}	\N
877	divar	ga6u4Pti	رهن اپارتمان ۱۱۰ متر ( رو به باغ )	فدک	\N	rent	\N	https://divar.ir/v/_/ga6u4Pti	2026-09-28 15:44:50.177664+00	2026-09-28 15:49:25.439836+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "رهن کامل", "bottom": "عارفخانی در فدک", "amounts": {}}	\N
878	divar	ga6uIXo4	165 دانشجو دانش آموز صفر کلید نخورده //مدرن لوکس	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga6uIXo4	2026-09-28 15:44:36.277039+00	2026-09-28 15:49:25.441861+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در فرهنگ", "amounts": {}}	\N
880	divar	ga6q48Tj	اپارتمان طبقه یک	هفده شهریور	\N	rent	\N	https://divar.ir/v/_/ga6q48Tj	2026-09-28 15:42:58.538197+00	2026-09-28 15:49:25.445602+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفده شهریور", "amounts": {"اجاره": 15000000}}	\N
881	divar	gaouw05j	واحد دو خواب ۱۰۵ متری فول	جاهد شهر	\N	rent	41	https://divar.ir/v/_/gaouw05j	2026-09-28 15:42:52.023939+00	2026-09-28 15:49:25.447571+00	\N	\N	\N	mashhad	105	\N	\N	22000000	{"mid": "اجاره: ۲۲,۰۰۰,۰۰۰ تومان", "bottom": "سرزمین در جاهد شهر", "amounts": {"اجاره": 22000000}}	\N
883	divar	gavupiyb	180مــتری ((سیدرضـی رود پارک)) پذیرایی بزرگ	آزادشهر	27900000000	sale	\N	https://divar.ir/v/_/gavupiyb	2026-09-28 15:59:11.931795+00	2026-09-28 15:59:35.729306+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۷,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بامک بین امامت ۳۶و۳۸ در آزادشهر", "amounts": {"raw_amount": 27900000000}}	\N
884	divar	ga6yYy9l	آپارتمان نوساز تمام امکانات	نوده	3500000000	sale	\N	https://divar.ir/v/_/ga6yYy9l	2026-09-28 15:59:11.529553+00	2026-09-28 15:59:35.733331+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در نوده", "amounts": {"raw_amount": 3500000000}}	\N
885	divar	ga4O8L1h	۱۱۰متر/اوایل رحمانیه/خوش نقشه	الهیه	9900000000	sale	44	https://divar.ir/v/_/ga4O8L1h	2026-09-28 15:59:04.546075+00	2026-09-28 15:59:35.7359+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۹,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری بزرگ رویال در الهیه", "amounts": {"raw_amount": 9900000000}}	\N
886	divar	gao6-FbM	آپارتمان ۱۳۰ متری تک واحدی مشهد -صیادشیرازی	هفت تیر (آب و برق)	16800000000	sale	\N	https://divar.ir/v/_/gao6-FbM	2026-09-28 15:58:54.708789+00	2026-09-28 15:59:35.738253+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "۱۶,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (آب و برق)", "amounts": {"raw_amount": 16800000000}}	\N
887	divar	ga66InIe	۱۰۷ متر / الهیه ۴ / کلا ۹ واحد / نوساز	جاهد شهر	14000000000	sale	41	https://divar.ir/v/_/ga66InIe	2026-09-28 15:58:30.798519+00	2026-09-28 15:59:35.740378+00	\N	\N	\N	mashhad	107	\N	\N	\N	{"mid": "۱۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن آراد در جاهد شهر", "amounts": {"raw_amount": 14000000000}}	\N
888	divar	ga66YlLA	هوم یار/آپارتمان ۲۰۰متری /رو به فضاسبز	الهیه	18900000000	sale	44	https://divar.ir/v/_/ga66YlLA	2026-09-28 15:58:29.000738+00	2026-09-28 15:59:35.742426+00	\N	\N	\N	mashhad	200	\N	\N	\N	{"mid": "۱۸,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 18900000000}}	\N
890	divar	ga66IRbM	آپارتمان فروشی 80 متری	کشف	2000000000	sale	\N	https://divar.ir/v/_/ga66IRbM	2026-09-28 15:57:50.539144+00	2026-09-28 15:59:35.746206+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کشف", "amounts": {"raw_amount": 2000000000}}	\N
891	divar	gau6i5Hg	دانشجو/۱۴۰متر	دانشجو	19200000000	sale	39	https://divar.ir/v/_/gau6i5Hg	2026-09-28 15:57:36.872723+00	2026-09-28 15:59:35.74874+00	\N	\N	\N	mashhad	140	\N	\N	\N	{"mid": "۱۹,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در دانشجو", "amounts": {"raw_amount": 19200000000}}	\N
892	divar	ga66YTY4	ویلایی ۲۰۰ متر عرض ۸ یک طبقه بنا با مغازه تجاری	سرافرازان	26500000000	sale	22	https://divar.ir/v/_/ga66YTY4	2026-09-28 15:57:34.343389+00	2026-09-28 15:59:35.750826+00	\N	\N	\N	mashhad	200	\N	\N	\N	{"mid": "۲۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سرافرازان", "amounts": {"raw_amount": 26500000000}}	\N
893	divar	ga66IDg8	95 متری/بازسازی شده/فول امکانات/سندآماده	نرگس (شهرک غرب)	9735000000	sale	38	https://divar.ir/v/_/ga66IDg8	2026-09-28 15:57:06.238731+00	2026-09-28 15:59:35.752907+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۹,۷۳۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نرگس (شهرک غرب)", "amounts": {"raw_amount": 9735000000}}	\N
894	divar	ga66oANt	108متر پنجتن شهرک صبا	پنجتن	6500000000	sale	\N	https://divar.ir/v/_/ga66oANt	2026-09-28 15:56:41.603246+00	2026-09-28 15:59:35.755121+00	\N	\N	\N	mashhad	108	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پنجتن", "amounts": {"raw_amount": 6500000000}}	\N
896	divar	ga66Yuad	آپارتمان 75 متری امامت	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga66Yuad	2026-09-28 15:59:02.472347+00	2026-09-28 15:59:35.758708+00	\N	\N	\N	mashhad	75	\N	\N	18000000	{"mid": "اجاره: ۱۸,۰۰۰,۰۰۰ تومان", "bottom": "اژانس اریا در آزادشهر", "amounts": {"اجاره": 18000000}}	\N
897	divar	ga664UUz	آپارتمان ۸۰ متری اول صیاد*طبقه اول	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/ga664UUz	2026-09-28 15:58:23.749962+00	2026-09-28 15:59:35.760883+00	\N	\N	\N	mashhad	80	\N	\N	19000000	{"mid": "اجاره: ۱۹,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (حافظ)", "amounts": {"اجاره": 19000000}}	\N
898	divar	ga6eowO7	۱۰۰ متر اپارتما‌ن/ احمد‌آباد/کلید نخورده و فول	بهشت	\N	rent	18	https://divar.ir/v/_/ga6eowO7	2026-09-28 15:57:54.608825+00	2026-09-28 15:59:35.763168+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در بهشت", "amounts": {}}	\N
899	divar	ga6yo9t4	منزل مسکونی برای زائر به صورت رایگان	آیت الله کاشانی	\N	rent	\N	https://divar.ir/v/_/ga6yo9t4	2026-09-28 15:55:19.533866+00	2026-09-28 15:59:35.765275+00	\N	\N	\N	mashhad	\N	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "دقایقی پیش در آیت الله کاشانی", "amounts": {"اجاره": 1000}}	\N
900	divar	ga624H0h	رهن کامل اپارتمان در کلاهدوز	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga624H0h	2026-09-28 15:52:05.569873+00	2026-09-28 15:59:35.767377+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در فرهنگ", "amounts": {}}	\N
901	divar	ga6yIxbQ	آپارتمان ۱۳۰ متری،۳ خواب،فول امکانات،سرجلو	حسین‌آباد	\N	rent	\N	https://divar.ir/v/_/ga6yIxbQ	2026-09-28 15:50:39.856592+00	2026-09-28 15:59:35.769288+00	\N	\N	\N	mashhad	130	3	\N	22500000	{"mid": "اجاره: ۲۲,۵۰۰,۰۰۰ تومان", "bottom": "مسکن پردیس در حسین‌آباد", "amounts": {"اجاره": 22500000}}	\N
902	divar	ga6yordr	85متری دوخواب	یوسفیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6yordr	2026-09-28 15:50:11.627971+00	2026-09-28 15:59:35.771729+00	\N	\N	\N	mashhad	85	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در یوسفیه (شهرک غرب)", "amounts": {"اجاره": 2000000}}	\N
905	divar	ga6CJ_2a	آپارتمان ۷۵ متری وکالتی	مشکینی (شهرک غرب)	4820000000	sale	38	https://divar.ir/v/_/ga6CJ_2a	2026-09-28 16:09:34.039205+00	2026-09-28 16:09:48.304421+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۴,۸۲۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در مشکینی (شهرک غرب)", "amounts": {"raw_amount": 4820000000}}	\N
906	divar	gaxR9o-n	باغ ویلا گوهردشت ۲۸۰۰ متر تهاتر با آپارتمان (فوری)	میان ولایت	10400000000	sale	\N	https://divar.ir/v/_/gaxR9o-n	2026-09-28 16:09:08.300087+00	2026-09-28 16:09:48.312019+00	\N	\N	\N	mashhad	2800	\N	\N	\N	{"mid": "۱۰,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 10400000000}}	\N
907	divar	ga6-Isyy	تعدادی قطعه زمین 150 متری	پورسینا	2550000000	sale	\N	https://divar.ir/v/_/ga6-Isyy	2026-09-28 16:08:09.654202+00	2026-09-28 16:09:48.315577+00	\N	\N	\N	mashhad	150	\N	\N	\N	{"mid": "۲,۵۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پورسینا", "amounts": {"raw_amount": 2550000000}}	\N
908	divar	ga66IybP	۱۵۰۰متر باغ ملکی کنار مترو	الهیه	5000000000	sale	44	https://divar.ir/v/_/ga66IybP	2026-09-28 16:07:59.275483+00	2026-09-28 16:09:48.318218+00	\N	\N	\N	mashhad	1500	\N	\N	\N	{"mid": "۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 5000000000}}	\N
909	divar	ga2Cslgv	فروش‌آپارتمان‌ خانه ۶۰ متری  صیاد۵۴	هفت تیر (نه دره)	3500000000	sale	\N	https://divar.ir/v/_/ga2Cslgv	2026-09-28 16:07:41.320225+00	2026-09-28 16:09:48.32079+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (نه دره)", "amounts": {"raw_amount": 3500000000}}	\N
910	divar	gaeK9hg0	فروش اپارتمان ۱۴۴ متری در امامت۸	آزادشهر	24950000000	sale	\N	https://divar.ir/v/_/gaeK9hg0	2026-09-28 16:07:29.07199+00	2026-09-28 16:09:48.32477+00	\N	\N	\N	mashhad	144	\N	\N	\N	{"mid": "۲۴,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در آزادشهر", "amounts": {"raw_amount": 24950000000}}	\N
911	divar	ga6CJHYa	زمین سوله 130متری	گرجی علیا	2100000000	sale	\N	https://divar.ir/v/_/ga6CJHYa	2026-09-28 16:07:19.845841+00	2026-09-28 16:09:48.327351+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "۲,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گرجی علیا", "amounts": {"raw_amount": 2100000000}}	\N
912	divar	gahSEFDD	کوهسنگی ویلایی موقعیت مکانی عالی	شهید بهشتی	12300000000	sale	18	https://divar.ir/v/_/gahSEFDD	2026-09-28 16:05:59.475582+00	2026-09-28 16:09:48.331063+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید بهشتی", "amounts": {"raw_amount": 12300000000}}	\N
915	divar	ga6CJTfq	150 متر صفر دانشجو نزدیک مترو مسکن کارا	دانشجو	\N	rent	39	https://divar.ir/v/_/ga6CJTfq	2026-09-28 16:05:40.581939+00	2026-09-28 16:09:48.339341+00	\N	\N	\N	mashhad	150	\N	\N	50000000	{"mid": "اجاره: ۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در دانشجو", "amounts": {"اجاره": 50000000}}	\N
916	divar	ga6-YoXK	208 متر با 90 متر روف گاردن اختصاصی	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/ga6-YoXK	2026-09-28 16:05:30.230376+00	2026-09-28 16:09:48.343173+00	\N	\N	\N	mashhad	208	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (حافظ)", "amounts": {"اجاره": 10000000}}	\N
917	divar	ga6-YiC_	خانه ویلایی دربست	طبرسی شمالی	\N	rent	42	https://divar.ir/v/_/ga6-YiC_	2026-09-28 16:05:10.50685+00	2026-09-28 16:09:48.346879+00	\N	\N	\N	mashhad	\N	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {"اجاره": 4000000}}	\N
918	divar	ga6CZFQV	آپارتمان سه خواب نوساز دونبش تک‌واحدی درحدصفر	کوثر	\N	rent	13	https://divar.ir/v/_/ga6CZFQV	2026-09-28 16:04:48.782175+00	2026-09-28 16:09:48.3501+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در کوثر", "amounts": {}}	\N
919	divar	gafW4cnD	۹۰ متری/ ۲ خواب/ صفر کلید نخورده/ مناسب زوج	الهیه	\N	rent	44	https://divar.ir/v/_/gafW4cnD	2026-09-28 16:01:07.780794+00	2026-09-28 16:09:48.352892+00	\N	\N	\N	mashhad	90	2	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"اجاره": 20000000}}	\N
920	divar	galKmsK4	مستغلاتی*۲واحد مدرن*قلب امامت*مسکن الهی/پژوهیان	آزادشهر	\N	rent	\N	https://divar.ir/v/_/galKmsK4	2026-09-28 16:00:13.891045+00	2026-09-28 16:09:48.355455+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن   الهی    نبش امامت ۴۶ در آزادشهر", "amounts": {}}	\N
926	divar	ga5a22_Z	زمین کاربری مسکونی بلوار مفتح متری 12 تا 35 میلیون	مهدی آباد	1800000000	sale	\N	https://divar.ir/v/_/ga5a22_Z	2026-09-27 19:02:46.638074+00	2026-09-28 16:19:58.627272+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در مهدی آباد", "amounts": {"raw_amount": 1800000000}}	\N
927	divar	ga6OZlCE	۷۰ متری / فول امکانات- قیمت مناسب/ ۱۷ شهریور	هفده شهریور	4000000000	sale	\N	https://divar.ir/v/_/ga6OZlCE	2026-09-28 16:19:48.554225+00	2026-09-28 16:19:58.631349+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفده شهریور", "amounts": {"raw_amount": 4000000000}}	\N
928	divar	gasIOdaf	۱۵۰ متر   / آپارتمان   صفر /        ۳  نبش	دانشجو	19000000000	sale	39	https://divar.ir/v/_/gasIOdaf	2026-09-28 16:19:47.590062+00	2026-09-28 16:19:58.635256+00	\N	\N	\N	mashhad	150	\N	\N	\N	{"mid": "۱۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در دانشجو", "amounts": {"raw_amount": 19000000000}}	\N
929	divar	ga6O5kLB	فروش ۸۰ متری / فوری / فول امکانات	کوه سنگی	11500000000	sale	\N	https://divar.ir/v/_/ga6O5kLB	2026-09-28 16:19:42.994552+00	2026-09-28 16:19:58.639148+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۱۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوه سنگی", "amounts": {"raw_amount": 11500000000}}	\N
930	divar	ga6OJj-X	اپارتمان160متری/ تاپ لوکیشین/ دوکله/روف گاردن	الهیه	18240000000	sale	44	https://divar.ir/v/_/ga6OJj-X	2026-09-28 16:19:36.853582+00	2026-09-28 16:19:58.641811+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۱۸,۲۴۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 18240000000}}	\N
931	divar	gaZiyHEU	اپارتمان ۳۰۰متری مخصوص خاص پسندان	دانشجو	46150000000	sale	39	https://divar.ir/v/_/gaZiyHEU	2026-09-28 16:19:26.953802+00	2026-09-28 16:19:58.644313+00	\N	\N	\N	mashhad	300	\N	\N	\N	{"mid": "۴۶,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در دانشجو", "amounts": {"raw_amount": 46150000000}}	\N
932	divar	ga6OZh_e	گلشن صفر سند آماده لابی	هنرستان	39500000000	sale	11	https://divar.ir/v/_/ga6OZh_e	2026-09-28 16:19:26.710794+00	2026-09-28 16:19:58.646514+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هنرستان", "amounts": {"raw_amount": 39500000000}}	\N
933	divar	gaDeyLgw	معاوضه آپارتمان درودی۱۸ با گلبهار	حضرت حجت	3600000000	sale	\N	https://divar.ir/v/_/gaDeyLgw	2026-09-28 16:19:15.127542+00	2026-09-28 16:19:58.64891+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در حضرت حجت", "amounts": {"raw_amount": 3600000000}}	\N
934	divar	gaeCpRGu	دو عدد هوایی سوم و چهارم روی همکف	حضرت حجت	1000000000	sale	\N	https://divar.ir/v/_/gaeCpRGu	2026-09-28 16:18:48.60919+00	2026-09-28 16:19:58.651111+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در حضرت حجت", "amounts": {"raw_amount": 1000000000}}	\N
935	divar	ganq6ioJ	۱۵۵ متری .۳خواب.شمالی.معبر ۲۰.تحویل برج ۱۰	امام خمینی	25500000000	sale	\N	https://divar.ir/v/_/ganq6ioJ	2026-09-28 16:18:17.923429+00	2026-09-28 16:19:58.653032+00	\N	\N	\N	mashhad	155	3	\N	\N	{"mid": "۲۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امام خمینی", "amounts": {"raw_amount": 25500000000}}	\N
936	divar	ga6OJMZZ	فروش خانه مسکونی / کشاورز	نوید	6000000000	sale	\N	https://divar.ir/v/_/ga6OJMZZ	2026-09-28 16:18:11.638007+00	2026-09-28 16:19:58.655062+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "عبائی در نوید", "amounts": {"raw_amount": 6000000000}}	\N
937	divar	ga5-n7f3	آپارتمان ۱۶۰ متری دوبلکس دوخوابه صحن حیاط دار نجف۶	نوده	3680000000	sale	\N	https://divar.ir/v/_/ga5-n7f3	2026-09-28 16:18:10.162221+00	2026-09-28 16:19:58.65731+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۳,۶۸۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوده", "amounts": {"raw_amount": 3680000000}}	\N
938	divar	ga5SHMOk	آپارتمان 97 متری	آیت الله کاشانی	9000000000	sale	\N	https://divar.ir/v/_/ga5SHMOk	2026-09-28 16:18:04.374759+00	2026-09-28 16:19:58.65923+00	\N	\N	\N	mashhad	97	\N	\N	\N	{"mid": "۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آیت الله کاشانی", "amounts": {"raw_amount": 9000000000}}	\N
939	divar	ga6OpDkG	فروش اپارتمان	گوهرشاد	12000000000	sale	20	https://divar.ir/v/_/ga6OpDkG	2026-09-28 16:17:43.112004+00	2026-09-28 16:19:58.66169+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گوهرشاد", "amounts": {"raw_amount": 12000000000}}	\N
940	divar	ga6O5BNB	۲۰۵ متر کوثر شمالی / پلان تفکیکی لاله ۶ هاشمیه	کوثر	41000000000	sale	13	https://divar.ir/v/_/ga6O5BNB	2026-09-28 16:17:38.690635+00	2026-09-28 16:19:58.663869+00	\N	\N	\N	mashhad	205	\N	\N	\N	{"mid": "۴۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "رادوین در کوثر", "amounts": {"raw_amount": 41000000000}}	\N
941	divar	ga6G5NJo	آپارتمان چراغچی23	سپاد	3100000000	sale	\N	https://divar.ir/v/_/ga6G5NJo	2026-09-28 16:16:55.942005+00	2026-09-28 16:19:58.665827+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سپاد", "amounts": {"raw_amount": 3100000000}}	\N
942	divar	ga6KZhur	فروش آپارتمان در بهترین موقعیت	هنرور	3600000000	sale	\N	https://divar.ir/v/_/ga6KZhur	2026-09-28 16:16:33.780458+00	2026-09-28 16:19:58.668245+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"raw_amount": 3600000000}}	\N
943	divar	gavKi5BH	خانه ویلایی آپارتمان اجاره کنارمترو	شهید قربانی	\N	rent	\N	https://divar.ir/v/_/gavKi5BH	2026-09-23 02:35:07.684695+00	2026-09-28 16:19:58.670789+00	\N	\N	\N	mashhad	\N	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "در شهید قربانی", "amounts": {"اجاره": 2000000}}	\N
944	divar	gaoqRYXT	اجاره مسکونی	ایوان	\N	rent	\N	https://divar.ir/v/_/gaoqRYXT	2026-09-28 16:19:54.831179+00	2026-09-28 16:19:58.673314+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در ایوان", "amounts": {"اجاره": 10000000}}	\N
945	divar	gayiqQy1	3طبقه واحد مجزا/ دانشگاه/ مناسب2 یا 3 خانواده	سناباد	\N	rent	\N	https://divar.ir/v/_/gayiqQy1	2026-09-28 16:19:51.122433+00	2026-09-28 16:19:58.676302+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در سناباد", "amounts": {}}	\N
946	divar	ga6Cp3rP	ویلایی/ باشگاه ورزشی / موسسه زبان	فلسطین	\N	rent	19	https://divar.ir/v/_/ga6Cp3rP	2026-09-28 16:17:05.036286+00	2026-09-28 16:19:58.67884+00	\N	\N	\N	mashhad	\N	\N	\N	400000000	{"mid": "اجاره: ۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "تالار معاملات ملکی سجادی در فلسطین", "amounts": {"اجاره": 400000000}}	\N
947	divar	gaXa-rJ_	آبادگران برج 420 متر پنت هوس	آبادگران	\N	rent	\N	https://divar.ir/v/_/gaXa-rJ_	2026-09-28 16:15:40.266292+00	2026-09-28 16:19:58.681379+00	\N	\N	\N	mashhad	420	\N	\N	145000000	{"mid": "اجاره: ۱۴۵,۰۰۰,۰۰۰ تومان", "bottom": "در آبادگران", "amounts": {"اجاره": 145000000}}	\N
948	divar	ga6K5Pt3	خانه اجاره ای ویلای	پنجتن	\N	rent	\N	https://divar.ir/v/_/ga6K5Pt3	2026-09-28 16:15:27.7704+00	2026-09-28 16:19:58.68397+00	\N	\N	\N	mashhad	\N	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پنجتن", "amounts": {"اجاره": 4000000}}	\N
949	divar	ga6G5uhp	آپارتمان همکف راه جدا 75متر عدلخمینی	امام خمینی	\N	rent	\N	https://divar.ir/v/_/ga6G5uhp	2026-09-28 16:14:41.379719+00	2026-09-28 16:19:58.68732+00	\N	\N	\N	mashhad	75	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امام خمینی", "amounts": {"اجاره": 15000000}}	\N
950	divar	ga6-I6_y	اجاره آپارتمان طبرسی شمالی ۴	طبرسی شمالی	\N	rent	42	https://divar.ir/v/_/ga6-I6_y	2026-09-28 16:13:46.117585+00	2026-09-28 16:19:58.689905+00	\N	\N	\N	mashhad	\N	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {"اجاره": 4000000}}	\N
951	divar	gaz6MxPc	آپارتمان طبقه اول	نظام دوست	\N	rent	\N	https://divar.ir/v/_/gaz6MxPc	2026-09-28 16:13:36.644774+00	2026-09-28 16:19:58.692499+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در نظام دوست", "amounts": {"اجاره": 10000000}}	\N
952	divar	ga66AmSB	آپارتمان ۱۲۰ متری	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga66AmSB	2026-09-28 16:12:34.095745+00	2026-09-28 16:19:58.694676+00	\N	\N	\N	mashhad	120	\N	\N	22000000	{"mid": "اجاره: ۲۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"اجاره": 22000000}}	\N
953	divar	gaw6O1Zy	ویلایی سجاد ۵۰۰ متری ترکی ساز برای خاص پسندا	سجاد شهر	\N	rent	21	https://divar.ir/v/_/gaw6O1Zy	2026-09-28 16:12:30.750623+00	2026-09-28 16:19:58.696682+00	\N	\N	\N	mashhad	500	\N	\N	330000000	{"mid": "اجاره: ۳۳۰,۰۰۰,۰۰۰ تومان", "bottom": "رادوین در سجاد شهر", "amounts": {"اجاره": 330000000}}	\N
954	divar	gazmoNF5	آپارتمان ۶۵ متری شیک و لوکس	سرافرازان	\N	rent	22	https://divar.ir/v/_/gazmoNF5	2026-09-28 16:11:50.922366+00	2026-09-28 16:19:58.698875+00	\N	\N	\N	mashhad	65	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "در سرافرازان", "amounts": {"اجاره": 15000000}}	\N
955	divar	ga6GJf0M	رهن و اجاره طبقه همکف ۷۵ متری یک خواب	امام خمینی	\N	rent	\N	https://divar.ir/v/_/ga6GJf0M	2026-09-28 16:11:13.659301+00	2026-09-28 16:19:58.701185+00	\N	\N	\N	mashhad	75	\N	\N	18000000	{"mid": "اجاره: ۱۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امام خمینی", "amounts": {"اجاره": 18000000}}	\N
956	divar	ga3uuaeJ	۱۲۵ متری / فرامرز عباسی ۳۳ / اسانسور پارکینگ /	شهید فرامرز عباسی	\N	rent	\N	https://divar.ir/v/_/ga3uuaeJ	2026-09-28 16:10:04.651034+00	2026-09-28 16:19:58.703325+00	\N	\N	\N	mashhad	125	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید فرامرز عباسی", "amounts": {"اجاره": 30000000}}	\N
959	divar	ga6W557Z	متـ۱۲۵ـر/هاشمیه صارمی/لابی	کوثر	26000000000	sale	13	https://divar.ir/v/_/ga6W557Z	2026-09-28 16:30:02.939228+00	2026-09-28 16:30:12.734796+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوثر", "amounts": {"raw_amount": 26000000000}}	\N
960	divar	ga6WJ8Pm	۱۴۵متر* ۲واحدی سندآماده رحمانیه*شمالی آفتابگیر	الهیه	15300000000	sale	44	https://divar.ir/v/_/ga6WJ8Pm	2026-09-28 16:29:51.157398+00	2026-09-28 16:30:12.75063+00	\N	\N	\N	mashhad	145	\N	\N	\N	{"mid": "۱۵,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 15300000000}}	\N
961	divar	ga6W5ha6	هوایی دوم۹۵متری باپروانه ساخت طبقه دوم با پارکینگ	منزل آباد	1520000000	sale	\N	https://divar.ir/v/_/ga6W5ha6	2026-09-28 16:29:47.407848+00	2026-09-28 16:30:12.759263+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۱,۵۲۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در منزل آباد", "amounts": {"raw_amount": 1520000000}}	\N
962	divar	ga6Wpyxc	۱۶۰ متر سامانیه با ۸ متر تراس قابل چیدمان مدرن	هنرستان	45000000000	sale	11	https://divar.ir/v/_/ga6Wpyxc	2026-09-28 16:29:26.682325+00	2026-09-28 16:30:12.762558+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۴۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "رادوین در هنرستان", "amounts": {"raw_amount": 45000000000}}	\N
963	divar	ga6WpuPV	رو به خیابان 88 متر حسابی 8 فول امکانات آفتابگیر	فرهنگیان (شهرک غرب)	9900000000	sale	37	https://divar.ir/v/_/ga6WpuPV	2026-09-28 16:29:16.655429+00	2026-09-28 16:30:12.76626+00	\N	\N	\N	mashhad	88	\N	\N	\N	{"mid": "۹,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سپهر فلاحی ۱۳ در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 9900000000}}	\N
964	divar	ga5WU5MF	آپارتمان ۹۵ متری الهیه /فول/کم واحد /سند آماده	الهیه	10200000000	sale	44	https://divar.ir/v/_/ga5WU5MF	2026-09-28 16:28:49.711671+00	2026-09-28 16:30:12.769275+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۱۰,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری حافظ رتبه اول الهیه در الهیه", "amounts": {"raw_amount": 10200000000}}	\N
965	divar	ga6W5Vyi	منزل ویلایی سند دار 2 طبقه جنوبی خ عبادی	گاز	12900000000	sale	\N	https://divar.ir/v/_/ga6W5Vyi	2026-09-28 16:28:45.43858+00	2026-09-28 16:30:12.771431+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گاز", "amounts": {"raw_amount": 12900000000}}	\N
966	divar	gaqOV7Jr	۹۰متر شیک تکواحدی اوایل فلاحی/غرق نور	فرهنگیان (شهرک غرب)	7900000000	sale	37	https://divar.ir/v/_/gaqOV7Jr	2026-09-28 16:28:15.177325+00	2026-09-28 16:30:12.774145+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۷,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن جان نثار حسابی شمالی۲ در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 7900000000}}	\N
967	divar	ga6WpMYX	همکف راه جدا ماشین رو مهرمادر	خواجه ربیع	2550000000	sale	\N	https://divar.ir/v/_/ga6WpMYX	2026-09-28 16:27:21.92373+00	2026-09-28 16:30:12.776592+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۵۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در خواجه ربیع", "amounts": {"raw_amount": 2550000000}}	\N
969	divar	ga6WJ8_d	دو خواب ۱۰۰ متری در اواسط صارمی	هنرستان	\N	rent	11	https://divar.ir/v/_/ga6WJ8_d	2026-09-28 16:29:50.359699+00	2026-09-28 16:30:12.780733+00	\N	\N	\N	mashhad	100	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "در هنرستان", "amounts": {"اجاره": 25000000}}	\N
970	divar	ga6WZvrz	100 متری / فول امکانات /  تخلیه / فلاحی سنجرانی	شهرک لشکر (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6WZvrz	2026-09-28 16:28:55.93221+00	2026-09-28 16:30:12.782886+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "رهن کامل", "bottom": "گروه مهندسی ساختمانی دیان در شهرک لشکر (شهرک غرب)", "amounts": {}}	\N
971	divar	ga6W5CY9	رهن و اجاره آپارتمان	مقدم	\N	rent	\N	https://divar.ir/v/_/ga6W5CY9	2026-09-28 16:28:26.579197+00	2026-09-28 16:30:12.785107+00	\N	\N	\N	mashhad	\N	\N	\N	16000000	{"mid": "اجاره: ۱۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مقدم", "amounts": {"اجاره": 16000000}}	\N
972	divar	ga6SZusi	اجاره اپارتمان امیریه طلائیه	امیریه	\N	rent	\N	https://divar.ir/v/_/ga6SZusi	2026-09-28 16:25:25.981752+00	2026-09-28 16:30:12.787558+00	\N	\N	\N	mashhad	\N	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیریه", "amounts": {"اجاره": 12000000}}	\N
973	divar	ga6OZpow	اجاره ماهیانه اپارتمان مبله	کوی راد	\N	rent	\N	https://divar.ir/v/_/ga6OZpow	2026-09-28 16:21:57.900341+00	2026-09-28 16:30:12.790132+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی راد", "amounts": {"اجاره": 15000000}}	\N
978	divar	gaqW38vy	آپارتمان۲۳۰متر دوبلکس طبرسی شمالی۱	رده	7900000000	sale	\N	https://divar.ir/v/_/gaqW38vy	2026-09-28 06:59:18.80366+00	2026-09-28 16:40:28.315789+00	\N	\N	\N	mashhad	230	\N	\N	\N	{"mid": "۷,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رده", "amounts": {"raw_amount": 7900000000}}	\N
979	divar	ga6e5-Gz	زمین ۴۶۰متری حاشیه توس	مهدی آباد (بلوار توس)	29000000000	sale	\N	https://divar.ir/v/_/ga6e5-Gz	2026-09-28 16:39:05.379987+00	2026-09-28 16:40:28.322621+00	\N	\N	\N	mashhad	460	\N	\N	\N	{"mid": "۲۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مهدی آباد (بلوار توس)", "amounts": {"raw_amount": 29000000000}}	\N
980	divar	ga6e5REw	آپارتمان ۶۰ متری دلاوران / سند شش دانگ	سرافرازان	6200000000	sale	22	https://divar.ir/v/_/ga6e5REw	2026-09-28 16:38:40.512639+00	2026-09-28 16:40:28.326766+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۶,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سرافرازان", "amounts": {"raw_amount": 6200000000}}	\N
981	divar	ga6epeSl	۸۵ متر ۲ خواب حائری	حجت	5800000000	sale	\N	https://divar.ir/v/_/ga6epeSl	2026-09-28 16:36:53.897175+00	2026-09-28 16:40:28.330541+00	\N	\N	\N	mashhad	85	2	\N	\N	{"mid": "۵,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حجت", "amounts": {"raw_amount": 5800000000}}	\N
982	divar	ga6e5VJS	۱۰۰ متر/صفر/طبقات ۱ و ۲/سنجرانی	شهرک لشکر (شهرک غرب)	12000000000	sale	38	https://divar.ir/v/_/ga6e5VJS	2026-09-28 16:36:25.970046+00	2026-09-28 16:40:28.334738+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک لشکر (شهرک غرب)", "amounts": {"raw_amount": 12000000000}}	\N
983	divar	ga6SItGu	خانه 3 طبقه	مهدی آباد	6000000000	sale	\N	https://divar.ir/v/_/ga6SItGu	2026-09-28 16:36:15.268851+00	2026-09-28 16:40:28.339218+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مهدی آباد", "amounts": {"raw_amount": 6000000000}}	\N
984	divar	ga6aJlIF	آپارتمان کشاورز	نوید	7000000000	sale	\N	https://divar.ir/v/_/ga6aJlIF	2026-09-28 16:36:06.014349+00	2026-09-28 16:40:28.342368+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوید", "amounts": {"raw_amount": 7000000000}}	\N
985	divar	ga6e5Tkh	101 متری الهیه سند اماده	جاهد شهر	10500000000	sale	41	https://divar.ir/v/_/ga6e5Tkh	2026-09-28 16:35:41.4545+00	2026-09-28 16:40:28.345628+00	\N	\N	\N	mashhad	101	\N	\N	\N	{"mid": "۱۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران الهیه ۳۴ در جاهد شهر", "amounts": {"raw_amount": 10500000000}}	\N
986	divar	gaeqcy3s	رهن کامل آپارتمان نوساز صفر قولنامه رایگان خودنویس	فردوسی	\N	rent	\N	https://divar.ir/v/_/gaeqcy3s	2026-09-21 13:50:51.298158+00	2026-09-28 16:40:28.348264+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "در فردوسی", "amounts": {"اجاره": 10000}}	\N
987	divar	ga6i5KE6	۹۰متردربست دوخواب جلال	زیبا شهر	\N	rent	\N	https://divar.ir/v/_/ga6i5KE6	2026-09-28 16:39:55.73535+00	2026-09-28 16:40:28.35068+00	\N	\N	\N	mashhad	90	\N	\N	24000000	{"mid": "اجاره: ۲۴,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن اریانا یاسین باروئی بین جلال ۶۸و۷۰ در زیبا شهر", "amounts": {"اجاره": 24000000}}	\N
988	divar	ga6eJzES	آپارتمان دو خوابه ۸۴متری	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/ga6eJzES	2026-09-28 16:39:49.882583+00	2026-09-28 16:40:28.353813+00	\N	\N	\N	mashhad	84	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در هفت تیر (حافظ)", "amounts": {"اجاره": 25000000}}	\N
989	divar	ga6eZ4Qk	اپارتمان توس ۷۰ زمان	توس (بلوار توس)	\N	rent	\N	https://divar.ir/v/_/ga6eZ4Qk	2026-09-28 16:38:54.636092+00	2026-09-28 16:40:28.356032+00	\N	\N	\N	mashhad	\N	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {"اجاره": 3000000}}	\N
990	divar	ga6a5UcB	رهن کامل ۷۰ متر طبرسی شمالی 5	رده	\N	rent	\N	https://divar.ir/v/_/ga6a5UcB	2026-09-28 16:35:20.812326+00	2026-09-28 16:40:28.357965+00	\N	\N	\N	mashhad	70	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رده", "amounts": {"اجاره": 1000000}}	\N
991	divar	ga6e5AXM	( رحمانیه 29 یا الهیه 34 )شیک فول برند 106متر لوکس	الهیه	\N	rent	44	https://divar.ir/v/_/ga6e5AXM	2026-09-28 16:34:24.439039+00	2026-09-28 16:40:28.360115+00	\N	\N	\N	mashhad	106	\N	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال لو در الهیه", "amounts": {"اجاره": 35000000}}	\N
992	divar	ga6apWif	۱۷۰ متر ویلایی باسازی شده طبقه اول مطهری شمالی	شهید مطهری	\N	rent	28	https://divar.ir/v/_/ga6apWif	2026-09-28 16:33:58.080036+00	2026-09-28 16:40:28.362126+00	\N	\N	\N	mashhad	170	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در شهید مطهری", "amounts": {}}	\N
993	divar	ga6a5b-L	آپارتمان ۱۲۵ متری/الهیه ۳۴/غرق نور	الهیه	\N	rent	44	https://divar.ir/v/_/ga6a5b-L	2026-09-28 16:31:56.673996+00	2026-09-28 16:40:28.364072+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن ممتاز ایران در الهیه", "amounts": {}}	\N
994	divar	gai21wBM	۱۷۰ متر قبل فرهنک /عدل تراس قابل چیدمان زوج پسند	فرهنگ	\N	rent	\N	https://divar.ir/v/_/gai21wBM	2026-09-28 16:31:55.706506+00	2026-09-28 16:40:28.366483+00	\N	\N	\N	mashhad	170	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "رادوین در فرهنگ", "amounts": {"اجاره": 100000}}	\N
998	divar	QampQu3i	فروش زمین سرمایه‌گذاری در جلدک،سپاد صفی اباد چاهشک	جاهد شهر	560000000	sale	41	https://divar.ir/v/_/QampQu3i	2026-09-17 20:36:25.838883+00	2026-09-28 16:50:38.763597+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵۶۰,۰۰۰,۰۰۰ تومان", "bottom": "علی خاکشور جلدک سپاد صفی اباد فرهنگیان چاهشک در جاهد شهر", "amounts": {"raw_amount": 560000000}}	\N
999	divar	ga6qJdHy	فروش خانه	کوی دروی	4000000000	sale	\N	https://divar.ir/v/_/ga6qJdHy	2026-09-28 16:50:30.507358+00	2026-09-28 16:50:38.772091+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در کوی دروی", "amounts": {"raw_amount": 4000000000}}	\N
1000	divar	ga6qZSXF	55 متری / مرتب / رو به آفتاب/ سند آماده	الهیه	4800000000	sale	44	https://divar.ir/v/_/ga6qZSXF	2026-09-28 16:49:56.535129+00	2026-09-28 16:50:38.77598+00	\N	\N	\N	mashhad	55	\N	\N	\N	{"mid": "۴,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در الهیه", "amounts": {"raw_amount": 4800000000}}	\N
1001	divar	ga6qZdEz	ملک مسکونی،مشهد،جنب حرم مطهر	کوی راد	33600000000	sale	\N	https://divar.ir/v/_/ga6qZdEz	2026-09-28 16:49:47.095378+00	2026-09-28 16:50:38.778497+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳۳,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در کوی راد", "amounts": {"raw_amount": 33600000000}}	\N
1002	divar	ga6q5eAj	آپارتمان ۱۰۰ متری دو خواب حاشیه فرهنگ میدان سیدرضی	فرهنگ	15000000000	sale	\N	https://divar.ir/v/_/ga6q5eAj	2026-09-28 16:49:46.764423+00	2026-09-28 16:50:38.781204+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در فرهنگ", "amounts": {"raw_amount": 15000000000}}	\N
1003	divar	ga6q5HmV	زمین  جهاد (کامرانیه) ۳۰۰ متر جنوبی و دونبش	جاهد شهر	12000000000	sale	41	https://divar.ir/v/_/ga6q5HmV	2026-09-28 16:49:35.950863+00	2026-09-28 16:50:38.783598+00	\N	\N	\N	mashhad	300	\N	\N	\N	{"mid": "۱۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "خریدو فروش حرفه ای زمین اپارتمان و مشارکت و تهاتر در جاهد شهر", "amounts": {"raw_amount": 12000000000}}	\N
1004	divar	ga6eoxnQ	فروش ویلایی ۱۲۵متر ۲طبقه بنا	سید رضی	27500000000	sale	\N	https://divar.ir/v/_/ga6eoxnQ	2026-09-28 16:48:41.018249+00	2026-09-28 16:50:38.786209+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۲۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن امکان بین جلال۳۷و۳۹ در سید رضی", "amounts": {"raw_amount": 27500000000}}	\N
1005	divar	ga2UbPqu	حیاط ویلایی خانه باغ استخر داخل	میان ولایت	4500000000	sale	\N	https://divar.ir/v/_/ga2UbPqu	2026-09-28 16:47:18.168958+00	2026-09-28 16:50:38.788681+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 4500000000}}	\N
1006	divar	ga6mZtIj	طبقه اول حاشیه خیابان شیک وکالتی	یوسفیه (شهرک غرب)	2390000000	sale	38	https://divar.ir/v/_/ga6mZtIj	2026-09-28 16:46:39.67756+00	2026-09-28 16:50:38.790827+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۳۹۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در یوسفیه (شهرک غرب)", "amounts": {"raw_amount": 2390000000}}	\N
1007	divar	ga6mJ30i	155مترصفر کلید نخورده* مُـدرن *فوری*مسکن الهی تقوی	آزادشهر	24200000000	sale	\N	https://divar.ir/v/_/ga6mJ30i	2026-09-28 16:46:33.416715+00	2026-09-28 16:50:38.793466+00	\N	\N	\N	mashhad	155	\N	\N	\N	{"mid": "۲۴,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن   الهی    نبش امامت ۴۶ در آزادشهر", "amounts": {"raw_amount": 24200000000}}	\N
1008	divar	ga5u4syc	آپارتمان۸۵متری دوخواب	یوسفیه (شهرک غرب)	5500000000	sale	38	https://divar.ir/v/_/ga5u4syc	2026-09-28 16:45:55.672584+00	2026-09-28 16:50:38.796175+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در یوسفیه (شهرک غرب)", "amounts": {"raw_amount": 5500000000}}	\N
1009	divar	gaZu2F0p	زمین نیرومندان سند شیش دانگ پنجتن	پنجتن	2900000000	sale	\N	https://divar.ir/v/_/gaZu2F0p	2026-09-28 16:45:11.719705+00	2026-09-28 16:50:38.798451+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در پنجتن", "amounts": {"raw_amount": 2900000000}}	\N
1011	divar	ga6eZ-Nn	۱۹۰ متر،چهار خواب،جلال،قبل از معلم	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga6eZ-Nn	2026-09-28 16:49:05.87382+00	2026-09-28 16:50:38.802594+00	\N	\N	\N	mashhad	190	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن امکان بین جلال۳۷و۳۹ در آزادشهر", "amounts": {"اجاره": 40000000}}	\N
1012	divar	ga6qpG1V	۱۷۰متر/۳خواب/فول بازسازی/مدرن	هفت تیر (آب و برق)	\N	rent	\N	https://divar.ir/v/_/ga6qpG1V	2026-09-28 16:47:37.627364+00	2026-09-28 16:50:38.804719+00	\N	\N	\N	mashhad	170	3	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن متین در هفت تیر (آب و برق)", "amounts": {"اجاره": 35000000}}	\N
1013	divar	ga6q5Efd	آپارتمان.کرایه به زوارامام رضا	خرمشهر	\N	rent	\N	https://divar.ir/v/_/ga6q5Efd	2026-09-28 16:47:27.608168+00	2026-09-28 16:50:38.80687+00	\N	\N	\N	mashhad	\N	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در خرمشهر", "amounts": {"اجاره": 3000000}}	\N
1014	divar	ga6Kz3CE	آپارتمان طبقه همکف	بلال	\N	rent	\N	https://divar.ir/v/_/ga6Kz3CE	2026-09-28 16:46:58.372169+00	2026-09-28 16:50:38.809507+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بلال", "amounts": {"اجاره": 8000000}}	\N
1015	divar	ga2yTae8	۱۳۵ متری/در حد صفر/فول امکانات/شریعتی	حسابی جنوبی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga2yTae8	2026-09-28 16:46:44.545816+00	2026-09-28 16:50:38.812057+00	\N	\N	\N	mashhad	135	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "گروه مهندسی ساختمانی دیان در حسابی جنوبی (شهرک غرب)", "amounts": {"اجاره": 100000}}	\N
1016	divar	gax22RUz	رهن آپارتمان	رستگار	\N	rent	\N	https://divar.ir/v/_/gax22RUz	2026-09-28 16:46:43.409122+00	2026-09-28 16:50:38.814622+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در رستگار", "amounts": {}}	\N
1017	divar	gazaK92Z	آپارتمان ۱۱۰ متری، ۳ خواب، بازسازی شده	سید رضی	\N	rent	\N	https://divar.ir/v/_/gazaK92Z	2026-09-28 16:45:47.435127+00	2026-09-28 16:50:38.81801+00	\N	\N	\N	mashhad	110	3	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سید رضی", "amounts": {"اجاره": 35000000}}	\N
1018	divar	ga6mZUEP	سوئیت ۳۵ متری (استادیوسفی۳۳)	استاد یوسفی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6mZUEP	2026-09-28 16:45:39.708236+00	2026-09-28 16:50:38.820408+00	\N	\N	\N	mashhad	35	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در استاد یوسفی (شهرک غرب)", "amounts": {"اجاره": 6000000}}	\N
1019	divar	ga6mpTpE	توس 43غلامی ۶اپارتمان 100متر همکف	حضرت حجت	\N	rent	\N	https://divar.ir/v/_/ga6mpTpE	2026-09-28 16:45:29.29401+00	2026-09-28 16:50:38.822648+00	\N	\N	\N	mashhad	100	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حضرت حجت", "amounts": {"اجاره": 3000000}}	\N
1020	divar	ga6mZBEj	۱۶۰متر صفر هاشمیه	نیروی هوایی	\N	rent	\N	https://divar.ir/v/_/ga6mZBEj	2026-09-28 16:43:27.619245+00	2026-09-28 16:50:38.824917+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در نیروی هوایی", "amounts": {}}	\N
1021	divar	ga6i59rY	۲۴۰متر هر۳خواب مستر *نسترن* با حیاط اختصاصی ۴/۵م	نیروی هوایی	\N	rent	\N	https://divar.ir/v/_/ga6i59rY	2026-09-28 16:43:08.282882+00	2026-09-28 16:50:38.826868+00	\N	\N	\N	mashhad	240	3	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نیروی هوایی", "amounts": {"اجاره": 30000000}}	\N
1022	divar	ga6iJo0J	رهن و اجاره	شهید معقول	\N	rent	\N	https://divar.ir/v/_/ga6iJo0J	2026-09-28 16:41:14.944053+00	2026-09-28 16:50:38.829047+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید معقول", "amounts": {"اجاره": 8000000}}	\N
1023	divar	ga6iZe5w	اوایل حافظ85متز تک واحدی طبقه 3 فول و بازسازی	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/ga6iZe5w	2026-09-28 16:40:46.812391+00	2026-09-28 16:50:38.831329+00	\N	\N	\N	mashhad	\N	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (حافظ)", "amounts": {"اجاره": 20000000}}	\N
1028	divar	ganmRajf	فروش آپارتمان 145 متری در عبدالمطلب	یاس	10000000000	sale	\N	https://divar.ir/v/_/ganmRajf	2026-09-27 08:43:02.513307+00	2026-09-28 17:00:48.868266+00	\N	\N	\N	mashhad	145	\N	\N	\N	{"mid": "۱۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در یاس", "amounts": {"raw_amount": 10000000000}}	\N
1029	divar	gau67j_R	اول الهیه۱۰۲متر/۱۰واحد/نقشه و متریال ایده ال/دربار	الهیه	9850000000	sale	44	https://divar.ir/v/_/gau67j_R	2026-09-20 08:07:17.407171+00	2026-09-28 17:00:48.879798+00	\N	\N	\N	mashhad	102	\N	\N	\N	{"mid": "۹,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن دربار در الهیه", "amounts": {"raw_amount": 9850000000}}	\N
1030	divar	ga62JKTE	۱۶۰متر/مجیدیه/سند آماده/مدرن	الهیه	16700000000	sale	44	https://divar.ir/v/_/ga62JKTE	2026-09-28 17:00:39.422988+00	2026-09-28 17:00:48.885038+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۱۶,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 16700000000}}	\N
1031	divar	gaTVSqj7	فروش واحد مسکونی	بهمن	2800000000	sale	43	https://divar.ir/v/_/gaTVSqj7	2026-09-28 17:00:31.887373+00	2026-09-28 17:00:48.889462+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهمن", "amounts": {"raw_amount": 2800000000}}	\N
1032	divar	ga6yZN3F	آپارتمان ۱۰۵ متری فول بالاترین طبقه بازسازی شده	هفت تیر (آب و برق)	12000000000	sale	\N	https://divar.ir/v/_/ga6yZN3F	2026-09-28 16:58:48.086773+00	2026-09-28 17:00:48.89312+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (آب و برق)", "amounts": {"raw_amount": 12000000000}}	\N
1033	divar	ga6yJmV2	۱۰۰ متری ۲ خواب نوساز	امیر	8500000000	sale	\N	https://divar.ir/v/_/ga6yJmV2	2026-09-28 16:58:40.437429+00	2026-09-28 17:00:48.896115+00	\N	\N	\N	mashhad	100	2	\N	\N	{"mid": "۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیر", "amounts": {"raw_amount": 8500000000}}	\N
1034	divar	ga6upmtd	فروش آپارتمان شهر جدید بینالود مهر 4	جاهد شهر	1650000000	sale	41	https://divar.ir/v/_/ga6upmtd	2026-09-28 16:58:39.029002+00	2026-09-28 17:00:48.898475+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"raw_amount": 1650000000}}	\N
1035	divar	gaeS6_Qi	آپارتمان عبدالمطلب15	یاس	6000000000	sale	\N	https://divar.ir/v/_/gaeS6_Qi	2026-09-28 16:58:35.742692+00	2026-09-28 17:00:48.900623+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "رضامرادی در یاس", "amounts": {"raw_amount": 6000000000}}	\N
1036	divar	gaCmBrjz	۲۶۰۰متر زمین .حاشیه اصلی . تراکم۲۱سقف	فرهنگیان (شهرک غرب)	550000000000	sale	37	https://divar.ir/v/_/gaCmBrjz	2026-09-28 16:58:29.068973+00	2026-09-28 17:00:48.902882+00	\N	\N	\N	mashhad	2600	\N	\N	\N	{"mid": "۵۵۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 550000000000}}	\N
1037	divar	ga6ypV67	اپارتمان‌ طبقه‌چهارم‌‌در‌شهرک‌صبا‌ح	پنجتن	5000000000	sale	\N	https://divar.ir/v/_/ga6ypV67	2026-09-28 16:58:28.81893+00	2026-09-28 17:00:48.905082+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پنجتن", "amounts": {"raw_amount": 5000000000}}	\N
1038	divar	gaCWhnQL	۲۴۰متر .تک واحدی .دو کله .نوساز	الهیه	24950000000	sale	44	https://divar.ir/v/_/gaCWhnQL	2026-09-28 16:58:02.512457+00	2026-09-28 17:00:48.907233+00	\N	\N	\N	mashhad	240	\N	\N	\N	{"mid": "۲۴,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در الهیه", "amounts": {"raw_amount": 24950000000}}	\N
1039	divar	ga6uXdHc	زمین دوردیوار.کلاکوب	سپاد	700000000	sale	\N	https://divar.ir/v/_/ga6uXdHc	2026-09-28 16:58:01.928789+00	2026-09-28 17:00:48.909438+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سپاد", "amounts": {"raw_amount": 700000000}}	\N
1040	divar	gaAeiy4u	۳۲۰متر.صفر.دوبلکس.دو نبش .۴ خواب	احمدآباد	100000000000	sale	\N	https://divar.ir/v/_/gaAeiy4u	2026-09-28 16:57:37.459969+00	2026-09-28 17:00:48.912705+00	\N	\N	\N	mashhad	320	4	\N	\N	{"mid": "۱۰۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در احمدآباد", "amounts": {"raw_amount": 100000000000}}	\N
1041	divar	ga6yZXEj	تهاتر 2واحدآپارتمان80متری امامت با آپارتمان160متری	زیبا شهر	11500000000	sale	\N	https://divar.ir/v/_/ga6yZXEj	2026-09-28 16:57:12.44921+00	2026-09-28 17:00:48.914924+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۱۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در زیبا شهر", "amounts": {"raw_amount": 11500000000}}	\N
1042	divar	gaJCeJBu	۱۱۴متر.دو خواب .سند اماده	الهیه	11550000000	sale	44	https://divar.ir/v/_/gaJCeJBu	2026-09-28 16:57:00.937802+00	2026-09-28 17:00:48.917218+00	\N	\N	\N	mashhad	114	\N	\N	\N	{"mid": "۱۱,۵۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در الهیه", "amounts": {"raw_amount": 11550000000}}	\N
1043	divar	gawaCNya	۱۰۷متر.دو واحدی.دونبش .سند اماده .اول منطقه	الهیه	11000000000	sale	44	https://divar.ir/v/_/gawaCNya	2026-09-28 16:56:15.664333+00	2026-09-28 17:00:48.919571+00	\N	\N	\N	mashhad	107	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در الهیه", "amounts": {"raw_amount": 11000000000}}	\N
1044	divar	gaz68OCL	سفتکاری	نوده	2050000000	sale	\N	https://divar.ir/v/_/gaz68OCL	2026-09-28 16:56:14.855817+00	2026-09-28 17:00:48.921956+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۰۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در نوده", "amounts": {"raw_amount": 2050000000}}	\N
1045	divar	gaKGeh7x	رهن و اجاره	عامل	\N	rent	\N	https://divar.ir/v/_/gaKGeh7x	2026-09-28 16:58:13.014653+00	2026-09-28 17:00:48.924249+00	\N	\N	\N	mashhad	\N	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "در عامل", "amounts": {"اجاره": 2000000}}	\N
1046	divar	gayqK31E	۱۲۵متر دو خواب  .همکف. سلمان	راهنمایی	\N	rent	\N	https://divar.ir/v/_/gayqK31E	2026-09-28 16:55:55.266744+00	2026-09-28 17:00:48.926441+00	\N	\N	\N	mashhad	125	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در راهنمایی", "amounts": {"اجاره": 100000}}	\N
1047	divar	gaAmlkni	باغ ویلا  اجاره سالانه یا فروش و معاوضه	میان ولایت	\N	rent	\N	https://divar.ir/v/_/gaAmlkni	2026-09-28 16:54:29.630043+00	2026-09-28 17:00:48.92868+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"اجاره": 100000}}	\N
1048	divar	ga6u5T2h	خانه رهن و اجاره	کریم آباد	\N	rent	\N	https://divar.ir/v/_/ga6u5T2h	2026-09-28 16:52:40.212282+00	2026-09-28 17:00:48.931465+00	\N	\N	\N	mashhad	\N	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کریم آباد", "amounts": {"اجاره": 6000000}}	\N
1049	divar	ga6qZHlh	آپارتمان100 -نیلوفر -همکف	امیر	\N	rent	\N	https://divar.ir/v/_/ga6qZHlh	2026-09-28 16:50:53.487568+00	2026-09-28 17:00:48.934002+00	\N	\N	\N	mashhad	\N	\N	\N	11000000	{"mid": "اجاره: ۱۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیر", "amounts": {"اجاره": 11000000}}	\N
1057	divar	gaqq41Az	آپارتمان فروشی	سیلو	8000000000	sale	\N	https://divar.ir/v/_/gaqq41Az	2026-09-19 16:37:43.209238+00	2026-09-28 17:25:01.135479+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در سیلو", "amounts": {"raw_amount": 8000000000}}	\N
1058	divar	ga6KK0ER	آپارتمان ۱۱۰ متری صادقی	گوهرشاد	18800000000	sale	20	https://divar.ir/v/_/ga6KK0ER	2026-09-28 17:24:43.702036+00	2026-09-28 17:25:01.658509+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۱۸,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در گوهرشاد", "amounts": {"raw_amount": 18800000000}}	\N
1059	divar	ga6KamgC	زمین ۷۰۰ متری سنددار ، آمادده برای ساخت	کلاته برفی	6300000000	sale	\N	https://divar.ir/v/_/ga6KamgC	2026-09-28 17:24:41.92519+00	2026-09-28 17:25:01.72277+00	\N	\N	\N	mashhad	700	\N	\N	\N	{"mid": "۶,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در کلاته برفی", "amounts": {"raw_amount": 6300000000}}	\N
1060	divar	ga6K6wUf	۸۵متری/ دوخواب/ فول امکانات / بانو پسند	هفت تیر (آب و برق)	10200000000	sale	\N	https://divar.ir/v/_/ga6K6wUf	2026-09-28 17:24:29.630639+00	2026-09-28 17:25:01.782766+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۱۰,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (آب و برق)", "amounts": {"raw_amount": 10200000000}}	\N
1061	divar	ga6KqqNw	واحد ۸۰ متری بازسازی شده	رضاشهر	9350000000	sale	\N	https://divar.ir/v/_/ga6KqqNw	2026-09-28 17:24:17.027808+00	2026-09-28 17:25:01.845308+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۹,۳۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در رضاشهر", "amounts": {"raw_amount": 9350000000}}	\N
1063	divar	gav-ZlCd	محله زشک۲۰۰ زمین کنار رود خانه ساخت ازاذ	پارک کوهستان	800000000	sale	\N	https://divar.ir/v/_/gav-ZlCd	2026-09-28 17:23:22.165482+00	2026-09-28 17:25:01.890604+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در پارک کوهستان", "amounts": {"raw_amount": 800000000}}	\N
1064	divar	ga6Gq74L	۷۰متری دوخواب با اسانسور صفر شکار	هنرور	4150000000	sale	\N	https://divar.ir/v/_/ga6Gq74L	2026-09-28 17:21:49.726236+00	2026-09-28 17:25:01.907784+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۴,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"raw_amount": 4150000000}}	\N
1065	divar	gaWSW1Z9	آپارتمان 82 متری	جانباز	6970000000	sale	\N	https://divar.ir/v/_/gaWSW1Z9	2026-09-28 17:21:38.899724+00	2026-09-28 17:25:01.928831+00	\N	\N	\N	mashhad	82	\N	\N	\N	{"mid": "۶,۹۷۰,۰۰۰,۰۰۰ تومان", "bottom": "در جانباز", "amounts": {"raw_amount": 6970000000}}	\N
1066	divar	ga6Gaud-	ویلایی	نوده	11000000000	sale	\N	https://divar.ir/v/_/ga6Gaud-	2026-09-28 17:20:40.267775+00	2026-09-28 17:25:01.945778+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوده", "amounts": {"raw_amount": 11000000000}}	\N
1069	divar	ga6GqfGF	سیدرضی/نوساز/تک واحدی/طبقه پنجم	سید رضی	\N	rent	\N	https://divar.ir/v/_/ga6GqfGF	2026-09-28 17:23:59.554132+00	2026-09-28 17:25:01.977131+00	\N	\N	\N	mashhad	\N	\N	\N	70000000	{"mid": "اجاره: ۷۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن‌ کومه نبش هنرستان۱۳ در سید رضی", "amounts": {"اجاره": 70000000}}	\N
1070	divar	ga6GKkvf	۲۰۰ متر آپارتمان / احمد آباد  / بازسازی شده شیک	گوهرشاد	\N	rent	20	https://divar.ir/v/_/ga6GKkvf	2026-09-28 17:21:05.009139+00	2026-09-28 17:25:01.989966+00	\N	\N	\N	mashhad	200	\N	\N	63000000	{"mid": "اجاره: ۶۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گوهرشاد", "amounts": {"اجاره": 63000000}}	\N
1071	divar	ga3iMYyt	ویللای ۷۰متری	جانباز	\N	rent	\N	https://divar.ir/v/_/ga3iMYyt	2026-09-28 17:19:07.305169+00	2026-09-28 17:25:02.008424+00	\N	\N	\N	mashhad	70	\N	\N	175000000	{"mid": "اجاره: ۱۷۵,۰۰۰,۰۰۰ تومان", "bottom": "در جانباز", "amounts": {"اجاره": 175000000}}	\N
1072	divar	ga6iY2Bz	اپارتمان ۸۰متر طبقه سوم مسلم شمالی(گاز)	گاز	\N	rent	\N	https://divar.ir/v/_/ga6iY2Bz	2026-09-28 17:17:11.885152+00	2026-09-28 17:25:02.024241+00	\N	\N	\N	mashhad	80	\N	\N	5500000	{"mid": "اجاره: ۵,۵۰۰,۰۰۰ تومان", "bottom": "دفتر معاملات شبانی در گاز", "amounts": {"اجاره": 5500000}}	\N
1073	divar	ga0OAZ5j	هم خونه	الهیه	\N	rent	44	https://divar.ir/v/_/ga0OAZ5j	2026-09-28 17:16:32.729319+00	2026-09-28 17:25:02.041114+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"اجاره": 100000}}	\N
1074	divar	ga6upTXr	۱۶۵ متر آپارتمان/ناصرخسرو/کلید نخورده فول	احمدآباد	\N	rent	\N	https://divar.ir/v/_/ga6upTXr	2026-09-28 17:14:03.135557+00	2026-09-28 17:25:02.057043+00	\N	\N	\N	mashhad	165	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در احمدآباد", "amounts": {}}	\N
1075	divar	ga6-pne_	۹۸ متری الهیه ۳۷ ساخت ۴۰۳،بسیار شیک،دو واحدی	الهیه	\N	rent	44	https://divar.ir/v/_/ga6-pne_	2026-09-28 17:13:52.492252+00	2026-09-28 17:25:02.071255+00	\N	\N	\N	mashhad	98	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"اجاره": 1000000}}	\N
1076	divar	ga6-JyjV	۱۲۰ متری صفر رضاشهر	رضاشهر	\N	rent	\N	https://divar.ir/v/_/ga6-JyjV	2026-09-28 17:12:49.003557+00	2026-09-28 17:25:02.090074+00	\N	\N	\N	mashhad	120	\N	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاشهر", "amounts": {"اجاره": 35000000}}	\N
1077	divar	ga6-Z1Hs	آپارتمان نو  ۱۴۰ متر مناسب جهیزیه	الهیه	\N	rent	44	https://divar.ir/v/_/ga6-Z1Hs	2026-09-28 17:11:56.498944+00	2026-09-28 17:25:02.105785+00	\N	\N	\N	mashhad	140	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در الهیه", "amounts": {}}	\N
1078	divar	gah6FuLZ	110مترط.اول.پیامبراعظم55توس72تخلیه قابل تبدیل	توس (بلوار توس)	\N	rent	\N	https://divar.ir/v/_/gah6FuLZ	2026-09-28 17:11:48.32655+00	2026-09-28 17:25:02.128741+00	\N	\N	\N	mashhad	110	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "در توس (بلوار توس)", "amounts": {"اجاره": 100000}}	\N
1079	divar	ga66J1Kk	اپارتمان عبدالمطلب	یاس	\N	rent	\N	https://divar.ir/v/_/ga66J1Kk	2026-09-28 17:11:47.487354+00	2026-09-28 17:25:02.142184+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در یاس", "amounts": {}}	\N
1080	divar	ga6-5veL	۴خواب*تازه ساز*۲۴۰متری*مسکن الهی/پژوهیان	فارغ التحصیلان	\N	rent	\N	https://divar.ir/v/_/ga6-5veL	2026-09-28 17:11:40.995721+00	2026-09-28 17:25:02.156583+00	\N	\N	\N	mashhad	240	4	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن   الهی    نبش امامت ۴۶ در فارغ التحصیلان", "amounts": {}}	\N
1081	divar	gavGqnAF	یک واحد آپارتمان نیم کار 3خواب	بهمن	2700000000	sale	43	https://divar.ir/v/_/gavGqnAF	2026-09-28 05:29:56.616294+00	2026-09-28 17:35:13.774007+00	\N	\N	\N	mashhad	\N	3	\N	\N	{"mid": "۲,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهمن", "amounts": {"raw_amount": 2700000000}}	\N
1083	divar	ga6SK2rJ	زمین ۱۳۵ متری قند شیرین توس ۳۹	حضرت حجت	15000000000	sale	\N	https://divar.ir/v/_/ga6SK2rJ	2026-09-28 17:34:46.089346+00	2026-09-28 17:35:13.782573+00	\N	\N	\N	mashhad	135	\N	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در حضرت حجت", "amounts": {"raw_amount": 15000000000}}	\N
1084	divar	gaau4pWq	فروش آپارتمان سند دار مطهری شمالی ۳۷	سمزقند	7000000000	sale	\N	https://divar.ir/v/_/gaau4pWq	2026-09-28 17:33:42.057502+00	2026-09-28 17:35:13.785103+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در سمزقند", "amounts": {"raw_amount": 7000000000}}	\N
1085	divar	ga6SqwJ7	12خوابه50متر حیاط اختصاصی ط7	کوی سیدی	8500000000	sale	\N	https://divar.ir/v/_/ga6SqwJ7	2026-09-28 17:33:41.308073+00	2026-09-28 17:35:13.787551+00	\N	\N	\N	mashhad	50	12	\N	\N	{"mid": "۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی سیدی", "amounts": {"raw_amount": 8500000000}}	\N
1086	divar	gaTqQXr-	آپارتمان 90 متری فول امکانات جنوبی دونبش	حرم مطهر رضوی	18500000000	sale	\N	https://divar.ir/v/_/gaTqQXr-	2026-09-28 17:32:24.56097+00	2026-09-28 17:35:13.789736+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۱۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در حرم مطهر رضوی", "amounts": {"raw_amount": 18500000000}}	\N
1087	divar	ga5GGJyS	اپارتمان 148 متری / حاشیه اصلی / اگهی واقعی	الهیه	15000000000	sale	44	https://divar.ir/v/_/ga5GGJyS	2026-09-28 17:32:16.315978+00	2026-09-28 17:35:13.792382+00	\N	\N	\N	mashhad	148	\N	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 15000000000}}	\N
1088	divar	ga6SaUhJ	فروش فوق العاده یک واحد آپارتمان خیلی شیک	شهید مطهری	7400000000	sale	28	https://divar.ir/v/_/ga6SaUhJ	2026-09-28 17:32:00.668806+00	2026-09-28 17:35:13.794387+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید مطهری", "amounts": {"raw_amount": 7400000000}}	\N
1089	divar	ga6Oan7F	باغ ویلا	میان ولایت	20000000000	sale	\N	https://divar.ir/v/_/ga6Oan7F	2026-09-28 17:29:23.623885+00	2026-09-28 17:35:13.797261+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 20000000000}}	\N
1090	divar	ga6OqyDu	آپارتمان65متری2خواب/همکف/پارکینگ/سنددار/ساجدی	بهاران	6850000000	sale	17	https://divar.ir/v/_/ga6OqyDu	2026-09-28 17:28:54.363244+00	2026-09-28 17:35:13.799434+00	\N	\N	\N	mashhad	65	2	\N	\N	{"mid": "۶,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهاران", "amounts": {"raw_amount": 6850000000}}	\N
1091	divar	gaZ-cHCT	اپارتمان فروشی ۷۰ با پارکینگ	یوسفیه (شهرک غرب)	3950000000	sale	38	https://divar.ir/v/_/gaZ-cHCT	2026-09-28 17:28:18.936479+00	2026-09-28 17:35:13.801654+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در یوسفیه (شهرک غرب)", "amounts": {"raw_amount": 3950000000}}	\N
1092	divar	ga6K6rLW	خانه ۵۰متری در دوطبقه ونیم به صورت جدا گانه	انقلاب	6000000000	sale	\N	https://divar.ir/v/_/ga6K6rLW	2026-09-28 17:27:17.223772+00	2026-09-28 17:35:13.804119+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در انقلاب", "amounts": {"raw_amount": 6000000000}}	\N
1093	divar	ga6WqIms	هم‌ خونه	گاز	\N	rent	\N	https://divar.ir/v/_/ga6WqIms	2026-09-28 17:34:32.365257+00	2026-09-28 17:35:13.80626+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در گاز", "amounts": {"اجاره": 1000000}}	\N
1094	divar	ga6SK7cb	خانه رهن واجاره	مهدی آباد (بلوار توس)	\N	rent	\N	https://divar.ir/v/_/ga6SK7cb	2026-09-28 17:33:40.206224+00	2026-09-28 17:35:13.808093+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مهدی آباد (بلوار توس)", "amounts": {"اجاره": 8000000}}	\N
1095	divar	ga52Yn5U	آپارتمان ۵۰متری فاز۲رستگاری11	حجاب (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga52Yn5U	2026-09-28 17:31:08.188996+00	2026-09-28 17:35:13.810073+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در حجاب (شهرک غرب)", "amounts": {}}	\N
1096	divar	ga6OaU9W	رهن و اجاره منزل ویلایی نوفل لوشاتو	نوفل لوشاتو	\N	rent	\N	https://divar.ir/v/_/ga6OaU9W	2026-09-28 17:26:53.92307+00	2026-09-28 17:35:13.811801+00	\N	\N	\N	mashhad	\N	\N	\N	60000000	{"mid": "اجاره: ۶۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوفل لوشاتو", "amounts": {"اجاره": 60000000}}	\N
1105	divar	ga4KM1Yf	فروش باغ ویلای نوساز استخر داخل /داخل شهر	جاهد شهر	6600000000	sale	41	https://divar.ir/v/_/ga4KM1Yf	2026-09-28 17:44:58.188305+00	2026-09-28 17:45:24.732492+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن حقوقی زاگرس در جاهد شهر", "amounts": {"raw_amount": 6600000000}}	\N
1106	divar	gaYaXPsX	زمین باغی ملکی سند دار با پیش پرداخت فقط 100 م	درزآب	100000000	sale	\N	https://divar.ir/v/_/gaYaXPsX	2026-09-28 17:44:13.516753+00	2026-09-28 17:45:24.736735+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه سرمایه گذاری ویلاسازان در درزآب", "amounts": {"raw_amount": 100000000}}	\N
1107	divar	gaWeWQ86	آپارتمان بازسازی شده مجد	سعد آباد	13000000000	sale	\N	https://divar.ir/v/_/gaWeWQ86	2026-09-28 17:43:44.822585+00	2026-09-28 17:45:24.740685+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در سعد آباد", "amounts": {"raw_amount": 13000000000}}	\N
1108	divar	gaZ2JYam	خانه ویلایی ۱۰۰ متری خواجه ربیع سرمایه  گزاری عالی	بهمن	3200000000	sale	43	https://divar.ir/v/_/gaZ2JYam	2026-09-28 17:42:24.573187+00	2026-09-28 17:45:24.744664+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهمن", "amounts": {"raw_amount": 3200000000}}	\N
1109	divar	ga2y3cN5	*آپارتمان ۱۲۰ متری*سه خواب*سندآماده*	امیریه	11700000000	sale	\N	https://divar.ir/v/_/ga2y3cN5	2026-09-28 17:42:24.125601+00	2026-09-28 17:45:24.749185+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۱۱,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در امیریه", "amounts": {"raw_amount": 11700000000}}	\N
1110	divar	gabi9IFa	نسترن یک/145 متر/فول امکانات/تک واحدی/سه خواب قیم	نیروی هوایی	20600000000	sale	\N	https://divar.ir/v/_/gabi9IFa	2026-09-28 17:42:23.122812+00	2026-09-28 17:45:24.752821+00	\N	\N	\N	mashhad	145	\N	\N	\N	{"mid": "۲۰,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن یک در نیروی هوایی", "amounts": {"raw_amount": 20600000000}}	\N
1111	divar	gaYWVavF	سه خواب/طراحی نئوکلاسیک/ هفت تیر سه/عکسوفیلم داریم	هنرستان	34400000000	sale	11	https://divar.ir/v/_/gaYWVavF	2026-09-28 17:40:32.181551+00	2026-09-28 17:45:24.757183+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳۴,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن یک در هنرستان", "amounts": {"raw_amount": 34400000000}}	\N
1112	divar	gavxXSce	اپارتمان ۱۰۰ متری توس۱۰۹ یا توس۱۱۳حاشیه۱۰متر ط اول	دوست آباد	2500000000	sale	\N	https://divar.ir/v/_/gavxXSce	2026-09-28 17:40:28.132341+00	2026-09-28 17:45:24.761539+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در دوست آباد", "amounts": {"raw_amount": 2500000000}}	\N
1113	divar	ga6SqrI9	منزل دوبلکس مشهد	طبرسی	5400000000	sale	\N	https://divar.ir/v/_/ga6SqrI9	2026-09-28 17:40:24.271262+00	2026-09-28 17:45:24.765629+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طبرسی", "amounts": {"raw_amount": 5400000000}}	\N
1114	divar	gab69RYH	۱۱۰متر/ویلای چهار/دوخواب/بازسازی شده/فول امکانات	هفت تیر (آب و برق)	14300000000	sale	\N	https://divar.ir/v/_/gab69RYH	2026-09-28 17:39:35.946826+00	2026-09-28 17:45:24.769139+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۱۴,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن یک در هفت تیر (آب و برق)", "amounts": {"raw_amount": 14300000000}}	\N
1115	divar	ga6aaBR5	آپارتمان ۸۵متری بازسازی شده	حجاب (شهرک غرب)	6500000000	sale	38	https://divar.ir/v/_/ga6aaBR5	2026-09-28 17:38:54.965821+00	2026-09-28 17:45:24.772517+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حجاب (شهرک غرب)", "amounts": {"raw_amount": 6500000000}}	\N
1117	divar	ga6eqCQl	علیمردانی ۶/ ۷۰ متری/همکف/تخلیه فوری	ایثار	\N	rent	\N	https://divar.ir/v/_/ga6eqCQl	2026-09-28 17:43:10.703299+00	2026-09-28 17:45:24.779945+00	\N	\N	\N	mashhad	70	\N	\N	17000000	{"mid": "اجاره: ۱۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثار", "amounts": {"اجاره": 17000000}}	\N
1118	divar	ga6W6Ysb	اجاره خانه ویلایی دربست حیاط دار طبرسی ۴	نظام دوست	\N	rent	\N	https://divar.ir/v/_/ga6W6Ysb	2026-09-28 17:36:45.884059+00	2026-09-28 17:45:24.783126+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نظام دوست", "amounts": {"اجاره": 5000000}}	\N
1119	divar	ga6Wqm2x	اجاره آپارتمان طبرسی شمالی ۴	نظام دوست	\N	rent	\N	https://divar.ir/v/_/ga6Wqm2x	2026-09-28 17:36:45.325273+00	2026-09-28 17:45:24.786992+00	\N	\N	\N	mashhad	\N	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نظام دوست", "amounts": {"اجاره": 4000000}}	\N
1129	divar	ga6iq2xI	61متر یک خواب با 25 متر حیاط اختصاصی پروین	پروین اعتصامی	8000000000	sale	\N	https://divar.ir/v/_/ga6iq2xI	2026-09-28 17:50:25.587478+00	2026-09-28 17:50:33.765296+00	\N	\N	\N	mashhad	61	\N	\N	\N	{"mid": "۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در پروین اعتصامی", "amounts": {"raw_amount": 8000000000}}	\N
1130	divar	ga6iaq-T	آپارتمان همکف سرجلو	شهرک بهارستان	2750000000	sale	\N	https://divar.ir/v/_/ga6iaq-T	2026-09-28 17:50:21.898914+00	2026-09-28 17:50:33.770068+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهرک بهارستان", "amounts": {"raw_amount": 2750000000}}	\N
1131	divar	ga6eaV8Z	75متر آزادی 49سند شش دونگ  مجتمع پرستو خوش نور	توس (بلوار توس)	4800000000	sale	\N	https://divar.ir/v/_/ga6eaV8Z	2026-09-28 17:50:10.222534+00	2026-09-28 17:50:33.772999+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۴,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در توس (بلوار توس)", "amounts": {"raw_amount": 4800000000}}	\N
1132	divar	ga6iKZAO	منزل ویلایی فروشی	بهشت	7000000000	sale	18	https://divar.ir/v/_/ga6iKZAO	2026-09-28 17:49:29.989672+00	2026-09-28 17:50:33.775983+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهشت", "amounts": {"raw_amount": 7000000000}}	\N
1133	divar	ga6iaMpg	خانه فروشی	کاظم آباد پنجشنبه	1500000000	sale	\N	https://divar.ir/v/_/ga6iaMpg	2026-09-28 17:48:37.852742+00	2026-09-28 17:50:33.778984+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کاظم آباد پنجشنبه", "amounts": {"raw_amount": 1500000000}}	\N
1134	divar	ga6CKm5o	خانه شخصی فروشی	شهید قربانی	5500000000	sale	\N	https://divar.ir/v/_/ga6CKm5o	2026-09-28 17:47:33.354475+00	2026-09-28 17:50:33.782583+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید قربانی", "amounts": {"raw_amount": 5500000000}}	\N
1135	divar	ga6eqYhB	ویلای ۱۰۱ متری سند شش دانگ توس ۸۱	شهرک مطهری	8000000000	sale	\N	https://divar.ir/v/_/ga6eqYhB	2026-09-28 17:46:39.947274+00	2026-09-28 17:50:33.785954+00	\N	\N	\N	mashhad	101	\N	\N	\N	{"mid": "۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک مطهری", "amounts": {"raw_amount": 8000000000}}	\N
1136	divar	ga6eqmve	طبقه نیمه ساز در توس ۱۱۷، روستای اسماعیل آباد	اسماعیل آباد	1500000000	sale	\N	https://divar.ir/v/_/ga6eqmve	2026-09-28 17:46:11.38031+00	2026-09-28 17:50:33.789094+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در اسماعیل آباد", "amounts": {"raw_amount": 1500000000}}	\N
1137	divar	ga6equTf	صفر 160 متر * نئو مدرن * ویو ابدی * امامت 1	آزادشهر	31000000000	sale	\N	https://divar.ir/v/_/ga6equTf	2026-09-28 17:45:40.932387+00	2026-09-28 17:50:33.792245+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۳۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن گسترش منقولی در آزادشهر", "amounts": {"raw_amount": 31000000000}}	\N
1144	divar	ga6iqO1P	اجاره منزل ویلایی	امام خمینی	\N	rent	\N	https://divar.ir/v/_/ga6iqO1P	2026-09-28 17:50:18.594166+00	2026-09-28 17:50:33.809251+00	\N	\N	\N	mashhad	\N	\N	\N	5500000	{"mid": "اجاره: ۵,۵۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در امام خمینی", "amounts": {"اجاره": 5500000}}	\N
1145	divar	gataQj5H	رهن و اجاره منزل ویلایی	توس فردوسی	\N	rent	\N	https://divar.ir/v/_/gataQj5H	2026-09-28 17:50:02.448281+00	2026-09-28 17:50:33.812825+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس فردوسی", "amounts": {"اجاره": 10000000}}	\N
1146	divar	ga4qsNjB	رهن و اجاره ۲واحد آپارتمانی( دربست)نوساز	شهید بهشتی	\N	rent	18	https://divar.ir/v/_/ga4qsNjB	2026-09-28 17:49:07.736269+00	2026-09-28 17:50:33.816141+00	\N	\N	\N	mashhad	\N	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "در شهید بهشتی", "amounts": {"اجاره": 6000000}}	\N
1147	divar	ga6iaBF2	ویلایی دوطبقه دربست رهن ، اجاره	شهرک امام هادی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6iaBF2	2026-09-28 17:47:47.401383+00	2026-09-28 17:50:33.820115+00	\N	\N	\N	mashhad	\N	\N	\N	21000000	{"mid": "اجاره: ۲۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک امام هادی (شهرک غرب)", "amounts": {"اجاره": 21000000}}	\N
1148	divar	ga6i6Ggm	رهن واجاره	سپاد	\N	rent	\N	https://divar.ir/v/_/ga6i6Ggm	2026-09-28 17:47:19.204795+00	2026-09-28 17:50:33.824644+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سپاد", "amounts": {"اجاره": 15000000}}	\N
1149	divar	gaseUBvK	همخونه	شهرک شیرین	\N	rent	\N	https://divar.ir/v/_/gaseUBvK	2026-09-28 17:46:16.284326+00	2026-09-28 17:50:33.828506+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک شیرین", "amounts": {"اجاره": 1000000}}	\N
1150	divar	ga6e6X76	آپارتمان اجاره	نوید	\N	rent	\N	https://divar.ir/v/_/ga6e6X76	2026-09-28 17:45:53.140798+00	2026-09-28 17:50:33.832838+00	\N	\N	\N	mashhad	\N	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "دقایقی پیش در نوید", "amounts": {"اجاره": 1000}}	\N
1159	divar	gaTadLHN	95متر طبقه پنجم صفر دوخواب نور چند واحد مشابه دیگر	الهیه	8800000000	sale	44	https://divar.ir/v/_/gaTadLHN	2026-09-28 18:00:15.244907+00	2026-09-28 18:00:44.729135+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۸,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 8800000000}}	\N
1160	divar	gagmzyjf	۷۵ متر ۲ خواب طبقه۴	یوسفیه (شهرک غرب)	4800000000	sale	38	https://divar.ir/v/_/gagmzyjf	2026-09-28 17:59:57.966556+00	2026-09-28 18:00:44.747135+00	\N	\N	\N	mashhad	75	2	\N	\N	{"mid": "۴,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در یوسفیه (شهرک غرب)", "amounts": {"raw_amount": 4800000000}}	\N
1161	divar	ga6qKODD	فروش آپارتمان	کوی سیدی	7500000000	sale	\N	https://divar.ir/v/_/ga6qKODD	2026-09-28 17:57:35.594321+00	2026-09-28 18:00:44.752679+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی سیدی", "amounts": {"raw_amount": 7500000000}}	\N
1162	divar	ga6mq0m-	فروش خانه حیاط دار	هفت تیر (نه دره)	14000000000	sale	\N	https://divar.ir/v/_/ga6mq0m-	2026-09-28 17:56:39.610832+00	2026-09-28 18:00:44.757991+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (نه دره)", "amounts": {"raw_amount": 14000000000}}	\N
1163	divar	ga5SEU11	مــنـزل آپـارتـمـانـی ۱۱۰مـتــری مخـصوص خـاص پسندا	نوده	1999000000	sale	\N	https://divar.ir/v/_/ga5SEU11	2026-09-28 17:56:17.234468+00	2026-09-28 18:00:44.764756+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۹۹۹,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوده", "amounts": {"raw_amount": 1999000000}}	\N
1164	divar	gapmFy6d	اراضی فاز دوم الهیه با تاییدیه شهرداری و کد نوسازی	جاهد شهر	400000000	sale	41	https://divar.ir/v/_/gapmFy6d	2026-09-28 17:55:51.554854+00	2026-09-28 18:00:44.773864+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "خرید و فروش باغ آپارتمان سوله در جاهد شهر", "amounts": {"raw_amount": 400000000}}	\N
1165	divar	ga6mqoXP	فروش اپارتمان ۶۰ متری	یاس	4000000000	sale	\N	https://divar.ir/v/_/ga6mqoXP	2026-09-28 17:55:06.111447+00	2026-09-28 18:00:44.780973+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در یاس", "amounts": {"raw_amount": 4000000000}}	\N
1166	divar	ga6mKo-y	فروش زمین	میان ولایت	6000000000	sale	\N	https://divar.ir/v/_/ga6mKo-y	2026-09-28 17:55:05.556202+00	2026-09-28 18:00:44.786956+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 6000000000}}	\N
1167	divar	ga6m66t7	فروش۱۵۵ متری/طبقه۴/نوساز/سند آماده/فوری	آزادشهر	24000000000	sale	\N	https://divar.ir/v/_/ga6m66t7	2026-09-28 17:55:04.117148+00	2026-09-28 18:00:44.791295+00	\N	\N	\N	mashhad	155	\N	\N	\N	{"mid": "۲۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "اژانس اریا در آزادشهر", "amounts": {"raw_amount": 24000000000}}	\N
1168	divar	ga6iq4Ku	باغ دور دیوار 1000 متر چهارفصل	میان ولایت	32000000000	sale	\N	https://divar.ir/v/_/ga6iq4Ku	2026-09-28 17:55:03.377638+00	2026-09-28 18:00:44.796125+00	\N	\N	\N	mashhad	1000	\N	\N	\N	{"mid": "۳۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 32000000000}}	\N
1169	divar	gay6HU9O	آپارتمان105M/اول منطقه/کم واحد/نورگیر/سندآماده	الهیه	10800000000	sale	44	https://divar.ir/v/_/gay6HU9O	2026-09-28 17:54:23.820952+00	2026-09-28 18:00:44.800443+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۰,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن دربار در الهیه", "amounts": {"raw_amount": 10800000000}}	\N
1170	divar	ga6mqgdO	آپارتمان ۵۵متری بهمن۲۴ /۴	بهمن	1700000000	sale	43	https://divar.ir/v/_/ga6mqgdO	2026-09-28 17:54:17.62054+00	2026-09-28 18:00:44.805769+00	\N	\N	\N	mashhad	55	\N	\N	\N	{"mid": "۱,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهمن", "amounts": {"raw_amount": 1700000000}}	\N
1171	divar	ga6mqoGn	آپارتمان ۱۲۵ متر	سید رضی	12500000000	sale	\N	https://divar.ir/v/_/ga6mqoGn	2026-09-28 17:54:02.69172+00	2026-09-28 18:00:44.810526+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سید رضی", "amounts": {"raw_amount": 12500000000}}	\N
1172	divar	ga6m6hrL	آپارتمان فروشی	ایثار	5500000000	sale	\N	https://divar.ir/v/_/ga6m6hrL	2026-09-28 17:53:50.411337+00	2026-09-28 18:00:44.816476+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثار", "amounts": {"raw_amount": 5500000000}}	\N
1174	divar	gaZq01Pf	واحد اداری پزشکی 150متر / مجتمع پزشکان	جاهد شهر	\N	rent	41	https://divar.ir/v/_/gaZq01Pf	2026-09-28 18:00:40.86618+00	2026-09-28 18:00:44.824594+00	\N	\N	\N	mashhad	150	\N	\N	45000000	{"mid": "اجاره: ۴۵,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"اجاره": 45000000}}	\N
1175	divar	ga6qKrfJ	۱۷۵ متر تک واحدی صفر گلشن هفت تیر	هنرستان	\N	rent	11	https://divar.ir/v/_/ga6qKrfJ	2026-09-28 17:59:00.114322+00	2026-09-28 18:00:44.828974+00	\N	\N	\N	mashhad	175	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن والی در هنرستان", "amounts": {}}	\N
1176	divar	ga6qaE5b	آپارتمان طبقه چهارم	گاز	\N	rent	\N	https://divar.ir/v/_/ga6qaE5b	2026-09-28 17:56:27.143663+00	2026-09-28 18:00:44.83559+00	\N	\N	\N	mashhad	\N	\N	\N	3500000	{"mid": "اجاره: ۳,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گاز", "amounts": {"اجاره": 3500000}}	\N
1177	divar	ga6i6kzW	منزل ویلایی رهن و اجاره / ماشین رو	هفده شهریور	\N	rent	\N	https://divar.ir/v/_/ga6i6kzW	2026-09-28 17:51:00.278266+00	2026-09-28 18:00:44.840524+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفده شهریور", "amounts": {"اجاره": 10000000}}	\N
1191	divar	gaUqlcm1	آپارتمان ۱۲۰متر/دوخواب نور/سند آماده / رو به آفتاب	الهیه	11000000000	sale	44	https://divar.ir/v/_/gaUqlcm1	2026-09-28 18:05:35.620725+00	2026-09-28 18:06:13.704916+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 11000000000}}	\N
1192	divar	ga6yqKxk	وقتی تفاوت، از همان نگاه اول پیداست/۲۹۲متر	سجاد شهر	75000000000	sale	21	https://divar.ir/v/_/ga6yqKxk	2026-09-28 18:05:16.383903+00	2026-09-28 18:06:13.712472+00	\N	\N	\N	mashhad	292	\N	\N	\N	{"mid": "۷۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در سجاد شهر", "amounts": {"raw_amount": 75000000000}}	\N
1193	divar	gauhPKae	آپارتمان ۱۵۸متر/تک واحدی/سند آماده/تهاتر با دوخواب	الهیه	15500000000	sale	44	https://divar.ir/v/_/gauhPKae	2026-09-28 18:05:12.761703+00	2026-09-28 18:06:13.717014+00	\N	\N	\N	mashhad	158	\N	\N	\N	{"mid": "۱۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 15500000000}}	\N
1194	divar	gaSyKHQ3	آپارتمان ۱۰۰متر/شمالی خورجینی/سند آماده/تخلیه	الهیه	10500000000	sale	44	https://divar.ir/v/_/gaSyKHQ3	2026-09-28 18:04:45.656186+00	2026-09-28 18:06:13.722396+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 10500000000}}	\N
1195	divar	ga6u6n65	زمین	شهید احمدی روشن	2600000000	sale	\N	https://divar.ir/v/_/ga6u6n65	2026-09-28 18:03:02.260769+00	2026-09-28 18:06:13.727492+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید احمدی روشن", "amounts": {"raw_amount": 2600000000}}	\N
1196	divar	ga6uaDS3	آپارتمان صفر منزل اباد	منزل آباد	5200000000	sale	\N	https://divar.ir/v/_/ga6uaDS3	2026-09-28 18:01:06.730027+00	2026-09-28 18:06:13.732055+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در منزل آباد", "amounts": {"raw_amount": 5200000000}}	\N
1203	divar	ga6uKvhg	همخونه رفیعی	نرگس (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6uKvhg	2026-09-28 18:03:22.670374+00	2026-09-28 18:06:13.761479+00	\N	\N	\N	mashhad	\N	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نرگس (شهرک غرب)", "amounts": {"اجاره": 7000000}}	\N
1216	divar	ga6KUcF3	116 متر، آپارتمان  ۳ خواب دونبش نورگیر ،مجتمع غدیر	امیریه	9730000000	sale	\N	https://divar.ir/v/_/ga6KUcF3	2026-09-28 10:33:58.594427+00	2026-09-28 18:16:25.542306+00	\N	\N	\N	mashhad	116	3	\N	\N	{"mid": "۹,۷۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیریه", "amounts": {"raw_amount": 9730000000}}	\N
1217	divar	ga66aByw	باغچه 430متری در بهترین نقطه خرم دره	توس فردوسی	1000000000	sale	\N	https://divar.ir/v/_/ga66aByw	2026-09-28 18:15:45.078578+00	2026-09-28 18:16:25.55775+00	\N	\N	\N	mashhad	430	\N	\N	\N	{"mid": "۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در توس فردوسی", "amounts": {"raw_amount": 1000000000}}	\N
1218	divar	ga66KcxG	آپارتمان فروشی امامت	آزادشهر	22000000000	sale	\N	https://divar.ir/v/_/ga66KcxG	2026-09-28 18:15:01.641696+00	2026-09-28 18:16:25.561861+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آزادشهر", "amounts": {"raw_amount": 22000000000}}	\N
1219	divar	gaUyyOIL	آپارتمان ۸۵ متری	خرمشهر	8400000000	sale	\N	https://divar.ir/v/_/gaUyyOIL	2026-09-28 18:15:00.992887+00	2026-09-28 18:16:25.565514+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۸,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در خرمشهر", "amounts": {"raw_amount": 8400000000}}	\N
1220	divar	ga1aQQ6L	خونه قدیمی فروش فوری	کوی سیدی	25000000000	sale	\N	https://divar.ir/v/_/ga1aQQ6L	2026-09-28 18:14:46.015677+00	2026-09-28 18:16:25.569625+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوی سیدی", "amounts": {"raw_amount": 25000000000}}	\N
1221	divar	gahSAomi	خرید هوشمندانه در اوایل هفت‌تیر/۱۵۵ متر/ وام ۱/۵۰۰	هنرستان	23000000000	sale	11	https://divar.ir/v/_/gahSAomi	2026-09-28 18:13:55.842276+00	2026-09-28 18:16:25.573647+00	\N	\N	\N	mashhad	155	\N	\N	\N	{"mid": "۲۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هنرستان", "amounts": {"raw_amount": 23000000000}}	\N
1222	divar	galOy6QY	زمین باغی آرامگاه فردوسی	توس فردوسی	450000000	sale	\N	https://divar.ir/v/_/galOy6QY	2026-09-28 18:12:29.012651+00	2026-09-28 18:16:25.577815+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس فردوسی", "amounts": {"raw_amount": 450000000}}	\N
1223	divar	ga62KMU-	خانه آپارتمانی	ثامن	4000000000	sale	\N	https://divar.ir/v/_/ga62KMU-	2026-09-28 18:11:22.156176+00	2026-09-28 18:16:25.581318+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ثامن", "amounts": {"raw_amount": 4000000000}}	\N
1224	divar	ga6eq3ba	۱۳۶ متری*دوطبقه*ماشین رو/حر۱۳	شهید معقول	6000000000	sale	\N	https://divar.ir/v/_/ga6eq3ba	2026-09-28 18:11:06.891847+00	2026-09-28 18:16:25.585949+00	\N	\N	\N	mashhad	136	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید معقول", "amounts": {"raw_amount": 6000000000}}	\N
1225	divar	gayGZcqn	فروش آپارتمان ۷۰متری۲خواب تک واحدی	راهنمایی	7150000000	sale	\N	https://divar.ir/v/_/gayGZcqn	2026-09-28 18:10:22.433279+00	2026-09-28 18:16:25.589843+00	\N	\N	\N	mashhad	70	2	\N	\N	{"mid": "۷,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در راهنمایی", "amounts": {"raw_amount": 7150000000}}	\N
1226	divar	ga6uq1jQ	طبقه سوم ۱۰۰متری خیلی شیک	توس (بلوار توس)	3650000000	sale	\N	https://divar.ir/v/_/ga6uq1jQ	2026-09-28 18:10:06.991802+00	2026-09-28 18:16:25.59439+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۳,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {"raw_amount": 3650000000}}	\N
1227	divar	ga62KD9w	۸۰ متری /۲خواب/فول امکانات/آماده نشیمن	سید رضی	12500000000	sale	\N	https://divar.ir/v/_/ga62KD9w	2026-09-28 18:08:21.154551+00	2026-09-28 18:16:25.598568+00	\N	\N	\N	mashhad	80	2	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "اژانس اریا در سید رضی", "amounts": {"raw_amount": 12500000000}}	\N
1230	divar	ga3-fqll	خریدارحرفه‌ای جلال ببیند+قبل معلم/وسوسه انگیز قیمت	آزادشهر	29000000000	sale	\N	https://divar.ir/v/_/ga3-fqll	2026-09-28 18:07:13.436611+00	2026-09-28 18:16:25.608923+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری عالیجناب در آزادشهر", "amounts": {"raw_amount": 29000000000}}	\N
1231	divar	ga6yKhmS	آپارتمان 75 متری	چاهشک	2800000000	sale	\N	https://divar.ir/v/_/ga6yKhmS	2026-09-28 18:07:02.739586+00	2026-09-28 18:16:25.612975+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۲,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چاهشک", "amounts": {"raw_amount": 2800000000}}	\N
1233	divar	ga6yqOFy	باغ ویلا فروشی در چهچه	میان ولایت	1300000000	sale	\N	https://divar.ir/v/_/ga6yqOFy	2026-09-28 18:06:23.746711+00	2026-09-28 18:16:25.619354+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 1300000000}}	\N
1234	divar	ga6yqH5q	خانه ویلایی	محمدآباد	3100000000	sale	\N	https://divar.ir/v/_/ga6yqH5q	2026-09-28 18:06:14.16432+00	2026-09-28 18:16:25.623234+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در محمدآباد", "amounts": {"raw_amount": 3100000000}}	\N
1236	divar	ga66qgaT	اجاره واحد ۷۸ متری	هنرستان	\N	rent	11	https://divar.ir/v/_/ga66qgaT	2026-09-28 18:15:29.736742+00	2026-09-28 18:16:25.630587+00	\N	\N	\N	mashhad	78	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در هنرستان", "amounts": {"اجاره": 2000000}}	\N
1237	divar	ga6u6vzX	منزل ویلایی دربست دو خواب ماشین رو	چهاربرج	\N	rent	\N	https://divar.ir/v/_/ga6u6vzX	2026-09-28 18:13:17.023873+00	2026-09-28 18:16:25.634304+00	\N	\N	\N	mashhad	\N	\N	\N	7500000	{"mid": "اجاره: ۷,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهاربرج", "amounts": {"اجاره": 7500000}}	\N
1238	divar	ga6yagAI	باغ ویلا دو هزار متری شاهنامه	چهاربرج	\N	rent	\N	https://divar.ir/v/_/ga6yagAI	2026-09-28 18:06:56.467782+00	2026-09-28 18:16:25.638066+00	\N	\N	\N	mashhad	\N	\N	\N	70000000	{"mid": "اجاره: ۷۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهاربرج", "amounts": {"اجاره": 70000000}}	\N
1251	divar	ga3yIPIJ	فروش زمین 600 متری داخل مجتمع دوردیوار	لقمانی	820000000	sale	\N	https://divar.ir/v/_/ga3yIPIJ	2026-09-27 07:36:05.940252+00	2026-09-28 19:16:09.809884+00	\N	\N	\N	mashhad	600	\N	\N	\N	{"mid": "۸۲۰,۰۰۰,۰۰۰ تومان", "bottom": "در لقمانی", "amounts": {"raw_amount": 820000000}}	\N
1252	divar	gaRm02vq	۱۲۵ متر ، نوساز ، گرمایش از کف ، سند آماده	امیریه	12000000000	sale	\N	https://divar.ir/v/_/gaRm02vq	2026-09-25 17:21:45.96064+00	2026-09-28 19:16:09.829298+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۱۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیریه", "amounts": {"raw_amount": 12000000000}}	\N
1253	divar	ga6y7j_Y	مناسب سرمایه گذاری ، متراژ مناسب ، سازه مهندسی	راه آهن	8950000000	sale	\N	https://divar.ir/v/_/ga6y7j_Y	2026-09-28 19:15:07.799626+00	2026-09-28 19:16:09.835843+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در راه آهن", "amounts": {"raw_amount": 8950000000}}	\N
1254	divar	ga6yLQxP	آپارتمان نیمه ساز راه جدا معاوضه با خودرو هم دارم	رده	2500000000	sale	\N	https://divar.ir/v/_/ga6yLQxP	2026-09-28 19:14:09.644513+00	2026-09-28 19:16:09.841076+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رده", "amounts": {"raw_amount": 2500000000}}	\N
1255	divar	ga6u7Wzx	زمین باغی سند دار با امتیازات شاهنامه ۱۴ جنب زیتون	باغستان	7000000000	sale	\N	https://divar.ir/v/_/ga6u7Wzx	2026-09-28 19:11:47.499973+00	2026-09-28 19:16:09.845609+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در باغستان", "amounts": {"raw_amount": 7000000000}}	\N
1256	divar	gaRyoofO	خانه فروشی	تبادکان	1050000000	sale	\N	https://divar.ir/v/_/gaRyoofO	2026-09-28 19:10:20.930536+00	2026-09-28 19:16:09.850133+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۰۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در تبادکان", "amounts": {"raw_amount": 1050000000}}	\N
1257	divar	ga6u7BAV	خانه دربست	عسگریه	6300000000	sale	\N	https://divar.ir/v/_/ga6u7BAV	2026-09-28 19:10:00.345427+00	2026-09-28 19:16:09.854506+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در عسگریه", "amounts": {"raw_amount": 6300000000}}	\N
1258	divar	ga6qrk1M	۱۹۰متر ویلایی	امیر	24000000000	sale	\N	https://divar.ir/v/_/ga6qrk1M	2026-09-28 19:08:05.57154+00	2026-09-28 19:16:09.858965+00	\N	\N	\N	mashhad	190	\N	\N	\N	{"mid": "۲۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیر", "amounts": {"raw_amount": 24000000000}}	\N
1259	divar	ga6W7GvG	املاک محمد باغچه ۱۰۰۰متری سروآباد خانسعادت	میان ولایت	1500000000	sale	\N	https://divar.ir/v/_/ga6W7GvG	2026-09-28 19:07:58.13187+00	2026-09-28 19:16:09.863228+00	\N	\N	\N	mashhad	1000	\N	\N	\N	{"mid": "۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 1500000000}}	\N
1260	divar	ga06hX-W	۱۵۵صفر۳خواب مهندسی تکواحد عبادی اواسط مطهری شمالی	سمزقند	11600000000	sale	\N	https://divar.ir/v/_/ga06hX-W	2026-09-28 19:06:28.36595+00	2026-09-28 19:16:09.868371+00	\N	\N	\N	mashhad	\N	3	\N	\N	{"mid": "۱۱,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سمزقند", "amounts": {"raw_amount": 11600000000}}	\N
1261	divar	gaxO4lHC	۱۰۰ متر آپارتمان/طبقه اول /فرجی	کوی المهدی	4750000000	sale	\N	https://divar.ir/v/_/gaxO4lHC	2026-09-28 19:05:53.961927+00	2026-09-28 19:16:09.872651+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۴,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوی المهدی", "amounts": {"raw_amount": 4750000000}}	\N
1262	divar	gamm2Hhu	فروش ویژه زمین ۵۰۲متری باامتیاز آب برق	توس فردوسی	370000000	sale	\N	https://divar.ir/v/_/gamm2Hhu	2026-09-28 19:04:50.521114+00	2026-09-28 19:16:09.87664+00	\N	\N	\N	mashhad	502	\N	\N	\N	{"mid": "۳۷۰,۰۰۰,۰۰۰ تومان", "bottom": "دفتر فروش۰ویلاسازان سرمدی  در توس فردوسی", "amounts": {"raw_amount": 370000000}}	\N
1263	divar	ga6CbhBU	آپارتمان ۱۱۰متری/فول فرنیش/دسترسی آسان به حرم مطهر	عنصری	24000000000	sale	\N	https://divar.ir/v/_/ga6CbhBU	2026-09-28 19:04:17.382877+00	2026-09-28 19:16:09.880385+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۲۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در عنصری", "amounts": {"raw_amount": 24000000000}}	\N
1264	divar	ga6m7sag	فروش اپارتمان	سرافرازان	24000000000	sale	22	https://divar.ir/v/_/ga6m7sag	2026-09-28 19:03:28.874856+00	2026-09-28 19:16:09.884491+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سرافرازان", "amounts": {"raw_amount": 24000000000}}	\N
1265	divar	ga6iba7L	ویلایی تمیز تمیز	شهید قربانی	2600000000	sale	\N	https://divar.ir/v/_/ga6iba7L	2026-09-28 19:02:42.474081+00	2026-09-28 19:16:09.888509+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید قربانی", "amounts": {"raw_amount": 2600000000}}	\N
1267	divar	ga6y7EKf	رهن و اجاره منزل ویلایی دربست	آیت الله کاشانی	\N	rent	\N	https://divar.ir/v/_/ga6y7EKf	2026-09-28 19:14:32.863299+00	2026-09-28 19:16:09.894944+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آیت الله کاشانی", "amounts": {"اجاره": 10000000}}	\N
1268	divar	ga6y7dNW	۵۰ متری قیمت عالی	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga6y7dNW	2026-09-28 19:14:07.470226+00	2026-09-28 19:16:09.898839+00	\N	\N	\N	mashhad	50	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"اجاره": 15000000}}	\N
1269	divar	gaTa_1eT	اجاره سالانه مسافرخانه با مجوز	نوغان	\N	rent	\N	https://divar.ir/v/_/gaTa_1eT	2026-09-28 19:11:44.514502+00	2026-09-28 19:16:09.90213+00	\N	\N	\N	mashhad	\N	\N	\N	46000000	{"mid": "اجاره: ۴۶,۰۰۰,۰۰۰ تومان", "bottom": "در نوغان", "amounts": {"اجاره": 46000000}}	\N
1270	divar	ga6ubg8u	همخونه  خانوم میخوام	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga6ubg8u	2026-09-28 19:10:01.288593+00	2026-09-28 19:16:09.906319+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"اجاره": 5000000}}	\N
1271	divar	ga6qb3wt	رهن و اجاره	شاهد (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6qb3wt	2026-09-28 19:07:15.252052+00	2026-09-28 19:16:09.910336+00	\N	\N	\N	mashhad	\N	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شاهد (شهرک غرب)", "amounts": {"اجاره": 30000000}}	\N
1272	divar	ga6W7dlb	همخونه	گاز	\N	rent	\N	https://divar.ir/v/_/ga6W7dlb	2026-09-28 19:03:34.787955+00	2026-09-28 19:16:09.914474+00	\N	\N	\N	mashhad	\N	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گاز", "amounts": {"اجاره": 2000000}}	\N
1273	divar	ga6i770g	آپارتمان رهن واجاره تمیزومرتب	خواجه ربیع	\N	rent	\N	https://divar.ir/v/_/ga6i770g	2026-09-28 19:02:08.979396+00	2026-09-28 19:16:09.918059+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در خواجه ربیع", "amounts": {"اجاره": 5000000}}	\N
1274	divar	ga6mrLFe	رهن واجاره	شهید قربانی	\N	rent	\N	https://divar.ir/v/_/ga6mrLFe	2026-09-28 19:01:57.973291+00	2026-09-28 19:16:09.921682+00	\N	\N	\N	mashhad	\N	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید قربانی", "amounts": {"اجاره": 3000000}}	\N
1275	divar	ga6iLuVm	خونه ویلایی ۱۵۰ متری بزرگ رهن کامل	اروند	\N	rent	\N	https://divar.ir/v/_/ga6iLuVm	2026-09-28 18:58:43.905215+00	2026-09-28 19:16:09.925155+00	\N	\N	\N	mashhad	150	\N	\N	\N	{"mid": "رهن کامل", "bottom": "یک ربع پیش در اروند", "amounts": {}}	\N
1276	divar	ga6ibON1	اجاره خانه	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/ga6ibON1	2026-09-28 18:56:01.075963+00	2026-09-28 19:16:09.929235+00	\N	\N	\N	mashhad	\N	\N	\N	17000000	{"mid": "اجاره: ۱۷,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در هفت تیر (حافظ)", "amounts": {"اجاره": 17000000}}	\N
1278	divar	gadWcVmx	رهن کامل ۸۵ متری ۲ خواب	توس (بلوار توس)	\N	rent	\N	https://divar.ir/v/_/gadWcVmx	2026-09-28 18:46:07.037733+00	2026-09-28 19:16:09.935415+00	\N	\N	\N	mashhad	85	2	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "در توس (بلوار توس)", "amounts": {"اجاره": 1000000}}	\N
1279	divar	ga6WrdXs	رهن و اجاره مسکونی همکف  فقط زوج آگهی شخصی	هفت تیر (نه دره)	\N	rent	\N	https://divar.ir/v/_/ga6WrdXs	2026-09-28 18:44:18.797401+00	2026-09-28 19:16:09.939335+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "نیم ساعت پیش در هفت تیر (نه دره)", "amounts": {"اجاره": 10000000}}	\N
1280	divar	ga6OLfg2	خانه رهن واجاره	عبادی	\N	rent	\N	https://divar.ir/v/_/ga6OLfg2	2026-09-28 18:35:50.327836+00	2026-09-28 19:16:09.943406+00	\N	\N	\N	mashhad	\N	\N	\N	7500000	{"mid": "اجاره: ۷,۵۰۰,۰۰۰ تومان", "bottom": "نیم ساعت پیش در عبادی", "amounts": {"اجاره": 7500000}}	\N
1281	divar	ga12LxN4	همخانه	کشف	\N	rent	\N	https://divar.ir/v/_/ga12LxN4	2026-09-28 18:30:53.450508+00	2026-09-28 19:16:09.947217+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "در کشف", "amounts": {"اجاره": 10000}}	\N
1282	divar	ga6Cb_go	اجاره انبار یا منزل	مصلی (کارمندان اول)	\N	rent	\N	https://divar.ir/v/_/ga6Cb_go	2026-09-28 18:25:08.723648+00	2026-09-28 19:16:09.951171+00	\N	\N	\N	mashhad	\N	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "نیم ساعت پیش در مصلی (کارمندان اول)", "amounts": {"اجاره": 30000000}}	\N
1284	divar	ga66Lwdq	یک واحد آپارتمان در بهترین لوکشن خوش نقشه	میعاد (شهرک غرب)	8000000000	sale	38	https://divar.ir/v/_/ga66Lwdq	2026-09-28 19:25:55.349038+00	2026-09-28 19:26:26.181063+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در میعاد (شهرک غرب)", "amounts": {"raw_amount": 8000000000}}	\N
1285	divar	ga66rqH0	فروش منزل مسکونی مشهد	پنجتن	6890000000	sale	\N	https://divar.ir/v/_/ga66rqH0	2026-09-28 19:25:42.624299+00	2026-09-28 19:26:26.187602+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۸۹۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در پنجتن", "amounts": {"raw_amount": 6890000000}}	\N
1286	divar	gaUlr3oa	آپارتمان ۴۰۰ متری صفر  حاشیه اصلی (۲ پارکینگ سندی)	الهیه	46000000000	sale	44	https://divar.ir/v/_/gaUlr3oa	2026-09-28 19:25:25.01371+00	2026-09-28 19:26:26.193231+00	\N	\N	\N	mashhad	400	\N	\N	\N	{"mid": "۴۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 46000000000}}	\N
1287	divar	ga5myEsL	آپارتمان اکازیون فوق العاده تمیز ۲۴۰ متر زیربنا	شهید مطهری	14270000000	sale	28	https://divar.ir/v/_/ga5myEsL	2026-09-28 19:23:58.221909+00	2026-09-28 19:26:26.19931+00	\N	\N	\N	mashhad	240	\N	\N	\N	{"mid": "۱۴,۲۷۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید مطهری", "amounts": {"raw_amount": 14270000000}}	\N
1288	divar	ga6yLFyc	ویلایی دو طبقه	رضاشهر	17300000000	sale	\N	https://divar.ir/v/_/ga6yLFyc	2026-09-28 19:22:27.790632+00	2026-09-28 19:26:26.204631+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۷,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاشهر", "amounts": {"raw_amount": 17300000000}}	\N
1289	divar	gatGgks1	اول جلال۲نبش/کار قوی/ندیدی مثلشوبااین قیمت2پارکینگ	آزادشهر	46000000000	sale	\N	https://divar.ir/v/_/gatGgks1	2026-09-28 19:22:22.670193+00	2026-09-28 19:26:26.210261+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری عالیجناب در آزادشهر", "amounts": {"raw_amount": 46000000000}}	\N
1290	divar	gaVOTNbT	زمین مسکونی سند دار مفتح شرقی	انصار	13000000000	sale	\N	https://divar.ir/v/_/gaVOTNbT	2026-09-28 19:20:20.631936+00	2026-09-28 19:26:26.215215+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در انصار", "amounts": {"raw_amount": 13000000000}}	\N
1291	divar	gaZCM_uq	باغ ویلا باغستان میزان شاهنامه ۸۰ معاوضه	میان ولایت	1250000000	sale	\N	https://divar.ir/v/_/gaZCM_uq	2026-09-28 19:20:16.185106+00	2026-09-28 19:26:26.220754+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 1250000000}}	\N
1292	divar	ga6y7RT9	فروش منزل ۱۲۵ متر	تلگرد	8200000000	sale	\N	https://divar.ir/v/_/ga6y7RT9	2026-09-28 19:19:39.363044+00	2026-09-28 19:26:26.226412+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۸,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در تلگرد", "amounts": {"raw_amount": 8200000000}}	\N
1293	divar	ga6y75i6	ویلایی 72 متری توس 33	کشف	1700000000	sale	\N	https://divar.ir/v/_/ga6y75i6	2026-09-28 19:17:51.598147+00	2026-09-28 19:26:26.231021+00	\N	\N	\N	mashhad	72	\N	\N	\N	{"mid": "۱,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کشف", "amounts": {"raw_amount": 1700000000}}	\N
1294	divar	ga6ybqwN	ویلایی ۱۲۵متری / بلوار اصلانی	شهرک بهارستان	10000000000	sale	\N	https://divar.ir/v/_/ga6ybqwN	2026-09-28 19:16:29.584163+00	2026-09-28 19:26:26.235458+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۱۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک بهارستان", "amounts": {"raw_amount": 10000000000}}	\N
1295	divar	ga6yr0lx	۱۴۰متر ویلایی	فدک	18000000000	sale	\N	https://divar.ir/v/_/ga6yr0lx	2026-09-28 19:16:19.506361+00	2026-09-28 19:26:26.240086+00	\N	\N	\N	mashhad	140	\N	\N	\N	{"mid": "۱۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فدک", "amounts": {"raw_amount": 18000000000}}	\N
1296	divar	ga6urSBv	موقعیت قوی، سازه فنی ، ارزش خرید بالا	راه آهن	13000000000	sale	\N	https://divar.ir/v/_/ga6urSBv	2026-09-28 19:16:13.156751+00	2026-09-28 19:26:26.244243+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در راه آهن", "amounts": {"raw_amount": 13000000000}}	\N
1305	divar	ga667yQO	فول بازسازی بهترین لوکیشن ناصر خسرو	احمدآباد	\N	rent	\N	https://divar.ir/v/_/ga667yQO	2026-09-28 19:24:02.297247+00	2026-09-28 19:26:26.270042+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در احمدآباد", "amounts": {"اجاره": 5000000}}	\N
1306	divar	ga66rccR	هم خونه میخوام	جانباز	\N	rent	\N	https://divar.ir/v/_/ga66rccR	2026-09-28 19:22:32.299034+00	2026-09-28 19:26:26.273723+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جانباز", "amounts": {"اجاره": 1000000}}	\N
1307	divar	ga627zts	اجاره خونه دربست	هنرور	\N	rent	\N	https://divar.ir/v/_/ga627zts	2026-09-28 19:19:50.923321+00	2026-09-28 19:26:26.277286+00	\N	\N	\N	mashhad	\N	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"اجاره": 1000}}	\N
1320	divar	ga3m88g9	آپارتمان ۸۵متر طبقه۳روپیلوت ۲نبش صفربازدید۹صبح تا۶	موسوی قوچانی	4300000000	sale	\N	https://divar.ir/v/_/ga3m88g9	2026-09-26 13:35:35.26804+00	2026-09-28 19:36:59.82907+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۴,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در موسوی قوچانی", "amounts": {"raw_amount": 4300000000}}	\N
1321	divar	gaChTqV1	آپارتمان ۱۴۹ متری تکواحدی صفر رحمانیه مدرن	الهیه	15900000000	sale	44	https://divar.ir/v/_/gaChTqV1	2026-09-28 19:36:46.947583+00	2026-09-28 19:36:59.856377+00	\N	\N	\N	mashhad	149	\N	\N	\N	{"mid": "۱۵,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 15900000000}}	\N
1322	divar	gajCRrLk	زمین دوردیوارملکی بااب بولواربهمن	خرم آباد	1800000000	sale	\N	https://divar.ir/v/_/gajCRrLk	2026-09-28 19:36:18.858005+00	2026-09-28 19:36:59.86437+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در خرم آباد", "amounts": {"raw_amount": 1800000000}}	\N
1323	divar	ga1agTlk	ویلایی ۹۷ متر چمن	شیرودی	12500000000	sale	\N	https://divar.ir/v/_/ga1agTlk	2026-09-28 19:36:17.95096+00	2026-09-28 19:36:59.871371+00	\N	\N	\N	mashhad	97	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شیرودی", "amounts": {"raw_amount": 12500000000}}	\N
1324	divar	ga6G8mWg	آپارتمان ۴ خواب ۱۸۰ متری مجیدیه ( محرابی	جاهد شهر	17500000000	sale	41	https://divar.ir/v/_/ga6G8mWg	2026-09-28 19:36:10.342568+00	2026-09-28 19:36:59.877813+00	\N	\N	\N	mashhad	180	4	\N	\N	{"mid": "۱۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در جاهد شهر", "amounts": {"raw_amount": 17500000000}}	\N
1325	divar	ga6GMOke	فروش اپارتمان ۹۰ متری در موسوی قوچانی	موسوی قوچانی	7300000000	sale	\N	https://divar.ir/v/_/ga6GMOke	2026-09-28 19:35:18.731543+00	2026-09-28 19:36:59.883485+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۷,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در موسوی قوچانی", "amounts": {"raw_amount": 7300000000}}	\N
1326	divar	ga6Csf8Q	زمین امان آباد	کوی المهدی	1900000000	sale	\N	https://divar.ir/v/_/ga6Csf8Q	2026-09-28 19:34:49.802429+00	2026-09-28 19:36:59.887746+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی المهدی", "amounts": {"raw_amount": 1900000000}}	\N
1327	divar	gamauT7_	آپارتمان ۱۱۵ متر شیرودی	چهنو	9500000000	sale	\N	https://divar.ir/v/_/gamauT7_	2026-09-28 19:34:29.122429+00	2026-09-28 19:36:59.891635+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در چهنو", "amounts": {"raw_amount": 9500000000}}	\N
1328	divar	ga66rKtI	زمین ۲۴۰ متری روستای گراب	مقصود آباد	840000000	sale	\N	https://divar.ir/v/_/ga66rKtI	2026-09-28 19:31:46.310796+00	2026-09-28 19:36:59.895864+00	\N	\N	\N	mashhad	240	\N	\N	\N	{"mid": "۸۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مقصود آباد", "amounts": {"raw_amount": 840000000}}	\N
1329	divar	ga6C8FHS	یک واحد آپارتمان طبقه همکف ویک دربند مغازه	رده	3500000000	sale	\N	https://divar.ir/v/_/ga6C8FHS	2026-09-28 19:31:33.102282+00	2026-09-28 19:36:59.899832+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رده", "amounts": {"raw_amount": 3500000000}}	\N
1330	divar	gaGmuaQu	فروش آپارتمان ۱۳۰ متر	هفده شهریور	9500000000	sale	\N	https://divar.ir/v/_/gaGmuaQu	2026-09-28 19:30:25.613655+00	2026-09-28 19:36:59.904021+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفده شهریور", "amounts": {"raw_amount": 9500000000}}	\N
1331	divar	gaRy2eNJ	فروش آپارتمان ۱۰۰ متری سلطانی	کارگران	6800000000	sale	40	https://divar.ir/v/_/gaRy2eNJ	2026-09-28 19:28:59.853031+00	2026-09-28 19:36:59.908752+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۶,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کارگران", "amounts": {"raw_amount": 6800000000}}	\N
1332	divar	ga1yGuRr	ویلایی ۱۲۵ متری فدائیان اسلام	کارگران	11000000000	sale	40	https://divar.ir/v/_/ga1yGuRr	2026-09-28 19:27:43.339737+00	2026-09-28 19:36:59.912419+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کارگران", "amounts": {"raw_amount": 11000000000}}	\N
1338	divar	ga6-r19v	رهن اجاره واحد آپارتمان 175متر وکیل آباد امامت	زیبا شهر	\N	rent	\N	https://divar.ir/v/_/ga6-r19v	2026-09-28 19:28:38.135266+00	2026-09-28 19:36:59.929909+00	\N	\N	\N	mashhad	175	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در زیبا شهر", "amounts": {"اجاره": 25000000}}	\N
1353	divar	gazBpLjM	زمین ابرده علیا(بنیادمسکن)معاوضه با خودرو	نیروی هوایی	1600000000	sale	\N	https://divar.ir/v/_/gazBpLjM	2026-09-28 19:46:08.935523+00	2026-09-28 19:47:33.172686+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در نیروی هوایی", "amounts": {"raw_amount": 1600000000}}	\N
1354	divar	ga6iG6ZY	آپارتمان شیک، خوش‌نقشه و با طراحی کاربردی	شهرک بهارستان	6000000000	sale	\N	https://divar.ir/v/_/ga6iG6ZY	2026-09-28 19:45:19.603056+00	2026-09-28 19:47:33.194228+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک بهارستان", "amounts": {"raw_amount": 6000000000}}	\N
1355	divar	ga6KsAd7	واحد آپارتمان ۷۰ متری	توس (بلوار توس)	2800000000	sale	\N	https://divar.ir/v/_/ga6KsAd7	2026-09-28 19:43:47.421032+00	2026-09-28 19:47:33.203765+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۲,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {"raw_amount": 2800000000}}	\N
1356	divar	ga6KspqF	آپارتمان فروشی	موسوی قوچانی	7000000000	sale	\N	https://divar.ir/v/_/ga6KspqF	2026-09-28 19:42:09.554675+00	2026-09-28 19:47:33.213825+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در موسوی قوچانی", "amounts": {"raw_amount": 7000000000}}	\N
1357	divar	ga6K8z9x	اپارتمان ابتدای بلوار مهران ۶۰متری طبقه۴	دانشجو	8000000000	sale	39	https://divar.ir/v/_/ga6K8z9x	2026-09-28 19:41:19.528917+00	2026-09-28 19:47:33.223532+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در دانشجو", "amounts": {"raw_amount": 8000000000}}	\N
1358	divar	gatuFoWO	اپارتمان ۱۳۰متری شاهنامه	کلاته برفی	8500000000	sale	\N	https://divar.ir/v/_/gatuFoWO	2026-09-28 19:40:34.798494+00	2026-09-28 19:47:33.232034+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کلاته برفی", "amounts": {"raw_amount": 8500000000}}	\N
1359	divar	ga6KseG_	خانه ویلایی دوطبقه بسیار شیک	بهار	4500000000	sale	\N	https://divar.ir/v/_/ga6KseG_	2026-09-28 19:40:31.101543+00	2026-09-28 19:47:33.240536+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهار", "amounts": {"raw_amount": 4500000000}}	\N
1360	divar	gamy9i9f	آپارتمان ۴۵ متر شیرودی	چهنو	3800000000	sale	\N	https://divar.ir/v/_/gamy9i9f	2026-09-28 19:38:55.343164+00	2026-09-28 19:47:33.249473+00	\N	\N	\N	mashhad	45	\N	\N	\N	{"mid": "۳,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در چهنو", "amounts": {"raw_amount": 3800000000}}	\N
1361	divar	ga5pMZ-o	فورش خانه ۷۵متری طبقه اول را جدا	علی آباد	1650000000	sale	\N	https://divar.ir/v/_/ga5pMZ-o	2026-09-28 19:38:37.393852+00	2026-09-28 19:47:33.258463+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۱,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در علی آباد", "amounts": {"raw_amount": 1650000000}}	\N
1362	divar	ga6Cc5OR	خانه آپارتمانی فوری فوری	شهرک بهارستان	3900000000	sale	\N	https://divar.ir/v/_/ga6Cc5OR	2026-09-28 19:37:24.548778+00	2026-09-28 19:47:33.26661+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک بهارستان", "amounts": {"raw_amount": 3900000000}}	\N
1363	divar	gadOKTcz	ویلایی ۱۳۰ متر نسترن	هفده شهریور	13000000000	sale	\N	https://divar.ir/v/_/gadOKTcz	2026-09-28 19:37:21.946173+00	2026-09-28 19:47:33.275183+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "۱۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفده شهریور", "amounts": {"raw_amount": 13000000000}}	\N
1365	divar	ga6GcvSS	۱۶۸ متر الهیه ۳	الهیه	20000000000	sale	44	https://divar.ir/v/_/ga6GcvSS	2026-09-28 19:37:19.847256+00	2026-09-28 19:47:33.291196+00	\N	\N	\N	mashhad	168	\N	\N	\N	{"mid": "۲۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 20000000000}}	\N
1366	divar	ga6GcR8X	اپارتمان فروشی در طبرسی جنوبی(بلوار اول طبرسی)مشهد	رسالت	3845000000	sale	32	https://divar.ir/v/_/ga6GcR8X	2026-09-28 19:37:07.643822+00	2026-09-28 19:47:33.299707+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۸۴۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رسالت", "amounts": {"raw_amount": 3845000000}}	\N
1367	divar	ga6GMoR5	زمین منزل اباد	منزل آباد	7700000000	sale	\N	https://divar.ir/v/_/ga6GMoR5	2026-09-28 19:37:03.204461+00	2026-09-28 19:47:33.309029+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در منزل آباد", "amounts": {"raw_amount": 7700000000}}	\N
1373	divar	ga4ud9Bf	فرصت سکونت درخشنودی/حرم/مبله/مسکن الماس	حسین‌آباد	\N	rent	\N	https://divar.ir/v/_/ga4ud9Bf	2026-09-27 09:04:00.156242+00	2026-09-28 19:47:33.348579+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "مسکن الماس(پاشا)بین ایثار۱۷و۱۹ در حسین‌آباد", "amounts": {"اجاره": 1000000}}	\N
1374	divar	ga6Osvd5	رهن واجاره منزل	شهید قربانی	\N	rent	\N	https://divar.ir/v/_/ga6Osvd5	2026-09-28 19:45:17.076104+00	2026-09-28 19:47:33.357013+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید قربانی", "amounts": {"اجاره": 8000000}}	\N
1390	divar	gauujHk3	لوکس ترین۲۰۲متری/متریال برند*الهیه/صفر سند آماده	الهیه	19600000000	sale	44	https://divar.ir/v/_/gauujHk3	2026-09-19 07:36:12.333713+00	2026-09-28 19:58:01.601322+00	\N	\N	\N	mashhad	202	\N	\N	\N	{"mid": "۱۹,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری بزرگ رویال در الهیه", "amounts": {"raw_amount": 19600000000}}	\N
1392	divar	gap-0WIM	باغ ملکی سند دار	توس فردوسی	610000000	sale	\N	https://divar.ir/v/_/gap-0WIM	2026-09-28 19:57:02.627201+00	2026-09-28 19:58:01.631223+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس فردوسی", "amounts": {"raw_amount": 610000000}}	\N
1393	divar	ga6acACa	باغ ویلا لاکچری معاوضه	کوی سیدی	25000000000	sale	\N	https://divar.ir/v/_/ga6acACa	2026-09-28 19:55:55.010371+00	2026-09-28 19:58:01.640345+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی سیدی", "amounts": {"raw_amount": 25000000000}}	\N
1394	divar	ga6W84fs	فروش اپارتمان	امیر	4500000000	sale	\N	https://divar.ir/v/_/ga6W84fs	2026-09-28 19:54:42.642901+00	2026-09-28 19:58:01.652126+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیر", "amounts": {"raw_amount": 4500000000}}	\N
1395	divar	ga6WcNP2	آپارتمان فروشی ۹۵ متری امامت زوج	آزادشهر	15950000000	sale	\N	https://divar.ir/v/_/ga6WcNP2	2026-09-28 19:52:38.902019+00	2026-09-28 19:58:01.660734+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۱۵,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آزادشهر", "amounts": {"raw_amount": 15950000000}}	\N
1398	divar	ga6WsFgS	رهن کامل	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga6WsFgS	2026-09-28 19:52:14.321013+00	2026-09-28 19:58:01.682315+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {}}	\N
1399	divar	ga6Sc1Lx	آپارتمان 160متر فول امکانات ساجدی5	بهاران	\N	rent	17	https://divar.ir/v/_/ga6Sc1Lx	2026-09-28 19:49:47.301679+00	2026-09-28 19:58:01.690161+00	\N	\N	\N	mashhad	160	\N	\N	50000000	{"mid": "اجاره: ۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهاران", "amounts": {"اجاره": 50000000}}	\N
1413	divar	ga6icJ3U	خانه لوکس	حسین‌آباد	8000000000	sale	\N	https://divar.ir/v/_/ga6icJ3U	2026-09-28 20:08:14.621597+00	2026-09-28 20:08:30.089681+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در حسین‌آباد", "amounts": {"raw_amount": 8000000000}}	\N
1414	divar	ga6icdPO	زمین چراغچی ۴۳ سند دار	سپاد	1350000000	sale	\N	https://divar.ir/v/_/ga6icdPO	2026-09-28 20:06:46.535915+00	2026-09-28 20:08:30.100451+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۳۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سپاد", "amounts": {"raw_amount": 1350000000}}	\N
1415	divar	QayXGTcx	زمین صفی آباد جلدک چاهشک تقی آباد	الهیه	1800000000	sale	44	https://divar.ir/v/_/QayXGTcx	2026-09-28 20:06:40.745329+00	2026-09-28 20:08:30.108985+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "خرید و فروش صفی آباد چاهشک جلدک الهیه در الهیه", "amounts": {"raw_amount": 1800000000}}	\N
1416	divar	galCWV_n	صفی آباد چاهشک ۲۲۷ اصلی	ارشاد	900000000	sale	15	https://divar.ir/v/_/galCWV_n	2026-09-28 20:06:21.196766+00	2026-09-28 20:08:30.116778+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "خرید و فروش صفی آباد چاهشک جلدک الهیه در ارشاد", "amounts": {"raw_amount": 900000000}}	\N
1417	divar	ga6eMVem	آپارتمان ۱۰۲ متر سند دار ابوطالب	موسوی قوچانی	8800000000	sale	\N	https://divar.ir/v/_/ga6eMVem	2026-09-28 20:05:57.646839+00	2026-09-28 20:08:30.125731+00	\N	\N	\N	mashhad	102	\N	\N	\N	{"mid": "۸,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در موسوی قوچانی", "amounts": {"raw_amount": 8800000000}}	\N
1418	divar	ga6e8tUY	خونه ویلایی	میان ولایت	4500000000	sale	\N	https://divar.ir/v/_/ga6e8tUY	2026-09-28 20:05:45.681289+00	2026-09-28 20:08:30.13461+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 4500000000}}	\N
1419	divar	gal-y_nN	باغ سند دار مفت	توس فردوسی	590000000	sale	\N	https://divar.ir/v/_/gal-y_nN	2026-09-28 20:05:23.747064+00	2026-09-28 20:08:30.142619+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵۹۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس فردوسی", "amounts": {"raw_amount": 590000000}}	\N
1420	divar	gaee8WC8	زمین فاز ۲ الهیه شرایط معامله سند دار	ارشاد	1050000000	sale	15	https://divar.ir/v/_/gaee8WC8	2026-09-28 20:05:17.795662+00	2026-09-28 20:08:30.152316+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۰۵۰,۰۰۰,۰۰۰ تومان", "bottom": "سیادتی منتخب فاز ۲ الهیه زمین سرمایه گذاری در ارشاد", "amounts": {"raw_amount": 1050000000}}	\N
1421	divar	gaemccaU	زمین اراضی فاز ۲ الهیه تاییده ثنا مالکیت	ارشاد	700000000	sale	15	https://divar.ir/v/_/gaemccaU	2026-09-28 20:04:59.081836+00	2026-09-28 20:08:30.162323+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "سیادتی منتخب فاز ۲ الهیه زمین سرمایه گذاری در ارشاد", "amounts": {"raw_amount": 700000000}}	\N
1422	divar	ga6a81Av	۱۲۰ متر/صفر/برای شروع شیک زندگی کن نه لزوما بزرگ	سجاد شهر	38000000000	sale	21	https://divar.ir/v/_/ga6a81Av	2026-09-28 20:04:00.79399+00	2026-09-28 20:08:30.170831+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۳۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "شجاعی در سجاد شهر", "amounts": {"raw_amount": 38000000000}}	\N
1423	divar	gaSWX2fG	آپارتمان ۹۵متری فول امکانات	رضاشهر	14900000000	sale	\N	https://divar.ir/v/_/gaSWX2fG	2026-09-28 20:03:37.485442+00	2026-09-28 20:08:30.17921+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۱۴,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رضاشهر", "amounts": {"raw_amount": 14900000000}}	\N
1424	divar	ga6e8gqH	145متر دهخدا 3 خواب  کل ساختمان سنگ اسلب	رضاشهر	27000000000	sale	\N	https://divar.ir/v/_/ga6e8gqH	2026-09-28 20:02:55.011074+00	2026-09-28 20:08:30.18865+00	\N	\N	\N	mashhad	145	3	\N	\N	{"mid": "۲۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاشهر", "amounts": {"raw_amount": 27000000000}}	\N
1425	divar	ga6i7zHV	۷۵ متری مجتمع بهاران پول لازم فوری طبقه ۲	نیروی هوایی	7500000000	sale	\N	https://divar.ir/v/_/ga6i7zHV	2026-09-28 20:02:34.408545+00	2026-09-28 20:08:30.198585+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نیروی هوایی", "amounts": {"raw_amount": 7500000000}}	\N
1426	divar	ga6acfMu	ملک ۱۲۱متر زمین	شیرودی	15000000000	sale	\N	https://divar.ir/v/_/ga6acfMu	2026-09-28 19:59:46.77334+00	2026-09-28 20:08:30.207411+00	\N	\N	\N	mashhad	121	\N	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شیرودی", "amounts": {"raw_amount": 15000000000}}	\N
1431	divar	ga6iMoa4	اجاره و رهن	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga6iMoa4	2026-09-28 20:05:58.224303+00	2026-09-28 20:08:30.24329+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"اجاره": 100000}}	\N
1432	divar	ga6eczTJ	خونه ۶۴ متری سرافرازان همکف	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga6eczTJ	2026-09-28 20:02:30.231573+00	2026-09-28 20:08:30.253368+00	\N	\N	\N	mashhad	64	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهارچشمه", "amounts": {"اجاره": 15000000}}	\N
1433	divar	ga6acyT6	واحد ۸۵متری	ولیعصر (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6acyT6	2026-09-28 19:58:35.878738+00	2026-09-28 20:08:30.262831+00	\N	\N	\N	mashhad	85	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ولیعصر (شهرک غرب)", "amounts": {"اجاره": 20000000}}	\N
1446	divar	ga4-U8f4	زمین فروشی	اسماعیل آباد (سپاد)	3450000000	sale	\N	https://divar.ir/v/_/ga4-U8f4	2026-09-26 23:12:16.855932+00	2026-09-28 20:19:13.849126+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۴۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در اسماعیل آباد (سپاد)", "amounts": {"raw_amount": 3450000000}}	\N
1447	divar	ga6Oij7Y	زمین ،شمال منطقه خوش آب و هوا	کوثر	2770000000	sale	13	https://divar.ir/v/_/ga6Oij7Y	2026-09-28 20:18:15.769733+00	2026-09-28 20:19:13.85936+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۷۷۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوثر", "amounts": {"raw_amount": 2770000000}}	\N
1448	divar	ga6qMhoj	فروش منزل ویلایی نقلی تقریبا ۵۰متری	همت آباد	1270000000	sale	\N	https://divar.ir/v/_/ga6qMhoj	2026-09-28 20:15:16.03109+00	2026-09-28 20:19:13.867475+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۱,۲۷۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در همت آباد", "amounts": {"raw_amount": 1270000000}}	\N
1449	divar	gatWV-dq	فوری 2میلیارد زیر قیمت  برق 3فاز تهاتر با ماشین	میان ولایت	8000000000	sale	\N	https://divar.ir/v/_/gatWV-dq	2026-09-28 20:13:01.007128+00	2026-09-28 20:19:13.873025+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 8000000000}}	\N
1450	divar	gapmX4vN	آپارتمان 84 متر نزدیک حرم	سراب	11200000000	sale	\N	https://divar.ir/v/_/gapmX4vN	2026-09-28 20:12:59.491073+00	2026-09-28 20:19:13.879629+00	\N	\N	\N	mashhad	84	\N	\N	\N	{"mid": "۱۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در سراب", "amounts": {"raw_amount": 11200000000}}	\N
1451	divar	ga6is2bU	خانه فروشی در ده غیبی امام رضا ۹	رباط طرق	2450000000	sale	\N	https://divar.ir/v/_/ga6is2bU	2026-09-28 20:09:26.540827+00	2026-09-28 20:19:13.885616+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۴۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رباط طرق", "amounts": {"raw_amount": 2450000000}}	\N
1464	divar	gayKnW3a	اپارتمان۱۷۵متری تک واحد ،سندآماده، برند مسکن دربار	الهیه	20000000000	sale	44	https://divar.ir/v/_/gayKnW3a	2026-09-28 20:29:11.926884+00	2026-09-28 20:30:06.834639+00	\N	\N	\N	mashhad	175	\N	\N	\N	{"mid": "۲۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن دربار در الهیه", "amounts": {"raw_amount": 20000000000}}	\N
1465	divar	ga628kuL	آپارتمان لوکس وکیل آباد مشهد	فرهنگ	46000000000	sale	\N	https://divar.ir/v/_/ga628kuL	2026-09-28 20:27:55.567902+00	2026-09-28 20:30:06.844941+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگ", "amounts": {"raw_amount": 46000000000}}	\N
1466	divar	ga6yM1U8	اپارتمان۱۱۰مترسندآماده،غرق نور،خوش نشین،مسکن دربار	الهیه	11850000000	sale	44	https://divar.ir/v/_/ga6yM1U8	2026-09-28 20:26:57.334916+00	2026-09-28 20:30:06.853676+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۱۱,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن دربار در الهیه", "amounts": {"raw_amount": 11850000000}}	\N
1467	divar	ga6y8jqO	۱۷۸متر/تک‌واحدی اروپایی*الهیه*مطبخ دار/سوپر لوکس	جاهد شهر	20800000000	sale	41	https://divar.ir/v/_/ga6y8jqO	2026-09-28 20:24:13.242561+00	2026-09-28 20:30:06.861759+00	\N	\N	\N	mashhad	178	\N	\N	\N	{"mid": "۲۰,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری بزرگ رویال در جاهد شهر", "amounts": {"raw_amount": 20800000000}}	\N
1468	divar	ga6qM_YB	منزل آپارتمانی 65متری شیک نو ساز	طبرسی شمالی	2950000000	sale	42	https://divar.ir/v/_/ga6qM_YB	2026-09-28 20:19:19.967386+00	2026-09-28 20:30:06.869032+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۲,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {"raw_amount": 2950000000}}	\N
1480	divar	ga4iQs_N	۱۱۰متری/فول بازسازی/ویلا	هفت تیر (آب و برق)	14600000000	sale	\N	https://divar.ir/v/_/ga4iQs_N	2026-09-27 17:00:03.482735+00	2026-09-28 20:41:17.316997+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۱۴,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن ماد در هفت تیر (آب و برق)", "amounts": {"raw_amount": 14600000000}}	\N
1481	divar	gaStoAEu	آپارتمان خوش نقشه سند شش دانگ پیروزی اقبال	شهرآرا	9000000000	sale	3	https://divar.ir/v/_/gaStoAEu	2026-09-28 20:37:11.462961+00	2026-09-28 20:41:17.322585+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرآرا", "amounts": {"raw_amount": 9000000000}}	\N
1482	divar	ga6-cmUq	مجتمع جامعه ۲خوابه	فدک	6450000000	sale	\N	https://divar.ir/v/_/ga6-cmUq	2026-09-28 20:36:12.463314+00	2026-09-28 20:41:17.325336+00	\N	\N	\N	mashhad	\N	2	\N	\N	{"mid": "۶,۴۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فدک", "amounts": {"raw_amount": 6450000000}}	\N
1483	divar	ga66s7uH	آپارتمان در هنرور۵	هنرور	12980000000	sale	\N	https://divar.ir/v/_/ga66s7uH	2026-09-28 20:34:17.937644+00	2026-09-28 20:41:17.328501+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۹۸۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"raw_amount": 12980000000}}	\N
1484	divar	ga66s8xd	۱۶۰ متر / نوساز / سر نبش / بلوار مهدی	زمانه	26500000000	sale	\N	https://divar.ir/v/_/ga66s8xd	2026-09-28 20:33:00.819287+00	2026-09-28 20:41:17.332889+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۲۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن مداح نبش استقلال ۸ انتخاب اول شما در زمانه", "amounts": {"raw_amount": 26500000000}}	\N
1495	divar	ga6iXKMA	115متر،دوخواب،بسیارشیک ولاکچری صفر	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga6iXKMA	2026-09-28 14:22:52.194789+00	2026-09-28 20:41:17.351425+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "رهن کامل", "bottom": "شهرمشهد نبش رحمانیه۵ در جاهد شهر", "amounts": {}}	\N
1496	divar	ga6-cw1t	خانه نوساز تمیز شیک	امیر	\N	rent	\N	https://divar.ir/v/_/ga6-cw1t	2026-09-28 20:36:32.89909+00	2026-09-28 20:41:17.354339+00	\N	\N	\N	mashhad	\N	\N	\N	9000000	{"mid": "اجاره: ۹,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیر", "amounts": {"اجاره": 9000000}}	\N
1497	divar	ga4m-FXQ	اجاره آپارتمان عبادی 29	آیت الله کاشانی	\N	rent	\N	https://divar.ir/v/_/ga4m-FXQ	2026-09-28 20:36:21.350561+00	2026-09-28 20:41:17.356314+00	\N	\N	\N	mashhad	\N	\N	\N	22000000	{"mid": "اجاره: ۲۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آیت الله کاشانی", "amounts": {"اجاره": 22000000}}	\N
1498	divar	ga66saa4	۸۵ متری دو خواب نوساز طبرسی شمالی	طبرسی شمالی	\N	rent	42	https://divar.ir/v/_/ga66saa4	2026-09-28 20:30:41.048571+00	2026-09-28 20:41:17.35822+00	\N	\N	\N	mashhad	85	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {"اجاره": 10000000}}	\N
1499	divar	ga628TDL	رهن و اجاره خانه	بهمن	\N	rent	43	https://divar.ir/v/_/ga628TDL	2026-09-28 20:27:18.635725+00	2026-09-28 20:41:17.360057+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهمن", "amounts": {"اجاره": 5000000}}	\N
1513	divar	gaVaPa35	بالاترین قیمت خریدپلاک۱۷۹،۲۲۷ اصلی(صفی اباد،چاهشک)	جاهد شهر	2700000000	sale	41	https://divar.ir/v/_/gaVaPa35	2026-09-28 20:50:28.300938+00	2026-09-28 20:51:34.732804+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دفتر مرکزی فاز ۲ الهیه محمدی در جاهد شهر", "amounts": {"raw_amount": 2700000000}}	\N
1515	divar	gacKU-Vc	فروش 900مترباغ ویلا آماده با امتیازات کامل زیرقیمت	چهاربرج	5000000000	sale	\N	https://divar.ir/v/_/gacKU-Vc	2026-09-28 20:47:48.626772+00	2026-09-28 20:51:34.739839+00	\N	\N	\N	mashhad	900	\N	\N	\N	{"mid": "۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در چهاربرج", "amounts": {"raw_amount": 5000000000}}	\N
1516	divar	ga6G97CN	باغ۵۵۰ متری پول لازم	توس فردوسی	1550000000	sale	\N	https://divar.ir/v/_/ga6G97CN	2026-09-28 20:46:37.962085+00	2026-09-28 20:51:34.743302+00	\N	\N	\N	mashhad	550	\N	\N	\N	{"mid": "۱,۵۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس فردوسی", "amounts": {"raw_amount": 1550000000}}	\N
1517	divar	ga6K9EG-	اپارتمان سه خواب حاشیه تلاش جانباز	جانباز	14500000000	sale	\N	https://divar.ir/v/_/ga6K9EG-	2026-09-28 20:46:20.908463+00	2026-09-28 20:51:34.745872+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جانباز", "amounts": {"raw_amount": 14500000000}}	\N
1518	divar	ganaPtF8	فروش خونه دوطبقه یکجا	شهید جنگی	3000000000	sale	\N	https://divar.ir/v/_/ganaPtF8	2026-09-28 20:44:13.513787+00	2026-09-28 20:51:34.747756+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید جنگی", "amounts": {"raw_amount": 3000000000}}	\N
1525	divar	ga6-8sbR	اجاره واحد مسکونی ۱۵۰ متری ۵۱۲ دستگاه بلوار ارشاد	ارشاد	\N	rent	15	https://divar.ir/v/_/ga6-8sbR	2026-09-28 20:50:27.225454+00	2026-09-28 20:51:34.758087+00	\N	\N	\N	mashhad	150	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ارشاد", "amounts": {"اجاره": 40000000}}	\N
1543	divar	ga6WtCP5	آپارتمان تک واحدی طبقه۴ با آسانسور پارکینگ اختصاصی	ایثارگران	6500000000	sale	\N	https://divar.ir/v/_/ga6WtCP5	2026-09-28 21:01:01.36424+00	2026-09-28 21:01:57.013567+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در ایثارگران", "amounts": {"raw_amount": 6500000000}}	\N
1544	divar	ga664vxO	آپارتمان۱۳۰متری/رحمانیه/مدرن و لوکس/برند مطرح	الهیه	23400000000	sale	44	https://divar.ir/v/_/ga664vxO	2026-09-28 20:55:22.871995+00	2026-09-28 21:01:57.017174+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "۲۳,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 23400000000}}	\N
1545	divar	ga6Cp_o5	اپارتمان۱۶۸متری/رحمانیه/تک واحدی/مدرن	الهیه	25900000000	sale	44	https://divar.ir/v/_/ga6Cp_o5	2026-09-28 20:55:02.270752+00	2026-09-28 21:01:57.020223+00	\N	\N	\N	mashhad	168	\N	\N	\N	{"mid": "۲۵,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 25900000000}}	\N
1546	divar	gaFmWfTe	آپارتمان ۵۰متری راه جدا	شهید بصیر	1150000000	sale	\N	https://divar.ir/v/_/gaFmWfTe	2026-09-28 20:53:52.754932+00	2026-09-28 21:01:57.022627+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۱,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید بصیر", "amounts": {"raw_amount": 1150000000}}	\N
1547	divar	gatOFLb8	خانه ویلایی	چهاربرج	1600000000	sale	\N	https://divar.ir/v/_/gatOFLb8	2026-09-28 20:53:03.652822+00	2026-09-28 21:01:57.02478+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در چهاربرج", "amounts": {"raw_amount": 1600000000}}	\N
1548	divar	gaoKg54p	باغ ویلا با متراژ هزار و ۵۰ متر	توس فردوسی	2550000000	sale	\N	https://divar.ir/v/_/gaoKg54p	2026-09-28 20:52:42.946203+00	2026-09-28 21:01:57.026667+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۲,۵۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس فردوسی", "amounts": {"raw_amount": 2550000000}}	\N
1549	divar	ga6GNRgg	اپارتمان ۵۵متری شیک  درامام هادی	شهرک امام هادی (شهرک غرب)	2100000000	sale	38	https://divar.ir/v/_/ga6GNRgg	2026-09-28 20:52:18.662493+00	2026-09-28 21:01:57.02868+00	\N	\N	\N	mashhad	55	\N	\N	\N	{"mid": "۲,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک امام هادی (شهرک غرب)", "amounts": {"raw_amount": 2100000000}}	\N
1557	divar	gaZm-1_f	رهن و اجاره مبله ویلایی  ۷۰ متر بازسازی شده فول	فاطمیه	\N	rent	30	https://divar.ir/v/_/gaZm-1_f	2026-09-22 09:20:58.203592+00	2026-09-28 21:01:57.039926+00	\N	\N	\N	mashhad	70	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "در فاطمیه", "amounts": {"اجاره": 2000000}}	\N
1558	divar	ga6S9uZ_	اجاره یک آپارتمان ۱۷۵ متری	کوه سنگی	\N	rent	\N	https://divar.ir/v/_/ga6S9uZ_	2026-09-28 20:58:42.41707+00	2026-09-28 21:01:57.042083+00	\N	\N	\N	mashhad	175	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوه سنگی", "amounts": {"اجاره": 1000000}}	\N
1575	divar	ga6-cZER	۱۱۵متر.خواجه ربیع.مهرمادر	خواجه ربیع	4200000000	sale	\N	https://divar.ir/v/_/ga6-cZER	2026-09-28 21:07:28.01823+00	2026-09-28 21:12:14.858306+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۴,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در خواجه ربیع", "amounts": {"raw_amount": 4200000000}}	\N
1576	divar	ga6ada2A	تک واحدی / پیروزی 16/سند شش دانگ	سرافرازان	16500000000	sale	22	https://divar.ir/v/_/ga6ada2A	2026-09-28 21:07:02.746579+00	2026-09-28 21:12:14.864303+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سرافرازان", "amounts": {"raw_amount": 16500000000}}	\N
1577	divar	gaDVusAE	آپارتمان ۱۵۵ متری الهیه	الهیه	18800000000	sale	44	https://divar.ir/v/_/gaDVusAE	2026-09-28 21:06:26.487281+00	2026-09-28 21:12:14.867903+00	\N	\N	\N	mashhad	155	\N	\N	\N	{"mid": "۱۸,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 18800000000}}	\N
1578	divar	ga6aNZpi	منزل مسکونی	رضاییه	4600000000	sale	\N	https://divar.ir/v/_/ga6aNZpi	2026-09-28 21:05:30.499335+00	2026-09-28 21:12:14.870539+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاییه", "amounts": {"raw_amount": 4600000000}}	\N
1579	divar	ga6Wtgnb	۱۰۳ متر الهیه سندآماده/ کم واحد /دونبش غرق نور	الهیه	12550000000	sale	44	https://divar.ir/v/_/ga6Wtgnb	2026-09-28 21:02:00.868767+00	2026-09-28 21:12:14.872873+00	\N	\N	\N	mashhad	103	\N	\N	\N	{"mid": "۱۲,۵۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 12550000000}}	\N
1592	divar	ga6atzjd	آپارتمان ۹۰ متری در عنصری	عنصری	\N	rent	\N	https://divar.ir/v/_/ga6atzjd	2026-09-28 21:06:29.483323+00	2026-09-28 21:12:14.894923+00	\N	\N	\N	mashhad	90	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در عنصری", "amounts": {"اجاره": 20000000}}	\N
1610	divar	gahyWJlq	۸۵ متر « شمالی رو به افتاب » رفیعی	حسابی جنوبی (شهرک غرب)	7500000000	sale	38	https://divar.ir/v/_/gahyWJlq	2026-09-27 08:38:37.289102+00	2026-09-28 21:22:54.771061+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن شاهان نبش فلاحی۱۳٫۶ در حسابی جنوبی (شهرک غرب)", "amounts": {"raw_amount": 7500000000}}	\N
1611	divar	ga6qNkTK	توس۳۳دونبش۱۰۰متر دربست حیاط ماشین رو راه جدا	کشف	2800000000	sale	\N	https://divar.ir/v/_/ga6qNkTK	2026-09-28 21:22:36.981933+00	2026-09-28 21:22:54.775675+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۲,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کشف", "amounts": {"raw_amount": 2800000000}}	\N
1612	divar	ga6it4h2	پخش عمومی  فروش باغ و ویلا	مشکینی (شهرک غرب)	2350000000	sale	38	https://divar.ir/v/_/ga6it4h2	2026-09-28 21:18:20.056841+00	2026-09-28 21:22:54.778494+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۳۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مشکینی (شهرک غرب)", "amounts": {"raw_amount": 2350000000}}	\N
1613	divar	ga6mtJwV	فروش آپارتمان 65متری در رباط طرق	رباط طرق	2900000000	sale	\N	https://divar.ir/v/_/ga6mtJwV	2026-09-28 21:17:56.206068+00	2026-09-28 21:22:54.781085+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۲,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رباط طرق", "amounts": {"raw_amount": 2900000000}}	\N
1614	divar	gaAKL1dC	باغ600مترباموتوربرق درخت استخر آتکشده توالت انباری	توس فردوسی	690000000	sale	\N	https://divar.ir/v/_/gaAKL1dC	2026-09-28 21:16:33.190624+00	2026-09-28 21:22:54.783094+00	\N	\N	\N	mashhad	600	\N	\N	\N	{"mid": "۶۹۰,۰۰۰,۰۰۰ تومان", "bottom": "مجموعه باغی ویلایی خراسانی در توس فردوسی", "amounts": {"raw_amount": 690000000}}	\N
1626	divar	ga6qNfAM	خونه نجف 24 به رهن و اجاره داده می‌شود	نوده	\N	rent	\N	https://divar.ir/v/_/ga6qNfAM	2026-09-28 21:22:10.833192+00	2026-09-28 21:22:54.803591+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در نوده", "amounts": {"اجاره": 5000000}}	\N
1627	divar	ga6itV30	نیازمند همخونه	هنرستان	\N	rent	11	https://divar.ir/v/_/ga6itV30	2026-09-28 21:12:59.905882+00	2026-09-28 21:22:54.805932+00	\N	\N	\N	mashhad	\N	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرستان", "amounts": {"اجاره": 12000000}}	\N
1643	divar	ga6udiUR	آپارتمان ویلایی نزدیک سد تبارک	هفت تیر (حافظ)	27000000000	sale	5	https://divar.ir/v/_/ga6udiUR	2026-09-28 21:31:16.674721+00	2026-09-28 21:33:31.034449+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (حافظ)", "amounts": {"raw_amount": 27000000000}}	\N
1644	divar	ga6u98wQ	آپارتمان صفرکلیدنخورده ده غیبی امام رضا۱۵	رباط طرق	2200000000	sale	\N	https://divar.ir/v/_/ga6u98wQ	2026-09-28 21:30:54.146733+00	2026-09-28 21:33:31.040655+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رباط طرق", "amounts": {"raw_amount": 2200000000}}	\N
1645	divar	ga6u9exV	۱۶۰ متری / بلوار فرامرز / کلید نخورده/آماده تحویل	بهاران	21000000000	sale	17	https://divar.ir/v/_/ga6u9exV	2026-09-28 21:26:28.760268+00	2026-09-28 21:33:31.043296+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۲۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن مداح نبش استقلال ۸ انتخاب اول شما در بهاران", "amounts": {"raw_amount": 21000000000}}	\N
1646	divar	ga6qN_Jx	دیلایی ۱۲۰ متری در دوطبقه و نیم ۲۲۰ متر زیر بنا	رسالت	25000000000	sale	32	https://divar.ir/v/_/ga6qN_Jx	2026-09-28 21:25:27.453855+00	2026-09-28 21:33:31.04607+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۲۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رسالت", "amounts": {"raw_amount": 25000000000}}	\N
1658	divar	ga6ytuMt	همخونه خانوم	حجاب (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga6ytuMt	2026-09-28 21:31:44.653949+00	2026-09-28 21:33:31.065304+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حجاب (شهرک غرب)", "amounts": {"اجاره": 5000000}}	\N
1676	divar	gayuNNpk	135متر،سه خواب،سنددار،تصاویر واقعی	جاهد شهر	12650000000	sale	41	https://divar.ir/v/_/gayuNNpk	2026-09-29 13:57:39.592717+00	2026-09-30 08:26:18.289534+00	\N	\N	\N	mashhad	135	\N	\N	\N	{"mid": "۱۲,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 12650000000}}	\N
1677	divar	ga8eckXs	آپارتمان ۱۶۰ متر/۳خواب/۸۰ متر حیاط اختصاصی	شهید مطهری	10200000000	sale	28	https://divar.ir/v/_/ga8eckXs	2026-09-30 08:26:02.418106+00	2026-09-30 08:26:18.301313+00	\N	\N	\N	mashhad	160	3	\N	\N	{"mid": "۱۰,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید مطهری", "amounts": {"raw_amount": 10200000000}}	\N
1678	divar	ga8e8MKZ	آپارتمان ۷۸ متری الهیه	جاهد شهر	7100000000	sale	41	https://divar.ir/v/_/ga8e8MKZ	2026-09-30 08:26:01.48564+00	2026-09-30 08:26:18.310091+00	\N	\N	\N	mashhad	78	\N	\N	\N	{"mid": "۷,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در جاهد شهر", "amounts": {"raw_amount": 7100000000}}	\N
1679	divar	ga8e8VWM	ویلایی 60متری شهرک شهید رجایی موعود	موعود	2850000000	sale	\N	https://divar.ir/v/_/ga8e8VWM	2026-09-30 08:25:46.570901+00	2026-09-30 08:26:18.320059+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۲,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در موعود", "amounts": {"raw_amount": 2850000000}}	\N
1680	divar	ga8esaN4	۸۹متر/حاشیه رحمانیه/روبه پارک رحمانیه	الهیه	9160000000	sale	44	https://divar.ir/v/_/ga8esaN4	2026-09-30 08:25:36.623331+00	2026-09-30 08:26:18.327814+00	\N	\N	\N	mashhad	89	\N	\N	\N	{"mid": "۹,۱۶۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری بزرگ رویال در الهیه", "amounts": {"raw_amount": 9160000000}}	\N
1681	divar	ga0a-jjT	۸۰ متر / ابتدای کوثر شمالی / تاپ لوکیشن	کوثر	13000000000	sale	13	https://divar.ir/v/_/ga0a-jjT	2026-09-30 08:25:34.475223+00	2026-09-30 08:26:18.336188+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۱۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن والی در کوثر", "amounts": {"raw_amount": 13000000000}}	\N
1682	divar	gaw2hJkQ	رضاشهر حاشیه کلانتری ۵۰۰ متری دونبش	رضاشهر	200000000000	sale	\N	https://divar.ir/v/_/gaw2hJkQ	2026-09-30 08:25:23.002794+00	2026-09-30 08:26:18.344025+00	\N	\N	\N	mashhad	500	\N	\N	\N	{"mid": "۲۰۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رضاشهر", "amounts": {"raw_amount": 200000000000}}	\N
1683	divar	ga8eMYKS	240 متر مجلل ترین واحد منطقه ۱۲	الهیه	23700000000	sale	44	https://divar.ir/v/_/ga8eMYKS	2026-09-30 08:25:18.772263+00	2026-09-30 08:26:18.351274+00	\N	\N	\N	mashhad	240	\N	\N	\N	{"mid": "۲۳,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 23700000000}}	\N
1684	divar	ga36m5mW	۳ واحد در یک مجموعه / صفر کلید نخورده / فوق لوکس	هفت تیر (حافظ)	17000000000	sale	5	https://divar.ir/v/_/ga36m5mW	2026-09-30 08:25:10.227616+00	2026-09-30 08:26:18.357067+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن والی در هفت تیر (حافظ)", "amounts": {"raw_amount": 17000000000}}	\N
1685	divar	ga8ecMUg	۱۰۶ متر امامیه و استاد یوسفی/ سند آماده فول	استاد یوسفی (شهرک غرب)	10600000000	sale	38	https://divar.ir/v/_/ga8ecMUg	2026-09-30 08:24:29.974789+00	2026-09-30 08:26:18.364153+00	\N	\N	\N	mashhad	106	\N	\N	\N	{"mid": "۱۰,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در استاد یوسفی (شهرک غرب)", "amounts": {"raw_amount": 10600000000}}	\N
1686	divar	gaCePeZn	۱۲۰ متری دوخوابه شریعتی بازسازی شده / فـلاحـی	شاهد (شهرک غرب)	11550000000	sale	38	https://divar.ir/v/_/gaCePeZn	2026-09-30 08:24:26.970109+00	2026-09-30 08:26:18.370598+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۱۱,۵۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مهندس ضیائی  در شاهد (شهرک غرب)", "amounts": {"raw_amount": 11550000000}}	\N
1688	divar	ga8ih6Ll	هم خونه میشم ۲۱سالمه	حرم مطهر رضوی	\N	rent	\N	https://divar.ir/v/_/ga8ih6Ll	2026-09-30 08:26:14.209792+00	2026-09-30 08:26:18.381152+00	\N	\N	\N	mashhad	\N	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "در حرم مطهر رضوی", "amounts": {"اجاره": 1000}}	\N
1689	divar	ga8asCpw	طبقه همکف رهن اجاره	کوی المهدی	\N	rent	\N	https://divar.ir/v/_/ga8asCpw	2026-09-30 08:26:07.243146+00	2026-09-30 08:26:18.38681+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در کوی المهدی", "amounts": {"اجاره": 5000000}}	\N
1691	divar	ga8eMbKD	90 متری /2خواب نورگیر	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga8eMbKD	2026-09-30 08:25:28.181229+00	2026-09-30 08:26:18.395251+00	\N	\N	\N	mashhad	90	2	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن والی در چهارچشمه", "amounts": {"اجاره": 25000000}}	\N
1692	divar	ga8ecQ0R	آپارتمان 90متری	جانباز	\N	rent	\N	https://divar.ir/v/_/ga8ecQ0R	2026-09-30 08:24:41.346029+00	2026-09-30 08:26:18.3997+00	\N	\N	\N	mashhad	90	\N	\N	23000000	{"mid": "اجاره: ۲۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جانباز", "amounts": {"اجاره": 23000000}}	\N
1694	divar	ganiLpUO	۲۵۰ متر برج باران طبقه ۱۴ مشاعات هتلینگ	هنرستان	\N	rent	11	https://divar.ir/v/_/ganiLpUO	2026-09-30 08:23:19.044566+00	2026-09-30 08:26:18.407953+00	\N	\N	\N	mashhad	250	\N	\N	200000000	{"mid": "اجاره: ۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رمضانی در هنرستان", "amounts": {"اجاره": 200000000}}	\N
1695	divar	gaRKKa_Z	75متر همکف یک خوابه بازسازی در اسفندیانی	گوهرشاد	\N	rent	20	https://divar.ir/v/_/gaRKKa_Z	2026-09-30 08:22:34.714686+00	2026-09-30 08:26:18.413373+00	\N	\N	\N	mashhad	75	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "در گوهرشاد", "amounts": {"اجاره": 15000000}}	\N
1696	divar	ga8aMtSF	آپارتمان سه خواب نوساز دونبش تک‌واحدی درحدصفر	کوثر	\N	rent	13	https://divar.ir/v/_/ga8aMtSF	2026-09-30 08:22:19.014281+00	2026-09-30 08:26:18.418062+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در کوثر", "amounts": {}}	\N
1697	divar	gaMpdW2R	۹۰ متر ۲ خواب غرق نور فول صفر تا صد بازسازی تخلیه	هفت تیر (نه دره)	11000000000	sale	\N	https://divar.ir/v/_/gaMpdW2R	2026-09-30 07:58:01.874461+00	2026-09-30 08:36:31.023821+00	\N	\N	\N	mashhad	90	2	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (نه دره)", "amounts": {"raw_amount": 11000000000}}	\N
1698	divar	gazK-3EU	۱۲۰ متر هتل برج مسکونی افرا انتهای هنرستان نسترن	نیروی هوایی	34500000000	sale	\N	https://divar.ir/v/_/gazK-3EU	2026-09-30 08:35:57.04475+00	2026-09-30 08:36:31.042902+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۳۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در نیروی هوایی", "amounts": {"raw_amount": 34500000000}}	\N
1699	divar	ga8m8yBm	۱۰۰۰متر کاهو خیابان گلها با اب	میان ولایت	1950000000	sale	\N	https://divar.ir/v/_/ga8m8yBm	2026-09-30 08:35:53.44867+00	2026-09-30 08:36:31.048277+00	\N	\N	\N	mashhad	1000	\N	\N	\N	{"mid": "۱,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در میان ولایت", "amounts": {"raw_amount": 1950000000}}	\N
1700	divar	ga8msp9u	آپارتمان ۱۲۰ متر اواسط هفت تیر فول	هفت تیر (آب و برق)	14700000000	sale	\N	https://divar.ir/v/_/ga8msp9u	2026-09-30 08:35:49.790745+00	2026-09-30 08:36:31.053405+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۱۴,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در هفت تیر (آب و برق)", "amounts": {"raw_amount": 14700000000}}	\N
1701	divar	ga8mcypR	۴۷۰متر ویلایی صفر در ۴طبقه (ناصر خسرو)	احمدآباد	125000000000	sale	\N	https://divar.ir/v/_/ga8mcypR	2026-09-30 08:35:47.632173+00	2026-09-30 08:36:31.058794+00	\N	\N	\N	mashhad	470	\N	\N	\N	{"mid": "۱۲۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در احمدآباد", "amounts": {"raw_amount": 125000000000}}	\N
1702	divar	ga8mM0y3	علویه / عصمتیه صفر / 100 متری	امیریه	12000000000	sale	\N	https://divar.ir/v/_/ga8mM0y3	2026-09-30 08:35:44.290198+00	2026-09-30 08:36:31.064525+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مشارکت درساخت زمین مرکز تخصصی در امیریه", "amounts": {"raw_amount": 12000000000}}	\N
1703	divar	ga8m8hjx	باغ ۶۰۰ متری. شاهنامه ۷۶ لوکیش بیست	کلاته برفی	2650000000	sale	\N	https://divar.ir/v/_/ga8m8hjx	2026-09-30 08:35:24.544723+00	2026-09-30 08:36:31.07151+00	\N	\N	\N	mashhad	600	\N	\N	\N	{"mid": "۲,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کلاته برفی", "amounts": {"raw_amount": 2650000000}}	\N
1704	divar	ga8mMp-4	آپارتمان 119m*سند آماده*الهیه*رو به آفتاب*	الهیه	14350000000	sale	44	https://divar.ir/v/_/ga8mMp-4	2026-09-30 08:34:59.825841+00	2026-09-30 08:36:31.077475+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۴,۳۵۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری بزرگ رویال در الهیه", "amounts": {"raw_amount": 14350000000}}	\N
1705	divar	ga8e8tYE	۶۲ متری/ شریعتی( یوسفیه)/ بسیار تمیز	نرگس (شهرک غرب)	3850000000	sale	38	https://divar.ir/v/_/ga8e8tYE	2026-09-30 08:34:52.625385+00	2026-09-30 08:36:31.082765+00	\N	\N	\N	mashhad	62	\N	\N	\N	{"mid": "۳,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "علی اکبر ابراهیمی در نرگس (شهرک غرب)", "amounts": {"raw_amount": 3850000000}}	\N
1707	divar	ga8mMuFO	آپارتمان صفر مدرن تک واحدی پشت حاشیه وکیل آباد	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga8mMuFO	2026-09-30 08:35:12.608867+00	2026-09-30 08:36:31.091298+00	\N	\N	\N	mashhad	\N	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگ", "amounts": {"اجاره": 30000000}}	\N
1708	divar	ga8ess1i	آپارتمان 160متری رهن و اجاره	اقبال	\N	rent	1	https://divar.ir/v/_/ga8ess1i	2026-09-30 08:34:31.573668+00	2026-09-30 08:36:31.095002+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن مبینی در اقبال", "amounts": {}}	\N
1709	divar	ga8mcS1e	۱۶۵ متر آپارتمان / رهن و اجاره/ معاد قبل فرهنگ	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga8mcS1e	2026-09-30 08:34:04.827805+00	2026-09-30 08:36:31.09882+00	\N	\N	\N	mashhad	165	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگ", "amounts": {"اجاره": 40000000}}	\N
1710	divar	ga7yccYk	آپارتمان 90 متری  رهن کامل	هدایت	\N	rent	26	https://divar.ir/v/_/ga7yccYk	2026-09-30 08:33:22.758759+00	2026-09-30 08:36:31.102765+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در هدایت", "amounts": {}}	\N
1711	divar	ga7mlOD3	75متری دو خوابه رفیعی 5	نرگس (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga7mlOD3	2026-09-30 08:32:12.350708+00	2026-09-30 08:36:31.106598+00	\N	\N	\N	mashhad	75	\N	\N	17000000	{"mid": "اجاره: ۱۷,۰۰۰,۰۰۰ تومان", "bottom": "در نرگس (شهرک غرب)", "amounts": {"اجاره": 17000000}}	\N
1712	divar	ga8675G7	آپارتمان همکف اجاره ای	شهید رضوی	\N	rent	\N	https://divar.ir/v/_/ga8675G7	2026-09-30 08:31:48.437024+00	2026-09-30 08:36:31.110404+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید رضوی", "amounts": {"اجاره": 15000000}}	\N
1713	divar	ga8ictb8	دونبش غرق نورگیر/سه خواب / اجاره سجاد	سجاد شهر	\N	rent	21	https://divar.ir/v/_/ga8ictb8	2026-09-30 08:31:28.832161+00	2026-09-30 08:36:31.11454+00	\N	\N	\N	mashhad	\N	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "محمدی در سجاد شهر", "amounts": {"اجاره": 25000000}}	\N
1714	divar	ga7SK-wj	همخونه خ ا ن و م	ابوذر	\N	rent	24	https://divar.ir/v/_/ga7SK-wj	2026-09-30 08:31:18.170772+00	2026-09-30 08:36:31.118696+00	\N	\N	\N	mashhad	\N	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "در ابوذر", "amounts": {"اجاره": 3000000}}	\N
1715	divar	gar6KkCE	اپارتمان طبقه ی دوم	حضرت حجت	\N	rent	\N	https://divar.ir/v/_/gar6KkCE	2026-09-30 08:30:36.412532+00	2026-09-30 08:36:31.122702+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در حضرت حجت", "amounts": {"اجاره": 10000000}}	\N
1716	divar	ga8iciGf	۱۴۰ متری / شیک و تمیز / کوثرشمالی یک	کوثر	\N	rent	13	https://divar.ir/v/_/ga8iciGf	2026-09-30 08:30:10.270771+00	2026-09-30 08:36:31.126855+00	\N	\N	\N	mashhad	140	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 40000000}}	\N
1717	divar	gavmKiPH	۱۵۰ متر * زیر فی * تهاتر * وام و رهن * الهیه	الهیه	14400000000	sale	44	https://divar.ir/v/_/gavmKiPH	2026-09-29 07:56:51.149706+00	2026-09-30 08:46:43.276356+00	\N	\N	\N	mashhad	150	\N	\N	\N	{"mid": "۱۴,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در الهیه", "amounts": {"raw_amount": 14400000000}}	\N
1718	divar	ga8ycQuB	ویلایی صفر فول دو واحدی	وکیل‌آباد	19000000000	sale	\N	https://divar.ir/v/_/ga8ycQuB	2026-09-30 08:46:33.332074+00	2026-09-30 08:46:43.295654+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در وکیل‌آباد", "amounts": {"raw_amount": 19000000000}}	\N
1719	divar	ga8yMWO7	۱۶۰ متری فوق لوکس ابتدا دانش اموز جهت سرمایه گذاری	فرهنگ	28800000000	sale	\N	https://divar.ir/v/_/ga8yMWO7	2026-09-30 08:46:26.859815+00	2026-09-30 08:46:43.302148+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۲۸,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فرهنگ", "amounts": {"raw_amount": 28800000000}}	\N
1720	divar	ga8iMaom	55 متری / سر دونبش / حاشیه خیابان / سند شش دانگ	کوه سنگی	6900000000	sale	\N	https://divar.ir/v/_/ga8iMaom	2026-09-30 08:46:25.272104+00	2026-09-30 08:46:43.307121+00	\N	\N	\N	mashhad	55	\N	\N	\N	{"mid": "۶,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "سامان طاهری مسکن جم  در کوه سنگی", "amounts": {"raw_amount": 6900000000}}	\N
1721	divar	gad1xRjm	حسین اباد جلدک قطعات تحویل 1500متری	جاهد شهر	4000000000	sale	41	https://divar.ir/v/_/gad1xRjm	2026-09-30 08:46:18.933158+00	2026-09-30 08:46:43.312371+00	\N	\N	\N	mashhad	1500	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مهندس فخیم زاده حسین اباد جلدک خرید فروش  در جاهد شهر", "amounts": {"raw_amount": 4000000000}}	\N
1722	divar	ga8usxQn	اپارتمان ۹۵ متری دوخواب سردونش	نکاح	6000000000	sale	\N	https://divar.ir/v/_/ga8usxQn	2026-09-30 08:45:26.590804+00	2026-09-30 08:46:43.317138+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نکاح", "amounts": {"raw_amount": 6000000000}}	\N
1723	divar	gaui7tN1	اول رحمانیه/۱۰۸متر/۸ واحد/دربار	الهیه	10700000000	sale	44	https://divar.ir/v/_/gaui7tN1	2026-09-30 08:45:11.821581+00	2026-09-30 08:46:43.321683+00	\N	\N	\N	mashhad	108	\N	\N	\N	{"mid": "۱۰,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن دربار در الهیه", "amounts": {"raw_amount": 10700000000}}	\N
1725	divar	ga8ysKvq	۷۵ متری لادن ۲۵ گلدیس ۱۶	شهرآرا	\N	rent	3	https://divar.ir/v/_/ga8ysKvq	2026-09-30 08:46:28.750939+00	2026-09-30 08:46:43.329418+00	\N	\N	\N	mashhad	75	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهرآرا", "amounts": {"اجاره": 3000000}}	\N
1726	divar	ga8uc9ln	آپارتمان،رهن و اجاره،اوایل اندیشه،رازی،هریری	شهرک رازی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga8uc9ln	2026-09-30 08:46:03.614148+00	2026-09-30 08:46:43.333312+00	\N	\N	\N	mashhad	\N	\N	\N	14000000	{"mid": "اجاره: ۱۴,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهرک رازی (شهرک غرب)", "amounts": {"اجاره": 14000000}}	\N
1727	divar	gag2Px2q	جلال چفت معلم /170متری /تماما مستغلاتی /بدون مالک/	آزادشهر	\N	rent	\N	https://divar.ir/v/_/gag2Px2q	2026-09-30 08:44:17.227239+00	2026-09-30 08:46:43.337182+00	\N	\N	\N	mashhad	170	\N	\N	60000000	{"mid": "اجاره: ۶۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بامک بین امامت ۳۶و۳۸ در آزادشهر", "amounts": {"اجاره": 60000000}}	\N
1728	divar	ga8ucwVd	آپارتمان ۱۹۰ متری سه نبش درحد صفر اوایل بلوار	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga8ucwVd	2026-09-30 08:43:53.581565+00	2026-09-30 08:46:43.341161+00	\N	\N	\N	mashhad	190	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در فرهنگ", "amounts": {}}	\N
1729	divar	ga8usndg	واحد آپارتمان آبکوه، ۳ خواب ، ۱۶۰ متر	سناباد	\N	rent	\N	https://divar.ir/v/_/ga8usndg	2026-09-30 08:43:22.601875+00	2026-09-30 08:46:43.346857+00	\N	\N	\N	mashhad	160	3	\N	43000000	{"mid": "اجاره: ۴۳,۰۰۰,۰۰۰ تومان", "bottom": "پارثاوا ، تالار معاملات ملکی در سناباد", "amounts": {"اجاره": 43000000}}	\N
1730	divar	ga8u8Pzs	آپارتمان۷۵متری،طبقه۳روی پیلوت،درایثارگران۱۶،محجوب۴	ایثارگران	\N	rent	\N	https://divar.ir/v/_/ga8u8Pzs	2026-09-30 08:41:47.211601+00	2026-09-30 08:46:43.352174+00	\N	\N	\N	mashhad	75	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سراسری نور در ایثارگران", "amounts": {"اجاره": 10000000}}	\N
1731	divar	ga8u8Dqh	75متر دوخواب مجتمع پردیس ،قابل تبدیل	توس (بلوار توس)	\N	rent	\N	https://divar.ir/v/_/ga8u8Dqh	2026-09-30 08:41:37.453079+00	2026-09-30 08:46:43.356754+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "رهن کامل", "bottom": "کارگزاری سراسری عرب در توس (بلوار توس)", "amounts": {}}	\N
1732	divar	ga8u8Gzs	آپارتمان سه خواب لوکس/قبل فرهنگ	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga8u8Gzs	2026-09-30 08:41:24.452251+00	2026-09-30 08:46:43.361372+00	\N	\N	\N	mashhad	\N	\N	\N	80000000	{"mid": "اجاره: ۸۰,۰۰۰,۰۰۰ تومان", "bottom": "حمید کاظمی در فرهنگ", "amounts": {"اجاره": 80000000}}	\N
1733	divar	ga2mDOUV	۱۳۰ متری شیک فول حاشیه اقدسیه * ویو ابدی *	الهیه	\N	rent	44	https://divar.ir/v/_/ga2mDOUV	2026-09-30 08:41:16.44015+00	2026-09-30 08:46:43.365942+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {}}	\N
1734	divar	gauWIUTl	خانه فروشی مفتح شرقی مهدی آباد22	مهدی آباد	3800000000	sale	\N	https://divar.ir/v/_/gauWIUTl	2026-09-19 12:51:46.122568+00	2026-09-30 10:05:05.044896+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در مهدی آباد", "amounts": {"raw_amount": 3800000000}}	\N
1845	divar	gaT5c0gy	دوبلکس ۸۵ متری	نظام دوست	4000000000	sale	\N	https://divar.ir/v/_/gaT5c0gy	2026-09-30 13:02:17.579042+00	2026-09-30 13:03:20.10898+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در نظام دوست", "amounts": {"raw_amount": 4000000000}}	\N
1735	divar	gauOTFea	۱۴۴متری/تک واحدی/پشت حاشیه فکوری لاله ویو فکوری	نیروی هوایی	21200000000	sale	\N	https://divar.ir/v/_/gauOTFea	2026-09-29 06:06:01.135824+00	2026-09-30 10:05:05.049956+00	\N	\N	\N	mashhad	144	\N	\N	\N	{"mid": "۲۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن ماد در نیروی هوایی", "amounts": {"raw_amount": 21200000000}}	\N
1736	divar	ga8i6_-N	287متر/پنت هاوس الهیه*معتبرترین برند/اعیانی و خاص	الهیه	42200000000	sale	44	https://divar.ir/v/_/ga8i6_-N	2026-09-30 10:04:49.620083+00	2026-09-30 10:05:05.052493+00	\N	\N	\N	mashhad	287	\N	\N	\N	{"mid": "۴۲,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری بزرگ رویال در الهیه", "amounts": {"raw_amount": 42200000000}}	\N
1737	divar	ga86trJY	ملک آباد(قبل ریس)/۲۹۹متر/خطِ قرمز اشراف	فلسطین	105000000000	sale	19	https://divar.ir/v/_/ga86trJY	2026-09-30 10:04:45.630024+00	2026-09-30 10:05:05.054861+00	\N	\N	\N	mashhad	299	\N	\N	\N	{"mid": "۱۰۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فلسطین", "amounts": {"raw_amount": 105000000000}}	\N
1738	divar	ga8m6C5Y	۱۲۲متر*/مدرن و ویوابدی*الهیه/غرق نور پنجره ها قدی	امیریه	12200000000	sale	\N	https://divar.ir/v/_/ga8m6C5Y	2026-09-30 10:04:43.188272+00	2026-09-30 10:05:05.057914+00	\N	\N	\N	mashhad	122	\N	\N	\N	{"mid": "۱۲,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری بزرگ رویال در امیریه", "amounts": {"raw_amount": 12200000000}}	\N
1739	divar	ga8mKHX1	حس خاص لوکس نشینی/۱۵۰مترتک واحد مدرن/آشپزخانه نور	الهیه	15750000000	sale	44	https://divar.ir/v/_/ga8mKHX1	2026-09-30 10:04:31.682736+00	2026-09-30 10:05:05.060804+00	\N	\N	\N	mashhad	150	\N	\N	\N	{"mid": "۱۵,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری بزرگ رویال در الهیه", "amounts": {"raw_amount": 15750000000}}	\N
1740	divar	ga86Nnmx	۱۶۵ متری‌تکواحدی/صفر مدرن/یک قدمی وکیل‌آباد	هنرستان	42500000000	sale	11	https://divar.ir/v/_/ga86Nnmx	2026-09-30 10:04:21.215017+00	2026-09-30 10:05:05.063186+00	\N	\N	\N	mashhad	165	\N	\N	\N	{"mid": "۴۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هنرستان", "amounts": {"raw_amount": 42500000000}}	\N
1741	divar	ga86tPy6	همکف سند دار	نکاح	11200000000	sale	\N	https://divar.ir/v/_/ga86tPy6	2026-09-30 10:04:12.955346+00	2026-09-30 10:05:05.06539+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در نکاح", "amounts": {"raw_amount": 11200000000}}	\N
1742	divar	ga86dfUW	فروش آپارتمان ۱۰۱ اقبال قبل پیروزی/۷سال ساخت	اقبال	15000000000	sale	1	https://divar.ir/v/_/ga86dfUW	2026-09-30 10:04:02.914821+00	2026-09-30 10:05:05.067804+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در اقبال", "amounts": {"raw_amount": 15000000000}}	\N
1743	divar	ga62Yk-M	115متر دونبش غرق نور/فلاحی	شهرک لشکر (شهرک غرب)	14000000000	sale	38	https://divar.ir/v/_/ga62Yk-M	2026-09-30 10:03:31.359713+00	2026-09-30 10:05:05.070026+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۱۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن هاشمی (نبش فلاحی ۴۳) در شهرک لشکر (شهرک غرب)", "amounts": {"raw_amount": 14000000000}}	\N
1744	divar	gazpKzYJ	خونه باغ شیک نقلی ۴۰۰متری ملکی	درزآب	1120000000	sale	\N	https://divar.ir/v/_/gazpKzYJ	2026-09-30 10:03:28.849185+00	2026-09-30 10:05:05.073056+00	\N	\N	\N	mashhad	400	\N	\N	\N	{"mid": "۱,۱۲۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 1120000000}}	\N
1745	divar	ga869FbK	آپارتمان نقلی همکف/بازسازی صفرتاصد/روبروی پارک ملت	آزادشهر	9800000000	sale	\N	https://divar.ir/v/_/ga869FbK	2026-09-30 10:03:22.974655+00	2026-09-30 10:05:05.075308+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رضا الهی نبش فرهنگ یک در آزادشهر", "amounts": {"raw_amount": 9800000000}}	\N
1746	divar	ga86tR9s	۹۳ متر ۲خواب بازسازی فول مشاعات نسترن ملک آباد	فلسطین	19500000000	sale	19	https://divar.ir/v/_/ga86tR9s	2026-09-30 10:03:15.936597+00	2026-09-30 10:05:05.078471+00	\N	\N	\N	mashhad	93	2	\N	\N	{"mid": "۱۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مهیار جبلی در فلسطین", "amounts": {"raw_amount": 19500000000}}	\N
1747	divar	gaxOHW2t	باغ ۵۰۰ متری ۹۰متر خونش دوخواب تکمیل آب برق وصل	درزآب	2330000000	sale	\N	https://divar.ir/v/_/gaxOHW2t	2026-09-30 10:02:04.442708+00	2026-09-30 10:05:05.081324+00	\N	\N	\N	mashhad	500	\N	\N	\N	{"mid": "۲,۳۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 2330000000}}	\N
1748	divar	ga0GuqWE	رهن کامل آپارتمان ،نورگیر عالی ،کوچه ۱۲ متری	امامیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga0GuqWE	2026-09-30 10:04:10.268148+00	2026-09-30 10:05:05.083868+00	\N	\N	\N	mashhad	12	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "در امامیه (شهرک غرب)", "amounts": {"اجاره": 5000000}}	\N
1749	divar	ga86tb1t	آپارتمان ۴ خواب رویایی درحد صفر بلوار وکیل آباد	فارغ التحصیلان	\N	rent	\N	https://divar.ir/v/_/ga86tb1t	2026-09-30 10:03:35.304814+00	2026-09-30 10:05:05.086186+00	\N	\N	\N	mashhad	\N	4	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در فارغ التحصیلان", "amounts": {}}	\N
1750	divar	ga8yNQBX	۱۴۵ متر/ سه خواب/ غرق نور/ مستر	الهیه	\N	rent	44	https://divar.ir/v/_/ga8yNQBX	2026-09-30 09:55:50.593332+00	2026-09-30 10:05:05.088406+00	\N	\N	\N	mashhad	145	\N	\N	37000000	{"mid": "اجاره: ۳۷,۰۰۰,۰۰۰ تومان", "bottom": "مسکن برتر مدیران در الهیه", "amounts": {"اجاره": 37000000}}	\N
1751	divar	ga8udvGm	۸۰متری،دوخواب،مجد	کلاهدوز	\N	rent	\N	https://divar.ir/v/_/ga8udvGm	2026-09-30 09:52:25.224913+00	2026-09-30 10:05:05.091716+00	\N	\N	\N	mashhad	80	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کلاهدوز", "amounts": {"اجاره": 15000000}}	\N
1752	divar	ga8udpNC	همخونه موجه	امامیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga8udpNC	2026-09-30 09:51:38.989799+00	2026-09-30 10:05:05.094242+00	\N	\N	\N	mashhad	\N	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امامیه (شهرک غرب)", "amounts": {"اجاره": 4000000}}	\N
1753	divar	ga1JBf_D	رهن آپارتمان ۱۹۰ متر استثنایی لوکس تک واحدی ۳خواب	هنرستان	\N	rent	11	https://divar.ir/v/_/ga1JBf_D	2026-09-30 09:51:12.259543+00	2026-09-30 10:05:05.096787+00	\N	\N	\N	mashhad	190	3	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "در هنرستان", "amounts": {"اجاره": 10000}}	\N
1754	divar	ga8udQQw	۱۷۰متر ویلایی دربست/در۲طبقه مجزا/لوکیشن آرام/تخلیه	سید رضی	\N	rent	\N	https://divar.ir/v/_/ga8udQQw	2026-09-30 09:51:09.03392+00	2026-09-30 10:05:05.099096+00	\N	\N	\N	mashhad	170	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سید رضی", "amounts": {"اجاره": 40000000}}	\N
1755	divar	ga8q91Me	180 متر سه خواب فول امکانات رحمانیه	الهیه	\N	rent	44	https://divar.ir/v/_/ga8q91Me	2026-09-30 09:48:39.445899+00	2026-09-30 10:05:05.101609+00	\N	\N	\N	mashhad	180	\N	\N	58000000	{"mid": "اجاره: ۵۸,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در الهیه", "amounts": {"اجاره": 58000000}}	\N
1756	divar	ga5m2oJE	فروش آپارتمان ۷۸ متری اندیشه	شهرک رازی (شهرک غرب)	7400000000	sale	38	https://divar.ir/v/_/ga5m2oJE	2026-09-27 19:09:24.789377+00	2026-09-30 10:15:16.269087+00	\N	\N	\N	mashhad	78	\N	\N	\N	{"mid": "۷,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک رازی (شهرک غرب)", "amounts": {"raw_amount": 7400000000}}	\N
1757	divar	ga8GNUMy	آپارتمان ۱۳۰ متری / ۲ خواب /  غرق نور / سند دار	حسین‌آباد	12400000000	sale	\N	https://divar.ir/v/_/ga8GNUMy	2026-09-30 10:14:52.125568+00	2026-09-30 10:15:16.279951+00	\N	\N	\N	mashhad	130	2	\N	\N	{"mid": "۱۲,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سراسری ملی در حسین‌آباد", "amounts": {"raw_amount": 12400000000}}	\N
1758	divar	gaw5TY6K	۱۰۰ متری/بازسازی کامل/خوش نقشه/مسترملک،لطفی	جانباز	6400000000	sale	\N	https://divar.ir/v/_/gaw5TY6K	2026-09-30 10:13:37.323873+00	2026-09-30 10:15:16.285241+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۶,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مستر ملک جانباز۷نبش منفرد۷ در جانباز", "amounts": {"raw_amount": 6400000000}}	\N
1759	divar	gaw-9iNP	۱۰۰متری /خیابان ۲۰ متری/فول/مسترملک،لطفی	جانباز	8000000000	sale	\N	https://divar.ir/v/_/gaw-9iNP	2026-09-30 10:13:02.168247+00	2026-09-30 10:15:16.28774+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مستر ملک جانباز۷نبش منفرد۷ در جانباز", "amounts": {"raw_amount": 8000000000}}	\N
1760	divar	ga8-9uaU	ویلایی ۲۵۰ متری صیاد شیرازی ۲۳ نور۵	هفت تیر (حافظ)	65000000000	sale	5	https://divar.ir/v/_/ga8-9uaU	2026-09-30 10:12:19.636674+00	2026-09-30 10:15:16.289726+00	\N	\N	\N	mashhad	250	\N	\N	\N	{"mid": "۶۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (حافظ)", "amounts": {"raw_amount": 65000000000}}	\N
1761	divar	ga8C-U4l	آپارتمان 40 متری	هفت تیر (نه دره)	1310000000	sale	\N	https://divar.ir/v/_/ga8C-U4l	2026-09-30 10:12:11.960611+00	2026-09-30 10:15:16.291737+00	\N	\N	\N	mashhad	40	\N	\N	\N	{"mid": "۱,۳۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (نه دره)", "amounts": {"raw_amount": 1310000000}}	\N
1762	divar	ga8C-LNl	۱۲۵ متر ۳ خواب مستر تکواحدی ، لب خیابان امام رضا	سلام	23200000000	sale	\N	https://divar.ir/v/_/ga8C-LNl	2026-09-30 10:11:09.86125+00	2026-09-30 10:15:16.29355+00	\N	\N	\N	mashhad	125	3	\N	\N	{"mid": "۲۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن شمس در سلام", "amounts": {"raw_amount": 23200000000}}	\N
1763	divar	ga8-t_CX	آپارتمان ۷۵متری دو‌خواب فرهنگ	فرهنگ	12500000000	sale	\N	https://divar.ir/v/_/ga8-t_CX	2026-09-30 10:11:00.207323+00	2026-09-30 10:15:16.295382+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگ", "amounts": {"raw_amount": 12500000000}}	\N
1764	divar	ga7SZ9s8	آپارتمان 75 متری  / 2 خواب / دندان پزشکان	شریف	9300000000	sale	\N	https://divar.ir/v/_/ga7SZ9s8	2026-09-30 10:10:53.915102+00	2026-09-30 10:15:16.297439+00	\N	\N	\N	mashhad	75	2	\N	\N	{"mid": "۹,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رضا الهی نبش فرهنگ یک در شریف", "amounts": {"raw_amount": 9300000000}}	\N
1765	divar	ga8-dq26	خانه ویلایی	پورسینا	6000000000	sale	\N	https://divar.ir/v/_/ga8-dq26	2026-09-30 10:10:28.239366+00	2026-09-30 10:15:16.299346+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پورسینا", "amounts": {"raw_amount": 6000000000}}	\N
1766	divar	ga8CeiG9	رهن واجاره اپارتمان در توس۳۳ کشف	کشف	\N	rent	\N	https://divar.ir/v/_/ga8CeiG9	2026-09-30 10:14:33.74451+00	2026-09-30 10:15:16.301139+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در کشف", "amounts": {"اجاره": 100000}}	\N
1767	divar	ga8COLIp	آپارتمان 50متری رهن و اجاره سیدی اصلانی121	شهرک ابوذر	\N	rent	24	https://divar.ir/v/_/ga8COLIp	2026-09-30 10:11:05.186933+00	2026-09-30 10:15:16.30288+00	\N	\N	\N	mashhad	50	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک ابوذر", "amounts": {"اجاره": 6000000}}	\N
1768	divar	gaSpSRXG	آپارتمان ۲۷۰ متری ۴خوابه شیک ونوساز سردونبش	سید رضی	\N	rent	\N	https://divar.ir/v/_/gaSpSRXG	2026-09-30 10:11:04.186328+00	2026-09-30 10:15:16.304946+00	\N	\N	\N	mashhad	270	4	\N	\N	{"mid": "رهن کامل", "bottom": "در سید رضی", "amounts": {}}	\N
1769	divar	ga82NGUP	آپارتمان 100متر	گلشور	\N	rent	\N	https://divar.ir/v/_/ga82NGUP	2026-09-30 10:07:48.328854+00	2026-09-30 10:15:16.306729+00	\N	\N	\N	mashhad	100	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گلشور", "amounts": {"اجاره": 100000}}	\N
1770	divar	ga8-tA59	آپارتمان سه خواب مدرن صفر قبل فرهنگ	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga8-tA59	2026-09-30 10:06:01.491896+00	2026-09-30 10:15:16.308468+00	\N	\N	\N	mashhad	\N	\N	\N	115000000	{"mid": "اجاره: ۱۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگ", "amounts": {"اجاره": 115000000}}	\N
1771	divar	ga8Odt9V	۱۵۵ متر/۳ خواب / قرارداد ۲ ساله	دانشجو	\N	rent	39	https://divar.ir/v/_/ga8Odt9V	2026-09-30 10:05:23.386802+00	2026-09-30 10:15:16.310264+00	\N	\N	\N	mashhad	155	3	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رضا الهی نبش فرهنگ یک در دانشجو", "amounts": {"اجاره": 6000000}}	\N
1774	divar	ga8OOGwy	هم کف شیک و تمیز حدود ۷۰ متر	یاس	4500000000	sale	\N	https://divar.ir/v/_/ga8OOGwy	2026-09-30 10:24:22.582451+00	2026-09-30 10:25:27.578191+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در یاس", "amounts": {"raw_amount": 4500000000}}	\N
1775	divar	ga8OOHQd	آپارتمان ۲ خواب دورقاب	شهید مطهری	3900000000	sale	28	https://divar.ir/v/_/ga8OOHQd	2026-09-30 10:24:02.360089+00	2026-09-30 10:25:27.586455+00	\N	\N	\N	mashhad	\N	2	\N	\N	{"mid": "۳,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید مطهری", "amounts": {"raw_amount": 3900000000}}	\N
1776	divar	ga2SfgGc	خانه دربست بهمن فروشی	بهمن	1900000000	sale	43	https://divar.ir/v/_/ga2SfgGc	2026-09-30 10:24:00.944282+00	2026-09-30 10:25:27.589976+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهمن", "amounts": {"raw_amount": 1900000000}}	\N
1777	divar	ga8OOEW6	اپارتمان 70متری فروشی	دوست آباد	2450000000	sale	\N	https://divar.ir/v/_/ga8OOEW6	2026-09-30 10:23:55.340115+00	2026-09-30 10:25:27.593296+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۲,۴۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در دوست آباد", "amounts": {"raw_amount": 2450000000}}	\N
1778	divar	ga8Ke7nF	۱۲۰ متر ‌شمالی/۳ خواب/غرق نور/زیر قیمت	اقبال	15000000000	sale	1	https://divar.ir/v/_/ga8Ke7nF	2026-09-30 10:23:22.648691+00	2026-09-30 10:25:27.59611+00	\N	\N	\N	mashhad	120	3	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در اقبال", "amounts": {"raw_amount": 15000000000}}	\N
1779	divar	gaeCqWgy	فروش فوری اپارتمان صفر خیام ۶۳	زمرد	26000000000	sale	\N	https://divar.ir/v/_/gaeCqWgy	2026-09-30 10:19:24.512581+00	2026-09-30 10:25:27.598697+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در زمرد", "amounts": {"raw_amount": 26000000000}}	\N
1780	divar	ga8Guy8_	اپارتمان نقلی قیمت مناسب	بهمن	1700000000	sale	43	https://divar.ir/v/_/ga8Guy8_	2026-09-30 10:19:09.047135+00	2026-09-30 10:25:27.600692+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهمن", "amounts": {"raw_amount": 1700000000}}	\N
1781	divar	ga8GO7g-	آپارتمان 122متری طبقه ششم امام رضا 5	دانش	22500000000	sale	\N	https://divar.ir/v/_/ga8GO7g-	2026-09-30 10:19:08.346944+00	2026-09-30 10:25:27.603568+00	\N	\N	\N	mashhad	122	\N	\N	\N	{"mid": "۲۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن شمس در دانش", "amounts": {"raw_amount": 22500000000}}	\N
1782	divar	ga8Gu6ZS	۱۱۲ متر ۲ خواب مستر ، سازه بینظیر ،خیابان امام رضا	سلام	25300000000	sale	\N	https://divar.ir/v/_/ga8Gu6ZS	2026-09-30 10:18:37.737591+00	2026-09-30 10:25:27.605841+00	\N	\N	\N	mashhad	112	2	\N	\N	{"mid": "۲۵,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن شمس در سلام", "amounts": {"raw_amount": 25300000000}}	\N
1783	divar	gaqSzv1d	اجاره آپارتمان ۷۵ متری مطهری جنوبی	سعد آباد	\N	rent	\N	https://divar.ir/v/_/gaqSzv1d	2026-09-22 15:32:55.922552+00	2026-09-30 10:25:27.607773+00	\N	\N	\N	mashhad	75	\N	\N	14000000	{"mid": "اجاره: ۱۴,۰۰۰,۰۰۰ تومان", "bottom": "در سعد آباد", "amounts": {"اجاره": 14000000}}	\N
1784	divar	ga8Kuzl9	80 متر هم کف دو خواب جلال آل احمد	شهید رضوی	\N	rent	\N	https://divar.ir/v/_/ga8Kuzl9	2026-09-30 10:24:44.965529+00	2026-09-30 10:25:27.609538+00	\N	\N	\N	mashhad	80	\N	\N	22000000	{"mid": "اجاره: ۲۲,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهید رضوی", "amounts": {"اجاره": 22000000}}	\N
1785	divar	ga8OeVho	اجاره یک واحد اپارتمان طبقه دوم	شهید آوینی	\N	rent	\N	https://divar.ir/v/_/ga8OeVho	2026-09-30 10:24:32.389922+00	2026-09-30 10:25:27.612024+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهید آوینی", "amounts": {"اجاره": 8000000}}	\N
1786	divar	ga8CO3bk	خاقانی ۷۰ متری ۲ خواب طبقه اول	رضاشهر	\N	rent	\N	https://divar.ir/v/_/ga8CO3bk	2026-09-30 10:22:19.859388+00	2026-09-30 10:25:27.613946+00	\N	\N	\N	mashhad	70	2	\N	19000000	{"mid": "اجاره: ۱۹,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاشهر", "amounts": {"اجاره": 19000000}}	\N
1788	divar	ga4xTMRL	اوایل ابکو/155متری/3خواب/1500اجاره	کلاهدوز	\N	rent	\N	https://divar.ir/v/_/ga4xTMRL	2026-09-30 10:19:43.617836+00	2026-09-30 10:25:27.618088+00	\N	\N	\N	mashhad	155	3	\N	19500000	{"mid": "اجاره: ۱۹,۵۰۰,۰۰۰ تومان", "bottom": "مسکن نوروزیان در کلاهدوز", "amounts": {"اجاره": 19500000}}	\N
1789	divar	galK04NR	۳۱۰ متر آپارتمان/گلشن سجاد/۴ خواب مستر	سجاد شهر	\N	rent	21	https://divar.ir/v/_/galK04NR	2026-09-30 10:18:46.132778+00	2026-09-30 10:25:27.620312+00	\N	\N	\N	mashhad	310	4	\N	150000000	{"mid": "اجاره: ۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در سجاد شهر", "amounts": {"اجاره": 150000000}}	\N
1790	divar	ga8GuuTK	خانه همکف رهن و اجاره  75متری	شهید قربانی	\N	rent	\N	https://divar.ir/v/_/ga8GuuTK	2026-09-30 10:18:21.696181+00	2026-09-30 10:25:27.622248+00	\N	\N	\N	mashhad	75	\N	\N	4500000	{"mid": "اجاره: ۴,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید قربانی", "amounts": {"اجاره": 4500000}}	\N
1791	divar	ga8GutDZ	آپارتمان  رهن واجاره	ولیعصر (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga8GutDZ	2026-09-30 10:17:38.656925+00	2026-09-30 10:25:27.624997+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ولیعصر (شهرک غرب)", "amounts": {"اجاره": 10000000}}	\N
1792	divar	ga8iNbTO	دانش آموز /قبل فرهنگ /کلا 3 واحد / اصیل و تمیز	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga8iNbTO	2026-09-30 10:16:27.198188+00	2026-09-30 10:25:27.627594+00	\N	\N	\N	mashhad	\N	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سراسری بیهق در فرهنگ", "amounts": {"اجاره": 40000000}}	\N
1793	divar	ga8G-P3y	۷۰متری/یکخواب/طبقه اول/طبرسی۶/نظامدوست۱۴	نظام دوست	\N	rent	\N	https://divar.ir/v/_/ga8G-P3y	2026-09-30 10:16:06.338001+00	2026-09-30 10:25:27.629504+00	\N	\N	\N	mashhad	70	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "دقایقی پیش در نظام دوست", "amounts": {"اجاره": 1000}}	\N
1798	divar	galigiOj	آپارتمان 110 متری تک واحدی فول	هنرور	7600000000	sale	\N	https://divar.ir/v/_/galigiOj	2026-09-30 10:34:09.980771+00	2026-09-30 10:35:38.515171+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۷,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هنرور", "amounts": {"raw_amount": 7600000000}}	\N
1800	divar	ga8WuWDs	۱۰۰ متر ۲ خواب مستر نورگیر ، فوق مشاعات ، سرشور	دانش	25000000000	sale	\N	https://divar.ir/v/_/ga8WuWDs	2026-09-30 10:33:13.798268+00	2026-09-30 10:35:38.523182+00	\N	\N	\N	mashhad	100	2	\N	\N	{"mid": "۲۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن شمس در دانش", "amounts": {"raw_amount": 25000000000}}	\N
1801	divar	gaIBx8te	باغ و زمین باغی	پنجتن	1600000000	sale	\N	https://divar.ir/v/_/gaIBx8te	2026-09-30 10:32:58.340607+00	2026-09-30 10:35:38.526173+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در پنجتن", "amounts": {"raw_amount": 1600000000}}	\N
1802	divar	gaw-aI7z	فروش یک طبقه آپارتمان رسالت 162	علی آباد	2600000000	sale	\N	https://divar.ir/v/_/gaw-aI7z	2026-09-30 10:32:56.27243+00	2026-09-30 10:35:38.528277+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در علی آباد", "amounts": {"raw_amount": 2600000000}}	\N
1803	divar	ga5GD_Hw	ویلایی ۲۵۰ متری،جنوبی،تراکم زیاد،توجیه ساخت مطمئن	انقلاب	30000000000	sale	\N	https://divar.ir/v/_/ga5GD_Hw	2026-09-30 10:32:46.917433+00	2026-09-30 10:35:38.530222+00	\N	\N	\N	mashhad	250	\N	\N	\N	{"mid": "۳۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در انقلاب", "amounts": {"raw_amount": 30000000000}}	\N
1804	divar	ga8WuA0N	آپارتمان صیاد پیروزی/۹۰متر/بازسازی کامل/۲خواب	هفت تیر (آب و برق)	7600000000	sale	\N	https://divar.ir/v/_/ga8WuA0N	2026-09-30 10:32:03.599837+00	2026-09-30 10:35:38.532455+00	\N	\N	\N	mashhad	90	2	\N	\N	{"mid": "۷,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (آب و برق)", "amounts": {"raw_amount": 7600000000}}	\N
1805	divar	ga0296vO	فروش خانه 65 متر دو طبقه داخل کوچه یکمتری	امام خمینی	7300000000	sale	\N	https://divar.ir/v/_/ga0296vO	2026-09-30 10:32:01.627415+00	2026-09-30 10:35:38.534465+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۷,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امام خمینی", "amounts": {"raw_amount": 7300000000}}	\N
1806	divar	ga7Sfzlj	آپارتمان 115متری/دوخواب/ خیابان امام رضا	امام رضا (ع)	15000000000	sale	\N	https://divar.ir/v/_/ga7Sfzlj	2026-09-30 10:31:59.054116+00	2026-09-30 10:35:38.537276+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 15000000000}}	\N
1807	divar	ga8SO9ti	زمین	بهار	3234000000	sale	\N	https://divar.ir/v/_/ga8SO9ti	2026-09-30 10:31:33.778671+00	2026-09-30 10:35:38.539216+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۲۳۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهار", "amounts": {"raw_amount": 3234000000}}	\N
1808	divar	ga8WgaLi	همخونه فقط خانم	شهید بصیر	\N	rent	\N	https://divar.ir/v/_/ga8WgaLi	2026-09-30 10:33:54.417785+00	2026-09-30 10:35:38.541145+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید بصیر", "amounts": {"اجاره": 1000000}}	\N
1809	divar	ga8WOQP1	خونه رهن اجاره	کوی سیدی	\N	rent	\N	https://divar.ir/v/_/ga8WOQP1	2026-09-30 10:32:39.155965+00	2026-09-30 10:35:38.544302+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی سیدی", "amounts": {"اجاره": 15000000}}	\N
1810	divar	ga8m8qUE	160مــتری  صفر (( اوایل امامت سکونت چند ساله ))	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga8m8qUE	2026-09-30 10:30:29.601572+00	2026-09-30 10:35:38.546278+00	\N	\N	\N	mashhad	\N	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بامک بین امامت ۳۶و۳۸ در آزادشهر", "amounts": {"اجاره": 30000000}}	\N
1811	divar	ga8SuFX8	خونه ویلایی ۱۵۰ متری بزرگ رهن کامل	انصار	\N	rent	\N	https://divar.ir/v/_/ga8SuFX8	2026-09-30 10:28:27.124166+00	2026-09-30 10:35:38.548256+00	\N	\N	\N	mashhad	150	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در انصار", "amounts": {}}	\N
1812	divar	ga5Kgcln	آپارتمان ۷۵ متر یک خواب کف سرامیک واقع در بلال	قائم	\N	rent	36	https://divar.ir/v/_/ga5Kgcln	2026-09-30 10:28:23.516755+00	2026-09-30 10:35:38.550341+00	\N	\N	\N	mashhad	75	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "در قائم", "amounts": {"اجاره": 100000}}	\N
1813	divar	ga8Oe-Y8	اپارتمان ۱۰۰ متری، دوخواب	منزل آباد	\N	rent	\N	https://divar.ir/v/_/ga8Oe-Y8	2026-09-30 10:27:50.800236+00	2026-09-30 10:35:38.552346+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در منزل آباد", "amounts": {}}	\N
1814	divar	ga8OulC2	واحد 80 متری دو خواب سیدرضی	سید رضی	\N	rent	\N	https://divar.ir/v/_/ga8OulC2	2026-09-30 10:25:34.569176+00	2026-09-30 10:35:38.554251+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در سید رضی", "amounts": {}}	\N
1820	divar	gatqycOf	اپارتمان ۱۱۰متری شهرک امام سجاد خین عرب	خین عرب	3450000000	sale	\N	https://divar.ir/v/_/gatqycOf	2026-09-30 10:45:14.607565+00	2026-09-30 10:45:49.342303+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۳,۴۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در خین عرب", "amounts": {"raw_amount": 3450000000}}	\N
1821	divar	ga8e-Bli	خونه ویلایی ۲۱۰ دربلوار توس ۱۹۹شهید کاظمی ۴	کلاته برفی	7500000000	sale	\N	https://divar.ir/v/_/ga8e-Bli	2026-09-30 10:42:33.504017+00	2026-09-30 10:45:49.352412+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کلاته برفی", "amounts": {"raw_amount": 7500000000}}	\N
1822	divar	ga8aOhRX	۷۲متری حسابی شمالی	فرهنگیان (شهرک غرب)	7400000000	sale	37	https://divar.ir/v/_/ga8aOhRX	2026-09-30 10:41:11.144687+00	2026-09-30 10:45:49.357556+00	\N	\N	\N	mashhad	72	\N	\N	\N	{"mid": "۷,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 7400000000}}	\N
1823	divar	gadeNQ5l	آپارتمان مدرن ۲۰۵ متری رو به حرم قابل معاوضه	ایثار	20000000000	sale	\N	https://divar.ir/v/_/gadeNQ5l	2026-09-30 10:39:31.212269+00	2026-09-30 10:45:49.362254+00	\N	\N	\N	mashhad	205	\N	\N	\N	{"mid": "۲۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در ایثار", "amounts": {"raw_amount": 20000000000}}	\N
1824	divar	ga8aulL9	۹۸ متری/شیک/تمیز	شریف	11000000000	sale	\N	https://divar.ir/v/_/ga8aulL9	2026-09-30 10:38:57.732031+00	2026-09-30 10:45:49.366242+00	\N	\N	\N	mashhad	98	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شریف", "amounts": {"raw_amount": 11000000000}}	\N
1825	divar	ga8OeOJe	۱۲۰ متر ۳ خواب ۳ مستر ، فول متریال ، لوکیشن سرشور	دانش	30000000000	sale	\N	https://divar.ir/v/_/ga8OeOJe	2026-09-30 10:38:31.887356+00	2026-09-30 10:45:49.370268+00	\N	\N	\N	mashhad	120	3	\N	\N	{"mid": "۳۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن شمس در دانش", "amounts": {"raw_amount": 30000000000}}	\N
1826	divar	ga8a-c95	ویلایی ناصر خسرو ،حاشیه ۱۵	احمدآباد	210000000000	sale	\N	https://divar.ir/v/_/ga8a-c95	2026-09-30 10:37:49.393929+00	2026-09-30 10:45:49.374359+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۱۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "پارثاوا ، تالار معاملات ملکی در احمدآباد", "amounts": {"raw_amount": 210000000000}}	\N
1827	divar	ga8aOZNF	۱۱۵ متر ۲ خواب مستر ، سندآماده ،نزدیک حرم امام رضا	حرم مطهر رضوی	21200000000	sale	\N	https://divar.ir/v/_/ga8aOZNF	2026-09-30 10:37:37.916442+00	2026-09-30 10:45:49.377945+00	\N	\N	\N	mashhad	115	2	\N	\N	{"mid": "۲۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن شمس در حرم مطهر رضوی", "amounts": {"raw_amount": 21200000000}}	\N
1828	divar	ga8W-1P0	آپارتمان ۱۱۵ متری / برج لوکس لویزان	سرافرازان	18400000000	sale	22	https://divar.ir/v/_/ga8W-1P0	2026-09-30 10:37:34.415908+00	2026-09-30 10:45:49.380982+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۱۸,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سرافرازان", "amounts": {"raw_amount": 18400000000}}	\N
1831	divar	ga8We2Nm	65 متر رئوف 16	نکاح	4950000000	sale	\N	https://divar.ir/v/_/ga8We2Nm	2026-09-30 10:36:35.684486+00	2026-09-30 10:45:49.38645+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۴,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نکاح", "amounts": {"raw_amount": 4950000000}}	\N
1833	divar	ga8i-KB4	رهن کامل یا اجاره101مترشیک اول فرامرزعباسی انحصاری	شهید فرامرز عباسی	\N	rent	\N	https://divar.ir/v/_/ga8i-KB4	2026-09-30 10:45:37.456885+00	2026-09-30 10:45:49.389952+00	\N	\N	\N	mashhad	101	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهید فرامرز عباسی", "amounts": {"اجاره": 10000000}}	\N
1835	divar	galuGvtF	منزل رهن ۵۰ ملیون	بهمن	\N	rent	43	https://divar.ir/v/_/galuGvtF	2026-09-30 10:44:37.532138+00	2026-09-30 10:45:49.393079+00	\N	\N	\N	mashhad	\N	\N	\N	9500000	{"mid": "اجاره: ۹,۵۰۰,۰۰۰ تومان", "bottom": "در بهمن", "amounts": {"اجاره": 9500000}}	\N
1836	divar	ga66oLPJ	همکف/ یکخواب/ دانشجو/	دانشجو	\N	rent	39	https://divar.ir/v/_/ga66oLPJ	2026-09-30 10:42:39.200216+00	2026-09-30 10:45:49.395169+00	\N	\N	\N	mashhad	\N	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "در دانشجو", "amounts": {"اجاره": 25000000}}	\N
1837	divar	ga7eKsMp	رهن و اجاره آپارتمان 60متری رستگارمقدم	بهار	\N	rent	\N	https://divar.ir/v/_/ga7eKsMp	2026-09-30 10:36:28.705027+00	2026-09-30 10:45:49.397063+00	\N	\N	\N	mashhad	60	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهار", "amounts": {"اجاره": 5000000}}	\N
1844	divar	ganVBJAH	175متر تکواحدی صفر سندآماده برندلوکس ابتدا رحمانیه	الهیه	23000000000	sale	44	https://divar.ir/v/_/ganVBJAH	2026-09-30 13:02:43.551906+00	2026-09-30 13:03:20.094434+00	\N	\N	\N	mashhad	175	\N	\N	\N	{"mid": "۲۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 23000000000}}	\N
1846	divar	ga8Gv73j	87 متـر ـ انـدیشه ـ سند تـک بـرگ	حجاب (شهرک غرب)	5190000000	sale	38	https://divar.ir/v/_/ga8Gv73j	2026-09-30 13:02:09.976586+00	2026-09-30 13:03:20.113011+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۱۹۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حجاب (شهرک غرب)", "amounts": {"raw_amount": 5190000000}}	\N
1847	divar	ga9eAvI6	زمین باغ ویلا در خادر شاندیز	وکیل‌آباد	6000000000	sale	\N	https://divar.ir/v/_/ga9eAvI6	2026-09-30 13:00:12.549563+00	2026-09-30 13:03:20.116332+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در وکیل‌آباد", "amounts": {"raw_amount": 6000000000}}	\N
1848	divar	gacOe1Iw	ناصرخسرو ۹/اجاره فوری/موقعیت خوب/دلباز/پرنور	جانباز	4000000000	sale	\N	https://divar.ir/v/_/gacOe1Iw	2026-09-30 12:59:07.737187+00	2026-09-30 13:03:20.118754+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جانباز", "amounts": {"raw_amount": 4000000000}}	\N
1849	divar	ga3yE8lz	آپارتمان 93 متری	حسین‌آباد	7500000000	sale	\N	https://divar.ir/v/_/ga3yE8lz	2026-09-30 12:58:47.341211+00	2026-09-30 13:03:20.121744+00	\N	\N	\N	mashhad	93	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در حسین‌آباد", "amounts": {"raw_amount": 7500000000}}	\N
1850	divar	gao5qqFP	۱۶۲متر * امامت * طراحی مدرن * نوساز	آزادشهر	25700000000	sale	\N	https://divar.ir/v/_/gao5qqFP	2026-09-30 12:58:25.131909+00	2026-09-30 13:03:20.123782+00	\N	\N	\N	mashhad	162	\N	\N	\N	{"mid": "۲۵,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "جمال بهبودی در آزادشهر", "amounts": {"raw_amount": 25700000000}}	\N
1851	divar	gap-nKFR	۴۴۰ متر در سه طبقه شاهنامه	توس فردوسی	8500000000	sale	\N	https://divar.ir/v/_/gap-nKFR	2026-09-30 12:58:11.581833+00	2026-09-30 13:03:20.12608+00	\N	\N	\N	mashhad	440	\N	\N	\N	{"mid": "۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس فردوسی", "amounts": {"raw_amount": 8500000000}}	\N
1853	divar	ga8SfV_o	80 مـتـر / شـریعتی / شـخصـی سـاز / فـول	میعاد (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga8SfV_o	2026-09-30 13:03:03.982054+00	2026-09-30 13:03:20.129728+00	\N	\N	\N	mashhad	\N	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در میعاد (شهرک غرب)", "amounts": {"اجاره": 25000000}}	\N
1854	divar	ga9igPub	رهن کامل ۱۳۰ متر دوکله ۳ خواب تک واحدی	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga9igPub	2026-09-30 13:02:06.429825+00	2026-09-30 13:03:20.131867+00	\N	\N	\N	mashhad	130	3	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در چهارچشمه", "amounts": {}}	\N
1855	divar	ga6Kjp2i	۱۵۰ متر/ دانش آموز قبل مهران/مخصوص سخت پسندان	سید رضی	\N	rent	\N	https://divar.ir/v/_/ga6Kjp2i	2026-09-30 13:00:40.128058+00	2026-09-30 13:03:20.134114+00	\N	\N	\N	mashhad	150	\N	\N	27000000000	{"mid": "اجاره: ۲۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "نارمک نبش جلال ۱۲ در سید رضی", "amounts": {"اجاره": 27000000000}}	\N
1856	divar	ga9eAZ49	آپارتمان رهن اجاره سیدی قائم سبحان	کوی ولیعصر	\N	rent	\N	https://divar.ir/v/_/ga9eAZ49	2026-09-30 13:00:01.359312+00	2026-09-30 13:03:20.13623+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی ولیعصر", "amounts": {"اجاره": 100000}}	\N
1857	divar	ga9egl8W	هم خونه میشم ۲۰ سالمه	رضاشهر	\N	rent	\N	https://divar.ir/v/_/ga9egl8W	2026-09-30 12:59:49.679044+00	2026-09-30 13:03:20.138216+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاشهر", "amounts": {"اجاره": 10000}}	\N
1858	divar	ga7y9Rfh	آپارتمان رهن اجاره .جنب بیمارستان رضوی	شهرک امام هادی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga7y9Rfh	2026-09-30 12:58:48.94021+00	2026-09-30 13:03:20.140734+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک امام هادی (شهرک غرب)", "amounts": {"اجاره": 10000000}}	\N
1859	divar	ga9awU53	آپارتمان صفر 3 خوابه 140 متری	امیریه	\N	rent	\N	https://divar.ir/v/_/ga9awU53	2026-09-30 12:58:06.107428+00	2026-09-30 13:03:20.143884+00	\N	\N	\N	mashhad	140	3	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در امیریه", "amounts": {}}	\N
1860	divar	ga9ewEJo	اجاره خونه ۱۰۰ متری	کوی المهدی	\N	rent	\N	https://divar.ir/v/_/ga9ewEJo	2026-09-30 12:56:58.6052+00	2026-09-30 13:03:20.146203+00	\N	\N	\N	mashhad	100	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی المهدی", "amounts": {"اجاره": 1000}}	\N
1861	divar	ga2KZETI	آپارتمان ۷۱متر،۲خواب،جاهدشهر،سجادیه۶،مجتمع سجاد	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga2KZETI	2026-09-30 12:53:23.670435+00	2026-09-30 13:03:20.148474+00	\N	\N	\N	mashhad	71	2	\N	17000000	{"mid": "اجاره: ۱۷,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"اجاره": 17000000}}	\N
1862	divar	ga9aAKLu	اجاره خانه	آبکوه	\N	rent	31	https://divar.ir/v/_/ga9aAKLu	2026-09-30 12:53:07.130723+00	2026-09-30 13:03:20.150785+00	\N	\N	\N	mashhad	\N	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آبکوه", "amounts": {"اجاره": 20000000}}	\N
1863	divar	ga82fLZ-	۸۰متر/شریعتی/فول امکانات	میعاد (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga82fLZ-	2026-09-30 12:45:27.654157+00	2026-09-30 13:03:20.152962+00	\N	\N	\N	mashhad	80	\N	\N	17000000	{"mid": "اجاره: ۱۷,۰۰۰,۰۰۰ تومان", "bottom": "گروه مهندسی ساختمانی دیان در میعاد (شهرک غرب)", "amounts": {"اجاره": 17000000}}	\N
1864	divar	ga9Ow1jG	دوطبقه.فوری فوری	قائم	\N	rent	36	https://divar.ir/v/_/ga9Ow1jG	2026-09-30 12:43:45.625478+00	2026-09-30 13:03:20.154954+00	\N	\N	\N	mashhad	\N	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در قائم", "amounts": {"اجاره": 3000000}}	\N
1865	divar	ga9Owo4W	آپارتمانی هم کف	اروند	\N	rent	\N	https://divar.ir/v/_/ga9Owo4W	2026-09-30 12:43:34.295324+00	2026-09-30 13:03:20.156721+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در اروند", "amounts": {"اجاره": 5000000}}	\N
1866	divar	ga9OA6AL	80متر دوخواب فول	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga9OA6AL	2026-09-30 12:43:33.007254+00	2026-09-30 13:03:20.158643+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن ممتاز ایران در جاهد شهر", "amounts": {}}	\N
1867	divar	gauq-I9s	همخونه میشم آقاهستم	هفده شهریور	\N	rent	\N	https://divar.ir/v/_/gauq-I9s	2026-09-30 12:42:25.651041+00	2026-09-30 13:03:20.160898+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفده شهریور", "amounts": {"اجاره": 10000000}}	\N
1868	divar	ga9OgbS0	آپارتمان ۸۰ متری هاشمیه	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga9OgbS0	2026-09-30 12:41:53.422197+00	2026-09-30 13:03:20.163009+00	\N	\N	\N	mashhad	80	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن مهرداد در چهارچشمه", "amounts": {"اجاره": 30000000}}	\N
2279	divar	ga-OEScb	خانه رهن کامل	امیر المومنین	\N	rent	\N	https://divar.ir/v/_/ga-OEScb	2026-10-01 11:28:34.742819+00	2026-10-01 11:34:16.877263+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در امیر المومنین", "amounts": {}}	\N
1869	divar	ga9OARfl	۱۱۰ متر/۳خوابه/تک واحدی/دانشجو/بازسازی شده	دانشجو	\N	rent	39	https://divar.ir/v/_/ga9OARfl	2026-09-30 12:40:43.558538+00	2026-09-30 13:03:20.164888+00	\N	\N	\N	mashhad	110	3	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در دانشجو", "amounts": {"اجاره": 35000000}}	\N
1870	divar	ga26VaGg	رهن کامل واحد ۷۵ متری طبقه اول	دانشجو	\N	rent	39	https://divar.ir/v/_/ga26VaGg	2026-09-30 12:39:01.342383+00	2026-09-30 13:03:20.167276+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در دانشجو", "amounts": {}}	\N
1871	divar	gaUC3Swl	رهن کامل آپارتمان صفر گلبهار	جاهد شهر	\N	rent	41	https://divar.ir/v/_/gaUC3Swl	2026-09-30 12:35:27.042632+00	2026-09-30 13:03:20.169268+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"اجاره": 100000}}	\N
1873	divar	ga7u1Kun	۱۳۲ متر اوایل رفیعی / ۳ خواب /بدون مشرف	نرگس (شهرک غرب)	15600000000	sale	38	https://divar.ir/v/_/ga7u1Kun	2026-09-29 06:32:12.124799+00	2026-09-30 13:13:31.759588+00	\N	\N	\N	mashhad	132	3	\N	\N	{"mid": "۱۵,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن راد در نرگس (شهرک غرب)", "amounts": {"raw_amount": 15600000000}}	\N
1874	divar	garGaSwl	۱۰۵ متر شیک سند آماده کفایی	الهیه	10500000000	sale	44	https://divar.ir/v/_/garGaSwl	2026-09-30 13:13:24.421961+00	2026-09-30 13:13:31.763311+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 10500000000}}	\N
1875	divar	ga8aP5P1	معاوضه اپارتمان با منزل در شهریزد	بهشت	15500000000	sale	18	https://divar.ir/v/_/ga8aP5P1	2026-09-30 13:13:17.329201+00	2026-09-30 13:13:31.765753+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در بهشت", "amounts": {"raw_amount": 15500000000}}	\N
1876	divar	ga9qATaM	منزل مسکونی	هفده شهریور	29000000000	sale	\N	https://divar.ir/v/_/ga9qATaM	2026-09-30 13:12:15.72802+00	2026-09-30 13:13:31.768198+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفده شهریور", "amounts": {"raw_amount": 29000000000}}	\N
1877	divar	ga8-6H9q	آپارتمان ۱۶۰ متر / ابتدای دانشجو / بازسازی شده	فرهنگ	24500000000	sale	\N	https://divar.ir/v/_/ga8-6H9q	2026-09-30 13:11:26.870477+00	2026-09-30 13:13:31.771722+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۲۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "بورس آپارتمان و ویلایی مسکن ماندگار در فرهنگ", "amounts": {"raw_amount": 24500000000}}	\N
1878	divar	ga9igIrY	زمین هزار متری	درزآب	275000000	sale	\N	https://divar.ir/v/_/ga9igIrY	2026-09-30 13:11:12.328059+00	2026-09-30 13:13:31.773907+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۷۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در درزآب", "amounts": {"raw_amount": 275000000}}	\N
1879	divar	gaRyXV1z	آپارتمان تک خواب ۷۵ متری	علی آباد	2390000000	sale	\N	https://divar.ir/v/_/gaRyXV1z	2026-09-30 13:10:36.124076+00	2026-09-30 13:13:31.776247+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۲,۳۹۰,۰۰۰,۰۰۰ تومان", "bottom": "در علی آباد", "amounts": {"raw_amount": 2390000000}}	\N
1880	divar	ga9qAGqD	املاک سراسری ملل /بین شاهنامه 31/33	چهاربرج	7000000000	sale	\N	https://divar.ir/v/_/ga9qAGqD	2026-09-30 13:10:26.533435+00	2026-09-30 13:13:31.778414+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهاربرج", "amounts": {"raw_amount": 7000000000}}	\N
1881	divar	ganuvVz2	فروش انواع ویلایی با قیمت‌های مختلف	امامیه (شهرک غرب)	18400000000	sale	38	https://divar.ir/v/_/ganuvVz2	2026-09-30 13:08:05.374018+00	2026-09-30 13:13:31.780704+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۸,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امامیه (شهرک غرب)", "amounts": {"raw_amount": 18400000000}}	\N
1883	divar	ga6GiZDh	140متر سه خواب هاشمیه 21	هنرستان	\N	rent	11	https://divar.ir/v/_/ga6GiZDh	2026-09-30 13:11:13.153118+00	2026-09-30 13:13:31.784527+00	\N	\N	\N	mashhad	140	\N	\N	34000000	{"mid": "اجاره: ۳۴,۰۰۰,۰۰۰ تومان", "bottom": "در هنرستان", "amounts": {"اجاره": 34000000}}	\N
1884	divar	ga9qQNuK	آپارتمان ۷۵متری طبقه اول طبرسی ۳۹ جماران ۸	طبرسی شمالی	\N	rent	42	https://divar.ir/v/_/ga9qQNuK	2026-09-30 13:10:58.726171+00	2026-09-30 13:13:31.787199+00	\N	\N	\N	mashhad	75	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {"اجاره": 1000}}	\N
1885	divar	ga5ahFrH	رهن اجاره آپارتمان	نکاح	\N	rent	\N	https://divar.ir/v/_/ga5ahFrH	2026-09-30 13:07:28.442508+00	2026-09-30 13:13:31.789355+00	\N	\N	\N	mashhad	\N	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "در نکاح", "amounts": {"اجاره": 12000000}}	\N
1886	divar	ga9mgMKW	خانه ویلایی توس ۱۱۷ رهن واجاره	دوست آباد	\N	rent	\N	https://divar.ir/v/_/ga9mgMKW	2026-09-30 13:06:09.625566+00	2026-09-30 13:13:31.791776+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در دوست آباد", "amounts": {"اجاره": 8000000}}	\N
1898	divar	ga6CH97y	آپارتمان۱۱۲متربازسازی می‌شودشیخ صدوق10قطعه سوم	سیلو	6500000000	sale	\N	https://divar.ir/v/_/ga6CH97y	2026-09-30 10:31:32.577161+00	2026-09-30 13:23:40.712038+00	\N	\N	\N	mashhad	112	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "ساخت و ساز ملک  در سیلو", "amounts": {"raw_amount": 6500000000}}	\N
1899	divar	ga6mJGRI	اپارتمان	رده	5600000000	sale	\N	https://divar.ir/v/_/ga6mJGRI	2026-09-28 16:43:43.876828+00	2026-09-30 13:23:40.716781+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رده", "amounts": {"raw_amount": 5600000000}}	\N
1900	divar	ga76NgwX	آپارتمان 140متری/3خواب/الهیه/سنداماده	جاهد شهر	16800000000	sale	41	https://divar.ir/v/_/ga76NgwX	2026-09-30 13:23:28.406159+00	2026-09-30 13:23:40.720743+00	\N	\N	\N	mashhad	140	3	\N	\N	{"mid": "۱۶,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "ملکستان در جاهد شهر", "amounts": {"raw_amount": 16800000000}}	\N
1901	divar	ga9CgpM9	فُوولِ فوول/ رفیعی/ شخصی ساز/ سند آماده	میعاد (شهرک غرب)	9050000000	sale	38	https://divar.ir/v/_/ga9CgpM9	2026-09-30 13:23:12.103456+00	2026-09-30 13:23:40.72369+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹,۰۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در میعاد (شهرک غرب)", "amounts": {"raw_amount": 9050000000}}	\N
1902	divar	ga9ywkx8	ویلایی ۶۲۰متری دونبش  ملکی که از هر طرف ابهت داره	سجاد شهر	250000000000	sale	21	https://divar.ir/v/_/ga9ywkx8	2026-09-30 13:22:54.652237+00	2026-09-30 13:23:40.725712+00	\N	\N	\N	mashhad	620	\N	\N	\N	{"mid": "۲۵۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در سجاد شهر", "amounts": {"raw_amount": 250000000000}}	\N
1903	divar	gasewDvQ	زمین90متری باصفحه، مشارکت یافروش	کوشک مهدی	1250000000	sale	\N	https://divar.ir/v/_/gasewDvQ	2026-09-30 13:22:02.838583+00	2026-09-30 13:23:40.728043+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۱,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوشک مهدی", "amounts": {"raw_amount": 1250000000}}	\N
1904	divar	ga9ywvsX	۳۴۲ متر زمین (بازار خودرو) جنوبی	الهیه	33800000000	sale	44	https://divar.ir/v/_/ga9ywvsX	2026-09-30 13:21:46.477646+00	2026-09-30 13:23:40.729976+00	\N	\N	\N	mashhad	342	\N	\N	\N	{"mid": "۳۳,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پلاک در الهیه", "amounts": {"raw_amount": 33800000000}}	\N
1905	divar	gax6TQoY	طبقه اول،سیمتری طلاب مفتح۱۰، تک خواب،۷۰ متری	طلاب	4990000000	sale	\N	https://divar.ir/v/_/gax6TQoY	2026-09-30 13:21:34.375637+00	2026-09-30 13:23:40.732097+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۴,۹۹۰,۰۰۰,۰۰۰ تومان", "bottom": "در طلاب", "amounts": {"raw_amount": 4990000000}}	\N
1906	divar	ga9yQmuk	۱۲۴ متر حاشیه سجادیه	امیریه	13640000000	sale	\N	https://divar.ir/v/_/ga9yQmuk	2026-09-30 13:21:12.466916+00	2026-09-30 13:23:40.733942+00	\N	\N	\N	mashhad	124	\N	\N	\N	{"mid": "۱۳,۶۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیریه", "amounts": {"raw_amount": 13640000000}}	\N
1907	divar	ga9yQUtC	آپارتمان 85 متری	شهرک امام هادی (شهرک غرب)	3250000000	sale	38	https://divar.ir/v/_/ga9yQUtC	2026-09-30 13:20:57.787337+00	2026-09-30 13:23:40.736258+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۳,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک امام هادی (شهرک غرب)", "amounts": {"raw_amount": 3250000000}}	\N
1908	divar	ga9yQFEA	آپارتمان 110 متری ایثارگران19/1	ایثارگران	8120000000	sale	\N	https://divar.ir/v/_/ga9yQFEA	2026-09-30 13:20:44.228462+00	2026-09-30 13:23:40.738528+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۸,۱۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثارگران", "amounts": {"raw_amount": 8120000000}}	\N
1911	divar	ga92QHSm	اجاره اپارتمان۱۲۰ متری فول امکانات بهارستان ارغوان	بهارستان	\N	rent	\N	https://divar.ir/v/_/ga92QHSm	2026-09-30 13:22:56.670537+00	2026-09-30 13:23:40.743875+00	\N	\N	\N	mashhad	120	\N	\N	16000000	{"mid": "اجاره: ۱۶,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در بهارستان", "amounts": {"اجاره": 16000000}}	\N
1912	divar	ga7GFIfi	۱۳۰متری صفر/رحمانیه ۲۹  فول نصبیجات /مسکن دربار	الهیه	\N	rent	44	https://divar.ir/v/_/ga7GFIfi	2026-09-30 13:19:29.638097+00	2026-09-30 13:23:40.745757+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن دربار در الهیه", "amounts": {}}	\N
1919	divar	ga0aSD7h	آپارتمان ۱۳۰ متری مهدی نیا	جانباز	9500000000	sale	\N	https://divar.ir/v/_/ga0aSD7h	2026-09-23 19:19:19.110721+00	2026-09-30 13:33:50.519638+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جانباز", "amounts": {"raw_amount": 9500000000}}	\N
1920	divar	ga9-gnsQ	فروشی دوطبقه ویلایی ماشین رو	شهید معقول	3700000000	sale	\N	https://divar.ir/v/_/ga9-gnsQ	2026-09-30 13:33:34.178283+00	2026-09-30 13:33:50.525612+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید معقول", "amounts": {"raw_amount": 3700000000}}	\N
1921	divar	gav9phVR	حسابی جنوبی ۱۱	حسابی جنوبی (شهرک غرب)	13500000000	sale	38	https://divar.ir/v/_/gav9phVR	2026-09-30 13:32:27.619575+00	2026-09-30 13:33:50.531273+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن جوینده در حسابی جنوبی (شهرک غرب)", "amounts": {"raw_amount": 13500000000}}	\N
1922	divar	ga9-ANMd	آپارتمان فروشی سیدی قائم۳۶	کوی ولیعصر	4450000000	sale	\N	https://divar.ir/v/_/ga9-ANMd	2026-09-30 13:32:25.76013+00	2026-09-30 13:33:50.535682+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۴۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی ولیعصر", "amounts": {"raw_amount": 4450000000}}	\N
1923	divar	ga9uwp_2	۱۶۰متربنا باپارکینگ دوطبقه	شهید بصیر	5000000000	sale	\N	https://divar.ir/v/_/ga9uwp_2	2026-09-30 13:31:51.271751+00	2026-09-30 13:33:50.541525+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید بصیر", "amounts": {"raw_amount": 5000000000}}	\N
1924	divar	ga9-QI-H	آپارتمان مجیدیه ۴۹	جاهد شهر	15840000000	sale	41	https://divar.ir/v/_/ga9-QI-H	2026-09-30 13:31:45.138748+00	2026-09-30 13:33:50.544898+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۵,۸۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"raw_amount": 15840000000}}	\N
1925	divar	ga96wWnX	اپارتمان۱۰۸متر پیامبر اعظم ۴۹	توس (بلوار توس)	6800000000	sale	\N	https://divar.ir/v/_/ga96wWnX	2026-09-30 13:31:03.203805+00	2026-09-30 13:33:50.547571+00	\N	\N	\N	mashhad	108	\N	\N	\N	{"mid": "۶,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {"raw_amount": 6800000000}}	\N
1927	divar	ga9yQmAq	آپارتمان فروشی	امیر	10500000000	sale	\N	https://divar.ir/v/_/ga9yQmAq	2026-09-30 13:30:05.167159+00	2026-09-30 13:33:50.5511+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیر", "amounts": {"raw_amount": 10500000000}}	\N
1928	divar	ga7qVNoT	۱۷۸ متری تکواحدی اول الهیه	الهیه	21000000000	sale	44	https://divar.ir/v/_/ga7qVNoT	2026-09-30 13:29:40.406829+00	2026-09-30 13:33:50.552823+00	\N	\N	\N	mashhad	178	\N	\N	\N	{"mid": "۲۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 21000000000}}	\N
1930	divar	ga5-_j3M	آپارتمان ۱۰۰متری دوخواب	توس (بلوار توس)	\N	rent	\N	https://divar.ir/v/_/ga5-_j3M	2026-09-28 05:48:11.761093+00	2026-09-30 13:33:50.556146+00	\N	\N	\N	mashhad	100	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "در توس (بلوار توس)", "amounts": {"اجاره": 7000000}}	\N
1931	divar	gaqSHzhU	رهن کامل ۱۰۵ متری شیک	امیریه	\N	rent	\N	https://divar.ir/v/_/gaqSHzhU	2026-09-29 08:36:58.247361+00	2026-09-30 13:33:50.558779+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در امیریه", "amounts": {}}	\N
1932	divar	ga6u0l07	آپارتمان 158متر /  بلوار کتاب/ تک واحدی	نیروی هوایی	\N	rent	\N	https://divar.ir/v/_/ga6u0l07	2026-09-30 13:32:23.625058+00	2026-09-30 13:33:50.561322+00	\N	\N	\N	mashhad	158	\N	\N	50000000	{"mid": "اجاره: ۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نیروی هوایی", "amounts": {"اجاره": 50000000}}	\N
1933	divar	ga9-wR0C	اپارتمان/۱۰۰متر/امام رضا/امکانات کامل/قوی	کوشش	\N	rent	\N	https://divar.ir/v/_/ga9-wR0C	2026-09-30 13:32:01.991971+00	2026-09-30 13:33:50.563292+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "رهن کامل", "bottom": "گروه کارشناسان مسکن اکبری در کوشش", "amounts": {}}	\N
1934	divar	ga7-d3L5	رهن اجاره منزل	کوی ولیعصر	\N	rent	\N	https://divar.ir/v/_/ga7-d3L5	2026-09-30 13:31:54.372132+00	2026-09-30 13:33:50.565112+00	\N	\N	\N	mashhad	\N	\N	\N	6500000	{"mid": "اجاره: ۶,۵۰۰,۰۰۰ تومان", "bottom": "در کوی ولیعصر", "amounts": {"اجاره": 6500000}}	\N
1935	divar	ga92Q2ZW	160 متری / جلال / LUXURY / بدون مالک	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga92Q2ZW	2026-09-30 13:31:38.728917+00	2026-09-30 13:33:50.566887+00	\N	\N	\N	mashhad	160	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "تیم تخصصی آریان  در آزادشهر", "amounts": {"اجاره": 5000000}}	\N
1936	divar	ga96QzFw	خونه ۷۵متری ۱خواب طبقه اول	نظام دوست	\N	rent	\N	https://divar.ir/v/_/ga96QzFw	2026-09-30 13:30:26.143131+00	2026-09-30 13:33:50.569285+00	\N	\N	\N	mashhad	75	1	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نظام دوست", "amounts": {"اجاره": 7000000}}	\N
1937	divar	ga96w2V0	۱۵۰ صفر ابتدای دانشجو مناسب جهیزیه زوج	دانشجو	\N	rent	39	https://divar.ir/v/_/ga96w2V0	2026-09-30 13:30:11.054487+00	2026-09-30 13:33:50.572089+00	\N	\N	\N	mashhad	\N	\N	\N	50000000	{"mid": "اجاره: ۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در دانشجو", "amounts": {"اجاره": 50000000}}	\N
1938	divar	ga96AaJK	اجاره سالانه سوئیت آپارتمان	دانش	\N	rent	\N	https://divar.ir/v/_/ga96AaJK	2026-09-30 13:28:54.856137+00	2026-09-30 13:33:50.574021+00	\N	\N	\N	mashhad	\N	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "دقایقی پیش در دانش", "amounts": {"اجاره": 1000}}	\N
1939	divar	ga96AFGZ	خانه دربست یا ویلایی	دانشجو	\N	rent	39	https://divar.ir/v/_/ga96AFGZ	2026-09-30 13:26:50.440149+00	2026-09-30 13:33:50.575858+00	\N	\N	\N	mashhad	\N	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در دانشجو", "amounts": {"اجاره": 40000000}}	\N
1940	divar	ga6a9W1n	مجتمع نسیم/واحد نقاشی میشود/۲خواب کمددیواری	امیریه	\N	rent	\N	https://divar.ir/v/_/ga6a9W1n	2026-09-30 13:26:47.842132+00	2026-09-30 13:33:50.578487+00	\N	\N	\N	mashhad	\N	2	\N	\N	{"mid": "رهن کامل", "bottom": "در امیریه", "amounts": {}}	\N
1941	divar	ga8iboiw	۹۵ متر / همکف / اول دانش اموز	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga8iboiw	2026-09-30 13:26:24.434392+00	2026-09-30 13:33:50.580754+00	\N	\N	\N	mashhad	95	\N	\N	100000000	{"mid": "اجاره: ۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگ", "amounts": {"اجاره": 100000000}}	\N
1944	divar	gavWpKvV	260 متری 3 خواب / 3 نبش / تک واحدی / پلان تفکیکی	الهیه	29000000000	sale	44	https://divar.ir/v/_/gavWpKvV	2026-09-20 12:00:53.250263+00	2026-10-01 07:51:45.975138+00	\N	\N	\N	mashhad	260	3	\N	\N	{"mid": "۲۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 29000000000}}	\N
1945	divar	ga3OOB3L	۱۰۰متر/صفر/شمالی سرجلو/اوایل رفیعی	نرگس (شهرک غرب)	11500000000	sale	38	https://divar.ir/v/_/ga3OOB3L	2026-10-01 07:51:32.974732+00	2026-10-01 07:51:45.981716+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن راد در نرگس (شهرک غرب)", "amounts": {"raw_amount": 11500000000}}	\N
1946	divar	garuYQ15	فرصت استثنایی/پیش فروش۱۰۰متری با شرایط خرید آسان	هفده شهریور	20000000000	sale	\N	https://divar.ir/v/_/garuYQ15	2026-10-01 07:51:31.816675+00	2026-10-01 07:51:45.987159+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۲۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفده شهریور", "amounts": {"raw_amount": 20000000000}}	\N
1947	divar	ga--w-eT	باغچه فروشی گنبد واز	گنبدواز	3300000000	sale	\N	https://divar.ir/v/_/ga--w-eT	2026-10-01 07:50:53.390647+00	2026-10-01 07:51:45.992313+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در گنبدواز", "amounts": {"raw_amount": 3300000000}}	\N
1948	divar	ga-Chl6x	آپارتمان طبقه اول دلباز و تمیز	انقلاب	4900000000	sale	\N	https://divar.ir/v/_/ga-Chl6x	2026-10-01 07:50:41.893539+00	2026-10-01 07:51:45.996393+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در انقلاب", "amounts": {"raw_amount": 4900000000}}	\N
1949	divar	ga-CxdYI	آپارتمان 70 متری کریمی 15	شهید مطهری	4970000000	sale	28	https://divar.ir/v/_/ga-CxdYI	2026-10-01 07:50:31.797155+00	2026-10-01 07:51:46.000053+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۴,۹۷۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید مطهری", "amounts": {"raw_amount": 4970000000}}	\N
1950	divar	ga9KEAhM	۱۰۰ متری صفر تا صد بازسازی تخلیه بلوار وکیل آباد	دانشجو	11200000000	sale	39	https://divar.ir/v/_/ga9KEAhM	2026-10-01 07:50:05.84811+00	2026-10-01 07:51:46.003582+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در دانشجو", "amounts": {"raw_amount": 11200000000}}	\N
1951	divar	ga-Chfjo	80متری طبقه دوم «قانع» بازسازی	تربیت (صدف)	8700000000	sale	\N	https://divar.ir/v/_/ga-Chfjo	2026-10-01 07:49:31.797974+00	2026-10-01 07:51:46.006649+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۸,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "اژانس اریا در تربیت (صدف)", "amounts": {"raw_amount": 8700000000}}	\N
1954	divar	ga8yKVto	۱۴۰متر/۳خواب/تکواحدی/آسانسور /هاشمیه	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga8yKVto	2026-10-01 07:51:12.960446+00	2026-10-01 07:51:46.014192+00	\N	\N	\N	mashhad	140	3	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "در چهارچشمه", "amounts": {"اجاره": 1000}}	\N
1955	divar	ga-CBs7H	همکف حیاط‌دار (هاشمیه)۷۰ متر + ۷۰ متر حیاط اختصاصی	کوثر	\N	rent	13	https://divar.ir/v/_/ga-CBs7H	2026-10-01 07:50:15.648195+00	2026-10-01 07:51:46.017409+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در کوثر", "amounts": {}}	\N
1956	divar	ga-CxkzF	خانه دربست اول شیخ صدوق ۷	حیدرآباد	\N	rent	\N	https://divar.ir/v/_/ga-CxkzF	2026-10-01 07:49:46.904207+00	2026-10-01 07:51:46.020362+00	\N	\N	\N	mashhad	\N	\N	\N	37000000	{"mid": "اجاره: ۳۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حیدرآباد", "amounts": {"اجاره": 37000000}}	\N
1957	divar	ga-CBYuU	اجاره سیانس بانوان	کوی المهدی	\N	rent	\N	https://divar.ir/v/_/ga-CBYuU	2026-10-01 07:49:06.510726+00	2026-10-01 07:51:46.024374+00	\N	\N	\N	mashhad	\N	\N	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی المهدی", "amounts": {"اجاره": 35000000}}	\N
1958	divar	ga32sbzn	آپارتمان 160متری/مدرن صفر لوکس/اول امامت مسکن الهی	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga32sbzn	2026-10-01 07:48:54.865484+00	2026-10-01 07:51:46.027991+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن   الهی    نبش امامت ۴۶ در آزادشهر", "amounts": {}}	\N
1960	divar	gaaO6-me	آپارتمان ۳ خواب حاشیه فکوری تقاطع صیاد شیرازی	هفت تیر (آب و برق)	\N	rent	\N	https://divar.ir/v/_/gaaO6-me	2026-10-01 07:48:17.693587+00	2026-10-01 07:51:46.034107+00	\N	\N	\N	mashhad	\N	3	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (آب و برق)", "amounts": {"اجاره": 30000000}}	\N
1961	divar	ga--AXuz	سوییت برای یک نفر خانم	امامیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga--AXuz	2026-10-01 07:47:56.380743+00	2026-10-01 07:51:46.037284+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امامیه (شهرک غرب)", "amounts": {"اجاره": 8000000}}	\N
1962	divar	ga-6Q98M	ویلایی دربست جلال۴۰ و۶خواب دفتر شرکت خوابگاه تخلیه	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga-6Q98M	2026-10-01 07:47:14.950653+00	2026-10-01 07:51:46.040776+00	\N	\N	\N	mashhad	\N	6	\N	55000000	{"mid": "اجاره: ۵۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آزادشهر", "amounts": {"اجاره": 55000000}}	\N
1963	divar	ga--wf1j	آپارتمان  150 متری جلال 44	سجاد شهر	\N	rent	21	https://divar.ir/v/_/ga--wf1j	2026-10-01 07:46:10.547873+00	2026-10-01 07:51:46.044689+00	\N	\N	\N	mashhad	150	\N	\N	46000000	{"mid": "اجاره: ۴۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سجاد شهر", "amounts": {"اجاره": 46000000}}	\N
1964	divar	ga-ORd6U	۱۱۵ متر / غرق نور /سند آماده / مدرن و بروز / صابری	الهیه	12300000000	sale	44	https://divar.ir/v/_/ga-ORd6U	2026-10-01 08:02:12.073709+00	2026-10-01 08:02:23.656813+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۱۲,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن میرشکاری در الهیه", "amounts": {"raw_amount": 12300000000}}	\N
1965	divar	ga-OBRVw	آپارتمان فروشی حاشیه دو خواب با آسانسور	ابوذر	5200000000	sale	24	https://divar.ir/v/_/ga-OBRVw	2026-10-01 08:01:57.675012+00	2026-10-01 08:02:23.668561+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در ابوذر", "amounts": {"raw_amount": 5200000000}}	\N
1966	divar	ga-ORV3r	129متـری- برند فاخر امیـر- حاشیه الهیـه	الهیه	15250000000	sale	44	https://divar.ir/v/_/ga-ORV3r	2026-10-01 08:01:35.975148+00	2026-10-01 08:02:23.675544+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۵,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 15250000000}}	\N
1967	divar	ga-OBKBh	125 متر خوش نقشه دونبش اوایل صیاد	هفت تیر (حافظ)	21500000000	sale	5	https://divar.ir/v/_/ga-OBKBh	2026-10-01 08:01:30.597257+00	2026-10-01 08:02:23.680254+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۲۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن طاهرنیا در هفت تیر (حافظ)", "amounts": {"raw_amount": 21500000000}}	\N
1968	divar	gauOsYEy	فروش آپارتمان .سحر..	انقلاب	4000000000	sale	\N	https://divar.ir/v/_/gauOsYEy	2026-10-01 08:01:18.130214+00	2026-10-01 08:02:23.685078+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری سپهری در انقلاب", "amounts": {"raw_amount": 4000000000}}	\N
1969	divar	gaRuUUWW	«ویلایی زشک استخردار+آبشار+معاوضه با طلا خودرو»	کلاهدوز	16000000000	sale	\N	https://divar.ir/v/_/gaRuUUWW	2026-10-01 08:00:59.874243+00	2026-10-01 08:02:23.690199+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کلاهدوز", "amounts": {"raw_amount": 16000000000}}	\N
1970	divar	gaXafY6o	فروش زمین۱۰۰۰متر،پروانه تسویه هاشمیه۴،حاشیه لاله	کوثر	670000000000	sale	13	https://divar.ir/v/_/gaXafY6o	2026-10-01 08:00:58.676498+00	2026-10-01 08:02:23.694229+00	\N	\N	\N	mashhad	1000	\N	\N	\N	{"mid": "۶۷۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مدیریت سید مجتبی آقائی شهری در کوثر", "amounts": {"raw_amount": 670000000000}}	\N
1971	divar	ga-sDuF0	زمین باغی فروشی، سند مادر ملکی، قواره ۴۸۰ متری	كنويست	385000000	sale	\N	https://divar.ir/v/_/ga-sDuF0	2026-10-01 08:00:26.210702+00	2026-10-01 08:02:23.698296+00	\N	\N	\N	mashhad	480	\N	\N	\N	{"mid": "۳۸۵,۰۰۰,۰۰۰ تومان", "bottom": "در كنويست", "amounts": {"raw_amount": 385000000}}	\N
1972	divar	ga6qRJgM	183متری الهیه۳خواب صفر تک واحدی /شخصی ساز	جاهد شهر	26500000000	sale	41	https://divar.ir/v/_/ga6qRJgM	2026-10-01 08:00:17.384553+00	2026-10-01 08:02:23.700892+00	\N	\N	\N	mashhad	183	3	\N	\N	{"mid": "۲۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 26500000000}}	\N
1973	divar	ga-KR-Lb	۱۱۴متر/ اقدسیه ۴۱/ برند سندآماده	الهیه	13000000000	sale	44	https://divar.ir/v/_/ga-KR-Lb	2026-10-01 08:00:07.285108+00	2026-10-01 08:02:23.704553+00	\N	\N	\N	mashhad	114	\N	\N	\N	{"mid": "۱۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن ممتاز ایران در الهیه", "amounts": {"raw_amount": 13000000000}}	\N
1974	divar	ga3CtpD1	اجاره  یک طبقه تا عید نوروز  به مجرد یا متاهل	سجادیه	\N	rent	21	https://divar.ir/v/_/ga3CtpD1	2026-09-30 16:59:47.967914+00	2026-10-01 08:02:23.708409+00	\N	\N	\N	mashhad	\N	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "در سجادیه", "amounts": {"اجاره": 12000000}}	\N
1975	divar	ga-OBL4D	170متر اپارتمان تک واحدی باهنر 6	کوثر	\N	rent	13	https://divar.ir/v/_/ga-OBL4D	2026-10-01 08:01:45.243669+00	2026-10-01 08:02:23.711991+00	\N	\N	\N	mashhad	170	\N	\N	55000000	{"mid": "اجاره: ۵۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در کوثر", "amounts": {"اجاره": 55000000}}	\N
1976	divar	gaySyoch	۱۷۰ متر /دانش آموز /مسکن الهی	دانشجو	\N	rent	39	https://divar.ir/v/_/gaySyoch	2026-10-01 08:00:53.857235+00	2026-10-01 08:02:23.716175+00	\N	\N	\N	mashhad	170	\N	\N	38000000	{"mid": "اجاره: ۳۸,۰۰۰,۰۰۰ تومان", "bottom": "مسکن   الهی    نبش امامت ۴۶ در دانشجو", "amounts": {"اجاره": 38000000}}	\N
1977	divar	ga9K07Yy	همخونه هم خونه میشم	جانباز	\N	rent	\N	https://divar.ir/v/_/ga9K07Yy	2026-10-01 07:59:51.974613+00	2026-10-01 08:02:23.720368+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "در جانباز", "amounts": {"اجاره": 15000000}}	\N
1978	divar	ga-KRo4L	سید رضی ۱۲/ ۱۶۵ طبقه دوم / ویلایی ۳ واحدی	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga-KRo4L	2026-10-01 07:58:35.36982+00	2026-10-01 08:02:23.724633+00	\N	\N	\N	mashhad	\N	\N	\N	32000000	{"mid": "اجاره: ۳۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگ", "amounts": {"اجاره": 32000000}}	\N
1979	divar	ga-KhNgH	رهن اجاره / تاپ لوکیشن / سروش / ۱۶۰ متر / ۳ خواب	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga-KhNgH	2026-10-01 07:57:19.488589+00	2026-10-01 08:02:23.728571+00	\N	\N	\N	mashhad	160	3	\N	70000000	{"mid": "اجاره: ۷۰,۰۰۰,۰۰۰ تومان", "bottom": "علیرضا نوری مسکن پارسا نبش صارمی ۲۹ در فرهنگ", "amounts": {"اجاره": 70000000}}	\N
1980	divar	gad6gvEC	140 متر پیروزی طبقه 4 فول شیک	سرافرازان	\N	rent	22	https://divar.ir/v/_/gad6gvEC	2026-10-01 07:56:16.259885+00	2026-10-01 08:02:23.733261+00	\N	\N	\N	mashhad	140	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در سرافرازان", "amounts": {}}	\N
1981	divar	gaEqmORm	آپارتمان  صفر واقع در صیاد شیرازی 14	هفت تیر (حافظ)	23500000000	sale	5	https://divar.ir/v/_/gaEqmORm	2026-09-18 16:00:33.004711+00	2026-10-01 08:12:35.531397+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (حافظ)", "amounts": {"raw_amount": 23500000000}}	\N
1982	divar	ga5WVvJD	واحد صـفر / ۱۰۵متری /۲ ماه تحویـل/ هاشمی مهنه	فرهنگیان (شهرک غرب)	13600000000	sale	37	https://divar.ir/v/_/ga5WVvJD	2026-10-01 08:12:19.864342+00	2026-10-01 08:12:35.549268+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۳,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن دایان نبش فلاحی ۱۳٫۳ در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 13600000000}}	\N
1983	divar	gaYa1xRH	۳ واحد آپارتمان بعد آموزگار ( معاوضه با ویلایی )	آزادشهر	22500000000	sale	\N	https://divar.ir/v/_/gaYa1xRH	2026-10-01 08:12:19.228576+00	2026-10-01 08:12:35.553847+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بامک بین امامت ۳۶و۳۸ در آزادشهر", "amounts": {"raw_amount": 22500000000}}	\N
1984	divar	ga-Wxuh6	زمین ۳۰۰، ۵۰۰ و ۸۰۰ متری منزل‌آباد داخل بافت	منزل آباد	7000000000	sale	\N	https://divar.ir/v/_/ga-Wxuh6	2026-10-01 08:12:18.528823+00	2026-10-01 08:12:35.557748+00	\N	\N	\N	mashhad	800	\N	\N	\N	{"mid": "۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در منزل آباد", "amounts": {"raw_amount": 7000000000}}	\N
1985	divar	ga7im7pD	قـلب پارک ملـت / به خونه خودت خوش اومدی	آزادشهر	31500000000	sale	\N	https://divar.ir/v/_/ga7im7pD	2026-10-01 08:12:08.519047+00	2026-10-01 08:12:35.566144+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بامک بین امامت ۳۶و۳۸ در آزادشهر", "amounts": {"raw_amount": 31500000000}}	\N
1986	divar	gaepfsg9	طبقه دوم و سوم  طبرسی جنوبی اخرفتاح حاشیه صدمتری	رسالت	4500000000	sale	32	https://divar.ir/v/_/gaepfsg9	2026-10-01 08:12:07.401946+00	2026-10-01 08:12:35.570102+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رسالت", "amounts": {"raw_amount": 4500000000}}	\N
1987	divar	gayOfrJT	۷۳ متر آپارتمان خوش نقشه و تخلیه/ رفیعی ۱۰	نرگس (شهرک غرب)	7350000000	sale	38	https://divar.ir/v/_/gayOfrJT	2026-10-01 08:11:58.393957+00	2026-10-01 08:12:35.599988+00	\N	\N	\N	mashhad	73	\N	\N	\N	{"mid": "۷,۳۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن راد در نرگس (شهرک غرب)", "amounts": {"raw_amount": 7350000000}}	\N
1988	divar	ga-WRhXw	۹۳ متری داخل مجتمع	مهدی آباد (بلوار توس)	6200000000	sale	\N	https://divar.ir/v/_/ga-WRhXw	2026-10-01 08:11:47.801637+00	2026-10-01 08:12:35.603685+00	\N	\N	\N	mashhad	93	\N	\N	\N	{"mid": "۶,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در مهدی آباد (بلوار توس)", "amounts": {"raw_amount": 6200000000}}	\N
1989	divar	ga8qM48l	آپارتمان ۱۰۵متر /تهاتر / فروش /مسکن الهی	امیریه	9500000000	sale	\N	https://divar.ir/v/_/ga8qM48l	2026-10-01 08:11:07.426014+00	2026-10-01 08:12:35.611112+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن   الهی    نبش امامت ۴۶ در امیریه", "amounts": {"raw_amount": 9500000000}}	\N
1990	divar	gaMlbwJE	۷۸ متر سجادیه اوایل ۶ سند آماده	الهیه	6880000000	sale	44	https://divar.ir/v/_/gaMlbwJE	2026-10-01 08:11:06.638607+00	2026-10-01 08:12:35.614739+00	\N	\N	\N	mashhad	78	\N	\N	\N	{"mid": "۶,۸۸۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 6880000000}}	\N
1991	divar	ga5WQdiY	همخونه	احمدآباد	\N	rent	\N	https://divar.ir/v/_/ga5WQdiY	2026-09-27 12:04:37.755097+00	2026-10-01 08:12:35.61832+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در احمدآباد", "amounts": {"اجاره": 10000000}}	\N
1993	divar	ga-WRkJZ	آپارتمان 100 متری ،فکوری	رضاشهر	\N	rent	\N	https://divar.ir/v/_/ga-WRkJZ	2026-10-01 08:12:30.366749+00	2026-10-01 08:12:35.624405+00	\N	\N	\N	mashhad	100	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "محمد مقدم در رضاشهر", "amounts": {"اجاره": 10000000}}	\N
1994	divar	ga3eKcRN	آپارتمان اداری	سجاد شهر	\N	rent	21	https://divar.ir/v/_/ga3eKcRN	2026-10-01 08:12:15.888941+00	2026-10-01 08:12:35.627557+00	\N	\N	\N	mashhad	\N	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "در سجاد شهر", "amounts": {"اجاره": 25000000}}	\N
1995	divar	ga-WRk8A	اپارتمان 81 متری کلا 6 واحد	الهیه	\N	rent	44	https://divar.ir/v/_/ga-WRk8A	2026-10-01 08:11:08.096751+00	2026-10-01 08:12:35.630695+00	\N	\N	\N	mashhad	81	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن باران الهیه ۳۴ در الهیه", "amounts": {}}	\N
1996	divar	gaWO54XT	آپارتمان نوساز/190متر/3خواب	فرهنگ	\N	rent	\N	https://divar.ir/v/_/gaWO54XT	2026-10-01 08:10:34.112869+00	2026-10-01 08:12:35.634551+00	\N	\N	\N	mashhad	190	3	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "در فرهنگ", "amounts": {"اجاره": 100000}}	\N
1997	divar	ga-WBD9y	رهن و اجاره ۹۵متر طبقه اول قاسم آباد ادیب۵۱،اندیشه	مشکینی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-WBD9y	2026-10-01 08:09:01.985965+00	2026-10-01 08:12:35.63828+00	\N	\N	\N	mashhad	95	\N	\N	19000000	{"mid": "اجاره: ۱۹,۰۰۰,۰۰۰ تومان", "bottom": "مدیریت سید مجتبی آقائی شهری در مشکینی (شهرک غرب)", "amounts": {"اجاره": 19000000}}	\N
1998	divar	ga-SR9EC	رهن آپارتمان	طبرسی شمالی	\N	rent	42	https://divar.ir/v/_/ga-SR9EC	2026-10-01 08:08:34.555556+00	2026-10-01 08:12:35.641715+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {"اجاره": 100000}}	\N
1999	divar	ga7q2rM4	۲۳۰متر آموزگار / ویو ابدی	فرهنگ	\N	rent	\N	https://divar.ir/v/_/ga7q2rM4	2026-10-01 08:08:23.570749+00	2026-10-01 08:12:35.645409+00	\N	\N	\N	mashhad	230	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "در فرهنگ", "amounts": {"اجاره": 1000000}}	\N
2000	divar	gaz2P4XS	آپارتمان  نوساز 160متری 3خواب	کوثر	\N	rent	13	https://divar.ir/v/_/gaz2P4XS	2026-10-01 08:08:13.472017+00	2026-10-01 08:12:35.648932+00	\N	\N	\N	mashhad	160	3	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "در کوثر", "amounts": {"اجاره": 100000}}	\N
2001	divar	ga-SxsFT	رهن و اجاره آپارتمان یوسفیه	یوسفیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-SxsFT	2026-10-01 08:08:00.782756+00	2026-10-01 08:12:35.652473+00	\N	\N	\N	mashhad	\N	\N	\N	9000000	{"mid": "اجاره: ۹,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در یوسفیه (شهرک غرب)", "amounts": {"اجاره": 9000000}}	\N
2002	divar	ga0yA2hP	آپارتمان/160متری/3خواب	کوثر	\N	rent	13	https://divar.ir/v/_/ga0yA2hP	2026-10-01 08:07:42.641006+00	2026-10-01 08:12:35.656266+00	\N	\N	\N	mashhad	160	3	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوثر", "amounts": {"اجاره": 30000000}}	\N
2003	divar	ga-SBo2W	رهن و اجاره آپارتمان ۸۰ متری  دو خوابه	چهنو	\N	rent	\N	https://divar.ir/v/_/ga-SBo2W	2026-10-01 08:07:05.807305+00	2026-10-01 08:12:35.659962+00	\N	\N	\N	mashhad	80	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهنو", "amounts": {"اجاره": 15000000}}	\N
2004	divar	gawyOccl	تک واحدی ط اول سر دونبش	رستگار	\N	rent	\N	https://divar.ir/v/_/gawyOccl	2026-10-01 08:06:54.795021+00	2026-10-01 08:12:35.663767+00	\N	\N	\N	mashhad	\N	\N	\N	9000000	{"mid": "اجاره: ۹,۰۰۰,۰۰۰ تومان", "bottom": "در رستگار", "amounts": {"اجاره": 9000000}}	\N
2005	divar	ga1ygR1a	۴۰۰ متر باغ داخل مجتمع	لقمانی	1100000000	sale	\N	https://divar.ir/v/_/ga1ygR1a	2026-09-28 08:59:33.975259+00	2026-10-01 08:23:16.633948+00	\N	\N	\N	mashhad	400	\N	\N	\N	{"mid": "۱,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در لقمانی", "amounts": {"raw_amount": 1100000000}}	\N
2006	divar	ga52iM1e	اپارتمان ۸۶ متری سند دار	جاهد شهر	8100000000	sale	41	https://divar.ir/v/_/ga52iM1e	2026-10-01 08:23:04.928743+00	2026-10-01 08:23:16.652724+00	\N	\N	\N	mashhad	86	\N	\N	\N	{"mid": "۸,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 8100000000}}	\N
2007	divar	ga-iBLyS	آپارتمان ۸۴ متری	تربیت (صدف)	10500000000	sale	\N	https://divar.ir/v/_/ga-iBLyS	2026-10-01 08:22:58.40159+00	2026-10-01 08:23:16.657993+00	\N	\N	\N	mashhad	84	\N	\N	\N	{"mid": "۱۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در تربیت (صدف)", "amounts": {"raw_amount": 10500000000}}	\N
2008	divar	ga-iRVFK	واحد های 60 متری / صفر/ پارکینگ اختصاصی	وحید	4150000000	sale	33	https://divar.ir/v/_/ga-iRVFK	2026-10-01 08:22:54.00311+00	2026-10-01 08:23:16.66362+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۴,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در وحید", "amounts": {"raw_amount": 4150000000}}	\N
2009	divar	ga-ixT1Q	برند منطقه/ورودی مجلل (منتجبی)	الهیه	16500000000	sale	44	https://divar.ir/v/_/ga-ixT1Q	2026-10-01 08:22:53.12248+00	2026-10-01 08:23:16.667537+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 16500000000}}	\N
2010	divar	ga-aB4SO	آپارتمان در مسلم جنوبی	فاطمیه	3500000000	sale	30	https://divar.ir/v/_/ga-aB4SO	2026-10-01 08:22:52.976347+00	2026-10-01 08:23:16.671919+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در فاطمیه", "amounts": {"raw_amount": 3500000000}}	\N
2011	divar	ga-ehjr7	آپارتمان 157متری پیروزی	سرافرازان	21200000000	sale	22	https://divar.ir/v/_/ga-ehjr7	2026-10-01 08:22:45.188175+00	2026-10-01 08:23:16.67669+00	\N	\N	\N	mashhad	157	\N	\N	\N	{"mid": "۲۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در سرافرازان", "amounts": {"raw_amount": 21200000000}}	\N
2012	divar	ga-ixOHX	واحد آپارتمان 90متری	ایثارگران	5900000000	sale	\N	https://divar.ir/v/_/ga-ixOHX	2026-10-01 08:22:43.025622+00	2026-10-01 08:23:16.680475+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۵,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در ایثارگران", "amounts": {"raw_amount": 5900000000}}	\N
2013	divar	ga06Ne9M	فروش آپارتمان	الهیه	6000000000	sale	44	https://divar.ir/v/_/ga06Ne9M	2026-10-01 08:22:32.377941+00	2026-10-01 08:23:16.684477+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 6000000000}}	\N
2014	divar	ga-iRCfQ	فروش آپارتمان دونبش الهیه ، رحمانیه	جاهد شهر	10000000000	sale	41	https://divar.ir/v/_/ga-iRCfQ	2026-10-01 08:22:23.010349+00	2026-10-01 08:23:16.688175+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پامچال در جاهد شهر", "amounts": {"raw_amount": 10000000000}}	\N
2015	divar	ga-ex7lI	آپارتمان بی نظیر  در دندانپزشکان	تربیت (صدف)	18390000000	sale	\N	https://divar.ir/v/_/ga-ex7lI	2026-10-01 08:22:01.070498+00	2026-10-01 08:23:16.692355+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۸,۳۹۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در تربیت (صدف)", "amounts": {"raw_amount": 18390000000}}	\N
2016	divar	ga-eh-kW	آپارتمان ۹۳متری/حسابی شمالی/۴واحدی	فرهنگیان (شهرک غرب)	9300000000	sale	37	https://divar.ir/v/_/ga-eh-kW	2026-10-01 08:21:40.793897+00	2026-10-01 08:23:16.696561+00	\N	\N	\N	mashhad	93	\N	\N	\N	{"mid": "۹,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 9300000000}}	\N
2017	divar	ga-aB4Tg	آپارتمان /93متری/واقع در کوهسنگی اداری تجاری	کوه سنگی	15500000000	sale	\N	https://divar.ir/v/_/ga-aB4Tg	2026-10-01 08:21:24.939394+00	2026-10-01 08:23:16.700361+00	\N	\N	\N	mashhad	93	\N	\N	\N	{"mid": "۱۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوه سنگی", "amounts": {"raw_amount": 15500000000}}	\N
2018	divar	ga-SR-Xe	۸۴متر/لوکیشن تاپ/فول	حسابی جنوبی (شهرک غرب)	8300000000	sale	38	https://divar.ir/v/_/ga-SR-Xe	2026-10-01 08:21:17.015598+00	2026-10-01 08:23:16.704576+00	\N	\N	\N	mashhad	84	\N	\N	\N	{"mid": "۸,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بهار در حسابی جنوبی (شهرک غرب)", "amounts": {"raw_amount": 8300000000}}	\N
2022	divar	ga-eRhsn	خانه  رهن اجاره مهرگان	شهید شهریاری	\N	rent	\N	https://divar.ir/v/_/ga-eRhsn	2026-10-01 08:21:10.081757+00	2026-10-01 08:23:16.715823+00	\N	\N	\N	mashhad	\N	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید شهریاری", "amounts": {"اجاره": 6000000}}	\N
2023	divar	ga7GPpL7	اجاره خانه ۶۰ متر تک خواب	شهرک امام هادی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga7GPpL7	2026-10-01 08:20:47.046124+00	2026-10-01 08:23:16.719775+00	\N	\N	\N	mashhad	60	\N	\N	5800000	{"mid": "اجاره: ۵,۸۰۰,۰۰۰ تومان", "bottom": "در شهرک امام هادی (شهرک غرب)", "amounts": {"اجاره": 5800000}}	\N
2024	divar	ga-eBVu2	230متر/بازسازی/اجاره	سجاد شهر	\N	rent	21	https://divar.ir/v/_/ga-eBVu2	2026-10-01 08:19:46.994839+00	2026-10-01 08:23:16.723669+00	\N	\N	\N	mashhad	230	\N	\N	\N	{"mid": "رهن کامل", "bottom": "محمدی در سجاد شهر", "amounts": {}}	\N
2025	divar	ga-aR4SK	۱۶۰متری/سه خواب+مستر/تک‌واحدی‌خلوت/سید‌رضی‌معلم	سید رضی	\N	rent	\N	https://divar.ir/v/_/ga-aR4SK	2026-10-01 08:19:38.524727+00	2026-10-01 08:23:16.727552+00	\N	\N	\N	mashhad	160	\N	\N	50000000	{"mid": "اجاره: ۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سراسری بیهق در سید رضی", "amounts": {"اجاره": 50000000}}	\N
2026	divar	ga-exVKv	شاهد ۶۶ / فول امکانات/ بازسازی شده	مشکینی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-exVKv	2026-10-01 08:19:30.314858+00	2026-10-01 08:23:16.731431+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن طاها در مشکینی (شهرک غرب)", "amounts": {}}	\N
2027	divar	ga3OOw8Y	اپارتمان ۱۹۰ متری فرامرز عباسی	شهید فرامرز عباسی	\N	rent	\N	https://divar.ir/v/_/ga3OOw8Y	2026-10-01 08:18:33.120735+00	2026-10-01 08:23:16.735427+00	\N	\N	\N	mashhad	190	\N	\N	60000000	{"mid": "اجاره: ۶۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید فرامرز عباسی", "amounts": {"اجاره": 60000000}}	\N
2028	divar	ga-exD7q	۱۶۵ ویلایی دو طبقه مجزا چهارراه مخابرات	ولیعصر (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-exD7q	2026-10-01 08:17:54.075659+00	2026-10-01 08:23:16.739571+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در ولیعصر (شهرک غرب)", "amounts": {}}	\N
2029	divar	ga-aBihJ	110 متر دو خواب کشاورز 1	نوید	\N	rent	\N	https://divar.ir/v/_/ga-aBihJ	2026-10-01 08:17:33.2044+00	2026-10-01 08:23:16.743483+00	\N	\N	\N	mashhad	110	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوید", "amounts": {"اجاره": 10000000}}	\N
2030	divar	ga-aRkBS	آ‌پارتمان تک واحدی۳خواب مملو نور	امیریه	\N	rent	\N	https://divar.ir/v/_/ga-aRkBS	2026-10-01 08:17:05.577128+00	2026-10-01 08:23:16.747492+00	\N	\N	\N	mashhad	\N	3	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "مسکن فرخی الهیه بین علویه۲۱و۲۳ در امیریه", "amounts": {"اجاره": 3000000}}	\N
2031	divar	ga-ax46h	آپارتمان ۱۰۰ متری هاشمیه ۱۴	کوثر	\N	rent	13	https://divar.ir/v/_/ga-ax46h	2026-10-01 08:17:03.431013+00	2026-10-01 08:23:16.751588+00	\N	\N	\N	mashhad	100	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 5000000}}	\N
2032	divar	ga9ai9WA	آپارتمان ۶۰ متری حاشیه مطهری ۳۶	شهید مطهری	4950000000	sale	28	https://divar.ir/v/_/ga9ai9WA	2026-10-01 08:33:13.728822+00	2026-10-01 08:33:38.004091+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۴,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "محمد قره باغی در شهید مطهری", "amounts": {"raw_amount": 4950000000}}	\N
2033	divar	gasCeQdI	۱۶۰متر سیدرضی قبل آموزگار آخرین واحد/مسکن الهی	سید رضی	26000000000	sale	\N	https://divar.ir/v/_/gasCeQdI	2026-10-01 08:32:22.78108+00	2026-10-01 08:33:38.018915+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۲۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن   الهی    نبش امامت ۴۶ در سید رضی", "amounts": {"raw_amount": 26000000000}}	\N
2034	divar	ga-qhXyY	۲۶۰ متر سجاد بدون مشابه/ مقطوع ۷۸ تومن	سجاد شهر	78000000000	sale	21	https://divar.ir/v/_/ga-qhXyY	2026-10-01 08:31:44.901632+00	2026-10-01 08:33:38.023598+00	\N	\N	\N	mashhad	260	\N	\N	\N	{"mid": "۷۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سجاد شهر", "amounts": {"raw_amount": 78000000000}}	\N
2035	divar	galeEP_x	105 متر نوساز با پارکینگ و آسانسور	توس (بلوار توس)	5150000000	sale	\N	https://divar.ir/v/_/galeEP_x	2026-10-01 08:30:57.782757+00	2026-10-01 08:33:38.02913+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۵,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس (بلوار توس)", "amounts": {"raw_amount": 5150000000}}	\N
2036	divar	ga-mhzm9	فروش چندین واحد آپارتمان در محدوده سرافرازان وغیره	سرافرازان	5500000000	sale	22	https://divar.ir/v/_/ga-mhzm9	2026-10-01 08:30:38.272733+00	2026-10-01 08:33:38.03482+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سرافرازان", "amounts": {"raw_amount": 5500000000}}	\N
2037	divar	ga-qBVwU	بهارستان ۱۸ / ۱۸۸ متری / طبقه اول	سجاد شهر	\N	rent	21	https://divar.ir/v/_/ga-qBVwU	2026-10-01 08:32:41.322338+00	2026-10-01 08:33:38.039881+00	\N	\N	\N	mashhad	188	\N	\N	60000000	{"mid": "اجاره: ۶۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در سجاد شهر", "amounts": {"اجاره": 60000000}}	\N
2038	divar	ga36t7Wm	۶۰متر ۱خواب محمدیه۱۸ مجرد/ متاهل	الهیه	\N	rent	44	https://divar.ir/v/_/ga36t7Wm	2026-10-01 08:32:05.490777+00	2026-10-01 08:33:38.044756+00	\N	\N	\N	mashhad	60	1	\N	13500000	{"mid": "اجاره: ۱۳,۵۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"اجاره": 13500000}}	\N
2039	divar	ga-qBVl0	۹۰متر/فول امکانات/طبقه۳	شهرک لشکر (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-qBVl0	2026-10-01 08:31:25.279651+00	2026-10-01 08:33:38.050189+00	\N	\N	\N	mashhad	90	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بهار در شهرک لشکر (شهرک غرب)", "amounts": {"اجاره": 25000000}}	\N
2040	divar	ga-mxfcV	بهاران طبقه دوم	بهاران	\N	rent	17	https://divar.ir/v/_/ga-mxfcV	2026-10-01 08:28:01.083378+00	2026-10-01 08:33:38.056696+00	\N	\N	\N	mashhad	\N	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهاران", "amounts": {"اجاره": 20000000}}	\N
2041	divar	gapek_fN	رهن و اجاره - طبقه اول - کشف - شقایق ۱۸ - بنفشه ۱۴	کشف	\N	rent	\N	https://divar.ir/v/_/gapek_fN	2026-10-01 08:27:37.295358+00	2026-10-01 08:33:38.062941+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "در کشف", "amounts": {"اجاره": 8000000}}	\N
2042	divar	ga-eRGIj	۱۱۰ متر آپارتمان طبقه اول رهن ۲۰۰ اجاره ۱۵/ هدایت	هنرور	\N	rent	\N	https://divar.ir/v/_/ga-eRGIj	2026-10-01 08:26:44.451773+00	2026-10-01 08:33:38.068727+00	\N	\N	\N	mashhad	110	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"اجاره": 15000000}}	\N
2043	divar	garmqS0p	۱۷۰ متر صفر مدرن جنوبی / امامت ۱۵ یا آزادی ۱۸	آزادشهر	\N	rent	\N	https://divar.ir/v/_/garmqS0p	2026-10-01 08:26:28.3785+00	2026-10-01 08:33:38.073428+00	\N	\N	\N	mashhad	170	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در آزادشهر", "amounts": {"اجاره": 30000000}}	\N
2044	divar	ga-ax00P	اپارتمان	حضرت حجت	\N	rent	\N	https://divar.ir/v/_/ga-ax00P	2026-10-01 08:25:38.078422+00	2026-10-01 08:33:38.077794+00	\N	\N	\N	mashhad	\N	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "دقایقی پیش در حضرت حجت", "amounts": {"اجاره": 1000}}	\N
2045	divar	gaqOkNpu	ویلایی نقلی کاریاسکونت فکوری۱۳ دربست پارکینگ ۱خواب	هفت تیر (آب و برق)	\N	rent	\N	https://divar.ir/v/_/gaqOkNpu	2026-10-01 08:25:26.343585+00	2026-10-01 08:33:38.08244+00	\N	\N	\N	mashhad	\N	1	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (آب و برق)", "amounts": {"اجاره": 15000000}}	\N
2046	divar	ga-eBz4j	۸۰ متری / هاشمیه/ یک خواب	کوثر	\N	rent	13	https://divar.ir/v/_/ga-eBz4j	2026-10-01 08:24:37.674976+00	2026-10-01 08:33:38.086652+00	\N	\N	\N	mashhad	80	\N	\N	28000000	{"mid": "اجاره: ۲۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 28000000}}	\N
2047	divar	ga-iRp-g	امامت / 100متری / دو خواب	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga-iRp-g	2026-10-01 08:24:26.279684+00	2026-10-01 08:33:38.09097+00	\N	\N	\N	mashhad	100	\N	\N	45000000	{"mid": "اجاره: ۴۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بامک بین امامت ۳۶و۳۸ در آزادشهر", "amounts": {"اجاره": 45000000}}	\N
2048	divar	ga0q8PbU	ویلایی کوچک فکوری۱۳ دربست ومستقل تخلیه یک خواب	هفت تیر (آب و برق)	\N	rent	\N	https://divar.ir/v/_/ga0q8PbU	2026-10-01 08:23:41.988396+00	2026-10-01 08:33:38.09517+00	\N	\N	\N	mashhad	\N	\N	\N	15200000	{"mid": "اجاره: ۱۵,۲۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (آب و برق)", "amounts": {"اجاره": 15200000}}	\N
2049	divar	gat9LfY0	فروش واحد آپارتمان	مقدم	15000000000	sale	\N	https://divar.ir/v/_/gat9LfY0	2026-10-01 08:43:57.821902+00	2026-10-01 08:44:11.944156+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در مقدم", "amounts": {"raw_amount": 15000000000}}	\N
2050	divar	ga-2RPg2	۱۲۰ متری /سند آماده/ مخصوص لوکس پسندان	الهیه	12900000000	sale	44	https://divar.ir/v/_/ga-2RPg2	2026-10-01 08:43:57.31849+00	2026-10-01 08:44:11.964542+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۱۲,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 12900000000}}	\N
2051	divar	ga-2xHyc	۱۶۳ متر/تک واحدی/بدون مشرفیت	امیریه	15950000000	sale	\N	https://divar.ir/v/_/ga-2xHyc	2026-10-01 08:43:47.838584+00	2026-10-01 08:44:11.976501+00	\N	\N	\N	mashhad	163	\N	\N	\N	{"mid": "۱۵,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیریه", "amounts": {"raw_amount": 15950000000}}	\N
2052	divar	ga-2xDBq	اپارتمان ۱۲۸مترسه خواب ثامن الاعمه ۱۲سال ساخت۲۵سال	امام خمینی	12500000000	sale	\N	https://divar.ir/v/_/ga-2xDBq	2026-10-01 08:43:47.404668+00	2026-10-01 08:44:11.987459+00	\N	\N	\N	mashhad	128	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در امام خمینی", "amounts": {"raw_amount": 12500000000}}	\N
2053	divar	ga-yxztd	فروش واحد آپارتمان سیدرضی دو خواب شیک	فرهنگ	14700000000	sale	\N	https://divar.ir/v/_/ga-yxztd	2026-10-01 08:43:39.067553+00	2026-10-01 08:44:11.996003+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۴,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در فرهنگ", "amounts": {"raw_amount": 14700000000}}	\N
2054	divar	ga-yBSnu	ویلایی نمایشگاه/ ۲۰۰ متری / سکونت و سرمایه گذاری	فارغ التحصیلان	40000000000	sale	\N	https://divar.ir/v/_/ga-yBSnu	2026-10-01 08:43:35.727409+00	2026-10-01 08:44:12.007077+00	\N	\N	\N	mashhad	200	\N	\N	\N	{"mid": "۴۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در فارغ التحصیلان", "amounts": {"raw_amount": 40000000000}}	\N
2055	divar	ga-yxdlP	آپارتمان 76.5متری/رسالت 81/شهرک امید دو خواب	سیس‌آباد	4500000000	sale	\N	https://divar.ir/v/_/ga-yxdlP	2026-10-01 08:41:34.452985+00	2026-10-01 08:44:12.019163+00	\N	\N	\N	mashhad	5	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سیس‌آباد", "amounts": {"raw_amount": 4500000000}}	\N
2056	divar	ga-yhPzC	80 متری فقط نقد همکاری دارم	الهیه	6950000000	sale	44	https://divar.ir/v/_/ga-yhPzC	2026-10-01 08:41:33.14776+00	2026-10-01 08:44:12.030708+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۶,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 6950000000}}	\N
2057	divar	ga-yRBbo	یک واحد آپارتمان ۱۰۰ متری	امیریه	3200000000	sale	\N	https://divar.ir/v/_/ga-yRBbo	2026-10-01 08:41:20.288929+00	2026-10-01 08:44:12.038109+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیریه", "amounts": {"raw_amount": 3200000000}}	\N
2058	divar	ga-yh-er	۱۰۰ متر طبقه چهارم دو خواب با اسانسور فرامرز ۲۹	شهید فرامرز عباسی	\N	rent	\N	https://divar.ir/v/_/ga-yh-er	2026-10-01 08:43:53.963571+00	2026-10-01 08:44:12.045513+00	\N	\N	\N	mashhad	100	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهید فرامرز عباسی", "amounts": {"اجاره": 12000000}}	\N
2059	divar	ga6ein92	همخونه	عامل	\N	rent	\N	https://divar.ir/v/_/ga6ein92	2026-10-01 08:43:39.676926+00	2026-10-01 08:44:12.050942+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "در عامل", "amounts": {"اجاره": 10000}}	\N
2060	divar	ga-yht11	منزل ویلایی دربست	رسالت	\N	rent	32	https://divar.ir/v/_/ga-yht11	2026-10-01 08:42:02.533125+00	2026-10-01 08:44:12.056306+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رسالت", "amounts": {"اجاره": 10000}}	\N
2061	divar	ga-yBfFZ	۱۵۰ متر همکف تابان هنرستان	هنرستان	\N	rent	11	https://divar.ir/v/_/ga-yBfFZ	2026-10-01 08:41:53.778237+00	2026-10-01 08:44:12.061713+00	\N	\N	\N	mashhad	150	\N	\N	45000000	{"mid": "اجاره: ۴۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرستان", "amounts": {"اجاره": 45000000}}	\N
2062	divar	ga-yBjUc	110متری 6واحدی 3 نبش تمام نور حجاب 92	حجاب (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-yBjUc	2026-10-01 08:41:36.314738+00	2026-10-01 08:44:12.066784+00	\N	\N	\N	mashhad	110	\N	\N	14000000	{"mid": "اجاره: ۱۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حجاب (شهرک غرب)", "amounts": {"اجاره": 14000000}}	\N
2063	divar	ga-qw5ct	۱۶۰متر + امامت نزدیک حاشیه + گریدA+	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga-qw5ct	2026-10-01 08:40:36.315414+00	2026-10-01 08:44:12.072088+00	\N	\N	\N	mashhad	160	\N	\N	75000000	{"mid": "اجاره: ۷۵,۰۰۰,۰۰۰ تومان", "bottom": "تیم تخصصی آریان  در آزادشهر", "amounts": {"اجاره": 75000000}}	\N
2064	divar	ga-yxDHl	70متری تمیز و مرتب	ایثارگران	\N	rent	\N	https://divar.ir/v/_/ga-yxDHl	2026-10-01 08:39:57.791405+00	2026-10-01 08:44:12.076841+00	\N	\N	\N	mashhad	70	\N	\N	9500000	{"mid": "اجاره: ۹,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثارگران", "amounts": {"اجاره": 9500000}}	\N
2065	divar	ga-uR63g	جلال/ 100 متری / دو نبش	شهید رضوی	\N	rent	\N	https://divar.ir/v/_/ga-uR63g	2026-10-01 08:38:22.970107+00	2026-10-01 08:44:12.081699+00	\N	\N	\N	mashhad	100	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بامک بین امامت ۳۶و۳۸ در شهید رضوی", "amounts": {"اجاره": 20000000}}	\N
2066	divar	ga-uBbDn	رهن ملک ۱۵۵ متری،  مالک هستم	الهیه	\N	rent	44	https://divar.ir/v/_/ga-uBbDn	2026-10-01 08:36:22.204387+00	2026-10-01 08:44:12.086537+00	\N	\N	\N	mashhad	155	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در الهیه", "amounts": {}}	\N
2067	divar	ga-Kx9UH	همخانه می‌پذیرم ۳۵ ساله  آرام و کم‌رفت‌وآمد	سعد آباد	\N	rent	\N	https://divar.ir/v/_/ga-Kx9UH	2026-10-01 08:36:22.156987+00	2026-10-01 08:44:12.091192+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سعد آباد", "amounts": {"اجاره": 5000000}}	\N
2068	divar	gaaCaHK_	همخونه اقا	پردیس	\N	rent	\N	https://divar.ir/v/_/gaaCaHK_	2026-10-01 08:36:21.295592+00	2026-10-01 08:44:12.096348+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در پردیس", "amounts": {"اجاره": 10000000}}	\N
2069	divar	ga-qhzC5	بزرگمهر جنوبی /ویلایی ۶۰۰ متر/مناسب مدرسه شرکت	سجاد شهر	\N	rent	21	https://divar.ir/v/_/ga-qhzC5	2026-10-01 08:36:20.935154+00	2026-10-01 08:44:12.101978+00	\N	\N	\N	mashhad	600	\N	\N	380000000	{"mid": "اجاره: ۳۸۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سجاد شهر", "amounts": {"اجاره": 380000000}}	\N
2070	divar	ga-uxQQX	آپارتمان 85 متری	حضرت حجت	\N	rent	\N	https://divar.ir/v/_/ga-uxQQX	2026-10-01 08:35:59.416906+00	2026-10-01 08:44:12.10665+00	\N	\N	\N	mashhad	85	\N	\N	6500000	{"mid": "اجاره: ۶,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حضرت حجت", "amounts": {"اجاره": 6500000}}	\N
2073	divar	ga--hWgk	همخونه میخوام	الهیه	\N	rent	44	https://divar.ir/v/_/ga--hWgk	2026-10-01 08:54:45.400473+00	2026-10-01 08:54:59.724985+00	\N	\N	\N	mashhad	\N	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در الهیه", "amounts": {"اجاره": 7000000}}	\N
2074	divar	ga--Bw-r	78 متری دانشجو 20 فوری	دانشجو	\N	rent	39	https://divar.ir/v/_/ga--Bw-r	2026-10-01 08:54:34.305253+00	2026-10-01 08:54:59.733592+00	\N	\N	\N	mashhad	78	\N	\N	\N	{"mid": "رهن کامل", "bottom": "لحظاتی پیش در دانشجو", "amounts": {}}	\N
2075	divar	ga-2xx8-	۱۷۵متری /فرامرز /بهاران/فول باسازی	بهاران	\N	rent	17	https://divar.ir/v/_/ga-2xx8-	2026-10-01 08:54:22.941439+00	2026-10-01 08:54:59.743246+00	\N	\N	\N	mashhad	175	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در بهاران", "amounts": {"اجاره": 15000000}}	\N
2076	divar	gazuOMmo	واحد۱۲۰متری تکواحدی/صارمی(حافظ)	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/gazuOMmo	2026-10-01 08:54:20.844526+00	2026-10-01 08:54:59.754342+00	\N	\N	\N	mashhad	120	\N	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (حافظ)", "amounts": {"اجاره": 35000000}}	\N
2078	divar	gamC_51l	ویلایی ۳۵۰متر دادگر احمد آباد	احمدآباد	\N	rent	\N	https://divar.ir/v/_/gamC_51l	2026-10-01 08:53:50.080322+00	2026-10-01 08:54:59.769901+00	\N	\N	\N	mashhad	350	\N	\N	150000000	{"mid": "اجاره: ۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در احمدآباد", "amounts": {"اجاره": 150000000}}	\N
2079	divar	ga--xgDc	۱۶۰ متر صفر تک واحدی ابتدای لادن مدرن وشیک	صیاد شیرازی	\N	rent	4	https://divar.ir/v/_/ga--xgDc	2026-10-01 08:53:29.906658+00	2026-10-01 08:54:59.776435+00	\N	\N	\N	mashhad	160	\N	\N	50000000	{"mid": "اجاره: ۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در صیاد شیرازی", "amounts": {"اجاره": 50000000}}	\N
2080	divar	ga-yRqa2	80 متری 2خواب مجیدیه مالک ام	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga-yRqa2	2026-10-01 08:51:41.036703+00	2026-10-01 08:54:59.781726+00	\N	\N	\N	mashhad	80	2	\N	9000000	{"mid": "اجاره: ۹,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"اجاره": 9000000}}	\N
2081	divar	ga2-rZ9J	رهن کامل چراغچی ۵ بیگلری ۲	بهمن	\N	rent	43	https://divar.ir/v/_/ga2-rZ9J	2026-10-01 08:51:29.045674+00	2026-10-01 08:54:59.786148+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "در بهمن", "amounts": {"اجاره": 100000}}	\N
2082	divar	gazWEjoI	همخونه نیازمندم	شهرک صنعتی توس	\N	rent	\N	https://divar.ir/v/_/gazWEjoI	2026-10-01 08:51:27.304814+00	2026-10-01 08:54:59.791381+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "در شهرک صنعتی توس", "amounts": {"اجاره": 10000}}	\N
2083	divar	ga-6he8b	خانه رهن واجاره	طبرسی شمالی	\N	rent	42	https://divar.ir/v/_/ga-6he8b	2026-10-01 08:49:07.212805+00	2026-10-01 08:54:59.796296+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {}}	\N
2084	divar	ga-6hXN2	100متری،۲خواب،مطهری	سناباد	\N	rent	\N	https://divar.ir/v/_/ga-6hXN2	2026-10-01 08:49:02.257758+00	2026-10-01 08:54:59.801282+00	\N	\N	\N	mashhad	100	2	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سناباد", "amounts": {"اجاره": 15000000}}	\N
2085	divar	ga-6xaT3	140متر نوسازمناسب جهیزیه/طبقه 6/روبه روپارک	شهید رضوی	\N	rent	\N	https://divar.ir/v/_/ga-6xaT3	2026-10-01 08:48:55.944148+00	2026-10-01 08:54:59.806026+00	\N	\N	\N	mashhad	140	\N	\N	64000000	{"mid": "اجاره: ۶۴,۰۰۰,۰۰۰ تومان", "bottom": "اژانس اریا در شهید رضوی", "amounts": {"اجاره": 64000000}}	\N
2086	divar	gazOYYfc	مجد/150متری/3خواب/رهن 2450/صفرشیک	آبکوه	\N	rent	31	https://divar.ir/v/_/gazOYYfc	2026-10-01 08:48:30.31488+00	2026-10-01 08:54:59.810688+00	\N	\N	\N	mashhad	150	3	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن نوروزیان در آبکوه", "amounts": {}}	\N
2087	divar	ga-2h9pR	رهن اجاره اپارتمان	شفا	\N	rent	\N	https://divar.ir/v/_/ga-2h9pR	2026-10-01 08:47:02.66793+00	2026-10-01 08:54:59.815971+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در شفا", "amounts": {}}	\N
2091	divar	ga-Syp1O	۱۲۸متر سند تگ برگ دانشگاه	سناباد	15000000000	sale	\N	https://divar.ir/v/_/ga-Syp1O	2026-10-01 09:16:25.972912+00	2026-10-01 09:16:42.316378+00	\N	\N	\N	mashhad	128	\N	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در سناباد", "amounts": {"raw_amount": 15000000000}}	\N
2092	divar	ga--h8fR	سجاد ۱۰۰ متر صفر / خواهان خریدار نقد نقد/	سجاد شهر	31500000000	sale	21	https://divar.ir/v/_/ga--h8fR	2026-10-01 09:16:00.571194+00	2026-10-01 09:16:42.334029+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۳۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در سجاد شهر", "amounts": {"raw_amount": 31500000000}}	\N
2093	divar	ga-SSd3v	یک واحد آپارتمان طبقه ششم سرجلو	وحید	6400000000	sale	33	https://divar.ir/v/_/ga-SSd3v	2026-10-01 09:15:52.255557+00	2026-10-01 09:16:42.344573+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در وحید", "amounts": {"raw_amount": 6400000000}}	\N
2094	divar	gaeqo6_g	۲۱۶ متر / چهار خواب تک واحدی/ ویو ابدی / فول vip	جاهد شهر	26000000000	sale	41	https://divar.ir/v/_/gaeqo6_g	2026-10-01 09:15:46.366916+00	2026-10-01 09:16:42.356359+00	\N	\N	\N	mashhad	216	\N	\N	\N	{"mid": "۲۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 26000000000}}	\N
2095	divar	ga-SCXMF	فروش آپارتمان ۹۵ متری دو خواب طبقه چهارم	هنرور	4600000000	sale	\N	https://divar.ir/v/_/ga-SCXMF	2026-10-01 09:15:32.924505+00	2026-10-01 09:16:42.368658+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۴,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"raw_amount": 4600000000}}	\N
2096	divar	gaeuemwv	۹۰متراپارتمان درحال تحویل صفر	حسابی جنوبی (شهرک غرب)	12600000000	sale	38	https://divar.ir/v/_/gaeuemwv	2026-10-01 09:15:29.00699+00	2026-10-01 09:16:42.380786+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۱۲,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سراسری آزموده ۴راه ورزش شریعتی بین ۵۴و۵۲ در حسابی جنوبی (شهرک غرب)", "amounts": {"raw_amount": 12600000000}}	\N
2097	divar	ga8aLmo5	پیش‌فروش/160متری/وحید/نزدیک حرم/کارگزاری مدد زاده	وحید	11990000000	sale	33	https://divar.ir/v/_/ga8aLmo5	2026-10-01 09:15:26.021895+00	2026-10-01 09:16:42.393187+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۱۱,۹۹۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری سراسری مدد زاده در وحید", "amounts": {"raw_amount": 11990000000}}	\N
2098	divar	ga9aRUOX	100 متری          اوایل الهیه         بازسازی شده	جاهد شهر	12000000000	sale	41	https://divar.ir/v/_/ga9aRUOX	2026-10-01 09:14:46.909029+00	2026-10-01 09:16:42.404288+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 12000000000}}	\N
2100	divar	ga-SSN--	آپارتمان۷۵ متری۲ خواب	رضاشهر	11300000000	sale	\N	https://divar.ir/v/_/ga-SSN--	2026-10-01 09:13:57.439341+00	2026-10-01 09:16:42.423921+00	\N	\N	\N	mashhad	75	2	\N	\N	{"mid": "۱۱,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن مهرداد در رضاشهر", "amounts": {"raw_amount": 11300000000}}	\N
2102	divar	gaae55K9	ویلایی ۱۲۵ متری ۲ طبقه مجزا ،غرق در نور در عبادی	گاز	\N	rent	\N	https://divar.ir/v/_/gaae55K9	2026-09-23 15:20:59.076508+00	2026-10-01 09:16:42.444141+00	\N	\N	\N	mashhad	125	\N	\N	26000000	{"mid": "اجاره: ۲۶,۰۰۰,۰۰۰ تومان", "bottom": "در گاز", "amounts": {"اجاره": 26000000}}	\N
2103	divar	ga-SCgc0	رهن	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga-SCgc0	2026-10-01 09:15:46.330999+00	2026-10-01 09:16:42.45637+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در جاهد شهر", "amounts": {"اجاره": 10000}}	\N
2104	divar	ga-SCjib	147 متر / اول الهیه / لوکس	الهیه	\N	rent	44	https://divar.ir/v/_/ga-SCjib	2026-10-01 09:15:02.530443+00	2026-10-01 09:16:42.468674+00	\N	\N	\N	mashhad	147	\N	\N	\N	{"mid": "رهن کامل", "bottom": "کارگزای مسکن رایان در الهیه", "amounts": {}}	\N
2105	divar	ga-Sya_-	153متر(دو واحدی)واقعی(رحمانیه)	الهیه	\N	rent	44	https://divar.ir/v/_/ga-Sya_-	2026-10-01 09:14:33.378431+00	2026-10-01 09:16:42.482315+00	\N	\N	\N	mashhad	153	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {}}	\N
2106	divar	ga9uC3xG	۵۰۰ متر ویلایی در ابوذرغفاری	احمدآباد	\N	rent	\N	https://divar.ir/v/_/ga9uC3xG	2026-10-01 09:14:20.057749+00	2026-10-01 09:16:42.495278+00	\N	\N	\N	mashhad	500	\N	\N	200000000	{"mid": "اجاره: ۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رجب پور در احمدآباد", "amounts": {"اجاره": 200000000}}	\N
2107	divar	ga-SiDNt	آپارتمان 100متر 2 خواب فول مشاعات پارکینگ اختصاصی	بهارستان	\N	rent	\N	https://divar.ir/v/_/ga-SiDNt	2026-10-01 09:13:24.492554+00	2026-10-01 09:16:42.509848+00	\N	\N	\N	mashhad	100	2	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهارستان", "amounts": {"اجاره": 30000000}}	\N
2108	divar	ga-OSJB-	خانه ویلایی	شهید بصیر	\N	rent	\N	https://divar.ir/v/_/ga-OSJB-	2026-10-01 09:13:20.033265+00	2026-10-01 09:16:42.515837+00	\N	\N	\N	mashhad	\N	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید بصیر", "amounts": {"اجاره": 7000000}}	\N
2109	divar	ga-KiGGF	۲۵۰متری ویلایی در ناصرخسرو	احمدآباد	\N	rent	\N	https://divar.ir/v/_/ga-KiGGF	2026-10-01 09:12:56.255612+00	2026-10-01 09:16:42.525923+00	\N	\N	\N	mashhad	250	\N	\N	130000000	{"mid": "اجاره: ۱۳۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رجب پور در احمدآباد", "amounts": {"اجاره": 130000000}}	\N
2110	divar	ga-OC9Jn	رهن کامل خانه	مصلی (کارمندان اول)	\N	rent	\N	https://divar.ir/v/_/ga-OC9Jn	2026-10-01 09:12:32.702266+00	2026-10-01 09:16:42.536542+00	\N	\N	\N	mashhad	\N	\N	\N	800000000	{"mid": "اجاره: ۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مصلی (کارمندان اول)", "amounts": {"اجاره": 800000000}}	\N
2111	divar	ga-OS5ns	اپارتمان‌ ۷۵متری دوخواب /امام رضا	خرمشهر	\N	rent	\N	https://divar.ir/v/_/ga-OS5ns	2026-10-01 09:12:11.009316+00	2026-10-01 09:16:42.547218+00	\N	\N	\N	mashhad	75	\N	\N	18000000	{"mid": "اجاره: ۱۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در خرمشهر", "amounts": {"اجاره": 18000000}}	\N
2112	divar	ga-OSvPu	هم خانه	ابوذر	\N	rent	24	https://divar.ir/v/_/ga-OSvPu	2026-10-01 09:12:03.702763+00	2026-10-01 09:16:42.557429+00	\N	\N	\N	mashhad	\N	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ابوذر", "amounts": {"اجاره": 3000000}}	\N
2113	divar	ga-Oyr9o	رهن و اجاره 125 متری صفر فول امکانات	میعاد (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-Oyr9o	2026-10-01 09:11:40.34325+00	2026-10-01 09:16:42.567446+00	\N	\N	\N	mashhad	125	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میعاد (شهرک غرب)", "amounts": {"اجاره": 100000}}	\N
2114	divar	ga72MGhQ	بلوار وکیل آباد مجتمع مسکونی پردیس ۷۸ متری	پردیس	7000000000	sale	\N	https://divar.ir/v/_/ga72MGhQ	2026-10-01 05:54:48.787167+00	2026-10-01 09:26:59.155198+00	\N	\N	\N	mashhad	78	\N	\N	\N	{"mid": "۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در پردیس", "amounts": {"raw_amount": 7000000000}}	\N
2115	divar	gaq6_3eD	آپارتمان 115 متری تک واحدی	هنرور	6200000000	sale	\N	https://divar.ir/v/_/gaq6_3eD	2026-09-21 10:03:11.581932+00	2026-10-01 09:26:59.174908+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۶,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هنرور", "amounts": {"raw_amount": 6200000000}}	\N
2116	divar	ga-eSIgT	فروش آپارتمان ۷۵ متری/اواسط صیاد/سند تک برگ/فول	هفت تیر (آب و برق)	8500000000	sale	\N	https://divar.ir/v/_/ga-eSIgT	2026-10-01 09:26:39.5486+00	2026-10-01 09:26:59.186688+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در هفت تیر (آب و برق)", "amounts": {"raw_amount": 8500000000}}	\N
2117	divar	ga-eSPd-	۱۴۶ متر ۳ خواب حاشیه فرهنگ سروش	سید رضی	19500000000	sale	\N	https://divar.ir/v/_/ga-eSPd-	2026-10-01 09:26:33.911194+00	2026-10-01 09:26:59.197995+00	\N	\N	\N	mashhad	146	3	\N	\N	{"mid": "۱۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در سید رضی", "amounts": {"raw_amount": 19500000000}}	\N
2118	divar	gazS-cnz	۱۱۰ متری / دونبش / سند آماده/ اول رحمانیه دو واحدی	الهیه	13000000000	sale	44	https://divar.ir/v/_/gazS-cnz	2026-10-01 09:26:13.886078+00	2026-10-01 09:26:59.207731+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۱۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 13000000000}}	\N
2119	divar	ga7SIevW	فروش خانه ویلایی	همت آباد	1250000000	sale	\N	https://divar.ir/v/_/ga7SIevW	2026-10-01 09:26:08.155362+00	2026-10-01 09:26:59.219572+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در همت آباد", "amounts": {"raw_amount": 1250000000}}	\N
2120	divar	ga6-TWx1	۱۱۰ متری / هوشمند/ اول رحمانیه/ دو واحدی /واقعی	الهیه	12500000000	sale	44	https://divar.ir/v/_/ga6-TWx1	2026-10-01 09:25:56.841664+00	2026-10-01 09:26:59.230157+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 12500000000}}	\N
2121	divar	ga6aXMqh	فروش واحد لوکس در قلب رحمانیه/ تک واحدی	الهیه	23000000000	sale	44	https://divar.ir/v/_/ga6aXMqh	2026-10-01 09:25:44.218481+00	2026-10-01 09:26:59.2414+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 23000000000}}	\N
2122	divar	gadOC3cR	۹۰ متر فــول امکانات فلاحــی	شهرک لشکر (شهرک غرب)	9590000000	sale	38	https://divar.ir/v/_/gadOC3cR	2026-10-01 09:25:44.169917+00	2026-10-01 09:26:59.253897+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۹,۵۹۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک لشکر (شهرک غرب)", "amounts": {"raw_amount": 9590000000}}	\N
2123	divar	ga7eHxSj	اول رحمانیه سند آماده/زیر کارشناسی مالک فروشنده	الهیه	19500000000	sale	44	https://divar.ir/v/_/ga7eHxSj	2026-10-01 09:25:33.033015+00	2026-10-01 09:26:59.265339+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 19500000000}}	\N
2124	divar	ga9ikepE	سوپرلوکسِ ۱۸۶ متریِ سند آمادهِ اول الهیه	الهیه	24000000000	sale	44	https://divar.ir/v/_/ga9ikepE	2026-10-01 09:25:24.802938+00	2026-10-01 09:26:59.27799+00	\N	\N	\N	mashhad	186	\N	\N	\N	{"mid": "۲۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 24000000000}}	\N
2125	divar	ga-KyYPW	آپارتمان بدون خرج/ اقدسیه/واقعی/ کم واحد/سنددار	الهیه	11600000000	sale	44	https://divar.ir/v/_/ga-KyYPW	2026-10-01 09:25:08.661633+00	2026-10-01 09:26:59.289586+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۱,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 11600000000}}	\N
2126	divar	gama3O7E	اپارتمان مناسب افراد خاص پسند	کشف	4730000000	sale	\N	https://divar.ir/v/_/gama3O7E	2026-10-01 09:24:38.4216+00	2026-10-01 09:26:59.301342+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۷۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در کشف", "amounts": {"raw_amount": 4730000000}}	\N
2128	divar	ga-ayqC4	همخونه نیازمندم	شهرک صنعتی توس	\N	rent	\N	https://divar.ir/v/_/ga-ayqC4	2026-10-01 09:24:08.525648+00	2026-10-01 09:26:59.319629+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک صنعتی توس", "amounts": {"اجاره": 10000}}	\N
2129	divar	ga-Wy0At	رهن ویلایی ۱۵۰	پورسینا	\N	rent	\N	https://divar.ir/v/_/ga-Wy0At	2026-10-01 09:20:29.262795+00	2026-10-01 09:26:59.331673+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در پورسینا", "amounts": {}}	\N
2130	divar	ga-WivZX	رهن و اجاره آپارتمان ۸۵ متری	شفا	\N	rent	\N	https://divar.ir/v/_/ga-WivZX	2026-10-01 09:20:05.64462+00	2026-10-01 09:26:59.342277+00	\N	\N	\N	mashhad	85	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شفا", "amounts": {"اجاره": 12000000}}	\N
2131	divar	ga-Sy2Dz	خانه اجاره ای شیک و مرتب	دوست آباد	\N	rent	\N	https://divar.ir/v/_/ga-Sy2Dz	2026-10-01 09:16:55.707907+00	2026-10-01 09:26:59.35334+00	\N	\N	\N	mashhad	\N	\N	\N	9000000	{"mid": "اجاره: ۹,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در دوست آباد", "amounts": {"اجاره": 9000000}}	\N
2132	divar	ga-Siq5V	رهن و اجاره آپارتمان ۱۱۰متری	کشاورز	\N	rent	\N	https://divar.ir/v/_/ga-Siq5V	2026-10-01 09:16:41.983262+00	2026-10-01 09:26:59.364484+00	\N	\N	\N	mashhad	110	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کشاورز", "amounts": {"اجاره": 7000000}}	\N
2135	divar	ga4menqb	اپارتمان نقلی ۶۰ متری یک طبقه کامل و هوایی	ایثارگران	3200000000	sale	\N	https://divar.ir/v/_/ga4menqb	2026-09-27 10:03:19.445147+00	2026-10-01 09:37:15.045264+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در ایثارگران", "amounts": {"raw_amount": 3200000000}}	\N
2136	divar	ga3-2d1m	فروش اپارتمان دلاوران	سرافرازان	12600000000	sale	22	https://divar.ir/v/_/ga3-2d1m	2026-09-26 07:09:22.797444+00	2026-10-01 09:37:15.072231+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در سرافرازان", "amounts": {"raw_amount": 12600000000}}	\N
2137	divar	gaiudqYL	آپارتمان  ۱۵۵ متری نوساز غرق نور خوش نقشه	ادیب نیشابوری (شهرک غرب)	17000000000	sale	38	https://divar.ir/v/_/gaiudqYL	2026-10-01 09:36:52.887591+00	2026-10-01 09:37:15.086033+00	\N	\N	\N	mashhad	155	\N	\N	\N	{"mid": "۱۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در ادیب نیشابوری (شهرک غرب)", "amounts": {"raw_amount": 17000000000}}	\N
2138	divar	ga-myaWQ	خانه منزل ویلایی تپه سلام	ایوان	4200000000	sale	\N	https://divar.ir/v/_/ga-myaWQ	2026-10-01 09:36:40.073681+00	2026-10-01 09:37:15.100521+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در ایوان", "amounts": {"raw_amount": 4200000000}}	\N
2139	divar	ganVzKcr	باغ ویلا	تبادکان	7300000000	sale	\N	https://divar.ir/v/_/ganVzKcr	2026-10-01 09:36:34.436516+00	2026-10-01 09:37:15.112644+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در تبادکان", "amounts": {"raw_amount": 7300000000}}	\N
2140	divar	AaPoqD0E	فروش قصرمجلل*300 متر*طراحی سلطنتی*ویژه خاص پسندان	آزادشهر	38000000000	sale	\N	https://divar.ir/v/_/AaPoqD0E	2026-10-01 09:36:19.90246+00	2026-10-01 09:37:15.12401+00	\N	\N	\N	mashhad	300	\N	\N	\N	{"mid": "۳۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در آزادشهر", "amounts": {"raw_amount": 38000000000}}	\N
2141	divar	ga-miOsW	فروش آپارتمان و یک مغازه تجاری دائم	اقبال	29000000000	sale	1	https://divar.ir/v/_/ga-miOsW	2026-10-01 09:35:42.814142+00	2026-10-01 09:37:15.135607+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در اقبال", "amounts": {"raw_amount": 29000000000}}	\N
2142	divar	AaFwP2qW	آدرس اشرافیت/آپارتمان165متر*3خواب+طراحی سفارشی	آزادشهر	26500000000	sale	\N	https://divar.ir/v/_/AaFwP2qW	2026-10-01 09:35:29.886536+00	2026-10-01 09:37:15.148509+00	\N	\N	\N	mashhad	165	3	\N	\N	{"mid": "۲۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در آزادشهر", "amounts": {"raw_amount": 26500000000}}	\N
2143	divar	QasH__s4	در لوکیشن عالی، چند طبقه موجود فرصت رو از دست ندید	فرهنگ	24500000000	sale	\N	https://divar.ir/v/_/QasH__s4	2026-10-01 09:34:25.832841+00	2026-10-01 09:37:15.162278+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فرهنگ", "amounts": {"raw_amount": 24500000000}}	\N
2144	divar	ga-aB-eY	واحدی که میخای حس خاص بودن بهت بده	الهیه	12200000000	sale	44	https://divar.ir/v/_/ga-aB-eY	2026-10-01 09:33:38.455564+00	2026-10-01 09:37:15.175967+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پلاک در الهیه", "amounts": {"raw_amount": 12200000000}}	\N
2145	divar	QakzfLcf	امضامعمار*175متر/باطراحی داخلی که شمارا خاص می‌کند	فرهنگ	27000000000	sale	\N	https://divar.ir/v/_/QakzfLcf	2026-10-01 09:33:28.662208+00	2026-10-01 09:37:15.188655+00	\N	\N	\N	mashhad	175	\N	\N	\N	{"mid": "۲۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فرهنگ", "amounts": {"raw_amount": 27000000000}}	\N
2146	divar	ga-iCsI-	سلام خونه تمیز نوساز	شهرک امام هادی (شهرک غرب)	7000000000	sale	38	https://divar.ir/v/_/ga-iCsI-	2026-10-01 09:33:28.205958+00	2026-10-01 09:37:15.201644+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک امام هادی (شهرک غرب)", "amounts": {"raw_amount": 7000000000}}	\N
2147	divar	ga-iyskJ	خانه دوبلکس درودی	حضرت حجت	4000000000	sale	\N	https://divar.ir/v/_/ga-iyskJ	2026-10-01 09:33:20.58576+00	2026-10-01 09:37:15.214172+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حضرت حجت", "amounts": {"raw_amount": 4000000000}}	\N
2148	divar	ga-iCpLt	فروش اپارتمان ۷۵ متری کوثر شمالی	کوثر	12500000000	sale	13	https://divar.ir/v/_/ga-iCpLt	2026-10-01 09:33:04.515197+00	2026-10-01 09:37:15.227281+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"raw_amount": 12500000000}}	\N
2149	divar	galGYvY2	فروش اپارتمان ۷۰متری حسن زاده۲۱	نظام دوست	1900000000	sale	\N	https://divar.ir/v/_/galGYvY2	2026-10-01 09:32:47.699392+00	2026-10-01 09:37:15.239601+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۱,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در نظام دوست", "amounts": {"raw_amount": 1900000000}}	\N
2150	divar	ga-eyiqx	باغ 1000متری.	میان ولایت	6000000000	sale	\N	https://divar.ir/v/_/ga-eyiqx	2026-10-01 09:32:32.292387+00	2026-10-01 09:37:15.251826+00	\N	\N	\N	mashhad	1000	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 6000000000}}	\N
2152	divar	ga4CNCVJ	اوایل ابکو/115متری/2خواب/1200رهن صفر	آبکوه	\N	rent	31	https://divar.ir/v/_/ga4CNCVJ	2026-10-01 09:34:04.329165+00	2026-10-01 09:37:15.274029+00	\N	\N	\N	mashhad	115	2	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "مسکن نوروزیان در آبکوه", "amounts": {"اجاره": 6000000}}	\N
2153	divar	ga-iC1Wf	سوئیت ۵۰ متری در همکف	گوهرشاد	\N	rent	20	https://divar.ir/v/_/ga-iC1Wf	2026-10-01 09:33:50.99046+00	2026-10-01 09:37:15.285917+00	\N	\N	\N	mashhad	50	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گوهرشاد", "amounts": {"اجاره": 15000000}}	\N
2154	divar	ga-iSkHl	آپارتمان ۱۱۰ متر / تک واحدی / کلاهدوز	کلاهدوز	\N	rent	\N	https://divar.ir/v/_/ga-iSkHl	2026-10-01 09:32:52.114941+00	2026-10-01 09:37:15.300133+00	\N	\N	\N	mashhad	110	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کلاهدوز", "amounts": {"اجاره": 10000}}	\N
2155	divar	gar66FxN	احمداباد/115متری/2خواب/1800رهن صفر	آبکوه	\N	rent	31	https://divar.ir/v/_/gar66FxN	2026-10-01 09:32:06.98261+00	2026-10-01 09:37:15.312324+00	\N	\N	\N	mashhad	115	2	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن نوروزیان در آبکوه", "amounts": {"اجاره": 5000000}}	\N
2157	divar	ga-iSYxQ	رهن کامل آپارتمان طبقه دو طبرسی شمالی 17 خداشناس8	طبرسی شمالی	\N	rent	42	https://divar.ir/v/_/ga-iSYxQ	2026-10-01 09:31:23.912047+00	2026-10-01 09:37:15.335593+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {}}	\N
2158	divar	ga-eydWl	دربست،سیدرضی سکونی	سید رضی	\N	rent	\N	https://divar.ir/v/_/ga-eydWl	2026-10-01 09:31:07.903695+00	2026-10-01 09:37:15.348249+00	\N	\N	\N	mashhad	\N	\N	\N	77000000	{"mid": "اجاره: ۷۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سید رضی", "amounts": {"اجاره": 77000000}}	\N
2159	divar	ga-eCzey	۱۰۵ متر / شخصی ساز / رهن اجاره/ اقدسیه	الهیه	\N	rent	44	https://divar.ir/v/_/ga-eCzey	2026-10-01 09:29:21.756725+00	2026-10-01 09:37:15.360592+00	\N	\N	\N	mashhad	105	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "مسكن فرهنگ در الهیه", "amounts": {"اجاره": 20000000}}	\N
2160	divar	ga-eiwZm	اپارتمان ماهانه سوییت خانه روزانه دوخواب	سلام	\N	rent	\N	https://divar.ir/v/_/ga-eiwZm	2026-10-01 09:29:19.741432+00	2026-10-01 09:37:15.371277+00	\N	\N	\N	mashhad	\N	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "سوئیت اپارتمان نیکوعقیده در سلام", "amounts": {"اجاره": 40000000}}	\N
2161	divar	ga-KwneQ	واحد ۹۰ متری / اواسط سیدرضی / فوق تمیز و مرتب	سید رضی	\N	rent	\N	https://divar.ir/v/_/ga-KwneQ	2026-10-01 09:28:23.79192+00	2026-10-01 09:37:15.383353+00	\N	\N	\N	mashhad	90	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "مسکن اُخوت در سید رضی", "amounts": {"اجاره": 100000}}	\N
2164	divar	gavOegDe	آپارتمان۸۵متری،امام رضا	امام رضا (ع)	17000000000	sale	\N	https://divar.ir/v/_/gavOegDe	2026-10-01 11:02:56.917723+00	2026-10-01 11:03:37.68536+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۱۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 17000000000}}	\N
2165	divar	garWuDIs	آپارتمان105متری،امام رضا همکف	امام رضا (ع)	13000000000	sale	\N	https://divar.ir/v/_/garWuDIs	2026-10-01 11:02:02.916262+00	2026-10-01 11:03:37.697771+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 13000000000}}	\N
2166	divar	gary8e6q	آپارتمان۱۰۰متری،محدوده حرم	حرم مطهر رضوی	16000000000	sale	\N	https://divar.ir/v/_/gary8e6q	2026-10-01 11:01:42.806631+00	2026-10-01 11:03:37.707988+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در حرم مطهر رضوی", "amounts": {"raw_amount": 16000000000}}	\N
2167	divar	ga-2zVqY	۱۰۰ متر آپارتمان ۲ خواب	کوی المهدی	5600000000	sale	\N	https://divar.ir/v/_/ga-2zVqY	2026-10-01 11:01:36.726564+00	2026-10-01 11:03:37.712652+00	\N	\N	\N	mashhad	100	2	\N	\N	{"mid": "۵,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی المهدی", "amounts": {"raw_amount": 5600000000}}	\N
2168	divar	gaie8T-Y	آپارتمان۱۲۰متری،لوکس،سرشور،محدوده حرم	آیت الله خامنه‌ای	30000000000	sale	\N	https://divar.ir/v/_/gaie8T-Y	2026-10-01 11:01:08.720602+00	2026-10-01 11:03:37.717354+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۳۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در آیت الله خامنه‌ای", "amounts": {"raw_amount": 30000000000}}	\N
2169	divar	ga-mjsup	اپارتمان	عامل	9000000000	sale	\N	https://divar.ir/v/_/ga-mjsup	2026-10-01 11:00:54.976687+00	2026-10-01 11:03:37.721005+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در عامل", "amounts": {"raw_amount": 9000000000}}	\N
2170	divar	ga-yDMj2	جشنواره نور در ابتدای امیریه /کلید نخورده/لابی دار	الهیه	15500000000	sale	44	https://divar.ir/v/_/ga-yDMj2	2026-10-01 10:57:29.248024+00	2026-10-01 11:03:37.725404+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سراسری زیما در الهیه", "amounts": {"raw_amount": 15500000000}}	\N
2171	divar	ga8ipm_T	قیمت شکنی/واحدهای متنوع دو و سه خوابه در منطقه	جاهد شهر	13400000000	sale	41	https://divar.ir/v/_/ga8ipm_T	2026-10-01 10:56:33.582377+00	2026-10-01 11:03:37.729014+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۳,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 13400000000}}	\N
2172	divar	gaaaXKpq	۱۳۲ متری  سه خواب سند آماده اول امیریه	امیریه	15500000000	sale	\N	https://divar.ir/v/_/gaaaXKpq	2026-10-01 10:56:09.812863+00	2026-10-01 11:03:37.733532+00	\N	\N	\N	mashhad	132	\N	\N	\N	{"mid": "۱۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیریه", "amounts": {"raw_amount": 15500000000}}	\N
2173	divar	ga8CKp6e	85متری / سند آماده / سراسر نور	امیریه	6900000000	sale	\N	https://divar.ir/v/_/ga8CKp6e	2026-10-01 10:55:20.483553+00	2026-10-01 11:03:37.738648+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۶,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیریه", "amounts": {"raw_amount": 6900000000}}	\N
2174	divar	ga-yDCiy	آپارتمان ۱۷۵ متری / صفر دوهاله / لوکیشن عالی رسالت	شهید فرامرز عباسی	36750000000	sale	\N	https://divar.ir/v/_/ga-yDCiy	2026-10-01 10:55:16.274331+00	2026-10-01 11:03:37.752826+00	\N	\N	\N	mashhad	175	\N	\N	\N	{"mid": "۳۶,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید فرامرز عباسی", "amounts": {"raw_amount": 36750000000}}	\N
2175	divar	ga4JeF14	آپارتمان 140 متری /  نورگیر عالی/شکار منطقه	جانباز	10000000000	sale	\N	https://divar.ir/v/_/ga4JeF14	2026-10-01 10:54:16.199922+00	2026-10-01 11:03:37.75867+00	\N	\N	\N	mashhad	140	\N	\N	\N	{"mid": "۱۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جانباز", "amounts": {"raw_amount": 10000000000}}	\N
2176	divar	ga-ujaVS	اپارتمان۱۶۵مترفول امکانات	انقلاب	12000000000	sale	\N	https://divar.ir/v/_/ga-ujaVS	2026-10-01 10:53:51.280691+00	2026-10-01 11:03:37.766232+00	\N	\N	\N	mashhad	165	\N	\N	\N	{"mid": "۱۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "موسی پناهی در انقلاب", "amounts": {"raw_amount": 12000000000}}	\N
2177	divar	ga-uzlnJ	۸۵ متر دوخواب لوکیشن عالی	حجت	4500000000	sale	\N	https://divar.ir/v/_/ga-uzlnJ	2026-10-01 10:53:46.025015+00	2026-10-01 11:03:37.771519+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حجت", "amounts": {"raw_amount": 4500000000}}	\N
2178	divar	ga-2j7Hx	خانه اجاره ای 150متر3خواب شیک فرخد	فرخد	\N	rent	\N	https://divar.ir/v/_/ga-2j7Hx	2026-10-01 11:03:19.498904+00	2026-10-01 11:03:37.775265+00	\N	\N	\N	mashhad	150	3	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در فرخد", "amounts": {"اجاره": 4000000}}	\N
2179	divar	ga-2DcHO	منزل	کشف	\N	rent	\N	https://divar.ir/v/_/ga-2DcHO	2026-10-01 11:01:13.94003+00	2026-10-01 11:03:37.77825+00	\N	\N	\N	mashhad	\N	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کشف", "amounts": {"اجاره": 4000000}}	\N
2180	divar	ga-yD6Gn	اجاره آپارتمان در مجیدیه۳.۱	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga-yD6Gn	2026-10-01 10:58:55.044939+00	2026-10-01 11:03:37.781794+00	\N	\N	\N	mashhad	\N	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"اجاره": 20000000}}	\N
2181	divar	ga-yzOSW	رهن و اجاره	سجادیه	\N	rent	21	https://divar.ir/v/_/ga-yzOSW	2026-10-01 10:56:03.785374+00	2026-10-01 11:03:37.78533+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سجادیه", "amounts": {"اجاره": 10000}}	\N
2182	divar	ga-uTHv-	خانه اجاره ای	شهرک بهارستان	\N	rent	\N	https://divar.ir/v/_/ga-uTHv-	2026-10-01 10:54:47.326893+00	2026-10-01 11:03:37.788483+00	\N	\N	\N	mashhad	\N	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک بهارستان", "amounts": {"اجاره": 12000000}}	\N
2183	divar	ga-uzowN	۸۰متر تخلیه دلاوران۱۱ فکوری۶۳	سرافرازان	\N	rent	22	https://divar.ir/v/_/ga-uzowN	2026-10-01 10:54:15.424604+00	2026-10-01 11:03:37.794169+00	\N	\N	\N	mashhad	80	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سرافرازان", "amounts": {"اجاره": 12000000}}	\N
2184	divar	ga-ujDri	۱۱۵متری.رحمانیه.تخلیه.خوش نقشه	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga-ujDri	2026-10-01 10:51:56.146531+00	2026-10-01 11:03:37.799269+00	\N	\N	\N	mashhad	115	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"اجاره": 25000000}}	\N
2185	divar	ga-uTL7N	همخونه میخوام	ایثار	\N	rent	\N	https://divar.ir/v/_/ga-uTL7N	2026-10-01 10:51:31.844096+00	2026-10-01 11:03:37.802855+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثار", "amounts": {"اجاره": 1000000}}	\N
2186	divar	ga-qTcEr	آپارتمان ۱۱۰ متر دوخواب طبقه اول فول امکانات	ویلاشهر	\N	rent	\N	https://divar.ir/v/_/ga-qTcEr	2026-10-01 10:48:34.546293+00	2026-10-01 11:03:37.805985+00	\N	\N	\N	mashhad	110	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در ویلاشهر", "amounts": {"اجاره": 25000000}}	\N
2188	divar	ga-ijYPs	حافظ صیاد دوخواب صفر نوساز	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/ga-ijYPs	2026-10-01 10:40:07.024604+00	2026-10-01 11:03:37.810767+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "یک ربع پیش در هفت تیر (حافظ)", "amounts": {}}	\N
2189	divar	ga2SKdeQ	آپارتمان دوخواب	شهید قربانی	\N	rent	\N	https://divar.ir/v/_/ga2SKdeQ	2026-10-01 10:36:53.030523+00	2026-10-01 11:03:37.81386+00	\N	\N	\N	mashhad	\N	\N	\N	8500000	{"mid": "اجاره: ۸,۵۰۰,۰۰۰ تومان", "bottom": "در شهید قربانی", "amounts": {"اجاره": 8500000}}	\N
2190	divar	ga-eTVGw	75 متری پایداری تخلیه	سرافرازان	\N	rent	22	https://divar.ir/v/_/ga-eTVGw	2026-10-01 10:35:06.185859+00	2026-10-01 11:03:37.816252+00	\N	\N	\N	mashhad	75	\N	\N	18000000	{"mid": "اجاره: ۱۸,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در سرافرازان", "amounts": {"اجاره": 18000000}}	\N
2191	divar	ga-aziY2	آپارتمان سوپر لوکس ۸ واحدی رحمانیه	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga-aziY2	2026-10-01 10:33:26.15076+00	2026-10-01 11:03:37.818938+00	\N	\N	\N	mashhad	\N	\N	\N	32000000	{"mid": "اجاره: ۳۲,۰۰۰,۰۰۰ تومان", "bottom": "نیم ساعت پیش در جاهد شهر", "amounts": {"اجاره": 32000000}}	\N
2192	divar	ga-az4lS	رهن و اجاره وحید طلاب	وحید	\N	rent	33	https://divar.ir/v/_/ga-az4lS	2026-10-01 10:33:16.559167+00	2026-10-01 11:03:37.822286+00	\N	\N	\N	mashhad	\N	\N	\N	9000000	{"mid": "اجاره: ۹,۰۰۰,۰۰۰ تومان", "bottom": "نیم ساعت پیش در وحید", "amounts": {"اجاره": 9000000}}	\N
2193	divar	ga-az2iW	املاک	خرمشهر	\N	rent	\N	https://divar.ir/v/_/ga-az2iW	2026-10-01 10:33:10.669892+00	2026-10-01 11:03:37.82674+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "نیم ساعت پیش در خرمشهر", "amounts": {}}	\N
2195	divar	gaOZnW-F	خانه ویلایی فروشی ۸۵متری دوطبقه	شهرک مهر آباد	5800000000	sale	\N	https://divar.ir/v/_/gaOZnW-F	2026-10-01 11:13:41.200436+00	2026-10-01 11:13:49.668736+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۵,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک مهر آباد", "amounts": {"raw_amount": 5800000000}}	\N
2196	divar	ga-CEJJg	75 متری دوخواب تک واحدی	تلگرد	6100000000	sale	\N	https://divar.ir/v/_/ga-CEJJg	2026-10-01 11:13:18.666266+00	2026-10-01 11:13:49.671453+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۶,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در تلگرد", "amounts": {"raw_amount": 6100000000}}	\N
2197	divar	ga-6zHW6	طبقه فروش درهدایت	ایثارگران	4700000000	sale	\N	https://divar.ir/v/_/ga-6zHW6	2026-10-01 11:13:05.910795+00	2026-10-01 11:13:49.674071+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در ایثارگران", "amounts": {"raw_amount": 4700000000}}	\N
2198	divar	gaqOlLI8	82متر/6واحد/عکس واحدست/مشرف به پارک	امیریه	8200000000	sale	\N	https://divar.ir/v/_/gaqOlLI8	2026-10-01 11:12:34.626574+00	2026-10-01 11:13:49.676423+00	\N	\N	\N	mashhad	82	\N	\N	\N	{"mid": "۸,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیریه", "amounts": {"raw_amount": 8200000000}}	\N
2199	divar	ga--jk8v	یک واحد آپاتمان ۷۰متری الهیه ۲۵	الهیه	4750000000	sale	44	https://divar.ir/v/_/ga--jk8v	2026-10-01 11:11:30.838392+00	2026-10-01 11:13:49.678442+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۴,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 4750000000}}	\N
2200	divar	ga62HYZ3	آپارتمان۱۱۰متری،فول فرنیش،محدوده حرم	حرم مطهر رضوی	24200000000	sale	\N	https://divar.ir/v/_/ga62HYZ3	2026-10-01 11:11:20.129524+00	2026-10-01 11:13:49.680573+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۲۴,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در حرم مطهر رضوی", "amounts": {"raw_amount": 24200000000}}	\N
2201	divar	gal6ms4g	آپارتمان ۱۰۰متری باپارکینگ وآسانسور	امیر	6500000000	sale	\N	https://divar.ir/v/_/gal6ms4g	2026-10-01 11:10:32.842331+00	2026-10-01 11:13:49.683733+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیر", "amounts": {"raw_amount": 6500000000}}	\N
2202	divar	ga3yHaB1	۹۲ متر سند آماده مجتمع سجاد اول سجادیه	الهیه	8550000000	sale	44	https://divar.ir/v/_/ga3yHaB1	2026-10-01 11:10:10.309451+00	2026-10-01 11:13:49.685678+00	\N	\N	\N	mashhad	92	\N	\N	\N	{"mid": "۸,۵۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 8550000000}}	\N
2203	divar	ga-6D_LF	فروش زمین ناظریه داخل  مناسب ساخت ویلا و آپارتمان	میان ولایت	1980000000	sale	\N	https://divar.ir/v/_/ga-6D_LF	2026-10-01 11:09:48.073974+00	2026-10-01 11:13:49.687976+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۹۸۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 1980000000}}	\N
2204	divar	ga--jDlg	ملک اپارتمان کلنگی ۱۰۰ متری حاشیه شیخ طوسی شمالی	رده	12500000000	sale	\N	https://divar.ir/v/_/ga--jDlg	2026-10-01 11:08:33.113271+00	2026-10-01 11:13:49.689814+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رده", "amounts": {"raw_amount": 12500000000}}	\N
2205	divar	ga-6Tek0	آپارتمان ط سوم یاران۱۲	هفده شهریور	9500000000	sale	\N	https://divar.ir/v/_/ga-6Tek0	2026-10-01 11:07:38.033792+00	2026-10-01 11:13:49.691786+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفده شهریور", "amounts": {"raw_amount": 9500000000}}	\N
2208	divar	ga--jvrT	رهن و اجاره سالانه خانه ویلایی استخر داخل	کلاته برفی	\N	rent	\N	https://divar.ir/v/_/ga--jvrT	2026-10-01 11:11:22.004336+00	2026-10-01 11:13:49.696603+00	\N	\N	\N	mashhad	\N	\N	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کلاته برفی", "amounts": {"اجاره": 35000000}}	\N
2209	divar	ga--jkxp	رهن فلاحی ۷	فرهنگیان (شهرک غرب)	\N	rent	37	https://divar.ir/v/_/ga--jkxp	2026-10-01 11:10:18.971487+00	2026-10-01 11:13:49.698377+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در فرهنگیان (شهرک غرب)", "amounts": {}}	\N
2210	divar	gaqaU3p8	هم خونه ۳نفر ۱۲۰م ۲خوابه حیاط بزرگ ۸۰۰م صیاد۵۰	هفت تیر (نه دره)	\N	rent	\N	https://divar.ir/v/_/gaqaU3p8	2026-10-01 11:10:03.196497+00	2026-10-01 11:13:49.700199+00	\N	\N	\N	mashhad	\N	2	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (نه دره)", "amounts": {"اجاره": 7000000}}	\N
2222	divar	gatWwX98	زمین ملکی کلنگی خیابان امام رضا نزدیک حرم دو معبر	دانش	39000000000	sale	\N	https://divar.ir/v/_/gatWwX98	2026-09-29 10:18:05.847441+00	2026-10-01 11:24:00.833972+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در دانش", "amounts": {"raw_amount": 39000000000}}	\N
2223	divar	gauKsueg	اول الهیه/۱۱۶متر/۱۰ واحد/سازه مهندسی ساز/دربار	الهیه	11850000000	sale	44	https://divar.ir/v/_/gauKsueg	2026-10-01 07:18:12.016225+00	2026-10-01 11:24:00.841961+00	\N	\N	\N	mashhad	116	\N	\N	\N	{"mid": "۱۱,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن دربار در الهیه", "amounts": {"raw_amount": 11850000000}}	\N
2224	divar	Qa0b4etE	۵۰۳متر باغچه ملکی دور دیوار ماریان	درزآب	600000000	sale	\N	https://divar.ir/v/_/Qa0b4etE	2026-10-01 11:22:50.997627+00	2026-10-01 11:24:00.845892+00	\N	\N	\N	mashhad	503	\N	\N	\N	{"mid": "۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 600000000}}	\N
2226	divar	garO9Qvn	آپارتمان ۹۲ متری	کوشش	18400000000	sale	\N	https://divar.ir/v/_/garO9Qvn	2026-10-01 11:19:57.040857+00	2026-10-01 11:24:00.852247+00	\N	\N	\N	mashhad	92	\N	\N	\N	{"mid": "۱۸,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در کوشش", "amounts": {"raw_amount": 18400000000}}	\N
2227	divar	gaq-z1vc	آپارتمان 175 متری محدوده حرم	کوشش	25000000000	sale	\N	https://divar.ir/v/_/gaq-z1vc	2026-10-01 11:19:50.356788+00	2026-10-01 11:24:00.855627+00	\N	\N	\N	mashhad	175	\N	\N	\N	{"mid": "۲۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در کوشش", "amounts": {"raw_amount": 25000000000}}	\N
2228	divar	gaq2TEM0	آپارتمان ۱۵۰ متری محدوده حرم	کوشش	19500000000	sale	\N	https://divar.ir/v/_/gaq2TEM0	2026-10-01 11:19:43.413342+00	2026-10-01 11:24:00.858645+00	\N	\N	\N	mashhad	150	\N	\N	\N	{"mid": "۱۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در کوشش", "amounts": {"raw_amount": 19500000000}}	\N
2229	divar	ga-GEpY6	آپارتمان105متری لوکس متریال قوی لب خیابان امام رضا	امام رضا (ع)	27300000000	sale	\N	https://divar.ir/v/_/ga-GEpY6	2026-10-01 11:19:41.298595+00	2026-10-01 11:24:00.861737+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۲۷,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امام رضا (ع)", "amounts": {"raw_amount": 27300000000}}	\N
2230	divar	gam28Bnj	آپارتمان ۱۲۰ متری ۳خواب مستر فاصله تا حرم ۱۰ دقیقه	کوشش	30000000000	sale	\N	https://divar.ir/v/_/gam28Bnj	2026-10-01 11:19:37.609951+00	2026-10-01 11:24:00.864429+00	\N	\N	\N	mashhad	120	3	\N	\N	{"mid": "۳۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در کوشش", "amounts": {"raw_amount": 30000000000}}	\N
2231	divar	ga-Gkd5H	آپارتمان80مترط سوم پارکینگدار شهیدی 1 سرجلو نوساز	کشف	3400000000	sale	\N	https://divar.ir/v/_/ga-Gkd5H	2026-10-01 11:19:12.9106+00	2026-10-01 11:24:00.867304+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۳,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کشف", "amounts": {"raw_amount": 3400000000}}	\N
2232	divar	ga7msxCr	باغ ویلا دوبلکس لوکس و نوساز /تهاتر خودرو / تجاری	باغستان	79000000000	sale	\N	https://divar.ir/v/_/ga7msxCr	2026-10-01 11:18:36.880742+00	2026-10-01 11:24:00.870025+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در باغستان", "amounts": {"raw_amount": 79000000000}}	\N
2233	divar	ga-Ck7ef	فروش ۳۰۰ متر حیاط ویلایی .هر طبقه ۱۲۰ متر بنا	عبادی	41000000000	sale	\N	https://divar.ir/v/_/ga-Ck7ef	2026-10-01 11:18:35.761504+00	2026-10-01 11:24:00.873142+00	\N	\N	\N	mashhad	300	\N	\N	\N	{"mid": "۴۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در عبادی", "amounts": {"raw_amount": 41000000000}}	\N
2234	divar	ga-GDROp	ویلایی 151متر	کارمندان دوم	23000000000	sale	\N	https://divar.ir/v/_/ga-GDROp	2026-10-01 11:18:15.234731+00	2026-10-01 11:24:00.87569+00	\N	\N	\N	mashhad	151	\N	\N	\N	{"mid": "۲۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کارمندان دوم", "amounts": {"raw_amount": 23000000000}}	\N
2235	divar	gat-2rkN	فروش خانه ۷۵متری تمیز وشیک با تخفیف ویژه	انصار	2800000000	sale	\N	https://divar.ir/v/_/gat-2rkN	2026-10-01 11:18:08.590069+00	2026-10-01 11:24:00.878226+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۲,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در انصار", "amounts": {"raw_amount": 2800000000}}	\N
2236	divar	gazynGmp	آپارتمان لوکس 130 متری	امام رضا (ع)	25350000000	sale	\N	https://divar.ir/v/_/gazynGmp	2026-10-01 11:17:29.123127+00	2026-10-01 11:24:00.881054+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "۲۵,۳۵۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 25350000000}}	\N
2237	divar	gaR2TBRi	آپارتمان 170 متر نورگیر تک واحدی صفر کلید نخورده	امام رضا (ع)	25500000000	sale	\N	https://divar.ir/v/_/gaR2TBRi	2026-10-01 11:16:28.23204+00	2026-10-01 11:24:00.883629+00	\N	\N	\N	mashhad	170	\N	\N	\N	{"mid": "۲۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 25500000000}}	\N
2238	divar	ga-CkEOw	سه تاقطعه 350متری دوردیوارونماسنگ	کلاکوب	1000000000	sale	\N	https://divar.ir/v/_/ga-CkEOw	2026-10-01 11:15:32.082623+00	2026-10-01 11:24:00.888473+00	\N	\N	\N	mashhad	350	\N	\N	\N	{"mid": "۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کلاکوب", "amounts": {"raw_amount": 1000000000}}	\N
2240	divar	ga-KEk_F	اپارتمان ۸۰ متری دوخوابه	ایثارگران	\N	rent	\N	https://divar.ir/v/_/ga-KEk_F	2026-10-01 11:23:48.357614+00	2026-10-01 11:24:00.894238+00	\N	\N	\N	mashhad	80	\N	\N	16000000	{"mid": "اجاره: ۱۶,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در ایثارگران", "amounts": {"اجاره": 16000000}}	\N
2241	divar	ga-G0sjH	رهن کامل آپارتمان	رده	\N	rent	\N	https://divar.ir/v/_/ga-G0sjH	2026-10-01 11:19:26.379903+00	2026-10-01 11:24:00.896821+00	\N	\N	\N	mashhad	\N	\N	\N	50000	{"mid": "اجاره: ۵۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رده", "amounts": {"اجاره": 50000}}	\N
2242	divar	ga-CUkOn	همخونه	قائم	\N	rent	36	https://divar.ir/v/_/ga-CUkOn	2026-10-01 11:16:01.200869+00	2026-10-01 11:24:00.899447+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در قائم", "amounts": {"اجاره": 5000000}}	\N
2243	divar	gav6JH6I	۱۲۰ متر  آپارتمان نوساز ابوطالب	هدایت	\N	rent	26	https://divar.ir/v/_/gav6JH6I	2026-10-01 11:16:00.848558+00	2026-10-01 11:24:00.902171+00	\N	\N	\N	mashhad	120	\N	\N	26000000	{"mid": "اجاره: ۲۶,۰۰۰,۰۰۰ تومان", "bottom": "در هدایت", "amounts": {"اجاره": 26000000}}	\N
2257	divar	gahCge9M	۸۰ متر « ۶ واحدی ، رو به آفتاب » حسابی شمالی ۲	فرهنگیان (شهرک غرب)	7500000000	sale	37	https://divar.ir/v/_/gahCge9M	2026-09-30 14:00:47.644936+00	2026-10-01 11:34:16.823657+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن شاهان نبش فلاحی۱۳٫۶ در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 7500000000}}	\N
2258	divar	ga1JYc-Z	۱۰۰۰متر دوردیوار کاهو	میان ولایت	880000000	sale	\N	https://divar.ir/v/_/ga1JYc-Z	2026-10-01 11:34:07.342324+00	2026-10-01 11:34:16.833631+00	\N	\N	\N	mashhad	1000	\N	\N	\N	{"mid": "۸۸۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 880000000}}	\N
2260	divar	ga-WEDof	115 متری فول‌ / سند آماده / خوش‌لوکیشن رحمانیه	الهیه	13350000000	sale	44	https://divar.ir/v/_/ga-WEDof	2026-10-01 11:33:48.902286+00	2026-10-01 11:34:16.839382+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۱۳,۳۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 13350000000}}	\N
2261	divar	ga-S0ngC	آپارتمان 65متریک خواب طبقه دوم وموارد دیگه	شهید مطهری	3750000000	sale	28	https://divar.ir/v/_/ga-S0ngC	2026-10-01 11:33:42.705948+00	2026-10-01 11:34:16.842869+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۳,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهید مطهری", "amounts": {"raw_amount": 3750000000}}	\N
2262	divar	gaf-MKBR	ویلایی ۴واحدی سند تک برگ	شهید مطهری	12000000000	sale	28	https://divar.ir/v/_/gaf-MKBR	2026-10-01 11:33:34.326635+00	2026-10-01 11:34:16.845529+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید مطهری", "amounts": {"raw_amount": 12000000000}}	\N
2263	divar	ga-SUv1w	آپارتمان دهنو موج های خروشان غرق در نور	وکیل‌آباد	10900000000	sale	\N	https://divar.ir/v/_/ga-SUv1w	2026-10-01 11:33:31.670934+00	2026-10-01 11:34:16.847384+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۰,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در وکیل‌آباد", "amounts": {"raw_amount": 10900000000}}	\N
2264	divar	ga-OkHSm	اپارتمان طبرسی ۹	رده	40000000000	sale	\N	https://divar.ir/v/_/ga-OkHSm	2026-10-01 11:32:59.460936+00	2026-10-01 11:34:16.849331+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رده", "amounts": {"raw_amount": 40000000000}}	\N
2265	divar	ga-SkQ58	۱۹۰متر ویلایی با پروانه ساخت، پژن	آیت الله کاشانی	22500000000	sale	\N	https://divar.ir/v/_/ga-SkQ58	2026-10-01 11:31:02.840851+00	2026-10-01 11:34:16.851622+00	\N	\N	\N	mashhad	190	\N	\N	\N	{"mid": "۲۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آیت الله کاشانی", "amounts": {"raw_amount": 22500000000}}	\N
2266	divar	gaRCLUfu	باغ	تبادکان	4000000000	sale	\N	https://divar.ir/v/_/gaRCLUfu	2026-10-01 11:30:21.608894+00	2026-10-01 11:34:16.853922+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در تبادکان", "amounts": {"raw_amount": 4000000000}}	\N
2267	divar	ga-OEurL	زمین باغی سنددار با آب/ مناسب ویلا سازی داخل مجتمع	درزآب	290000000	sale	\N	https://divar.ir/v/_/ga-OEurL	2026-10-01 11:29:14.275311+00	2026-10-01 11:34:16.856204+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۹۰,۰۰۰,۰۰۰ تومان", "bottom": "پرهیزی شاهنامه باغ ویلا زمین در درزآب", "amounts": {"raw_amount": 290000000}}	\N
2270	divar	ganGKZSK	آپارتمان 90متری	طبرسی شمالی	3250000000	sale	42	https://divar.ir/v/_/ganGKZSK	2026-10-01 11:27:16.585259+00	2026-10-01 11:34:16.861235+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۳,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در طبرسی شمالی", "amounts": {"raw_amount": 3250000000}}	\N
2271	divar	gajW_-jc	زمین ۱۶۰ متری شمالی در سرافرازان	چهارچشمه	15000000000	sale	\N	https://divar.ir/v/_/gajW_-jc	2026-10-01 11:27:07.723641+00	2026-10-01 11:34:16.863246+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در چهارچشمه", "amounts": {"raw_amount": 15000000000}}	\N
2272	divar	ga-K0797	آپارتمان شیک دلباز	شهید قربانی	5800000000	sale	\N	https://divar.ir/v/_/ga-K0797	2026-10-01 11:26:47.539125+00	2026-10-01 11:34:16.865111+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید قربانی", "amounts": {"raw_amount": 5800000000}}	\N
2273	divar	ga-KkwOR	آپارتمان 195 / سردونبش / ویو باغ	جانباز	13500000000	sale	\N	https://divar.ir/v/_/ga-KkwOR	2026-10-01 11:25:40.905786+00	2026-10-01 11:34:16.866968+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جانباز", "amounts": {"raw_amount": 13500000000}}	\N
2274	divar	ga-OkC9r	80مترهمکف حیاطدار باپارکینگ در توس 33کشف	کشف	2700000000	sale	\N	https://divar.ir/v/_/ga-OkC9r	2026-10-01 11:25:35.470215+00	2026-10-01 11:34:16.868834+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۲,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کشف", "amounts": {"raw_amount": 2700000000}}	\N
2278	divar	ga8qMKu-	رهن و اجاره /آپارتمان 90متری/ طبقه اول.	ایثارگران	\N	rent	\N	https://divar.ir/v/_/ga8qMKu-	2026-10-01 11:33:07.368326+00	2026-10-01 11:34:16.875281+00	\N	\N	\N	mashhad	90	\N	\N	14000000	{"mid": "اجاره: ۱۴,۰۰۰,۰۰۰ تومان", "bottom": "در ایثارگران", "amounts": {"اجاره": 14000000}}	\N
2280	divar	ga-OUgul	همخونه همخانه	پنجتن	\N	rent	\N	https://divar.ir/v/_/ga-OUgul	2026-10-01 11:27:03.033037+00	2026-10-01 11:34:16.879215+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پنجتن", "amounts": {"اجاره": 10000000}}	\N
2281	divar	ga-OUBJg	۶۰متری تک خواب صفر و نوساز ایثارگران	ایثارگران	\N	rent	\N	https://divar.ir/v/_/ga-OUBJg	2026-10-01 11:25:07.08989+00	2026-10-01 11:34:16.881534+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در ایثارگران", "amounts": {}}	\N
2283	divar	ga-KUpsl	آپارتمان تخلیه پارکینگ دو خواب حاشیه	توس (بلوار توس)	\N	rent	\N	https://divar.ir/v/_/ga-KUpsl	2026-10-01 11:24:15.812149+00	2026-10-01 11:34:16.884866+00	\N	\N	\N	mashhad	\N	\N	\N	12200000	{"mid": "اجاره: ۱۲,۲۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {"اجاره": 12200000}}	\N
2297	divar	ga62qUoq	آپارتمان 95متری/نزدیک حرم/سندملک	آیت الله خامنه‌ای	18000000000	sale	\N	https://divar.ir/v/_/ga62qUoq	2026-10-01 11:44:17.442726+00	2026-10-01 11:44:27.780735+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۱۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در آیت الله خامنه‌ای", "amounts": {"raw_amount": 18000000000}}	\N
2298	divar	ga-eUA3k	آپارتمان ۱۱۰ متری با پارکینگ آسانسور کوی امیر	فدک	9250000000	sale	\N	https://divar.ir/v/_/ga-eUA3k	2026-10-01 11:44:15.402766+00	2026-10-01 11:44:27.78336+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۹,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در فدک", "amounts": {"raw_amount": 9250000000}}	\N
2299	divar	gamSEfhp	باغ ویلادوبلکس4خوابه شاهنامه14 معاوضه خودرو	توس فردوسی	14000000000	sale	\N	https://divar.ir/v/_/gamSEfhp	2026-10-01 11:43:49.221524+00	2026-10-01 11:44:27.785537+00	\N	\N	\N	mashhad	\N	4	\N	\N	{"mid": "۱۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "سرمایه گذاری ۰۹۰۵۷۶۲۱۵۸۳عدالت۰۹۳۷۴۱۴۱۶۵۵ در توس فردوسی", "amounts": {"raw_amount": 14000000000}}	\N
2300	divar	gaqRSCIR	ویلایی دوطبقه رضاییه نزدیک حرم	رضاییه	7000000000	sale	\N	https://divar.ir/v/_/gaqRSCIR	2026-10-01 11:42:16.626805+00	2026-10-01 11:44:27.788147+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رضاییه", "amounts": {"raw_amount": 7000000000}}	\N
2301	divar	ga-aExqu	ویلایی به قیمت اپارتمان ۱۰۰ متری	صیاد شیرازی	18950000000	sale	4	https://divar.ir/v/_/ga-aExqu	2026-10-01 11:41:45.653202+00	2026-10-01 11:44:27.790136+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۸,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در صیاد شیرازی", "amounts": {"raw_amount": 18950000000}}	\N
2302	divar	ga-aks4b	هنرور	هنرور	8700000000	sale	\N	https://divar.ir/v/_/ga-aks4b	2026-10-01 11:41:20.325431+00	2026-10-01 11:44:27.792276+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرور", "amounts": {"raw_amount": 8700000000}}	\N
2303	divar	ga6S8NF9	آپارتمان فروشی در کوی المهدی،قائم سیدی	کوی ولیعصر	4500000000	sale	\N	https://divar.ir/v/_/ga6S8NF9	2026-10-01 11:40:41.350607+00	2026-10-01 11:44:27.794472+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوی ولیعصر", "amounts": {"raw_amount": 4500000000}}	\N
2304	divar	ga-W0fkV	منزل ویلایی 125متری 63	نوده	7000000000	sale	\N	https://divar.ir/v/_/ga-W0fkV	2026-10-01 11:36:43.759895+00	2026-10-01 11:44:27.796816+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوده", "amounts": {"raw_amount": 7000000000}}	\N
2305	divar	ga1RIEiq	استخر داخل بوستان	میان ولایت	8200000000	sale	\N	https://divar.ir/v/_/ga1RIEiq	2026-10-01 11:35:53.143744+00	2026-10-01 11:44:27.798775+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 8200000000}}	\N
2306	divar	ga4pX6tg	۷۵۰متر با ۱۱۰متر بنا حاشیه کاهو	میان ولایت	2900000000	sale	\N	https://divar.ir/v/_/ga4pX6tg	2026-10-01 11:35:38.551662+00	2026-10-01 11:44:27.801589+00	\N	\N	\N	mashhad	750	\N	\N	\N	{"mid": "۲,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 2900000000}}	\N
2307	divar	ga-WUPKB	متر 200  اندیشه 9	شهرک رازی (شهرک غرب)	22000000000	sale	38	https://divar.ir/v/_/ga-WUPKB	2026-10-01 11:35:23.189988+00	2026-10-01 11:44:27.804042+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک رازی (شهرک غرب)", "amounts": {"raw_amount": 22000000000}}	\N
2308	divar	gah6wbPp	سه نبش 111متر حسابی شمالی 8 دو خواب آفتابگیر	فرهنگیان (شهرک غرب)	11990000000	sale	37	https://divar.ir/v/_/gah6wbPp	2026-10-01 11:35:15.502658+00	2026-10-01 11:44:27.806424+00	\N	\N	\N	mashhad	111	\N	\N	\N	{"mid": "۱۱,۹۹۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سپهر فلاحی ۱۳ در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 11990000000}}	\N
2309	divar	gaf-fLJ7	۲۵۵متر با پروانه ساخت طرقبه طرقدر شهرک نگین	شهرک لشکر (شهرک غرب)	10900000000	sale	38	https://divar.ir/v/_/gaf-fLJ7	2026-10-01 11:35:03.279683+00	2026-10-01 11:44:27.80915+00	\N	\N	\N	mashhad	255	\N	\N	\N	{"mid": "۱۰,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک لشکر (شهرک غرب)", "amounts": {"raw_amount": 10900000000}}	\N
2310	divar	gakA77NU	م خریدارحسین آبادجلدک همه پلاک هااستعلام قیمت تماس	جاهد شهر	250000000	sale	41	https://divar.ir/v/_/gakA77NU	2026-10-01 11:35:02.806097+00	2026-10-01 11:44:27.811513+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 250000000}}	\N
2313	divar	ga-aUpJq	منزل اجاره	فاطمیه	\N	rent	30	https://divar.ir/v/_/ga-aUpJq	2026-10-01 11:41:19.333765+00	2026-10-01 11:44:27.817039+00	\N	\N	\N	mashhad	\N	\N	\N	11000000	{"mid": "اجاره: ۱۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فاطمیه", "amounts": {"اجاره": 11000000}}	\N
2314	divar	ga-aEZIw	۸۰ متری ویلایی رسالت ۱۶۸	علی آباد	\N	rent	\N	https://divar.ir/v/_/ga-aEZIw	2026-10-01 11:39:34.215883+00	2026-10-01 11:44:27.819478+00	\N	\N	\N	mashhad	80	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "دقایقی پیش در علی آباد", "amounts": {"اجاره": 10000}}	\N
2315	divar	ga-SEqxM	95متر،2خواب،فقط زوج بدون فرزند، جهیزیه	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga-SEqxM	2026-10-01 11:36:37.070232+00	2026-10-01 11:44:27.821964+00	\N	\N	\N	mashhad	95	2	\N	26000000	{"mid": "اجاره: ۲۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"اجاره": 26000000}}	\N
2331	divar	ga-mkjIJ	23600مترزمین حاشیه جاده جدیده خادم آبادمیامی	اروند	30000000000	sale	\N	https://divar.ir/v/_/ga-mkjIJ	2026-10-01 11:52:58.763189+00	2026-10-01 11:54:39.332673+00	\N	\N	\N	mashhad	23600	\N	\N	\N	{"mid": "۳۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در اروند", "amounts": {"raw_amount": 30000000000}}	\N
2406	divar	ga-ehHYB	اجاره	انقلاب	\N	rent	\N	https://divar.ir/v/_/ga-ehHYB	2026-10-01 12:08:24.578858+00	2026-10-01 12:15:04.80826+00	\N	\N	\N	mashhad	\N	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در انقلاب", "amounts": {"اجاره": 6000000}}	\N
2332	divar	ga-mELwf	خانه همکف راه جدا ماشین رو فروش فوری قیمت زیر فی	نظام دوست	2650000000	sale	\N	https://divar.ir/v/_/ga-mELwf	2026-10-01 11:52:08.197171+00	2026-10-01 11:54:39.339046+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نظام دوست", "amounts": {"raw_amount": 2650000000}}	\N
2333	divar	ga-e0q0B	منزل فروشی ویلایی	نیروی هوایی	8500000000	sale	\N	https://divar.ir/v/_/ga-e0q0B	2026-10-01 11:51:14.711123+00	2026-10-01 11:54:39.345558+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نیروی هوایی", "amounts": {"raw_amount": 8500000000}}	\N
2334	divar	ga-i0JF4	واحد آپارتمان ۹۰متری	پنجتن	4299000000	sale	\N	https://divar.ir/v/_/ga-i0JF4	2026-10-01 11:51:00.01449+00	2026-10-01 11:54:39.349576+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۴,۲۹۹,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پنجتن", "amounts": {"raw_amount": 4299000000}}	\N
2335	divar	ga92m7ls	۷۰ متر ۲ خواب مستر خوش نقشه ، ۵ دقیقه تا حرم مطهر	آیت الله خامنه‌ای	17500000000	sale	\N	https://divar.ir/v/_/ga92m7ls	2026-10-01 11:50:25.060753+00	2026-10-01 11:54:39.352761+00	\N	\N	\N	mashhad	70	2	\N	\N	{"mid": "۱۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن شمس در آیت الله خامنه‌ای", "amounts": {"raw_amount": 17500000000}}	\N
2336	divar	ga9-2HUb	۹۰ متر ۲ خوابه قواره جلو ،سندآماده ،نزدیک حرم مطهر	دانش	18900000000	sale	\N	https://divar.ir/v/_/ga9-2HUb	2026-10-01 11:49:58.324504+00	2026-10-01 11:54:39.356134+00	\N	\N	\N	mashhad	90	2	\N	\N	{"mid": "۱۸,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن شمس در دانش", "amounts": {"raw_amount": 18900000000}}	\N
2337	divar	ga-iEqDL	فروش فوری زمین با موقعیت خاص و آینده دار	وکیل‌آباد	10000000000	sale	\N	https://divar.ir/v/_/ga-iEqDL	2026-10-01 11:49:52.232642+00	2026-10-01 11:54:39.358744+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در وکیل‌آباد", "amounts": {"raw_amount": 10000000000}}	\N
2338	divar	ga1GAczj	خونه آپارتمانی	همت آباد	1600000000	sale	\N	https://divar.ir/v/_/ga1GAczj	2026-10-01 11:49:26.417828+00	2026-10-01 11:54:39.360828+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در همت آباد", "amounts": {"raw_amount": 1600000000}}	\N
2339	divar	ga9C3Q3d	۱۲۸ متر ۳ خواب‌ مستر ، سندآماده ، ۳ دقیقه‌ تا حرم	حرم مطهر رضوی	28000000000	sale	\N	https://divar.ir/v/_/ga9C3Q3d	2026-10-01 11:49:04.999107+00	2026-10-01 11:54:39.362777+00	\N	\N	\N	mashhad	128	3	\N	\N	{"mid": "۲۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن شمس در حرم مطهر رضوی", "amounts": {"raw_amount": 28000000000}}	\N
2340	divar	gajGaOfa	زمین ثامن ۱۳(محله شاندیز)	الهیه	12000000000	sale	44	https://divar.ir/v/_/gajGaOfa	2026-10-01 11:48:56.965953+00	2026-10-01 11:54:39.364794+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 12000000000}}	\N
2341	divar	ga2SXIjf	منزل ویلایی ۱۰۰ متری در دوطبقه خ ولیعصر ونیلوفر	امیر	10500000000	sale	\N	https://divar.ir/v/_/ga2SXIjf	2026-10-01 11:48:55.01966+00	2026-10-01 11:54:39.366879+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیر", "amounts": {"raw_amount": 10500000000}}	\N
2343	divar	gatSBbW-	رهن آپارتمان ۲۵۰متری صفر ۴خوابه فرامرز عباسی	شهید فرامرز عباسی	\N	rent	\N	https://divar.ir/v/_/gatSBbW-	2026-10-01 11:51:16.167406+00	2026-10-01 11:54:39.370156+00	\N	\N	\N	mashhad	250	4	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "در شهید فرامرز عباسی", "amounts": {"اجاره": 1000}}	\N
2344	divar	ga-m0H5N	منزل ۲ طبقه دربست رهن	طلاب	\N	rent	\N	https://divar.ir/v/_/ga-m0H5N	2026-10-01 11:51:02.73079+00	2026-10-01 11:54:39.372515+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طلاب", "amounts": {"اجاره": 1000000}}	\N
2345	divar	gaxukk6u	رهن واجاره ...شهرک بهار انتهای خیایان خین عرب	بهار	\N	rent	\N	https://divar.ir/v/_/gaxukk6u	2026-10-01 11:48:59.593159+00	2026-10-01 11:54:39.37898+00	\N	\N	\N	mashhad	\N	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "در بهار", "amounts": {"اجاره": 2000000}}	\N
2359	divar	ga7qSPw8	سه خوابه 160متری لوکس در چراغچی یک	ایثارگران	5800000000	sale	\N	https://divar.ir/v/_/ga7qSPw8	2026-09-29 03:16:26.162413+00	2026-10-01 12:04:54.350454+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۵,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در ایثارگران", "amounts": {"raw_amount": 5800000000}}	\N
2360	divar	ga-uE51v	50متر حاشیه اقدسیه سند آماده بازسازی کامل	الهیه	4500000000	sale	44	https://divar.ir/v/_/ga-uE51v	2026-10-01 12:03:41.290636+00	2026-10-01 12:04:54.362953+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سامانیه در الهیه", "amounts": {"raw_amount": 4500000000}}	\N
2361	divar	ga-uknHx	فروش واحد ۸۲ متری	چهارچشمه	8700000000	sale	\N	https://divar.ir/v/_/ga-uknHx	2026-10-01 12:03:04.3255+00	2026-10-01 12:04:54.369731+00	\N	\N	\N	mashhad	82	\N	\N	\N	{"mid": "۸,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهارچشمه", "amounts": {"raw_amount": 8700000000}}	\N
2362	divar	ganRx7M5	تکواحدی صفر از برند لاکچری ابتدا محمدیه 2 ژورنالی	الهیه	19900000000	sale	44	https://divar.ir/v/_/ganRx7M5	2026-10-01 12:02:45.064095+00	2026-10-01 12:04:54.373644+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۹,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 19900000000}}	\N
2363	divar	gaVGnxyk	150متر صفر 2نبش ویوابدی پارک //3خواب پنجره قدی	الهیه	15500000000	sale	44	https://divar.ir/v/_/gaVGnxyk	2026-10-01 12:02:30.044839+00	2026-10-01 12:04:54.37646+00	\N	\N	\N	mashhad	150	3	\N	\N	{"mid": "۱۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 15500000000}}	\N
2364	divar	ga-mEsdm	منزل ویلایی	زیرکن	5000000000	sale	\N	https://divar.ir/v/_/ga-mEsdm	2026-10-01 12:02:10.279689+00	2026-10-01 12:04:54.37859+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در زیرکن", "amounts": {"raw_amount": 5000000000}}	\N
2365	divar	ga-ukoa4	۲هزارمتر زمین زعفرون۴ساله شاهنامه۸۰ سرمایه گذاری	درزآب	660000000	sale	\N	https://divar.ir/v/_/ga-ukoa4	2026-10-01 12:01:50.4194+00	2026-10-01 12:04:54.380749+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶۶۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در درزآب", "amounts": {"raw_amount": 660000000}}	\N
2366	divar	ga-ukTHM	۱۲۰ متر فرشته طبقه اول کلید نخورده	کوثر	22000000000	sale	13	https://divar.ir/v/_/ga-ukTHM	2026-10-01 12:00:24.876437+00	2026-10-01 12:04:54.382806+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۲۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"raw_amount": 22000000000}}	\N
2594	divar	gaui9vMB	زمین خام تاباغ	توس فردوسی	200000000	sale	\N	https://divar.ir/v/_/gaui9vMB	2026-10-01 15:06:48.250724+00	2026-10-01 15:08:33.221799+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس فردوسی", "amounts": {"raw_amount": 200000000}}	\N
2367	divar	ga-uUCHw	منزل ویلایی مغازه دارد ۷متر حاشیه	طبرسی شمالی	9000000000	sale	42	https://divar.ir/v/_/ga-uUCHw	2026-10-01 11:59:54.649349+00	2026-10-01 12:04:54.384809+00	\N	\N	\N	mashhad	7	\N	\N	\N	{"mid": "۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {"raw_amount": 9000000000}}	\N
2369	divar	ga-q0dn9	۸۵ متری تک واحدی ۲خواب محدوده هف تیر و صیاد	هفت تیر (نه دره)	6800000000	sale	\N	https://divar.ir/v/_/ga-q0dn9	2026-10-01 11:57:54.402381+00	2026-10-01 12:04:54.388274+00	\N	\N	\N	mashhad	85	2	\N	\N	{"mid": "۶,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (نه دره)", "amounts": {"raw_amount": 6800000000}}	\N
2370	divar	ga-q0n5O	قاسم اباد/خوش نقشه /آفتابگیر/	جاهد شهر	13900000000	sale	41	https://divar.ir/v/_/ga-q0n5O	2026-10-01 11:57:27.687138+00	2026-10-01 12:04:54.390243+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۳,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"raw_amount": 13900000000}}	\N
2373	divar	ga-uU-1d	رهن و اجاره ویلایی دو طبقه مجزا رستمی مصلی	محمدآباد	\N	rent	\N	https://divar.ir/v/_/ga-uU-1d	2026-10-01 12:03:59.994073+00	2026-10-01 12:04:54.395622+00	\N	\N	\N	mashhad	\N	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در محمدآباد", "amounts": {"اجاره": 25000000}}	\N
2388	divar	gauOca8Z	اول رحمانیه ۱۲۷ متر سازه سوپرلوکس (مسکن دربار)	الهیه	12300000000	sale	44	https://divar.ir/v/_/gauOca8Z	2026-09-25 10:02:29.899829+00	2026-10-01 12:15:04.76302+00	\N	\N	\N	mashhad	127	\N	\N	\N	{"mid": "۱۲,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن دربار در الهیه", "amounts": {"raw_amount": 12300000000}}	\N
2389	divar	ga1Wzjgq	باغ ویلا شاهنامه 14 رضویه عشق آباد با آب برق گاز	میان ولایت	5750000000	sale	\N	https://divar.ir/v/_/ga1Wzjgq	2026-09-24 14:40:39.807091+00	2026-10-01 12:15:04.768886+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 5750000000}}	\N
2390	divar	ga-6kekT	اپارتمان دربست ،همکف	هفت تیر (نه دره)	2565000000	sale	\N	https://divar.ir/v/_/ga-6kekT	2026-10-01 12:14:28.272448+00	2026-10-01 12:15:04.773312+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۵۶۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در هفت تیر (نه دره)", "amounts": {"raw_amount": 2565000000}}	\N
2391	divar	ga-6UKUm	عمارت ویلایی در مشهد نزدیک حرم	سعد آباد	57000000000	sale	\N	https://divar.ir/v/_/ga-6UKUm	2026-10-01 12:13:24.523592+00	2026-10-01 12:15:04.776286+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سعد آباد", "amounts": {"raw_amount": 57000000000}}	\N
2392	divar	ga-2020m	65 متر یک خوابه مناسب جهیزیه	شهرآرا	2550000000	sale	3	https://divar.ir/v/_/ga-2020m	2026-10-01 12:11:46.034495+00	2026-10-01 12:15:04.779195+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۲,۵۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرآرا", "amounts": {"raw_amount": 2550000000}}	\N
2393	divar	ga--wOfq	باغ ویلا شیک ۳۰۰متری شاهنامه ۶۹روستای	درزآب	2800000000	sale	\N	https://divar.ir/v/_/ga--wOfq	2026-10-01 12:11:07.457079+00	2026-10-01 12:15:04.781232+00	\N	\N	\N	mashhad	300	\N	\N	\N	{"mid": "۲,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در درزآب", "amounts": {"raw_amount": 2800000000}}	\N
2394	divar	ga-yk455	زمین رسالت ۹۲	سیس‌آباد	270000000	sale	\N	https://divar.ir/v/_/ga-yk455	2026-10-01 12:10:53.814395+00	2026-10-01 12:15:04.783074+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۷۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سیس‌آباد", "amounts": {"raw_amount": 270000000}}	\N
2395	divar	ga-2knly	آپارتمان فلسطین	فلسطین	25200000000	sale	19	https://divar.ir/v/_/ga-2knly	2026-10-01 12:10:51.042531+00	2026-10-01 12:15:04.785237+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۵,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فلسطین", "amounts": {"raw_amount": 25200000000}}	\N
2396	divar	ga-2kHZ4	باغ ویلا	کلاته برفی	29000000000	sale	\N	https://divar.ir/v/_/ga-2kHZ4	2026-10-01 12:10:40.498114+00	2026-10-01 12:15:04.787388+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کلاته برفی", "amounts": {"raw_amount": 29000000000}}	\N
2397	divar	ga66gsQk	اپارتمان فتاح	رسالت	3250000000	sale	32	https://divar.ir/v/_/ga66gsQk	2026-10-01 12:09:04.930667+00	2026-10-01 12:15:04.789304+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در رسالت", "amounts": {"raw_amount": 3250000000}}	\N
2398	divar	ga7u9aWj	فروش یک قطعه زمین ۵۵۰ متری متری دور دیوار	میان ولایت	5500000000	sale	\N	https://divar.ir/v/_/ga7u9aWj	2026-10-01 12:07:41.925958+00	2026-10-01 12:15:04.791193+00	\N	\N	\N	mashhad	550	\N	\N	\N	{"mid": "۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 5500000000}}	\N
2399	divar	ga-mwNUj	اپارتمان ۱۲۰متری دوخواب پارکینگ اسانسور	توس (بلوار توس)	5400000000	sale	\N	https://divar.ir/v/_/ga-mwNUj	2026-10-01 12:06:15.321782+00	2026-10-01 12:15:04.793757+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۵,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس (بلوار توس)", "amounts": {"raw_amount": 5400000000}}	\N
2400	divar	gaH924aI	شاهنامه۷۰	چهاربرج	1300000000	sale	\N	https://divar.ir/v/_/gaH924aI	2026-10-01 12:04:49.615628+00	2026-10-01 12:15:04.795718+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در چهاربرج", "amounts": {"raw_amount": 1300000000}}	\N
2401	divar	ga-6kijo	همخونه بیاد لطفا	مصلی (کارمندان اول)	\N	rent	\N	https://divar.ir/v/_/ga-6kijo	2026-10-01 12:14:50.247526+00	2026-10-01 12:15:04.797674+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در مصلی (کارمندان اول)", "amounts": {"اجاره": 1000000}}	\N
2402	divar	ga-uE58n	رهن کامل آپارتمان	رده	\N	rent	\N	https://divar.ir/v/_/ga-uE58n	2026-10-01 12:13:36.295724+00	2026-10-01 12:15:04.800108+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رده", "amounts": {"اجاره": 10000}}	\N
2403	divar	gal247GE	اوایل دانشجو آپارتمان ۱۶۰ متری ۳خوابه طبقه ۴	دانشجو	\N	rent	39	https://divar.ir/v/_/gal247GE	2026-10-01 12:12:52.817645+00	2026-10-01 12:15:04.801997+00	\N	\N	\N	mashhad	160	3	\N	37000000	{"mid": "اجاره: ۳۷,۰۰۰,۰۰۰ تومان", "bottom": "در دانشجو", "amounts": {"اجاره": 37000000}}	\N
2404	divar	ga-ykyh5	اجاره یک واحد آپارتمان	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga-ykyh5	2026-10-01 12:09:06.349036+00	2026-10-01 12:15:04.80412+00	\N	\N	\N	mashhad	\N	\N	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"اجاره": 35000000}}	\N
2405	divar	ga1-0cS1	خونه نقلی سوئیتی بدون وسایل	شهرک ابوذر	\N	rent	24	https://divar.ir/v/_/ga1-0cS1	2026-10-01 12:08:30.335099+00	2026-10-01 12:15:04.806276+00	\N	\N	\N	mashhad	\N	\N	\N	3500000	{"mid": "اجاره: ۳,۵۰۰,۰۰۰ تومان", "bottom": "در شهرک ابوذر", "amounts": {"اجاره": 3500000}}	\N
2407	divar	ga-2kAAN	رهن اجاره آپارتمان ۷۵ متری صارمی	کوثر	\N	rent	13	https://divar.ir/v/_/ga-2kAAN	2026-10-01 12:08:09.814019+00	2026-10-01 12:15:04.810219+00	\N	\N	\N	mashhad	75	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن مهرداد در کوثر", "amounts": {"اجاره": 15000000}}	\N
2416	divar	ga-OmTf7	ویلایی 50متری	طبرسی شمالی	1500000000	sale	42	https://divar.ir/v/_/ga-OmTf7	2026-10-01 13:43:24.854308+00	2026-10-01 13:43:39.557808+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگذاری امـــلاک آرش در طبرسی شمالی", "amounts": {"raw_amount": 1500000000}}	\N
2417	divar	ga-GidDS	آپارتمان ۸۷ متری/ مجیدیه/ خوش نقشه(دونبش)	جاهد شهر	9500000000	sale	41	https://divar.ir/v/_/ga-GidDS	2026-10-01 13:43:23.997541+00	2026-10-01 13:43:39.562249+00	\N	\N	\N	mashhad	87	\N	\N	\N	{"mid": "۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در جاهد شهر", "amounts": {"raw_amount": 9500000000}}	\N
2418	divar	ga-OmaFM	۱۵۰ متر / ۸ واحدی / ۲ نبش / صفر سند آماده	الهیه	16000000000	sale	44	https://divar.ir/v/_/ga-OmaFM	2026-10-01 13:43:18.295024+00	2026-10-01 13:43:39.565892+00	\N	\N	\N	mashhad	150	\N	\N	\N	{"mid": "۱۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 16000000000}}	\N
2419	divar	gaeC4i3c	122 متر/ شمالی در بزرگترین خیابان فلاحی/ بانو پسند	شهرک لشکر (شهرک غرب)	13490000000	sale	38	https://divar.ir/v/_/gaeC4i3c	2026-10-01 13:42:22.421315+00	2026-10-01 13:43:39.569619+00	\N	\N	\N	mashhad	122	\N	\N	\N	{"mid": "۱۳,۴۹۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک لشکر (شهرک غرب)", "amounts": {"raw_amount": 13490000000}}	\N
2420	divar	gayeanpc	یک آپارتمان تک واحدی زیبا	گوهرشاد	20500000000	sale	20	https://divar.ir/v/_/gayeanpc	2026-10-01 13:41:49.509284+00	2026-10-01 13:43:39.573452+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در گوهرشاد", "amounts": {"raw_amount": 20500000000}}	\N
2421	divar	gaw1jkNA	بهترین شرایط خانه دار شدن	یوسفیه (شهرک غرب)	5000000000	sale	38	https://divar.ir/v/_/gaw1jkNA	2026-10-01 13:41:15.362402+00	2026-10-01 13:43:39.577611+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در یوسفیه (شهرک غرب)", "amounts": {"raw_amount": 5000000000}}	\N
2422	divar	ga-KWFWQ	هوای طبرسی شمالی	رده	1250000000	sale	\N	https://divar.ir/v/_/ga-KWFWQ	2026-10-01 13:38:22.319195+00	2026-10-01 13:43:39.581936+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رده", "amounts": {"raw_amount": 1250000000}}	\N
2423	divar	Qa6bu6cu	۱۷۰۰ متر باغ ویلا بسیار شیک و مجلل/شاهنامه ۱۴	توس (بلوار توس)	16500000000	sale	\N	https://divar.ir/v/_/Qa6bu6cu	2026-10-01 13:37:17.956442+00	2026-10-01 13:43:39.587039+00	\N	\N	\N	mashhad	1700	\N	\N	\N	{"mid": "۱۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس (بلوار توس)", "amounts": {"raw_amount": 16500000000}}	\N
2424	divar	ga-Gm5vn	81متر/ شریعتی /طبقه سوم ( آسانسور)	نرگس (شهرک غرب)	9040000000	sale	38	https://divar.ir/v/_/ga-Gm5vn	2026-10-01 13:37:07.144073+00	2026-10-01 13:43:39.591472+00	\N	\N	\N	mashhad	81	\N	\N	\N	{"mid": "۹,۰۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نرگس (شهرک غرب)", "amounts": {"raw_amount": 9040000000}}	\N
2425	divar	ga-6F2-t	کوی سیدی شهید ،دایی ۵۱ فدایی ۷،یا دایی ۳۷ خانی ۱۰	کوی سیدی	3550000000	sale	\N	https://divar.ir/v/_/ga-6F2-t	2026-10-01 13:36:45.745634+00	2026-10-01 13:43:39.596069+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۵۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی سیدی", "amounts": {"raw_amount": 3550000000}}	\N
2426	divar	ga-OlroK	75متر،شخصــی ساز 6واحدی مجیدیه 17 (مرشدلو)	جاهد شهر	7850000000	sale	41	https://divar.ir/v/_/ga-OlroK	2026-10-01 13:36:42.540643+00	2026-10-01 13:43:39.599921+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۷,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"raw_amount": 7850000000}}	\N
2428	divar	ga-KW9jb	۱۷۵متر/تکواحدی/گلشن	هنرستان	\N	rent	11	https://divar.ir/v/_/ga-KW9jb	2026-10-01 13:42:17.432851+00	2026-10-01 13:43:39.605465+00	\N	\N	\N	mashhad	175	\N	\N	50000000	{"mid": "اجاره: ۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرستان", "amounts": {"اجاره": 50000000}}	\N
2429	divar	ga-KGpYc	125 مـتر / تـخـلیه  / شـخصی ساز /فُوول	حسابی جنوبی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-KGpYc	2026-10-01 13:40:48.186373+00	2026-10-01 13:43:39.609799+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حسابی جنوبی (شهرک غرب)", "amounts": {"اجاره": 15000000}}	\N
2430	divar	ga-KWpk5	رهن صد میلیون و اجاره ۸میلیون	پنجتن	\N	rent	\N	https://divar.ir/v/_/ga-KWpk5	2026-10-01 13:40:01.6537+00	2026-10-01 13:43:39.613478+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پنجتن", "amounts": {"اجاره": 8000000}}	\N
2431	divar	ga-KGEkY	واحد مسکونی شیک صیاد رهن و اجاره	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/ga-KGEkY	2026-10-01 13:37:47.580546+00	2026-10-01 13:43:39.616914+00	\N	\N	\N	mashhad	\N	\N	\N	55000000	{"mid": "اجاره: ۵۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن صبوری در هفت تیر (حافظ)", "amounts": {"اجاره": 55000000}}	\N
2432	divar	ga56R5Cw	127متر/مجیدیه27/تخلیه/مستغلاتی	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga56R5Cw	2026-10-01 13:37:12.677109+00	2026-10-01 13:43:39.620442+00	\N	\N	\N	mashhad	127	\N	\N	32000000	{"mid": "اجاره: ۳۲,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"اجاره": 32000000}}	\N
2433	divar	ga9yQMbq	اجاره ویلایی کارگاهی	تلگرد	\N	rent	\N	https://divar.ir/v/_/ga9yQMbq	2026-10-01 13:35:11.360336+00	2026-10-01 13:43:39.623934+00	\N	\N	\N	mashhad	\N	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در تلگرد", "amounts": {"اجاره": 6000000}}	\N
2434	divar	gaxK2BnC	رهن واجاره خانه دربست(۱۴۰ متر)(نوساز)در شهیدبهشتی	شهید بهشتی	\N	rent	18	https://divar.ir/v/_/gaxK2BnC	2026-10-01 13:35:09.790962+00	2026-10-01 13:43:39.627364+00	\N	\N	\N	mashhad	140	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "در شهید بهشتی", "amounts": {"اجاره": 3000000}}	\N
2435	divar	ga-GGCxi	همخونه	شهید جنگی	\N	rent	\N	https://divar.ir/v/_/ga-GGCxi	2026-10-01 13:33:02.335217+00	2026-10-01 13:43:39.631523+00	\N	\N	\N	mashhad	\N	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید جنگی", "amounts": {"اجاره": 2000000}}	\N
2436	divar	ga--13VW	اپارتمان ۱۶۰ متری رهن کامل	سجاد شهر	\N	rent	21	https://divar.ir/v/_/ga--13VW	2026-10-01 13:31:23.317723+00	2026-10-01 13:43:39.635746+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در سجاد شهر", "amounts": {}}	\N
2437	divar	ga-CmbVT	آپارتمان ۵۰ متری	شهرآرا	\N	rent	3	https://divar.ir/v/_/ga-CmbVT	2026-10-01 13:30:34.163415+00	2026-10-01 13:43:39.640032+00	\N	\N	\N	mashhad	50	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرآرا", "amounts": {"اجاره": 10000000}}	\N
2438	divar	ga-CmVCI	اجاره خونه	توس (بلوار توس)	\N	rent	\N	https://divar.ir/v/_/ga-CmVCI	2026-10-01 13:30:07.6726+00	2026-10-01 13:43:39.644787+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {"اجاره": 1000000}}	\N
2439	divar	ga9OCw_6	آپارتمان 120متری 2 خواب تخلیه	الهیه	\N	rent	44	https://divar.ir/v/_/ga9OCw_6	2026-10-01 13:29:56.223058+00	2026-10-01 13:43:39.64949+00	\N	\N	\N	mashhad	120	2	\N	18000000	{"mid": "اجاره: ۱۸,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در الهیه", "amounts": {"اجاره": 18000000}}	\N
2440	divar	ga7irQQb	۸۵متر مفیدبرج آسمان ویوشهر ط۸ پارکینگ مسقف انباری	آبادگران	\N	rent	\N	https://divar.ir/v/_/ga7irQQb	2026-10-01 13:27:15.944293+00	2026-10-01 13:43:39.653081+00	\N	\N	\N	mashhad	85	\N	\N	22000000	{"mid": "اجاره: ۲۲,۰۰۰,۰۰۰ تومان", "bottom": "در آبادگران", "amounts": {"اجاره": 22000000}}	\N
2442	divar	ga5qzfxi	ویلایی ۲۵۰متری تراکم دار هاشمیه ۴۰/۱	چهارچشمه	58000000000	sale	\N	https://divar.ir/v/_/ga5qzfxi	2026-10-01 13:53:17.65733+00	2026-10-01 13:54:03.715811+00	\N	\N	\N	mashhad	250	\N	\N	\N	{"mid": "۵۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در چهارچشمه", "amounts": {"raw_amount": 58000000000}}	\N
2443	divar	ga_RwT-q	دورد آپارتمان 85متری خاص دوخوابه صفر	امیر	4450000000	sale	\N	https://divar.ir/v/_/ga_RwT-q	2026-10-01 13:51:24.815762+00	2026-10-01 13:54:03.723945+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۴,۴۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیر", "amounts": {"raw_amount": 4450000000}}	\N
2444	divar	ga6-4s8Q	آپارتمان 72متری طلاب،مفتح میرزاکوچک خان5	سجادیه	5200000000	sale	21	https://divar.ir/v/_/ga6-4s8Q	2026-10-01 13:51:02.324079+00	2026-10-01 13:54:03.730619+00	\N	\N	\N	mashhad	72	\N	\N	\N	{"mid": "۵,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در سجادیه", "amounts": {"raw_amount": 5200000000}}	\N
2445	divar	ga-Sm_QZ	آپارتمان وحید زیر فی	طلاب	2800000000	sale	\N	https://divar.ir/v/_/ga-Sm_QZ	2026-10-01 13:50:30.758604+00	2026-10-01 13:54:03.73542+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طلاب", "amounts": {"raw_amount": 2800000000}}	\N
2446	divar	ga72LUPI	۱۹۸متر*2p*صفر*سندآماده*رحمانیه	الهیه	18390000000	sale	44	https://divar.ir/v/_/ga72LUPI	2026-10-01 13:50:21.827715+00	2026-10-01 13:54:03.740751+00	\N	\N	\N	mashhad	198	\N	\N	\N	{"mid": "۱۸,۳۹۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 18390000000}}	\N
2447	divar	ga-SW3A9	آپارتمان ۱۹۳متری سه نبش حاشیه اندیشه فول	مشکینی (شهرک غرب)	17300000000	sale	38	https://divar.ir/v/_/ga-SW3A9	2026-10-01 13:50:21.183801+00	2026-10-01 13:54:03.744535+00	\N	\N	\N	mashhad	193	\N	\N	\N	{"mid": "۱۷,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مشکینی (شهرک غرب)", "amounts": {"raw_amount": 17300000000}}	\N
2448	divar	ga-SGtmF	آپارتمان صفر ، فول امکانات	هدایت	11800000000	sale	26	https://divar.ir/v/_/ga-SGtmF	2026-10-01 13:50:17.484502+00	2026-10-01 13:54:03.749097+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۱,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هدایت", "amounts": {"raw_amount": 11800000000}}	\N
2449	divar	gatKwVsU	خانه فروشی فوری  شکاردر بهمن با تخفیف خوب	بهمن	3150000000	sale	43	https://divar.ir/v/_/gatKwVsU	2026-10-01 13:50:06.501474+00	2026-10-01 13:54:03.753578+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهمن", "amounts": {"raw_amount": 3150000000}}	\N
2450	divar	ga-S224K	آپارتمان ۱۱۰ متری خادم الشریعه ۱۸	توس (بلوار توس)	4900000000	sale	\N	https://divar.ir/v/_/ga-S224K	2026-10-01 13:49:49.825942+00	2026-10-01 13:54:03.757407+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۴,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {"raw_amount": 4900000000}}	\N
2451	divar	ga-6ydn-	آپارتمان64متری یک خواب/مجتمع فیروزه شرق/شمس	ده دی	9000000000	sale	\N	https://divar.ir/v/_/ga-6ydn-	2026-10-01 13:49:39.678702+00	2026-10-01 13:54:03.761456+00	\N	\N	\N	mashhad	64	\N	\N	\N	{"mid": "۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن شمس در ده دی", "amounts": {"raw_amount": 9000000000}}	\N
2452	divar	gabOpEp8	فروش باغچه۵۰۰ متری سند ملکی اب برق گاز ماریان	درزآب	900000000	sale	\N	https://divar.ir/v/_/gabOpEp8	2026-10-01 13:49:29.526277+00	2026-10-01 13:54:03.765841+00	\N	\N	\N	mashhad	500	\N	\N	\N	{"mid": "۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دفترفروش مجتمع های پردیس در درزآب", "amounts": {"raw_amount": 900000000}}	\N
2453	divar	ga4Guxix	همکف ۶۵ متری ، راه جدا	رستگار	\N	rent	\N	https://divar.ir/v/_/ga4Guxix	2026-09-27 09:29:51.68104+00	2026-10-01 13:54:03.769947+00	\N	\N	\N	mashhad	65	\N	\N	9000000	{"mid": "اجاره: ۹,۰۰۰,۰۰۰ تومان", "bottom": "در رستگار", "amounts": {"اجاره": 9000000}}	\N
2454	divar	ga-WGiL3	واحد ۷۰ متری دوخواب	حسابی جنوبی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-WGiL3	2026-10-01 13:53:18.095342+00	2026-10-01 13:54:03.773831+00	\N	\N	\N	mashhad	70	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در حسابی جنوبی (شهرک غرب)", "amounts": {"اجاره": 5000000}}	\N
2455	divar	ga-W2YXL	ویلایی دوبلکس اول جاده شاندیز روبروی موجهای خروشان	وکیل‌آباد	\N	rent	\N	https://divar.ir/v/_/ga-W2YXL	2026-10-01 13:52:38.020645+00	2026-10-01 13:54:03.778026+00	\N	\N	\N	mashhad	\N	\N	\N	55000000	{"mid": "اجاره: ۵۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در وکیل‌آباد", "amounts": {"اجاره": 55000000}}	\N
2456	divar	ga-WWUns	اجاره اپارتمان امیریه طلائیه	امیریه	\N	rent	\N	https://divar.ir/v/_/ga-WWUns	2026-10-01 13:51:59.34619+00	2026-10-01 13:54:03.78205+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیریه", "amounts": {"اجاره": 15000000}}	\N
2457	divar	gaZ2hJIb	۷۶ متری /هاشمیه/نورگیر/نوساز	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/gaZ2hJIb	2026-10-01 13:51:40.585753+00	2026-10-01 13:54:03.786492+00	\N	\N	\N	mashhad	76	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن مهرداد در چهارچشمه", "amounts": {}}	\N
2458	divar	ga-SG5FW	۱۶۰متر صفر دانشجو / قائم مقام نزدیک حاشیه معلم	دانشجو	\N	rent	39	https://divar.ir/v/_/ga-SG5FW	2026-10-01 13:49:54.831651+00	2026-10-01 13:54:03.791408+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "رهن کامل", "bottom": "املاك مرتضی محمدی در دانشجو", "amounts": {}}	\N
2460	divar	ga-SWdke	۷۵متری/همکف/اوایل هاشمیه/نورگیر	کوثر	\N	rent	13	https://divar.ir/v/_/ga-SWdke	2026-10-01 13:48:22.749355+00	2026-10-01 13:54:03.798154+00	\N	\N	\N	mashhad	75	\N	\N	28000000	{"mid": "اجاره: ۲۸,۰۰۰,۰۰۰ تومان", "bottom": "مسکن مهرداد در کوثر", "amounts": {"اجاره": 28000000}}	\N
2461	divar	ga6mlo1R	هم خونه خانم	حیدرآباد	\N	rent	\N	https://divar.ir/v/_/ga6mlo1R	2026-10-01 13:46:09.95585+00	2026-10-01 13:54:03.802037+00	\N	\N	\N	mashhad	\N	\N	\N	7500000	{"mid": "اجاره: ۷,۵۰۰,۰۰۰ تومان", "bottom": "در حیدرآباد", "amounts": {"اجاره": 7500000}}	\N
2462	divar	gallLU_I	آپارتمان تمیز ۸۵ متری ۲ خواب	مصلی (کارمندان اول)	\N	rent	\N	https://divar.ir/v/_/gallLU_I	2026-10-01 13:45:13.877168+00	2026-10-01 13:54:03.806078+00	\N	\N	\N	mashhad	85	2	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "در مصلی (کارمندان اول)", "amounts": {"اجاره": 5000000}}	\N
2463	divar	ga-O2yEi	واحد ۱۵۰ متری ۳ خواب فول امکانات	گلبرگ	\N	rent	\N	https://divar.ir/v/_/ga-O2yEi	2026-10-01 13:44:55.172774+00	2026-10-01 13:54:03.811408+00	\N	\N	\N	mashhad	150	3	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گلبرگ", "amounts": {"اجاره": 25000000}}	\N
2464	divar	ga-O2baV	سوئیت مجردی/هاشمیه	هنرستان	\N	rent	11	https://divar.ir/v/_/ga-O2baV	2026-10-01 13:44:25.300817+00	2026-10-01 13:54:03.815801+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرستان", "amounts": {"اجاره": 15000000}}	\N
2468	divar	ga-eGwb2	زمین واحد آپارتمان سیدی صبا سپاه رباط طرق ده غیبی	انقلاب	750000000	sale	\N	https://divar.ir/v/_/ga-eGwb2	2026-10-01 14:04:21.868004+00	2026-10-01 14:04:34.695978+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در انقلاب", "amounts": {"raw_amount": 750000000}}	\N
2469	divar	ga-Oy0Mf	فروش آپارتمان فوری کشف	کشف	3700000000	sale	\N	https://divar.ir/v/_/ga-Oy0Mf	2026-10-01 14:04:08.33296+00	2026-10-01 14:04:34.702803+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کشف", "amounts": {"raw_amount": 3700000000}}	\N
2470	divar	ga-aG-gh	85 متر دوخوابه فول	حسین‌آباد	6700000000	sale	\N	https://divar.ir/v/_/ga-aG-gh	2026-10-01 14:03:29.866196+00	2026-10-01 14:04:34.709312+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۶,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در حسین‌آباد", "amounts": {"raw_amount": 6700000000}}	\N
2471	divar	ga-em_oJ	فروش خانه در شاهنامه	چهاربرج	1500000000	sale	\N	https://divar.ir/v/_/ga-em_oJ	2026-10-01 14:03:27.519909+00	2026-10-01 14:04:34.714876+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در چهاربرج", "amounts": {"raw_amount": 1500000000}}	\N
2472	divar	ga-emb6M	باغ ویلا درروستای رضوان	تبادکان	5000000000	sale	\N	https://divar.ir/v/_/ga-emb6M	2026-10-01 14:02:45.629395+00	2026-10-01 14:04:34.71983+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در تبادکان", "amounts": {"raw_amount": 5000000000}}	\N
2473	divar	gaa-4wbU	آپارتمان 80متری فول فرنیش	کوشش	17000000000	sale	\N	https://divar.ir/v/_/gaa-4wbU	2026-10-01 14:02:32.539522+00	2026-10-01 14:04:34.724561+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۱۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در کوشش", "amounts": {"raw_amount": 17000000000}}	\N
2474	divar	ga-em0Ln	آپارتمان122متری/سنددار/فول سرسه نبش	حسین‌آباد	11590000000	sale	\N	https://divar.ir/v/_/ga-em0Ln	2026-10-01 14:02:04.188569+00	2026-10-01 14:04:34.729401+00	\N	\N	\N	mashhad	122	\N	\N	\N	{"mid": "۱۱,۵۹۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری سراسری سلیمانی در حسین‌آباد", "amounts": {"raw_amount": 11590000000}}	\N
2475	divar	ga92TV9h	۸۷ متر، برج نگین الماس، تقاطع سجادیه و اقدسیه	الهیه	9770000000	sale	44	https://divar.ir/v/_/ga92TV9h	2026-10-01 14:02:00.208298+00	2026-10-01 14:04:34.734598+00	\N	\N	\N	mashhad	87	\N	\N	\N	{"mid": "۹,۷۷۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 9770000000}}	\N
2476	divar	ga1mCzyl	آپارتمان 80 متر 2 خواب شیک	مشکینی (شهرک غرب)	4300000000	sale	38	https://divar.ir/v/_/ga1mCzyl	2026-10-01 14:01:44.24411+00	2026-10-01 14:04:34.740495+00	\N	\N	\N	mashhad	80	2	\N	\N	{"mid": "۴,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در مشکینی (شهرک غرب)", "amounts": {"raw_amount": 4300000000}}	\N
2477	divar	gaU6TEc4	زمین جلدک باکد نوسازی  الهیه دیگر در راه است	جاهد شهر	760000000	sale	41	https://divar.ir/v/_/gaU6TEc4	2026-10-01 14:01:12.424544+00	2026-10-01 14:04:34.746033+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷۶۰,۰۰۰,۰۰۰ تومان", "bottom": "مهندس فخیم زاده حسین اباد جلدک خرید فروش  در جاهد شهر", "amounts": {"raw_amount": 760000000}}	\N
2478	divar	gaE-kQ9d	آپارتمان ۱۶۰متری ۳خواب،تک‌واحدی،خیابان۲۰متری،نوساز	امام رضا (ع)	32000000000	sale	\N	https://divar.ir/v/_/gaE-kQ9d	2026-10-01 14:00:53.337037+00	2026-10-01 14:04:34.751013+00	\N	\N	\N	mashhad	160	3	\N	\N	{"mid": "۳۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 32000000000}}	\N
2479	divar	galmnFs5	واحد ۸۰ متری با پارکینگ  و اسانسور	گلبرگ شمالی	4600000000	sale	\N	https://divar.ir/v/_/galmnFs5	2026-10-01 14:00:51.079102+00	2026-10-01 14:04:34.75628+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۴,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در گلبرگ شمالی", "amounts": {"raw_amount": 4600000000}}	\N
2480	divar	ga-Cja3N	حاشیهـ نقـویـه متـ۱۵۵ـری/ زمین سه نبش - تمام پنجره	الهیه	18950000000	sale	44	https://divar.ir/v/_/ga-Cja3N	2026-10-01 14:00:45.673101+00	2026-10-01 14:04:34.762557+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۸,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 18950000000}}	\N
2481	divar	ga-emdUs	اپارتمان 100 متری    شخصی ساز    فول بازسازی	الهیه	11000000000	sale	44	https://divar.ir/v/_/ga-emdUs	2026-10-01 14:00:31.875158+00	2026-10-01 14:04:34.767501+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 11000000000}}	\N
2482	divar	ganOg99Q	منزل رهن  کامل دربشارت صامعی	بهمن	\N	rent	43	https://divar.ir/v/_/ganOg99Q	2026-09-20 12:59:48.244023+00	2026-10-01 14:04:34.77285+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "در بهمن", "amounts": {"اجاره": 1000000}}	\N
2483	divar	ga-i2LF5	واحد فوق لاکچری رهن در اوایل الهیه	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga-i2LF5	2026-10-01 14:03:55.911692+00	2026-10-01 14:04:34.778592+00	\N	\N	\N	mashhad	\N	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "مسکن صبوری در جاهد شهر", "amounts": {"اجاره": 1000}}	\N
2484	divar	ga-a22zj	اپارتمان اجاره	سرافرازان	\N	rent	22	https://divar.ir/v/_/ga-a22zj	2026-10-01 13:59:10.051989+00	2026-10-01 14:04:34.783484+00	\N	\N	\N	mashhad	\N	\N	\N	7500000	{"mid": "اجاره: ۷,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سرافرازان", "amounts": {"اجاره": 7500000}}	\N
2485	divar	ga-amms2	ویلایی ۱۴۴متری خیابان ابوطالب ۱۸	گلبرگ	\N	rent	\N	https://divar.ir/v/_/ga-amms2	2026-10-01 13:57:32.804097+00	2026-10-01 14:04:34.788217+00	\N	\N	\N	mashhad	144	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن علیزاده در گلبرگ", "amounts": {}}	\N
2486	divar	ga-amTA0	۸۰ متر / دو خواب * تخلیه / مستغلاتی	الهیه	\N	rent	44	https://divar.ir/v/_/ga-amTA0	2026-10-01 13:55:40.456473+00	2026-10-01 14:04:34.792425+00	\N	\N	\N	mashhad	80	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سامانیه در الهیه", "amounts": {"اجاره": 20000000}}	\N
2487	divar	ga-a2T8Y	خانه ویلایی  ۶۵ متری داخل کوچه ۱ متری	شهید قربانی	\N	rent	\N	https://divar.ir/v/_/ga-a2T8Y	2026-10-01 13:55:38.382478+00	2026-10-01 14:04:34.79696+00	\N	\N	\N	mashhad	65	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید قربانی", "amounts": {"اجاره": 6000000}}	\N
2494	divar	ga725_Ss	فروشی منزل مسکونی دونبش نبش صامعی ۹	بهمن	1450000000	sale	43	https://divar.ir/v/_/ga725_Ss	2026-09-29 11:17:42.187309+00	2026-10-01 14:15:08.048774+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۴۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهمن", "amounts": {"raw_amount": 1450000000}}	\N
2495	divar	gao-7UPs	۱۲۰متری ماشین رو و کلید نخورده .	شهید احمدی روشن	2650000000	sale	\N	https://divar.ir/v/_/gao-7UPs	2026-09-27 18:32:31.328718+00	2026-10-01 14:15:08.057185+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۲,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید احمدی روشن", "amounts": {"raw_amount": 2650000000}}	\N
2496	divar	ga-WypPR	ویلایی . بلوار دانشجو . ۴ طبقه بنای نوساز ۱۷۵ متری	دانشجو	94000000000	sale	39	https://divar.ir/v/_/ga-WypPR	2026-10-01 14:14:43.49908+00	2026-10-01 14:15:08.061395+00	\N	\N	\N	mashhad	175	\N	\N	\N	{"mid": "۹۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن ولی پور  در دانشجو", "amounts": {"raw_amount": 94000000000}}	\N
2497	divar	gaxOQV0g	زمین باغی 800متری روستای لک لک	اقبال	830000000	sale	1	https://divar.ir/v/_/gaxOQV0g	2026-10-01 14:14:32.427017+00	2026-10-01 14:15:08.065296+00	\N	\N	\N	mashhad	800	\N	\N	\N	{"mid": "۸۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در اقبال", "amounts": {"raw_amount": 830000000}}	\N
2498	divar	ga0e50jY	آپارتمان ۸۰ متر فروشی در کوی سیدی زیر قیمت	کوی ولیعصر	3400000000	sale	\N	https://divar.ir/v/_/ga0e50jY	2026-10-01 14:14:23.903435+00	2026-10-01 14:15:08.069423+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۳,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوی ولیعصر", "amounts": {"raw_amount": 3400000000}}	\N
2499	divar	ga-qGQZB	خانه دلباز وشیک  وغرق نور در دوطبقه	توس (بلوار توس)	6500000000	sale	\N	https://divar.ir/v/_/ga-qGQZB	2026-10-01 14:13:48.050034+00	2026-10-01 14:15:08.072917+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {"raw_amount": 6500000000}}	\N
2500	divar	gakeVRM5	۲۲۰ متر/ تک واحدی/اوایل الهیه/صفر/سند آماده	الهیه	25000000000	sale	44	https://divar.ir/v/_/gakeVRM5	2026-10-01 14:13:39.396735+00	2026-10-01 14:15:08.076993+00	\N	\N	\N	mashhad	220	\N	\N	\N	{"mid": "۲۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری بزرگ رویال در الهیه", "amounts": {"raw_amount": 25000000000}}	\N
2501	divar	ga-qGO_K	آپارتمان امامت ۲۹ شیک تاپ لوکیشن	آزادشهر	26000000000	sale	\N	https://divar.ir/v/_/ga-qGO_K	2026-10-01 14:13:32.327155+00	2026-10-01 14:15:08.080788+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آزادشهر", "amounts": {"raw_amount": 26000000000}}	\N
2502	divar	ga-mWt7r	۶۰ متر آپارتمان / کوهسنگی / تمیز  و شیک	شهید بهشتی	\N	rent	18	https://divar.ir/v/_/ga-mWt7r	2026-10-01 14:11:19.679661+00	2026-10-01 14:15:08.084025+00	\N	\N	\N	mashhad	60	\N	\N	22000000	{"mid": "اجاره: ۲۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید بهشتی", "amounts": {"اجاره": 22000000}}	\N
2503	divar	ga-m2HwG	آپارتمان اجاره ایی	شهید بهشتی	\N	rent	18	https://divar.ir/v/_/ga-m2HwG	2026-10-01 14:09:59.462416+00	2026-10-01 14:15:08.087577+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید بهشتی", "amounts": {"اجاره": 1000000}}	\N
2504	divar	ga-mWLQm	آپارتمان ۷۰ متری/فکوری ۱۱/تخلیه و بدون مالک	هفت تیر (نه دره)	\N	rent	\N	https://divar.ir/v/_/ga-mWLQm	2026-10-01 14:07:53.833928+00	2026-10-01 14:15:08.091085+00	\N	\N	\N	mashhad	70	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (نه دره)", "amounts": {"اجاره": 2000000}}	\N
2505	divar	ga-im4Vw	آپارتمان  80متر. یک خواب  فکتوری	هفت تیر (نه دره)	\N	rent	\N	https://divar.ir/v/_/ga-im4Vw	2026-10-01 14:07:15.293247+00	2026-10-01 14:15:08.094463+00	\N	\N	\N	mashhad	80	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "عرفانی در هفت تیر (نه دره)", "amounts": {"اجاره": 15000000}}	\N
2508	divar	gaa2qE9N	فروش آپارتمان مطهری شمالی۲۳ عبادی۴۰ همکف	عبادی	5400000000	sale	\N	https://divar.ir/v/_/gaa2qE9N	2026-09-26 21:53:48.886695+00	2026-10-01 14:25:48.471065+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در عبادی", "amounts": {"raw_amount": 5400000000}}	\N
2509	divar	ga-yG7jk	بلوار رضا احمدآباد ۳۰۰متری ۴خواب فروش فوری معاوضه	احمدآباد	71000000000	sale	\N	https://divar.ir/v/_/ga-yG7jk	2026-10-01 14:24:49.411923+00	2026-10-01 14:25:48.492146+00	\N	\N	\N	mashhad	300	4	\N	\N	{"mid": "۷۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "متخصص رشد سرمایه ملکی در احمدآباد", "amounts": {"raw_amount": 71000000000}}	\N
2510	divar	ga-SRiss	195متر/نوساز/تک واحدی/فارغ التحصیلان/جنوبی	فارغ التحصیلان	35200000000	sale	\N	https://divar.ir/v/_/ga-SRiss	2026-10-01 14:24:39.468799+00	2026-10-01 14:25:48.502918+00	\N	\N	\N	mashhad	195	\N	\N	\N	{"mid": "۳۵,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پژوهش در فارغ التحصیلان", "amounts": {"raw_amount": 35200000000}}	\N
2511	divar	gari439C	آپارتمان فول امکانات /سند آماده/ تخلیه	فرهنگیان (شهرک غرب)	9200000000	sale	37	https://divar.ir/v/_/gari439C	2026-10-01 14:24:28.350824+00	2026-10-01 14:25:48.515895+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کاخ مسکن مقابل حسابی شمالی پنج در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 9200000000}}	\N
2512	divar	ga8aadAj	اپارتمان ۱۰۷ متری سند اماده ۸ واحدی سجادیه ۱۶	جاهد شهر	12500000000	sale	41	https://divar.ir/v/_/ga8aadAj	2026-10-01 14:24:25.110058+00	2026-10-01 14:25:48.527258+00	\N	\N	\N	mashhad	107	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 12500000000}}	\N
2514	divar	gasZOgBn	فروش باغ سنددار امتیازات کامل مجتمع قابل سکونت	درزآب	690000000	sale	\N	https://divar.ir/v/_/gasZOgBn	2026-10-01 14:23:46.255777+00	2026-10-01 14:25:48.547116+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶۹۰,۰۰۰,۰۰۰ تومان", "bottom": "دفترفروش مجتمع های پردیس در درزآب", "amounts": {"raw_amount": 690000000}}	\N
2515	divar	ga1O08Qh	خانه فروشی	نوده	900000000	sale	\N	https://divar.ir/v/_/ga1O08Qh	2026-10-01 14:23:43.402239+00	2026-10-01 14:25:48.556634+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در نوده", "amounts": {"raw_amount": 900000000}}	\N
2516	divar	ga-uAjT4	فروش واحد 90متری خوش نقشه در موسوی قوچانی	رستگار	5300000000	sale	\N	https://divar.ir/v/_/ga-uAjT4	2026-10-01 14:23:21.765892+00	2026-10-01 14:25:48.565888+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۵,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری ولیعصر  در رستگار", "amounts": {"raw_amount": 5300000000}}	\N
2517	divar	ganZQ67r	۳۰۰ متر دونبش جنوبی فضای سبز با پروانه	امیریه	35000000000	sale	\N	https://divar.ir/v/_/ganZQ67r	2026-10-01 14:23:08.623173+00	2026-10-01 14:25:48.573877+00	\N	\N	\N	mashhad	300	\N	\N	\N	{"mid": "۳۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "شهرمشهد نبش رحمانیه۵ در امیریه", "amounts": {"raw_amount": 35000000000}}	\N
2518	divar	ga-yWuaB	آپارتمان۹۰متری،امام رضا	حرم مطهر رضوی	15800000000	sale	\N	https://divar.ir/v/_/ga-yWuaB	2026-10-01 14:23:06.610665+00	2026-10-01 14:25:48.584097+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۱۵,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در حرم مطهر رضوی", "amounts": {"raw_amount": 15800000000}}	\N
2520	divar	ga-yW-dk	آپارتمان،۸۲ متری،گاز،مسلم	گاز	\N	rent	\N	https://divar.ir/v/_/ga-yW-dk	2026-10-01 14:25:39.755816+00	2026-10-01 14:25:48.600259+00	\N	\N	\N	mashhad	82	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در گاز", "amounts": {"اجاره": 20000000}}	\N
2521	divar	gazW_kQz	۱۳۰ متر تک واحدی هفت تیر برای خاص پسندا زوج	هفت تیر (حافظ)	\N	rent	5	https://divar.ir/v/_/gazW_kQz	2026-10-01 14:24:24.380953+00	2026-10-01 14:25:48.610786+00	\N	\N	\N	mashhad	130	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "رادوین در هفت تیر (حافظ)", "amounts": {"اجاره": 40000000}}	\N
2524	divar	ga-yWVVZ	خونه سپاه۳۷	شهرک بهارستان	\N	rent	\N	https://divar.ir/v/_/ga-yWVVZ	2026-10-01 14:21:15.773061+00	2026-10-01 14:25:48.642168+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک بهارستان", "amounts": {"اجاره": 8000000}}	\N
2525	divar	gaa2l7ef	۱۶۸متری جنوبی / حاشیه اصلی/مستغلاتی سکونت چند ساله	میعاد (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/gaa2l7ef	2026-10-01 14:21:04.338548+00	2026-10-01 14:25:48.654431+00	\N	\N	\N	mashhad	168	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "در میعاد (شهرک غرب)", "amounts": {"اجاره": 1000}}	\N
2526	divar	ga-u2v8s	80متری /یک خواب/طبقه اول	یوسفیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-u2v8s	2026-10-01 14:19:31.562291+00	2026-10-01 14:25:48.666622+00	\N	\N	\N	mashhad	80	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "مسکن برتر در یوسفیه (شهرک غرب)", "amounts": {"اجاره": 3000000}}	\N
2527	divar	ga36-o90	اجاره منزل	کوی دروی	\N	rent	\N	https://divar.ir/v/_/ga36-o90	2026-10-01 14:18:41.83573+00	2026-10-01 14:25:48.675997+00	\N	\N	\N	mashhad	\N	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "در کوی دروی", "amounts": {"اجاره": 7000000}}	\N
2528	divar	ga-uWs4Y	240 متر لوکیشن قوی و منحصر حس خوب زندگی	فارغ التحصیلان	\N	rent	\N	https://divar.ir/v/_/ga-uWs4Y	2026-10-01 14:18:37.73708+00	2026-10-01 14:25:48.687616+00	\N	\N	\N	mashhad	240	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "مسکن آرکا در فارغ التحصیلان", "amounts": {"اجاره": 100000}}	\N
2529	divar	ga42bVA3	۸۰ متری دو خوابه امامت	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga42bVA3	2026-10-01 14:17:50.662999+00	2026-10-01 14:25:48.699691+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در آزادشهر", "amounts": {}}	\N
2530	divar	ga-u2Sh-	آپارتمان ۱۳۰ متری دوممر فارغ التحصیلان	فارغ التحصیلان	\N	rent	\N	https://divar.ir/v/_/ga-u2Sh-	2026-10-01 14:16:50.796303+00	2026-10-01 14:25:48.710151+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در فارغ التحصیلان", "amounts": {}}	\N
2531	divar	ga3W99_o	۱۶۵متر/۳خواب/تکواحدی/صفر/فول امکانات	فرهنگیان (شهرک غرب)	\N	rent	37	https://divar.ir/v/_/ga3W99_o	2026-10-01 14:16:16.472199+00	2026-10-01 14:25:48.721738+00	\N	\N	\N	mashhad	165	3	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه مهندسی ساختمانی دیان در فرهنگیان (شهرک غرب)", "amounts": {"اجاره": 10000000}}	\N
2532	divar	ga--mq_-	کاهو گوهردشت باغ ویلا استخر سرپوشیده	میان ولایت	13200000000	sale	\N	https://divar.ir/v/_/ga--mq_-	2026-10-01 14:36:12.919815+00	2026-10-01 14:36:31.33223+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در میان ولایت", "amounts": {"raw_amount": 13200000000}}	\N
2533	divar	ga--2wGd	۱۷۸متری /۳ خواب/ اول الهیه /تک واحدی	الهیه	17150000000	sale	44	https://divar.ir/v/_/ga--2wGd	2026-10-01 14:35:58.773435+00	2026-10-01 14:36:31.3447+00	\N	\N	\N	mashhad	178	3	\N	\N	{"mid": "۱۷,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در الهیه", "amounts": {"raw_amount": 17150000000}}	\N
2534	divar	ga-aW8IR	خونه میخای بیا پلاک  ۱۰۰ مترلوکس ۸ واحدی	الهیه	12200000000	sale	44	https://divar.ir/v/_/ga-aW8IR	2026-10-01 14:34:59.62322+00	2026-10-01 14:36:31.355228+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۲,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پلاک در الهیه", "amounts": {"raw_amount": 12200000000}}	\N
2535	divar	ga-6Gmeg	فروش ویلایی	زمرد	8000000000	sale	\N	https://divar.ir/v/_/ga-6Gmeg	2026-10-01 14:34:26.652812+00	2026-10-01 14:36:31.364224+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مهرداد در زمرد", "amounts": {"raw_amount": 8000000000}}	\N
2536	divar	ga--mBVv	۲۰۰متر/صفر/دونبش مجیدیه ۳/حاشیه خیابان پهن	الهیه	25000000000	sale	44	https://divar.ir/v/_/ga--mBVv	2026-10-01 14:33:57.608384+00	2026-10-01 14:36:31.374453+00	\N	\N	\N	mashhad	200	\N	\N	\N	{"mid": "۲۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 25000000000}}	\N
2537	divar	ga--GP37	آپارتمان180متری 3 خواب  تکواحدی	الهیه	17150000000	sale	44	https://divar.ir/v/_/ga--GP37	2026-10-01 14:33:50.506984+00	2026-10-01 14:36:31.384908+00	\N	\N	\N	mashhad	180	3	\N	\N	{"mid": "۱۷,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در الهیه", "amounts": {"raw_amount": 17150000000}}	\N
2538	divar	ga-62E_I	آپارتمان در سحر ۴۷	انقلاب	5100000000	sale	\N	https://divar.ir/v/_/ga-62E_I	2026-10-01 14:33:09.112974+00	2026-10-01 14:36:31.394391+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در انقلاب", "amounts": {"raw_amount": 5100000000}}	\N
2539	divar	ga-6W5DI	آپارتمان۱۱۲متربازسازی می‌شودشیخ صدوق10قطعه سوم	سیلو	5800000000	sale	\N	https://divar.ir/v/_/ga-6W5DI	2026-10-01 14:32:16.627148+00	2026-10-01 14:36:31.403199+00	\N	\N	\N	mashhad	112	\N	\N	\N	{"mid": "۵,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "ساخت و ساز ملک  در سیلو", "amounts": {"raw_amount": 5800000000}}	\N
2540	divar	ga-22VGK	110مــتری (( امامت نزدیک به حاشیه )) بی همتا	آزادشهر	18200000000	sale	\N	https://divar.ir/v/_/ga-22VGK	2026-10-01 14:32:10.082565+00	2026-10-01 14:36:31.412741+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۸,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بامک بین امامت ۳۶و۳۸ در آزادشهر", "amounts": {"raw_amount": 18200000000}}	\N
2966	divar	ga-S7t7q	همخونه موجه	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga-S7t7q	2026-10-01 19:30:04.959649+00	2026-10-01 19:31:02.172189+00	\N	\N	\N	mashhad	\N	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در آزادشهر", "amounts": {"اجاره": 15000000}}	\N
2541	divar	ga1CUbpf	135 متر هاشمیه قبل فکوری	چهارچشمه	16200000000	sale	\N	https://divar.ir/v/_/ga1CUbpf	2026-10-01 14:32:03.132551+00	2026-10-01 14:36:31.420734+00	\N	\N	\N	mashhad	135	\N	\N	\N	{"mid": "۱۶,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن والی در چهارچشمه", "amounts": {"raw_amount": 16200000000}}	\N
2543	divar	ga-alRLu	آپارتمان مرتب مناسب ۳ نفر بزرگسال	حسین‌آباد	\N	rent	\N	https://divar.ir/v/_/ga-alRLu	2026-10-01 14:35:50.58585+00	2026-10-01 14:36:31.433657+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در حسین‌آباد", "amounts": {"اجاره": 5000000}}	\N
2544	divar	gauKa3Jp	همخونه	کارمندان دوم	\N	rent	\N	https://divar.ir/v/_/gauKa3Jp	2026-10-01 14:32:30.469187+00	2026-10-01 14:36:31.440963+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "در کارمندان دوم", "amounts": {"اجاره": 100000}}	\N
2545	divar	ga-6Wlnu	رهن و اجاره وکیل آباد ده دقیقه تا مترو	وکیل‌آباد	\N	rent	\N	https://divar.ir/v/_/ga-6Wlnu	2026-10-01 14:31:50.580694+00	2026-10-01 14:36:31.448141+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در وکیل‌آباد", "amounts": {"اجاره": 10000000}}	\N
2546	divar	ga-6GkTZ	۱۱۰ متری /طبقه اول/ ۳ واحد کلا	شهرک بهارستان	\N	rent	\N	https://divar.ir/v/_/ga-6GkTZ	2026-10-01 14:30:58.549237+00	2026-10-01 14:36:31.455703+00	\N	\N	\N	mashhad	110	\N	\N	8500000	{"mid": "اجاره: ۸,۵۰۰,۰۰۰ تومان", "bottom": "کارگزاری مهدی در شهرک بهارستان", "amounts": {"اجاره": 8500000}}	\N
2547	divar	ga-2mzTc	رهن اجاره آپارتمان اقبال	اقبال	\N	rent	1	https://divar.ir/v/_/ga-2mzTc	2026-10-01 14:30:46.008102+00	2026-10-01 14:36:31.461237+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن مهرداد در اقبال", "amounts": {"اجاره": 10000000}}	\N
2548	divar	ga-6WhxH	خانه اجاره ای روزانه	حسین‌آباد	\N	rent	\N	https://divar.ir/v/_/ga-6WhxH	2026-10-01 14:30:36.249085+00	2026-10-01 14:36:31.468146+00	\N	\N	\N	mashhad	\N	\N	\N	2500000	{"mid": "اجاره: ۲,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حسین‌آباد", "amounts": {"اجاره": 2500000}}	\N
2549	divar	ga-6mRFI	آپارتمان ۱۰۰ متری ابوطالب	گلبرگ شمالی	\N	rent	\N	https://divar.ir/v/_/ga-6mRFI	2026-10-01 14:29:40.262994+00	2026-10-01 14:36:31.475146+00	\N	\N	\N	mashhad	100	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گلبرگ شمالی", "amounts": {"اجاره": 5000000}}	\N
2550	divar	ga-2W9Ng	آپارتمان ۸۰ متری یک خوابه	وکیل‌آباد	\N	rent	\N	https://divar.ir/v/_/ga-2W9Ng	2026-10-01 14:28:39.87444+00	2026-10-01 14:36:31.483362+00	\N	\N	\N	mashhad	80	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در وکیل‌آباد", "amounts": {"اجاره": 10000000}}	\N
2551	divar	gapmAwCT	ویلایی	کلاهدوز	\N	rent	\N	https://divar.ir/v/_/gapmAwCT	2026-10-01 14:28:05.439862+00	2026-10-01 14:36:31.492088+00	\N	\N	\N	mashhad	\N	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "در کلاهدوز", "amounts": {"اجاره": 40000000}}	\N
2552	divar	gacuiu4l	آپارتمان ۱۱۰ مترصیاد صابر ۳ طبقه اول	هفت تیر (نه دره)	\N	rent	\N	https://divar.ir/v/_/gacuiu4l	2026-10-01 14:26:21.227208+00	2026-10-01 14:36:31.502155+00	\N	\N	\N	mashhad	110	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "واحدی در هفت تیر (نه دره)", "amounts": {"اجاره": 10000000}}	\N
2556	divar	ga92Vdyr	زمین باغ ویلا  شاهنامه دیاکو سرمایه گذاری اقساطی	توس فردوسی	250000000	sale	\N	https://divar.ir/v/_/ga92Vdyr	2026-10-01 14:46:46.772599+00	2026-10-01 14:47:04.728291+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "عدالت ۰۹۰۵۷۶۲۱۵۸۳ دیاکو ۰۹۳۷۴۱۴۱۶۵۵ در توس فردوسی", "amounts": {"raw_amount": 250000000}}	\N
2557	divar	gac-FS4Q	باغ ویلا استخر دار شاهنامه ۶۹ زاک	درزآب	4150000000	sale	\N	https://divar.ir/v/_/gac-FS4Q	2026-10-01 14:46:30.80245+00	2026-10-01 14:47:04.734719+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 4150000000}}	\N
2558	divar	gal4SoCV	باغ ویلا فول امکانات۱۱۰۰متری	درزآب	11000000000	sale	\N	https://divar.ir/v/_/gal4SoCV	2026-10-01 14:45:16.535917+00	2026-10-01 14:47:04.744666+00	\N	\N	\N	mashhad	1100	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 11000000000}}	\N
2559	divar	ga-G359q	اپارتمان دو خواب /لوکیشن امیریه	الهیه	11500000000	sale	44	https://divar.ir/v/_/ga-G359q	2026-10-01 14:45:05.201923+00	2026-10-01 14:47:04.755191+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پامچال در الهیه", "amounts": {"raw_amount": 11500000000}}	\N
2560	divar	ga-ym_mi	120 متر / کار قوی و لوکس / سندآماده	الهیه	14700000000	sale	44	https://divar.ir/v/_/ga-ym_mi	2026-10-01 14:44:27.247689+00	2026-10-01 14:47:04.768171+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۱۴,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "آریان نژاد در الهیه", "amounts": {"raw_amount": 14700000000}}	\N
2561	divar	gay6Xc0_	فروش آپارتمان ۱۲۰ متری چراغچی ۹	بلال	6000000000	sale	\N	https://divar.ir/v/_/gay6Xc0_	2026-10-01 14:43:56.098616+00	2026-10-01 14:47:04.780531+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در بلال", "amounts": {"raw_amount": 6000000000}}	\N
2563	divar	ga-GXEPs	85 متر حاشیه بلوار حجاب	حجاب (شهرک غرب)	7100000000	sale	38	https://divar.ir/v/_/ga-GXEPs	2026-10-01 14:42:20.383601+00	2026-10-01 14:47:04.804774+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۷,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حجاب (شهرک غرب)", "amounts": {"raw_amount": 7100000000}}	\N
2564	divar	gawGiQVh	فروش و تهاتر آپارتمان 170 متری صفر آزادشهر معاوضه	آزادشهر	22300000000	sale	\N	https://divar.ir/v/_/gawGiQVh	2026-10-01 14:42:07.160729+00	2026-10-01 14:47:04.815812+00	\N	\N	\N	mashhad	170	\N	\N	\N	{"mid": "۲۲,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن ممتاز  در آزادشهر", "amounts": {"raw_amount": 22300000000}}	\N
2565	divar	ga-CXvYZ	فروش فوری 91متر فول	فرهنگیان (شهرک غرب)	9200000000	sale	37	https://divar.ir/v/_/ga-CXvYZ	2026-10-01 14:41:47.866465+00	2026-10-01 14:47:04.825575+00	\N	\N	\N	mashhad	91	\N	\N	\N	{"mid": "۹,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 9200000000}}	\N
2566	divar	ga6an1kf	منزل فروشی مشهد ساغروان	میان ولایت	3500000000	sale	\N	https://divar.ir/v/_/ga6an1kf	2026-10-01 14:41:28.270338+00	2026-10-01 14:47:04.835125+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 3500000000}}	\N
2567	divar	ga-CX6DM	آپارتمان ۲۱۰ متری ناصرخسرو	احمدآباد	65000000000	sale	\N	https://divar.ir/v/_/ga-CX6DM	2026-10-01 14:41:18.541727+00	2026-10-01 14:47:04.842466+00	\N	\N	\N	mashhad	210	\N	\N	\N	{"mid": "۶۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در احمدآباد", "amounts": {"raw_amount": 65000000000}}	\N
2569	divar	gaPm-C-D	برند ارمیا ۱۰۰ متر خانه ای بسیار شیک و بدون پرتی	فرهنگیان (شهرک غرب)	12190000000	sale	37	https://divar.ir/v/_/gaPm-C-D	2026-10-01 14:57:31.2079+00	2026-10-01 14:57:38.792608+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۱۲,۱۹۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن سپهر فلاحی ۱۳ در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 12190000000}}	\N
2570	divar	gadi3WUn	فروش آپارتمان ۱۶۰متری/احمدآباد/بازسازی/کم واحد	احمدآباد	31500000000	sale	\N	https://divar.ir/v/_/gadi3WUn	2026-10-01 14:56:50.166549+00	2026-10-01 14:57:38.808509+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۳۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "تالار معاملات ملکی سجادی در احمدآباد", "amounts": {"raw_amount": 31500000000}}	\N
2571	divar	ga-OnhwJ	زمین مسکونی باغی برای زندگی اب برق گاز شاهنامه۸۰	توس فردوسی	990000000	sale	\N	https://divar.ir/v/_/ga-OnhwJ	2026-10-01 14:56:41.194175+00	2026-10-01 14:57:38.819958+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹۹۰,۰۰۰,۰۰۰ تومان", "bottom": "عدالت ۰۹۰۵۷۶۲۱۵۸۳ دیاکو ۰۹۳۷۴۱۴۱۶۵۵ در توس فردوسی", "amounts": {"raw_amount": 990000000}}	\N
2572	divar	gas-gbHC	آپارتمان ۸۰ متر سرافرازان	چهارچشمه	6950000000	sale	\N	https://divar.ir/v/_/gas-gbHC	2026-10-01 14:56:40.277005+00	2026-10-01 14:57:38.831319+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۶,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در چهارچشمه", "amounts": {"raw_amount": 6950000000}}	\N
2573	divar	ga-SnLAi	فروش خانه ویلایی	اروند	3500000000	sale	\N	https://divar.ir/v/_/ga-SnLAi	2026-10-01 14:55:54.807984+00	2026-10-01 14:57:38.842102+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در اروند", "amounts": {"raw_amount": 3500000000}}	\N
2574	divar	ga-On9iv	خانه 147	رضاییه	2000000000	sale	\N	https://divar.ir/v/_/ga-On9iv	2026-10-01 14:55:28.814232+00	2026-10-01 14:57:38.852746+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاییه", "amounts": {"raw_amount": 2000000000}}	\N
2575	divar	gamGMwqq	آپارتمان 125متر شیک خوش نقشه دو خواب مستر	فرهنگیان (شهرک غرب)	14750000000	sale	37	https://divar.ir/v/_/gamGMwqq	2026-10-01 14:55:07.550476+00	2026-10-01 14:57:38.862531+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۱۴,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 14750000000}}	\N
2576	divar	ga-SXBcO	آپارتمان ۷۰متر/طبقه۲/بهورز۵/فول بازسازی	فرهنگیان (شهرک غرب)	8450000000	sale	37	https://divar.ir/v/_/ga-SXBcO	2026-10-01 14:54:49.833346+00	2026-10-01 14:57:38.873706+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۸,۴۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 8450000000}}	\N
2577	divar	ga-Onszf	80متر  دو خواب	شهید مطهری	6400000000	sale	28	https://divar.ir/v/_/ga-Onszf	2026-10-01 14:54:44.704325+00	2026-10-01 14:57:38.882955+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۶,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید مطهری", "amounts": {"raw_amount": 6400000000}}	\N
2578	divar	ga-O35T0	فروش آپارتمان 105 متری امیریه	جاهد شهر	11500000000	sale	41	https://divar.ir/v/_/ga-O35T0	2026-10-01 14:54:19.788502+00	2026-10-01 14:57:38.893396+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پامچال در جاهد شهر", "amounts": {"raw_amount": 11500000000}}	\N
2579	divar	ga-SHAOE	۱۰۰ متر / ۲ خواب / پشت حاشیه وکیل اباد/ malek	دانشجو	13400000000	sale	39	https://divar.ir/v/_/ga-SHAOE	2026-10-01 14:54:17.979428+00	2026-10-01 14:57:38.902867+00	\N	\N	\N	mashhad	100	2	\N	\N	{"mid": "۱۳,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "اژانس اریا در دانشجو", "amounts": {"raw_amount": 13400000000}}	\N
2580	divar	ga-OXP87	خانه سرعقب کوچه دومتری	شهرک بهارستان	2400000000	sale	\N	https://divar.ir/v/_/ga-OXP87	2026-10-01 14:54:13.184323+00	2026-10-01 14:57:38.913156+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک بهارستان", "amounts": {"raw_amount": 2400000000}}	\N
2583	divar	ga9CW1bZ	رهن و اجاره خونه شیک و کم قیمت	خواجه ربیع	\N	rent	\N	https://divar.ir/v/_/ga9CW1bZ	2026-10-01 14:56:12.095301+00	2026-10-01 14:57:38.938304+00	\N	\N	\N	mashhad	\N	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در خواجه ربیع", "amounts": {"اجاره": 7000000}}	\N
2584	divar	ga7-c6pL	65متر/یک خواب/طبقه دوم	ایثارگران	\N	rent	\N	https://divar.ir/v/_/ga7-c6pL	2026-10-01 14:55:49.044922+00	2026-10-01 14:57:38.947843+00	\N	\N	\N	mashhad	65	\N	\N	3500000	{"mid": "اجاره: ۳,۵۰۰,۰۰۰ تومان", "bottom": "در ایثارگران", "amounts": {"اجاره": 3500000}}	\N
2585	divar	ga-SHDrd	۷۵ متری شیک اقبال ۱۴ تخلیه	اقبال	\N	rent	1	https://divar.ir/v/_/ga-SHDrd	2026-10-01 14:54:53.441655+00	2026-10-01 14:57:38.957741+00	\N	\N	\N	mashhad	75	\N	\N	16000000	{"mid": "اجاره: ۱۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در اقبال", "amounts": {"اجاره": 16000000}}	\N
2586	divar	ga-OnQ2Y	رهن و اجاره آپارتمان	هفت تیر (آب و برق)	\N	rent	\N	https://divar.ir/v/_/ga-OnQ2Y	2026-10-01 14:52:46.460564+00	2026-10-01 14:57:38.967857+00	\N	\N	\N	mashhad	\N	\N	\N	70000000	{"mid": "اجاره: ۷۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (آب و برق)", "amounts": {"اجاره": 70000000}}	\N
2587	divar	gazaTPF2	رهن کامل 1 واحد آپارتمان	تلگرد	\N	rent	\N	https://divar.ir/v/_/gazaTPF2	2026-10-01 14:51:52.28755+00	2026-10-01 14:57:38.977849+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در تلگرد", "amounts": {}}	\N
2588	divar	ga5WhSxd	هم خانه	بهمن	\N	rent	43	https://divar.ir/v/_/ga5WhSxd	2026-10-01 14:49:08.153143+00	2026-10-01 14:57:38.987864+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "در بهمن", "amounts": {"اجاره": 1000000}}	\N
2589	divar	ga-Knf7-	۸۰متر۲خواب هاشمیه۲۸/۶کوثر۳۵بدون مالک	کوثر	\N	rent	13	https://divar.ir/v/_/ga-Knf7-	2026-10-01 14:48:36.251714+00	2026-10-01 14:57:38.998746+00	\N	\N	\N	mashhad	80	2	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "آتیه سازان در کوثر", "amounts": {"اجاره": 25000000}}	\N
2591	divar	ga-e3JuK	خانه ویلایی دوطبقه سردونبش رسالت۱۲۰	همت آباد	5200000000	sale	\N	https://divar.ir/v/_/ga-e3JuK	2026-10-01 15:08:10.753768+00	2026-10-01 15:08:33.210864+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در همت آباد", "amounts": {"raw_amount": 5200000000}}	\N
2592	divar	gawWjktL	90متری آپارتمان طبقه۱	شهرک امام هادی (شهرک غرب)	3600000000	sale	38	https://divar.ir/v/_/gawWjktL	2026-10-01 15:07:23.038854+00	2026-10-01 15:08:33.214932+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۳,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک امام هادی (شهرک غرب)", "amounts": {"raw_amount": 3600000000}}	\N
2593	divar	ga1y0x38	۹۵ متر /۲خواب /۹واحدی الهیه	الهیه	8800000000	sale	44	https://divar.ir/v/_/ga1y0x38	2026-10-01 15:06:59.645181+00	2026-10-01 15:08:33.218615+00	\N	\N	\N	mashhad	95	2	\N	\N	{"mid": "۸,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در الهیه", "amounts": {"raw_amount": 8800000000}}	\N
2595	divar	ga-a3t5h	خانه نوساز کلید نخورده طبقه اول ماشین رو	علی آباد	3000000000	sale	\N	https://divar.ir/v/_/ga-a3t5h	2026-10-01 15:06:42.887266+00	2026-10-01 15:08:33.224303+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در علی آباد", "amounts": {"raw_amount": 3000000000}}	\N
2596	divar	gaYu-c60	معاوضه ۴۰۰۰ متر زمین ۲ نبش، اسدی مسکن پلاک	الهیه	400000000000	sale	44	https://divar.ir/v/_/gaYu-c60	2026-10-01 15:06:38.989805+00	2026-10-01 15:08:33.227022+00	\N	\N	\N	mashhad	4000	\N	\N	\N	{"mid": "۴۰۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پلاک در الهیه", "amounts": {"raw_amount": 400000000000}}	\N
2597	divar	ga-aXypN	300 متر ویلایی/ فارغ التحصیلان/نزدیک مترو	فارغ التحصیلان	71000000000	sale	\N	https://divar.ir/v/_/ga-aXypN	2026-10-01 15:05:55.301805+00	2026-10-01 15:08:33.229363+00	\N	\N	\N	mashhad	300	\N	\N	\N	{"mid": "۷۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پژوهش در فارغ التحصیلان", "amounts": {"raw_amount": 71000000000}}	\N
2598	divar	ga6mHUEu	آپارتمان100متر/دوخواب/ویوابدی/صفر/پارکینگ آسانسور	رستگار	6500000000	sale	\N	https://divar.ir/v/_/ga6mHUEu	2026-10-01 15:05:26.171684+00	2026-10-01 15:08:33.231203+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رستگار", "amounts": {"raw_amount": 6500000000}}	\N
2599	divar	ga-a3M0M	آپارتمان	انصار	1800000000	sale	\N	https://divar.ir/v/_/ga-a3M0M	2026-10-01 15:04:16.926274+00	2026-10-01 15:08:33.2331+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در انصار", "amounts": {"raw_amount": 1800000000}}	\N
2601	divar	ga-aX8Ll	۸۰ متری تمیز ،سید رضی و دانش آموز	سید رضی	\N	rent	\N	https://divar.ir/v/_/ga-aX8Ll	2026-10-01 15:06:31.283567+00	2026-10-01 15:08:33.23651+00	\N	\N	\N	mashhad	80	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سید رضی", "amounts": {"اجاره": 25000000}}	\N
2602	divar	ga4iDG_K	رهن واجاره دوطبقه باز سازی شده بسیار تمیز	یوسفیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga4iDG_K	2026-10-01 15:03:22.45119+00	2026-10-01 15:08:33.238591+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در یوسفیه (شهرک غرب)", "amounts": {}}	\N
2604	divar	gaw-BvIM	خونه اپارتمان	حسین‌آباد	\N	rent	\N	https://divar.ir/v/_/gaw-BvIM	2026-10-01 15:00:11.36453+00	2026-10-01 15:08:33.242046+00	\N	\N	\N	mashhad	\N	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "در حسین‌آباد", "amounts": {"اجاره": 3000000}}	\N
2605	divar	ga-WnWf7	120متری / دو خواب / الهیه	الهیه	\N	rent	44	https://divar.ir/v/_/ga-WnWf7	2026-10-01 14:59:49.953886+00	2026-10-01 15:08:33.243934+00	\N	\N	\N	mashhad	120	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در الهیه", "amounts": {"اجاره": 3000000}}	\N
2606	divar	ga-WXT-H	آپارتمان رهن و اجاره	طبرسی شمالی	\N	rent	42	https://divar.ir/v/_/ga-WXT-H	2026-10-01 14:59:34.085482+00	2026-10-01 15:08:33.24643+00	\N	\N	\N	mashhad	\N	\N	\N	500000	{"mid": "اجاره: ۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {"اجاره": 500000}}	\N
2610	divar	ga4yAPS7	اپارتمان فروشی هدایت غربی	هدایت	10400000000	sale	26	https://divar.ir/v/_/ga4yAPS7	2026-09-29 10:41:08.006914+00	2026-10-01 15:19:53.847015+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۰,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در هدایت", "amounts": {"raw_amount": 10400000000}}	\N
2611	divar	gaaOaQxH	باغ ویلا 1200متری فول خرم اباد سند اوقاف	بهار	13500000000	sale	\N	https://divar.ir/v/_/gaaOaQxH	2026-10-01 05:16:31.297495+00	2026-10-01 15:19:53.854137+00	\N	\N	\N	mashhad	1200	\N	\N	\N	{"mid": "۱۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهار", "amounts": {"raw_amount": 13500000000}}	\N
2612	divar	ga9SxhLp	آپارتمان	تلگرد	6200000000	sale	\N	https://divar.ir/v/_/ga9SxhLp	2026-10-01 15:19:22.122783+00	2026-10-01 15:19:53.857201+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در تلگرد", "amounts": {"raw_amount": 6200000000}}	\N
2613	divar	gamO1Z1d	ویلایی خاکزادی مسلم گاز۱۳۴مترسند۶دانگ	گاز	12500000000	sale	\N	https://divar.ir/v/_/gamO1Z1d	2026-10-01 15:19:06.394676+00	2026-10-01 15:19:53.859668+00	\N	\N	\N	mashhad	134	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "وحیدگل مقام در گاز", "amounts": {"raw_amount": 12500000000}}	\N
2614	divar	ga-mHkHS	تاپ لوکیشن صیاد۱۳ تکواحدی۱۴۰متر۳خواب	صیاد شیرازی	17600000000	sale	4	https://divar.ir/v/_/ga-mHkHS	2026-10-01 15:18:44.26687+00	2026-10-01 15:19:53.861707+00	\N	\N	\N	mashhad	140	3	\N	\N	{"mid": "۱۷,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن کاشانه در صیاد شیرازی", "amounts": {"raw_amount": 17600000000}}	\N
2615	divar	ga-e3oLs	خانه ویلایی	لقمانی	2700000000	sale	\N	https://divar.ir/v/_/ga-e3oLs	2026-10-01 15:18:34.094811+00	2026-10-01 15:19:53.864058+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در لقمانی", "amounts": {"raw_amount": 2700000000}}	\N
2616	divar	ga-dclqR	زمین باغی دور دیوار سند دار امتیاز برق و آب	درزآب	950000000	sale	\N	https://divar.ir/v/_/ga-dclqR	2026-10-01 15:18:22.686138+00	2026-10-01 15:19:53.866862+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 950000000}}	\N
2617	divar	ga-mnqeQ	۱۲۷متر طبقه اول «صفرسازی شده»تک واحدی/تهاتر	شریف	12500000000	sale	\N	https://divar.ir/v/_/ga-mnqeQ	2026-10-01 15:18:16.051631+00	2026-10-01 15:19:53.86901+00	\N	\N	\N	mashhad	127	\N	\N	\N	{"mid": "۱۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "اژانس اریا در شریف", "amounts": {"raw_amount": 12500000000}}	\N
2618	divar	ga-a3adM	اپارتمان مجیدیه	جاهد شهر	13500000000	sale	41	https://divar.ir/v/_/ga-a3adM	2026-10-01 15:18:01.918229+00	2026-10-01 15:19:53.871051+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پامچال در جاهد شهر", "amounts": {"raw_amount": 13500000000}}	\N
2619	divar	ga8WdkxY	زمین جنب میدان نمایشگاه	وکیل‌آباد	11000000000	sale	\N	https://divar.ir/v/_/ga8WdkxY	2026-10-01 15:17:14.468153+00	2026-10-01 15:19:53.872961+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در وکیل‌آباد", "amounts": {"raw_amount": 11000000000}}	\N
2620	divar	ga-mXFnE	زمین فروشی	مهدی آباد	1800000000	sale	\N	https://divar.ir/v/_/ga-mXFnE	2026-10-01 15:16:51.117681+00	2026-10-01 15:19:53.875165+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مهدی آباد", "amounts": {"raw_amount": 1800000000}}	\N
2622	divar	ga-in_ye	آپارتمان ۷۵ متری املاک کرمانج	باغون آباد	2150000000	sale	\N	https://divar.ir/v/_/ga-in_ye	2026-10-01 15:16:10.177014+00	2026-10-01 15:19:53.878453+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۲,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در باغون آباد", "amounts": {"raw_amount": 2150000000}}	\N
2670	divar	gaqaWayz	ویلایی ۱۲۵ متری جنوبی	شهرک بهارستان	10500000000	sale	\N	https://divar.ir/v/_/gaqaWayz	2026-10-01 15:49:47.565033+00	2026-10-01 15:51:59.211205+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۱۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک بهارستان", "amounts": {"raw_amount": 10500000000}}	\N
2623	divar	ga-2WePG	اپارتمان/70متر/مفتح/نزدیک حرم/کارگزاری الماس	ایثار	5400000000	sale	\N	https://divar.ir/v/_/ga-2WePG	2026-10-01 15:16:04.022345+00	2026-10-01 15:19:53.880438+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۵,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن الماس(پاشا)بین ایثار۱۷و۱۹ در ایثار", "amounts": {"raw_amount": 5400000000}}	\N
2624	divar	ga-iX4fd	خرید فروش ملک های فوری در شهر جدید گلبهار	جاهد شهر	1500000000	sale	41	https://divar.ir/v/_/ga-iX4fd	2026-10-01 15:15:02.111979+00	2026-10-01 15:19:53.882845+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری تیم‌ممتاز در جاهد شهر", "amounts": {"raw_amount": 1500000000}}	\N
2625	divar	ga-2UIeF	آپارتمان 140 متری/3خواب/امام خمینی	امام خمینی	22400000000	sale	\N	https://divar.ir/v/_/ga-2UIeF	2026-10-01 15:14:45.533406+00	2026-10-01 15:19:53.88478+00	\N	\N	\N	mashhad	140	3	\N	\N	{"mid": "۲۲,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام خمینی", "amounts": {"raw_amount": 22400000000}}	\N
2626	divar	ga-6SgEq	فلسطین /آپارتمان لوکس/ شخصی‌ساز	فلسطین	47200000000	sale	19	https://divar.ir/v/_/ga-6SgEq	2026-10-01 15:14:35.415234+00	2026-10-01 15:19:53.886966+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴۷,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فلسطین", "amounts": {"raw_amount": 47200000000}}	\N
2627	divar	ga-i3mQn	خانه مسکونی اسکلتی هندل اباد	كنويست	5000000000	sale	\N	https://divar.ir/v/_/ga-i3mQn	2026-10-01 15:14:27.118879+00	2026-10-01 15:19:53.888995+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در كنويست", "amounts": {"raw_amount": 5000000000}}	\N
2628	divar	gaiarVrO	باغ ویلای ۱۰۰۰ متری ناظریه شاندیز	میان ولایت	4100000000	sale	\N	https://divar.ir/v/_/gaiarVrO	2026-10-01 15:14:05.836779+00	2026-10-01 15:19:53.890907+00	\N	\N	\N	mashhad	1000	\N	\N	\N	{"mid": "۴,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 4100000000}}	\N
2629	divar	gavSOBIJ	شکارشکارفروش فوری طبقه اول رسالت ۱۳۰غلامی۶	همت آباد	1150000000	sale	\N	https://divar.ir/v/_/gavSOBIJ	2026-10-01 15:30:21.652376+00	2026-10-01 15:30:43.088296+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در همت آباد", "amounts": {"raw_amount": 1150000000}}	\N
2630	divar	gaeWv9Oe	فروش یه واحد۶۵متری نقلی	منزل آباد	2100000000	sale	\N	https://divar.ir/v/_/gaeWv9Oe	2026-10-01 15:29:59.283328+00	2026-10-01 15:30:43.094917+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۲,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در منزل آباد", "amounts": {"raw_amount": 2100000000}}	\N
2631	divar	ga-u3yaZ	۱۶۲/۲ متر الهیه/تک واحدی/دریای نور/مدرن حاشیه اصلی	الهیه	17600000000	sale	44	https://divar.ir/v/_/ga-u3yaZ	2026-10-01 15:29:09.438403+00	2026-10-01 15:30:43.098416+00	\N	\N	\N	mashhad	2	\N	\N	\N	{"mid": "۱۷,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری بزرگ رویال در الهیه", "amounts": {"raw_amount": 17600000000}}	\N
2632	divar	ga-un43x	۱۰۵ متر / 2 خواب / تاپ لوکیشن	الهیه	11500000000	sale	44	https://divar.ir/v/_/ga-un43x	2026-10-01 15:27:47.946606+00	2026-10-01 15:30:43.102039+00	\N	\N	\N	mashhad	105	2	\N	\N	{"mid": "۱۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پامچال در الهیه", "amounts": {"raw_amount": 11500000000}}	\N
2633	divar	ga-KHsns	آپارتمان۱۶۷متری،امام رضا	عنصری	33400000000	sale	\N	https://divar.ir/v/_/ga-KHsns	2026-10-01 15:26:55.456933+00	2026-10-01 15:30:43.104635+00	\N	\N	\N	mashhad	167	\N	\N	\N	{"mid": "۳۳,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در عنصری", "amounts": {"raw_amount": 33400000000}}	\N
2635	divar	ga-undij	ویلای حاشیه	کوی دروی	2600000000	sale	\N	https://divar.ir/v/_/ga-undij	2026-10-01 15:26:29.435384+00	2026-10-01 15:30:43.1081+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی دروی", "amounts": {"raw_amount": 2600000000}}	\N
2636	divar	ga-uHQP6	خونه ویلایی	لقمانی	1900000000	sale	\N	https://divar.ir/v/_/ga-uHQP6	2026-10-01 15:26:02.813358+00	2026-10-01 15:30:43.110558+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در لقمانی", "amounts": {"raw_amount": 1900000000}}	\N
2637	divar	ga-u3d9V	۱۳۰متر  کلیدنخورده  محمدیه	جاهد شهر	13000000000	sale	41	https://divar.ir/v/_/ga-u3d9V	2026-10-01 15:25:54.390996+00	2026-10-01 15:30:43.112454+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "۱۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پامچال در جاهد شهر", "amounts": {"raw_amount": 13000000000}}	\N
2638	divar	ga-63oDX	فروش باغ جاده کلات(معاوضه آپارتمان.ماشین) مبله فول	شهرک صنعتی مشهد	9000000000	sale	\N	https://divar.ir/v/_/ga-63oDX	2026-10-01 15:39:56.124747+00	2026-10-01 15:41:26.71034+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک صنعتی مشهد", "amounts": {"raw_amount": 9000000000}}	\N
2639	divar	ga-6HgbR	جاده شاندیز مدرس ۱ فروش فوری	وکیل‌آباد	4600000000	sale	\N	https://divar.ir/v/_/ga-6HgbR	2026-10-01 15:39:34.353166+00	2026-10-01 15:41:26.715312+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در وکیل‌آباد", "amounts": {"raw_amount": 4600000000}}	\N
2640	divar	ga-63SMO	فروش اپارتمان 98 متری سال 405	جاهد شهر	9600000000	sale	41	https://divar.ir/v/_/ga-63SMO	2026-10-01 15:38:43.623467+00	2026-10-01 15:41:26.718227+00	\N	\N	\N	mashhad	98	\N	\N	\N	{"mid": "۹,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"raw_amount": 9600000000}}	\N
2641	divar	ga-63NKW	چهارراه ورزش / برند/ دو ممر/ تک واحدی /3خواب‌آفتاب	شاهد (شهرک غرب)	17990000000	sale	38	https://divar.ir/v/_/ga-63NKW	2026-10-01 15:37:56.875643+00	2026-10-01 15:41:26.720337+00	\N	\N	\N	mashhad	\N	3	\N	\N	{"mid": "۱۷,۹۹۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شاهد (شهرک غرب)", "amounts": {"raw_amount": 17990000000}}	\N
2642	divar	ga-23z9Y	۱۰۵ متری فارغ التحصیلان	فارغ التحصیلان	15400000000	sale	\N	https://divar.ir/v/_/ga-23z9Y	2026-10-01 15:36:48.500896+00	2026-10-01 15:41:26.722431+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۵,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فارغ التحصیلان", "amounts": {"raw_amount": 15400000000}}	\N
2643	divar	QaoF2DCm	فروش ۱زمین نادر وکمیاب ۳۰متری تجاری حسین اباد جلدک	جاهد شهر	1600000000	sale	41	https://divar.ir/v/_/QaoF2DCm	2026-10-01 15:36:29.043761+00	2026-10-01 15:41:26.724252+00	\N	\N	\N	mashhad	30	\N	\N	\N	{"mid": "۱,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "علی خاکشور جلدک سپاد صفی اباد فرهنگیان چاهشک در جاهد شهر", "amounts": {"raw_amount": 1600000000}}	\N
2644	divar	ga0Cen1l	آپارتمان طبقه پنجم وششم باپشت بام اختصاصی	شهرک بهارستان	6500000000	sale	\N	https://divar.ir/v/_/ga0Cen1l	2026-10-01 15:36:24.744564+00	2026-10-01 15:41:26.726146+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک بهارستان", "amounts": {"raw_amount": 6500000000}}	\N
2645	divar	ga1m0Jzn	شکار واقعی ۱۱۵ متری فول امکانات در سیدرضی	شهید رضوی	13500000000	sale	\N	https://divar.ir/v/_/ga1m0Jzn	2026-10-01 15:36:20.928578+00	2026-10-01 15:41:26.727967+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۱۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بامک بین امامت ۳۶و۳۸ در شهید رضوی", "amounts": {"raw_amount": 13500000000}}	\N
2646	divar	ga-2nugD	فروش واحد شیک در فلاحی	شاهد (شهرک غرب)	16800000000	sale	38	https://divar.ir/v/_/ga-2nugD	2026-10-01 15:35:51.414381+00	2026-10-01 15:41:26.730466+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۶,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن صبوری در شاهد (شهرک غرب)", "amounts": {"raw_amount": 16800000000}}	\N
2648	divar	gaq21JJS	آپارتمان	امیر المومنین	\N	rent	\N	https://divar.ir/v/_/gaq21JJS	2026-10-01 15:39:28.919759+00	2026-10-01 15:41:26.733778+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در امیر المومنین", "amounts": {}}	\N
2649	divar	ga-6Xon7	آپارتمان امامت	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga-6Xon7	2026-10-01 15:39:19.912483+00	2026-10-01 15:41:26.735616+00	\N	\N	\N	mashhad	\N	\N	\N	14000000	{"mid": "اجاره: ۱۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آزادشهر", "amounts": {"اجاره": 14000000}}	\N
2650	divar	ga-6Ha40	یک خواب ۹۰متری مشگینی ۷	مشکینی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-6Ha40	2026-10-01 15:39:13.73988+00	2026-10-01 15:41:26.737526+00	\N	\N	\N	mashhad	90	\N	\N	16000000	{"mid": "اجاره: ۱۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مشکینی (شهرک غرب)", "amounts": {"اجاره": 16000000}}	\N
2651	divar	ga-6Xi2u	خانه ویلایی  دربست ماشین رو	قائم	\N	rent	36	https://divar.ir/v/_/ga-6Xi2u	2026-10-01 15:39:01.646045+00	2026-10-01 15:41:26.739455+00	\N	\N	\N	mashhad	\N	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در قائم", "amounts": {"اجاره": 3000000}}	\N
2653	divar	ga-6HF_C	رهن و اجاره خانه ۶۵ متری	سیس‌آباد	\N	rent	\N	https://divar.ir/v/_/ga-6HF_C	2026-10-01 15:36:58.252793+00	2026-10-01 15:41:26.744149+00	\N	\N	\N	mashhad	65	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سیس‌آباد", "amounts": {"اجاره": 2000000}}	\N
2654	divar	ga-2H8Mt	هم خونه	ارشاد	\N	rent	15	https://divar.ir/v/_/ga-2H8Mt	2026-10-01 15:36:40.481605+00	2026-10-01 15:41:26.747559+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ارشاد", "amounts": {"اجاره": 10000000}}	\N
2655	divar	ga-2X9Lx	رهن کامل چمن 25	کارگران	\N	rent	40	https://divar.ir/v/_/ga-2X9Lx	2026-10-01 15:36:31.177121+00	2026-10-01 15:41:26.750241+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در کارگران", "amounts": {}}	\N
2656	divar	gau-oUzZ	آپارتمان 75 متری همکف امامت 31	آزادشهر	\N	rent	\N	https://divar.ir/v/_/gau-oUzZ	2026-10-01 15:36:01.889319+00	2026-10-01 15:41:26.752141+00	\N	\N	\N	mashhad	75	\N	\N	16000000	{"mid": "اجاره: ۱۶,۰۰۰,۰۰۰ تومان", "bottom": "در آزادشهر", "amounts": {"اجاره": 16000000}}	\N
2657	divar	ga-2Xbn5	75 متری کوثر شمالی 41	کوثر	\N	rent	13	https://divar.ir/v/_/ga-2Xbn5	2026-10-01 15:34:44.480045+00	2026-10-01 15:41:26.754062+00	\N	\N	\N	mashhad	75	\N	\N	21000000	{"mid": "اجاره: ۲۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"اجاره": 21000000}}	\N
2658	divar	ga-2Hh7P	رهن کامل خانه نوساز	شترک	\N	rent	\N	https://divar.ir/v/_/ga-2Hh7P	2026-10-01 15:34:35.072784+00	2026-10-01 15:41:26.756333+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در شترک", "amounts": {}}	\N
2659	divar	ga72uXpV	همخانه میشم یاهم خونه میشم آقاهستم۲۳خانه ندارم	دانشجو	\N	rent	39	https://divar.ir/v/_/ga72uXpV	2026-10-01 15:32:23.671342+00	2026-10-01 15:41:26.758504+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "در دانشجو", "amounts": {"اجاره": 5000000}}	\N
2660	divar	ga-yX6dF	آپارتمان ۱۰۰ متری ۲ خواب	کارمندان دوم	\N	rent	\N	https://divar.ir/v/_/ga-yX6dF	2026-10-01 15:32:00.555342+00	2026-10-01 15:41:26.760576+00	\N	\N	\N	mashhad	100	2	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در کارمندان دوم", "amounts": {}}	\N
2661	divar	ga-y3lyn	ویلایی دربست ۲۴۰ متر/۱۰۰ متر حیاط/۲ طبقه	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga-y3lyn	2026-10-01 15:30:50.691853+00	2026-10-01 15:41:26.762524+00	\N	\N	\N	mashhad	240	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن والی در چهارچشمه", "amounts": {"اجاره": 30000000}}	\N
2662	divar	ga-yXY30	( ارشاد هجرت ) 180 متر 3 خواب صفر فول لوکس برند	ارشاد	\N	rent	15	https://divar.ir/v/_/ga-yXY30	2026-10-01 15:29:47.918122+00	2026-10-01 15:41:26.764507+00	\N	\N	\N	mashhad	180	3	\N	60000000	{"mid": "اجاره: ۶۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال لو در ارشاد", "amounts": {"اجاره": 60000000}}	\N
2663	divar	gakyOKXf	رهن اجاره /ابوذر /ناصرخسرو	احمدآباد	\N	rent	\N	https://divar.ir/v/_/gakyOKXf	2026-10-01 15:29:21.319972+00	2026-10-01 15:41:26.766464+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در احمدآباد", "amounts": {}}	\N
2664	divar	ga-uXcty	واحد اجاره توس 142	باغون آباد	\N	rent	\N	https://divar.ir/v/_/ga-uXcty	2026-10-01 15:25:47.360978+00	2026-10-01 15:41:26.768311+00	\N	\N	\N	mashhad	\N	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در باغون آباد", "amounts": {"اجاره": 6000000}}	\N
2665	divar	gazmsW7C	۷۰ متری خادم‌الشریعه ، پیامبر اعظم ۴۹ بلوار توس	توس (بلوار توس)	3920000000	sale	\N	https://divar.ir/v/_/gazmsW7C	2026-09-23 12:46:15.845877+00	2026-10-01 15:51:59.192727+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۳,۹۲۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس (بلوار توس)", "amounts": {"raw_amount": 3920000000}}	\N
2666	divar	ga66MtlA	76متر،دوخواب،شخصی ساز،بازسازی شده	جاهد شهر	7390000000	sale	41	https://divar.ir/v/_/ga66MtlA	2026-09-29 13:56:19.528593+00	2026-10-01 15:51:59.20114+00	\N	\N	\N	mashhad	76	\N	\N	\N	{"mid": "۷,۳۹۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 7390000000}}	\N
2667	divar	ga-G4OBu	آپارتمان امام هادی 80 متری	شهرک امام هادی (شهرک غرب)	2550000000	sale	38	https://divar.ir/v/_/ga-G4OBu	2026-10-01 15:51:48.393791+00	2026-10-01 15:51:59.204487+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۲,۵۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهرک امام هادی (شهرک غرب)", "amounts": {"raw_amount": 2550000000}}	\N
2668	divar	ga-GIJqn	آپارتمان ۱۶۰ متری طبقه ششم صفر جلال ۵۰ جنوبی	سید رضی	26500000000	sale	\N	https://divar.ir/v/_/ga-GIJqn	2026-10-01 15:51:09.096853+00	2026-10-01 15:51:59.207514+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۲۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در سید رضی", "amounts": {"raw_amount": 26500000000}}	\N
2669	divar	ga-GoRcA	آپارتمان لوکس از برند فاخر الهیه محمدیه	الهیه	12650000000	sale	44	https://divar.ir/v/_/ga-GoRcA	2026-10-01 15:51:00.733076+00	2026-10-01 15:51:59.209407+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۲,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در الهیه", "amounts": {"raw_amount": 12650000000}}	\N
2671	divar	ga7a3J4d	آپارتمان 85 متری منزل آباد	منزل آباد	3700000000	sale	\N	https://divar.ir/v/_/ga7a3J4d	2026-10-01 15:48:35.247467+00	2026-10-01 15:51:59.213076+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۳,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در منزل آباد", "amounts": {"raw_amount": 3700000000}}	\N
2672	divar	gatyVjBm	۱۹۵ متری راهنمایی معاوضه / مالکی	راهنمایی	31500000000	sale	\N	https://divar.ir/v/_/gatyVjBm	2026-10-01 15:48:09.136044+00	2026-10-01 15:51:59.215554+00	\N	\N	\N	mashhad	195	\N	\N	\N	{"mid": "۳۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در راهنمایی", "amounts": {"raw_amount": 31500000000}}	\N
2673	divar	gaitEniS	باغ ویلا داخل مجتمع پردیس ماریان	درزآب	630000000	sale	\N	https://divar.ir/v/_/gaitEniS	2026-10-01 15:48:06.057093+00	2026-10-01 15:51:59.217505+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 630000000}}	\N
2674	divar	ga--nnk8	آپارتمان 105 متری حاشیه خیابان اصلی	توس (بلوار توس)	5970000000	sale	\N	https://divar.ir/v/_/ga--nnk8	2026-10-01 15:47:53.614997+00	2026-10-01 15:51:59.220464+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۵,۹۷۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {"raw_amount": 5970000000}}	\N
2675	divar	ga--nQeq	آپارتمان ۴ خوابه در هفت تیر	هفت تیر (حافظ)	15500000000	sale	5	https://divar.ir/v/_/ga--nQeq	2026-10-01 15:47:12.076635+00	2026-10-01 15:51:59.223351+00	\N	\N	\N	mashhad	\N	4	\N	\N	{"mid": "۱۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (حافظ)", "amounts": {"raw_amount": 15500000000}}	\N
2676	divar	gaO6pI51	۵۰۰مترزمین سنددار نجم فقط ۲۵۰ میلیون۱۰۰ پیش پرداخت	درزآب	250000000	sale	\N	https://divar.ir/v/_/gaO6pI51	2026-10-01 15:46:14.589507+00	2026-10-01 15:51:59.230421+00	\N	\N	\N	mashhad	500	\N	\N	\N	{"mid": "۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 250000000}}	\N
2678	divar	ga-GoD0A	امیریه 37 شیکـ فول 105متر 2 خواب تمیز شخصی ساز	الهیه	\N	rent	44	https://divar.ir/v/_/ga-GoD0A	2026-10-01 15:49:46.112687+00	2026-10-01 15:51:59.241196+00	\N	\N	\N	mashhad	105	2	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال لو در الهیه", "amounts": {"اجاره": 5000000}}	\N
2679	divar	ga-GoA19	خانه اجاره ای	توس فردوسی	\N	rent	\N	https://divar.ir/v/_/ga-GoA19	2026-10-01 15:49:30.062285+00	2026-10-01 15:51:59.248805+00	\N	\N	\N	mashhad	\N	\N	\N	500000	{"mid": "اجاره: ۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس فردوسی", "amounts": {"اجاره": 500000}}	\N
2681	divar	gauuLwLN	سه خواب ۱۴۵متر الهیه رحمانیه	جاهد شهر	\N	rent	41	https://divar.ir/v/_/gauuLwLN	2026-10-01 15:42:49.3564+00	2026-10-01 15:51:59.262736+00	\N	\N	\N	mashhad	145	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"اجاره": 40000000}}	\N
2682	divar	ga-2nK-l	حاشیه پیروزی چهار راه صیاد 3خواب اجاره	صیاد شیرازی	\N	rent	4	https://divar.ir/v/_/ga-2nK-l	2026-10-01 15:41:41.671326+00	2026-10-01 15:51:59.266659+00	\N	\N	\N	mashhad	\N	3	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در صیاد شیرازی", "amounts": {"اجاره": 35000000}}	\N
2683	divar	ga--3Km5	۸۵متر دلباز رهن کامل	ایثارگران	\N	rent	\N	https://divar.ir/v/_/ga--3Km5	2026-10-01 15:41:40.677846+00	2026-10-01 15:51:59.268719+00	\N	\N	\N	mashhad	85	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثارگران", "amounts": {"اجاره": 1000}}	\N
2698	divar	ga9-jTKl	آپارتمان+۲تک خواب65متربلوارطبرسی وحید۲۱	وحید	2900000000	sale	33	https://divar.ir/v/_/ga9-jTKl	2026-10-01 14:57:48.583378+00	2026-10-01 16:02:15.093549+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۲,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "ساخت و ساز ملک  در وحید", "amounts": {"raw_amount": 2900000000}}	\N
2699	divar	gaaq_BXs	زمین باغی ۵۵۰ متر کاهو	میان ولایت	700000000	sale	\N	https://divar.ir/v/_/gaaq_BXs	2026-10-01 16:02:02.938088+00	2026-10-01 16:02:15.106669+00	\N	\N	\N	mashhad	550	\N	\N	\N	{"mid": "۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در میان ولایت", "amounts": {"raw_amount": 700000000}}	\N
2700	divar	gaaStCpy	خانه ویلایی ۲۲۰ متر حسین باشی، نزدیک حرم	عبادی	19000000000	sale	\N	https://divar.ir/v/_/gaaStCpy	2026-10-01 16:01:37.416293+00	2026-10-01 16:02:15.111928+00	\N	\N	\N	mashhad	220	\N	\N	\N	{"mid": "۱۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در عبادی", "amounts": {"raw_amount": 19000000000}}	\N
2701	divar	gazeZBso	آپارتمان ۱۸۵ متری حاشیه پیروزی	رضاشهر	30500000000	sale	\N	https://divar.ir/v/_/gazeZBso	2026-10-01 16:01:34.064874+00	2026-10-01 16:02:15.117999+00	\N	\N	\N	mashhad	185	\N	\N	\N	{"mid": "۳۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رضاشهر", "amounts": {"raw_amount": 30500000000}}	\N
2702	divar	ga-OIbHr	فوری فوری  ،بعلت پول لازمم	حضرت حجت	2650000000	sale	\N	https://divar.ir/v/_/ga-OIbHr	2026-10-01 16:01:20.154794+00	2026-10-01 16:02:15.12239+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در حضرت حجت", "amounts": {"raw_amount": 2650000000}}	\N
2703	divar	ga-OYp-S	ویلایی نیم قطعه ۱۲۵ متر زمین دو کله/ لوکیشن فلاحی	فرهنگیان (شهرک غرب)	18000000000	sale	37	https://divar.ir/v/_/ga-OYp-S	2026-10-01 16:01:08.810762+00	2026-10-01 16:02:15.127167+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۱۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 18000000000}}	\N
2704	divar	ga-OIgne	آپارتمان ۱۰۵ متری توس ۸۵ ،پارکینگ،گرمایش از کف	شهرک مطهری	4200000000	sale	\N	https://divar.ir/v/_/ga-OIgne	2026-10-01 16:01:00.710858+00	2026-10-01 16:02:15.130818+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۴,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک مطهری", "amounts": {"raw_amount": 4200000000}}	\N
2705	divar	ga-O4Y-s	یک واحد آپارتمان ۱۰۸ متری سه خواب	چهارچشمه	10500000000	sale	\N	https://divar.ir/v/_/ga-O4Y-s	2026-10-01 16:00:49.735453+00	2026-10-01 16:02:15.133911+00	\N	\N	\N	mashhad	108	\N	\N	\N	{"mid": "۱۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهارچشمه", "amounts": {"raw_amount": 10500000000}}	\N
2706	divar	gazeJ9-1	۸۵ متر شخصی‌ساز ابتدای رحمانیه	جاهد شهر	8380000000	sale	41	https://divar.ir/v/_/gazeJ9-1	2026-10-01 16:00:40.035035+00	2026-10-01 16:02:15.136249+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۸,۳۸۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن برتر مدیران در جاهد شهر", "amounts": {"raw_amount": 8380000000}}	\N
2707	divar	ga-OIbDc	فروش آپارتمان۱۰۵متر سند ششدانگ اندیشه،قاسم آباد	مشکینی (شهرک غرب)	10000000000	sale	38	https://divar.ir/v/_/ga-OIbDc	2026-10-01 15:59:53.064339+00	2026-10-01 16:02:15.138589+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۱۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مدیریت سید مجتبی آقائی شهری در مشکینی (شهرک غرب)", "amounts": {"raw_amount": 10000000000}}	\N
3017	divar	gaWuqNaV	آپارتمان ۶۰ متری	فدک	2900000000	sale	\N	https://divar.ir/v/_/gaWuqNaV	2026-10-01 19:52:25.848881+00	2026-10-01 19:56:34.968862+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۲,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فدک", "amounts": {"raw_amount": 2900000000}}	\N
2708	divar	ga-OYBI-	شریعتی۶۳/ ۹۰متر/ ۲خواب/فول امکانات	یوسفیه (شهرک غرب)	9600000000	sale	38	https://divar.ir/v/_/ga-OYBI-	2026-10-01 15:59:46.684041+00	2026-10-01 16:02:15.140756+00	\N	\N	\N	mashhad	90	2	\N	\N	{"mid": "۹,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در یوسفیه (شهرک غرب)", "amounts": {"raw_amount": 9600000000}}	\N
2709	divar	ga6C4zu_	منزل 200متری دوبلکس*سند ششدانگ*	توس فردوسی	6050000000	sale	\N	https://divar.ir/v/_/ga6C4zu_	2026-10-01 15:58:48.902416+00	2026-10-01 16:02:15.143069+00	\N	\N	\N	mashhad	200	\N	\N	\N	{"mid": "۶,۰۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس فردوسی", "amounts": {"raw_amount": 6050000000}}	\N
2710	divar	ga-K4_nE	باغ ۷۰۰ متری صفر	كنويست	3200000000	sale	\N	https://divar.ir/v/_/ga-K4_nE	2026-10-01 15:58:29.411431+00	2026-10-01 16:02:15.145268+00	\N	\N	\N	mashhad	700	\N	\N	\N	{"mid": "۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در كنويست", "amounts": {"raw_amount": 3200000000}}	\N
2711	divar	ga2Kqall	آپارتمان۱۰۰متری دندان پزشکآن رهن و اجاره	فارغ التحصیلان	\N	rent	\N	https://divar.ir/v/_/ga2Kqall	2026-09-25 16:33:57.370941+00	2026-10-01 16:02:15.147037+00	\N	\N	\N	mashhad	100	\N	\N	39000000	{"mid": "اجاره: ۳۹,۰۰۰,۰۰۰ تومان", "bottom": "در فارغ التحصیلان", "amounts": {"اجاره": 39000000}}	\N
2713	divar	ga-O458O	خانه	موعود	\N	rent	\N	https://divar.ir/v/_/ga-O458O	2026-10-01 16:01:49.269113+00	2026-10-01 16:02:15.150598+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در موعود", "amounts": {"اجاره": 100000}}	\N
2714	divar	ga-OoZQW	آپارتمان/صفر/لوکس/فول امکانات /هفت تیر	هنرستان	\N	rent	11	https://divar.ir/v/_/ga-OoZQW	2026-10-01 16:00:48.051278+00	2026-10-01 16:02:15.15273+00	\N	\N	\N	mashhad	\N	\N	\N	85000000	{"mid": "اجاره: ۸۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرستان", "amounts": {"اجاره": 85000000}}	\N
2715	divar	ga72nX_B	۹۵ متر/ قلب رحمانیه/ تخلیه	جاهد شهر	\N	rent	41	https://divar.ir/v/_/ga72nX_B	2026-10-01 15:59:36.029202+00	2026-10-01 16:02:15.154784+00	\N	\N	\N	mashhad	95	\N	\N	27000000	{"mid": "اجاره: ۲۷,۰۰۰,۰۰۰ تومان", "bottom": "مسکن برتر مدیران در جاهد شهر", "amounts": {"اجاره": 27000000}}	\N
2716	divar	ga8CaRRS	آپارتمان 73 متری /سجادیه/ دسترسی بالا	الهیه	\N	rent	44	https://divar.ir/v/_/ga8CaRRS	2026-10-01 15:58:37.627747+00	2026-10-01 16:02:15.156651+00	\N	\N	\N	mashhad	73	\N	\N	13000000	{"mid": "اجاره: ۱۳,۰۰۰,۰۰۰ تومان", "bottom": "مسکن برتر مدیران در الهیه", "amounts": {"اجاره": 13000000}}	\N
2717	divar	gaw2cSRb	100 متری جهت رهن و اجاره 5 سال ساخت	بهشت	\N	rent	18	https://divar.ir/v/_/gaw2cSRb	2026-10-01 15:57:58.974245+00	2026-10-01 16:02:15.158449+00	\N	\N	\N	mashhad	100	\N	\N	9000000	{"mid": "اجاره: ۹,۰۰۰,۰۰۰ تومان", "bottom": "در بهشت", "amounts": {"اجاره": 9000000}}	\N
2718	divar	gaZyRhLz	واحد صفر۱۳۰ فول رهن کامل	سجاد شهر	\N	rent	21	https://divar.ir/v/_/gaZyRhLz	2026-10-01 15:56:57.565152+00	2026-10-01 16:02:15.160722+00	\N	\N	\N	mashhad	\N	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "در سجاد شهر", "amounts": {"اجاره": 20000000}}	\N
2719	divar	gagCUm0x	ویلایی دربست دو طبقه،کوثر جنوبی	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/gagCUm0x	2026-10-01 15:56:39.955872+00	2026-10-01 16:02:15.162717+00	\N	\N	\N	mashhad	\N	\N	\N	65000000	{"mid": "اجاره: ۶۵,۰۰۰,۰۰۰ تومان", "bottom": "در چهارچشمه", "amounts": {"اجاره": 65000000}}	\N
2720	divar	ga-GIfEa	آپارتمان 85 متری رهن کامل.  250ملیون	رده	\N	rent	\N	https://divar.ir/v/_/ga-GIfEa	2026-10-01 15:55:12.894417+00	2026-10-01 16:02:15.16464+00	\N	\N	\N	mashhad	85	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رده", "amounts": {"اجاره": 10000}}	\N
2721	divar	ga49BN58	۱۳۵مترصفر/رهن کامل/بیستون/خیام جنوبی/سجاد	فلسطین	\N	rent	19	https://divar.ir/v/_/ga49BN58	2026-10-01 15:52:54.393661+00	2026-10-01 16:02:15.166881+00	\N	\N	\N	mashhad	135	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در فلسطین", "amounts": {"اجاره": 30000000}}	\N
2722	divar	ga9qRSM8	اقدسیه 3/نوساز شیک/مناسب جهیزیه	الهیه	\N	rent	44	https://divar.ir/v/_/ga9qRSM8	2026-10-01 15:52:36.748416+00	2026-10-01 16:02:15.168796+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مشارکت درساخت زمین مرکز تخصصی در الهیه", "amounts": {}}	\N
2723	divar	ga6WT3Xg	رحمانیه 30) دوبلکس 250 متر 3 خواب صفر اروپائی شیکـ	الهیه	\N	rent	44	https://divar.ir/v/_/ga6WT3Xg	2026-10-01 15:52:22.837017+00	2026-10-01 16:02:15.170663+00	\N	\N	\N	mashhad	250	3	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال لو در الهیه", "amounts": {"اجاره": 15000000}}	\N
2734	divar	ga-azUpo	فوری/واحد ۲۱۰ متری تهاتر با خودرو و آپارتمان/ صفر	الهیه	30300000000	sale	44	https://divar.ir/v/_/ga-azUpo	2026-10-01 16:12:56.44687+00	2026-10-01 16:13:03.497583+00	\N	\N	\N	mashhad	210	\N	\N	\N	{"mid": "۳۰,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری بزرگ رویال در الهیه", "amounts": {"raw_amount": 30300000000}}	\N
2735	divar	ga6-zA4p	۹۰متر/پارکینگ اختصاصی/آسانسور	مشکینی (شهرک غرب)	6600000000	sale	38	https://divar.ir/v/_/ga6-zA4p	2026-10-01 16:11:52.325799+00	2026-10-01 16:13:03.501618+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۶,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در مشکینی (شهرک غرب)", "amounts": {"raw_amount": 6600000000}}	\N
2736	divar	ga-6WyVk	آپارتمان منفرد ۱۰  ۱۱۶ متری	جانباز	9500000000	sale	\N	https://divar.ir/v/_/ga-6WyVk	2026-10-01 16:11:45.398864+00	2026-10-01 16:13:03.505397+00	\N	\N	\N	mashhad	116	\N	\N	\N	{"mid": "۹,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جانباز", "amounts": {"raw_amount": 9500000000}}	\N
2737	divar	ga0Kvdzb	آپارتمان 75 متری دو خواب خوش نقشه چراغچی	بهمن	2800000000	sale	43	https://divar.ir/v/_/ga0Kvdzb	2026-10-01 16:11:16.907708+00	2026-10-01 16:13:03.508707+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۲,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهمن", "amounts": {"raw_amount": 2800000000}}	\N
2738	divar	ga-WIphJ	80متر/شیک/سند ملکی آماده/باز سازی شده/غرق نور	الهیه	6900000000	sale	44	https://divar.ir/v/_/ga-WIphJ	2026-10-01 16:09:50.433374+00	2026-10-01 16:13:03.512029+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۶,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 6900000000}}	\N
2739	divar	gahCAo25	آپارتمان 85متری/سندملکی/لوکس/سرشور نزدیک حرم مطهر	حرم مطهر رضوی	23000000000	sale	\N	https://divar.ir/v/_/gahCAo25	2026-10-01 16:08:53.147792+00	2026-10-01 16:13:03.514264+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۲۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در حرم مطهر رضوی", "amounts": {"raw_amount": 23000000000}}	\N
2771	divar	ga-iIsf_	رهن اجاره خانه باغ ویلایی نوساز	میان ولایت	\N	rent	\N	https://divar.ir/v/_/ga-iIsf_	2026-10-01 16:22:17.003231+00	2026-10-01 16:23:28.974472+00	\N	\N	\N	mashhad	\N	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"اجاره": 3000000}}	\N
2740	divar	gamKF36k	آپارتمان 60متری خ امام رضا5دقیقه پیاده روی تا حرم	حرم مطهر رضوی	14000000000	sale	\N	https://divar.ir/v/_/gamKF36k	2026-10-01 16:08:35.273334+00	2026-10-01 16:13:03.516591+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۱۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در حرم مطهر رضوی", "amounts": {"raw_amount": 14000000000}}	\N
2741	divar	ga-W4F5Y	واحد نقلی الهیه	الهیه	4000000000	sale	44	https://divar.ir/v/_/ga-W4F5Y	2026-10-01 16:07:42.11552+00	2026-10-01 16:13:03.519446+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 4000000000}}	\N
2742	divar	ga-OIjoW	خانه سفت کاری	مهدی آباد (بلوار توس)	1000000000	sale	\N	https://divar.ir/v/_/ga-OIjoW	2026-10-01 16:05:19.252093+00	2026-10-01 16:13:03.521614+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مهدی آباد (بلوار توس)", "amounts": {"raw_amount": 1000000000}}	\N
2745	divar	ga-aIa_B	همخونه میشم اقا هستم	کوثر	\N	rent	13	https://divar.ir/v/_/ga-aIa_B	2026-10-01 16:12:30.639938+00	2026-10-01 16:13:03.52647+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در کوثر", "amounts": {"اجاره": 5000000}}	\N
2747	divar	ga-WYldL	آپارتمان 175 نوساز ملک آباد	فلسطین	\N	rent	19	https://divar.ir/v/_/ga-WYldL	2026-10-01 16:10:03.580788+00	2026-10-01 16:13:03.531251+00	\N	\N	\N	mashhad	\N	\N	\N	130000000	{"mid": "اجاره: ۱۳۰,۰۰۰,۰۰۰ تومان", "bottom": "خانه خوشبختی در فلسطین", "amounts": {"اجاره": 130000000}}	\N
2748	divar	ga-OCxnT	250 متری / صدف / فول امکانات / نوساز	شریف	\N	rent	\N	https://divar.ir/v/_/ga-OCxnT	2026-10-01 16:09:47.891916+00	2026-10-01 16:13:03.533635+00	\N	\N	\N	mashhad	250	\N	\N	50000000	{"mid": "اجاره: ۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن بامک بین امامت ۳۶و۳۸ در شریف", "amounts": {"اجاره": 50000000}}	\N
2749	divar	ga-WYAvH	اجاره آپارتمان	یوسفیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-WYAvH	2026-10-01 16:07:20.199372+00	2026-10-01 16:13:03.535613+00	\N	\N	\N	mashhad	\N	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در یوسفیه (شهرک غرب)", "amounts": {"اجاره": 7000000}}	\N
2750	divar	ga-SYzTS	رهن و اجاره خونه ویلایی	کلاته برفی	\N	rent	\N	https://divar.ir/v/_/ga-SYzTS	2026-10-01 16:06:15.170309+00	2026-10-01 16:13:03.537776+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کلاته برفی", "amounts": {"اجاره": 5000000}}	\N
2751	divar	ga-S4625	خونه هم فروشی هم رهن	بهمن	\N	rent	43	https://divar.ir/v/_/ga-S4625	2026-10-01 16:06:13.397002+00	2026-10-01 16:13:03.540014+00	\N	\N	\N	mashhad	\N	\N	\N	3500000	{"mid": "اجاره: ۳,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهمن", "amounts": {"اجاره": 3500000}}	\N
2752	divar	ga-SYwei	رهن کامل منزل۷۵متری	بهمن	\N	rent	43	https://divar.ir/v/_/ga-SYwei	2026-10-01 16:05:29.075423+00	2026-10-01 16:13:03.542485+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در بهمن", "amounts": {}}	\N
2753	divar	ga-S4EKn	همخونه همخانه	امیریه	\N	rent	\N	https://divar.ir/v/_/ga-S4EKn	2026-10-01 16:02:35.289253+00	2026-10-01 16:13:03.544841+00	\N	\N	\N	mashhad	\N	\N	\N	5000	{"mid": "اجاره: ۵,۰۰۰ تومان", "bottom": "دقایقی پیش در امیریه", "amounts": {"اجاره": 5000}}	\N
2758	divar	ga-iI0D9	178 متر / مناسب سخت پسندان / کانکت / برند	امام رضا (ع)	37000000000	sale	\N	https://divar.ir/v/_/ga-iI0D9	2026-10-01 16:22:51.031638+00	2026-10-01 16:23:28.935674+00	\N	\N	\N	mashhad	178	\N	\N	\N	{"mid": "۳۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 37000000000}}	\N
2759	divar	gaxpnDkD	۱۶۵ مترصفر / جلال / امامت / صاحبی	فرهنگ	41200000000	sale	\N	https://divar.ir/v/_/gaxpnDkD	2026-10-01 16:22:46.371417+00	2026-10-01 16:23:28.944786+00	\N	\N	\N	mashhad	165	\N	\N	\N	{"mid": "۴۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مهندس محمدرضا صاحبی در فرهنگ", "amounts": {"raw_amount": 41200000000}}	\N
2760	divar	ga-iYecK	آپارتمان 100 متری شیک	ایثارگران	6500000000	sale	\N	https://divar.ir/v/_/ga-iYecK	2026-10-01 16:22:12.389086+00	2026-10-01 16:23:28.949032+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثارگران", "amounts": {"raw_amount": 6500000000}}	\N
2761	divar	ga-iYpSg	122 متر / تک واحدی / دونبش / امام رضا فرد	خرمشهر	22000000000	sale	\N	https://divar.ir/v/_/ga-iYpSg	2026-10-01 16:22:09.383666+00	2026-10-01 16:23:28.951724+00	\N	\N	\N	mashhad	122	\N	\N	\N	{"mid": "۲۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در خرمشهر", "amounts": {"raw_amount": 22000000000}}	\N
2762	divar	ga-ioSFv	فروش آپارتمان فوری	فدک	10000000000	sale	\N	https://divar.ir/v/_/ga-ioSFv	2026-10-01 16:21:00.514707+00	2026-10-01 16:23:28.953833+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فدک", "amounts": {"raw_amount": 10000000000}}	\N
2763	divar	ga-mAVin	204 متر/ پشت حاشیه وکیل آباد /تک واحدی	فارغ التحصیلان	30000000000	sale	\N	https://divar.ir/v/_/ga-mAVin	2026-10-01 16:19:43.5912+00	2026-10-01 16:23:28.955815+00	\N	\N	\N	mashhad	204	\N	\N	\N	{"mid": "۳۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن پژوهش در فارغ التحصیلان", "amounts": {"raw_amount": 30000000000}}	\N
2764	divar	ga-eY88Z	85 متر / اول امام رضا محدوده جهاد / فول	سلام	19600000000	sale	\N	https://divar.ir/v/_/ga-eY88Z	2026-10-01 16:19:09.659321+00	2026-10-01 16:23:28.957975+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۱۹,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در سلام", "amounts": {"raw_amount": 19600000000}}	\N
2765	divar	ga-eIlmb	100متری/سند شش دانگ	جاهد شهر	8850000000	sale	41	https://divar.ir/v/_/ga-eIlmb	2026-10-01 16:18:54.151232+00	2026-10-01 16:23:28.96083+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۸,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"raw_amount": 8850000000}}	\N
2766	divar	ga-e4l-k	فروش اپارتمان	هفت تیر (نه دره)	4200000000	sale	\N	https://divar.ir/v/_/ga-e4l-k	2026-10-01 16:18:35.213546+00	2026-10-01 16:23:28.96374+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (نه دره)", "amounts": {"raw_amount": 4200000000}}	\N
2767	divar	gaq-BtkR	خانه ویلایی ۸۵ متری رسالت ۹۱	سیس‌آباد	2200000000	sale	\N	https://divar.ir/v/_/gaq-BtkR	2026-10-01 16:18:12.000421+00	2026-10-01 16:23:28.9673+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۲,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در سیس‌آباد", "amounts": {"raw_amount": 2200000000}}	\N
2768	divar	ga-eIpMN	105 متر / اول امام رضا پیاده تا حرم 3 دقیقه / فول	آیت الله خامنه‌ای	27000000000	sale	\N	https://divar.ir/v/_/ga-eIpMN	2026-10-01 16:17:51.461709+00	2026-10-01 16:23:28.969622+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "۲۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در آیت الله خامنه‌ای", "amounts": {"raw_amount": 27000000000}}	\N
2772	divar	ga-iIYCB	امیریه 29 لوکس صفر کلید نخورده 108 متر فول امکانات	الهیه	\N	rent	44	https://divar.ir/v/_/ga-iIYCB	2026-10-01 16:21:43.470734+00	2026-10-01 16:23:28.976691+00	\N	\N	\N	mashhad	108	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن رویال لو در الهیه", "amounts": {}}	\N
2773	divar	ga76v0MA	۱۰۰ متر دوخوابه/نورگیر/ عرض ۱۰ خوش نقشه/ کم‌واحد	رضاشهر	\N	rent	\N	https://divar.ir/v/_/ga76v0MA	2026-10-01 16:21:21.864871+00	2026-10-01 16:23:28.978896+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در رضاشهر", "amounts": {}}	\N
2774	divar	ga-iYLSF	همخونه	تربیت (صدف)	\N	rent	\N	https://divar.ir/v/_/ga-iYLSF	2026-10-01 16:20:03.922593+00	2026-10-01 16:23:28.980827+00	\N	\N	\N	mashhad	\N	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در تربیت (صدف)", "amounts": {"اجاره": 7000000}}	\N
2775	divar	ga-iICH6	۷۵متر۲خواب تخلیه پارکینگ آسانسور امامیه ۶۸ میثاق	امامیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-iICH6	2026-10-01 16:20:00.519281+00	2026-10-01 16:23:28.982651+00	\N	\N	\N	mashhad	75	2	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در امامیه (شهرک غرب)", "amounts": {}}	\N
2776	divar	ga6y5hW7	125متر نزدیک به میدان لادن /تجاری/غرق در نور	اقبال	\N	rent	1	https://divar.ir/v/_/ga6y5hW7	2026-10-01 16:18:46.786922+00	2026-10-01 16:23:28.984515+00	\N	\N	\N	mashhad	125	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "مسکن یعقوبی نبش اقبال ۱۵ در اقبال", "amounts": {"اجاره": 1000}}	\N
2777	divar	ga-eo2sX	آپارتمان ۵۰متری رسالت	همت آباد	\N	rent	\N	https://divar.ir/v/_/ga-eo2sX	2026-10-01 16:18:42.208253+00	2026-10-01 16:23:28.986458+00	\N	\N	\N	mashhad	50	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در همت آباد", "amounts": {"اجاره": 4000000}}	\N
2778	divar	ga-e4qu8	رهن اجاره امامت ۴۵	زیبا شهر	\N	rent	\N	https://divar.ir/v/_/ga-e4qu8	2026-10-01 16:17:59.107801+00	2026-10-01 16:23:28.988484+00	\N	\N	\N	mashhad	\N	\N	\N	1000000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در زیبا شهر", "amounts": {"اجاره": 1000000000}}	\N
2779	divar	ga8iQsCO	یک همخونه موجه خانم	شهرک رازی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga8iQsCO	2026-10-01 16:17:37.992335+00	2026-10-01 16:23:28.990625+00	\N	\N	\N	mashhad	\N	\N	\N	500000	{"mid": "اجاره: ۵۰۰,۰۰۰ تومان", "bottom": "در شهرک رازی (شهرک غرب)", "amounts": {"اجاره": 500000}}	\N
2780	divar	ga8K-Z_9	۱۶۰ متر اوایل اقبال/افتابگیر هر ۳ اتاق/موقیعت خوب	اقبال	\N	rent	1	https://divar.ir/v/_/ga8K-Z_9	2026-10-01 16:17:10.81793+00	2026-10-01 16:23:28.992473+00	\N	\N	\N	mashhad	160	3	\N	55000000	{"mid": "اجاره: ۵۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن یعقوبی نبش اقبال ۱۵ در اقبال", "amounts": {"اجاره": 55000000}}	\N
2781	divar	ga-i31OU	75 متر امام رضا/نورگیر وافتابگیر/پارکینگ	خرمشهر	\N	rent	\N	https://divar.ir/v/_/ga-i31OU	2026-10-01 16:16:11.232484+00	2026-10-01 16:23:28.994496+00	\N	\N	\N	mashhad	75	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "مسکن یعقوبی نبش اقبال ۱۵ در خرمشهر", "amounts": {"اجاره": 25000000}}	\N
2782	divar	ga-eoLMA	خانه رهن واجاره درتوس۴۳شهیدغلامی	حضرت حجت	\N	rent	\N	https://divar.ir/v/_/ga-eoLMA	2026-10-01 16:15:49.849844+00	2026-10-01 16:23:28.996417+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حضرت حجت", "amounts": {"اجاره": 5000000}}	\N
2783	divar	ga-aY3Ns	۱۱۰ متری دو خواب لوکس /در حد صفر	الهیه	\N	rent	44	https://divar.ir/v/_/ga-aY3Ns	2026-10-01 16:14:33.387564+00	2026-10-01 16:23:28.998277+00	\N	\N	\N	mashhad	110	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری بزرگ رویال در الهیه", "amounts": {"اجاره": 30000000}}	\N
2789	divar	gahSz5NW	دوطبقه دربست راه جدا مهندسی ساز فقط ۴۵۰۰	شهید احمدی روشن	4500000000	sale	\N	https://divar.ir/v/_/gahSz5NW	2026-09-29 17:18:34.783264+00	2026-10-01 16:34:00.400365+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید احمدی روشن", "amounts": {"raw_amount": 4500000000}}	\N
2790	divar	ga-qYtyR	اپارتمان 2 خواب	رده	3200000000	sale	\N	https://divar.ir/v/_/ga-qYtyR	2026-10-01 16:33:51.187425+00	2026-10-01 16:34:00.406778+00	\N	\N	\N	mashhad	\N	2	\N	\N	{"mid": "۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در رده", "amounts": {"raw_amount": 3200000000}}	\N
2791	divar	ga-u0bhd	((درآمد ۲۰ میلیونی از یک خونه))	میان ولایت	3600000000	sale	\N	https://divar.ir/v/_/ga-u0bhd	2026-10-01 16:33:14.00993+00	2026-10-01 16:34:00.423643+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در میان ولایت", "amounts": {"raw_amount": 3600000000}}	\N
2792	divar	ga-qY1oZ	فروش آپارتمان   لوکیشن تاپ الهیه	الهیه	4250000000	sale	44	https://divar.ir/v/_/ga-qY1oZ	2026-10-01 16:33:12.014694+00	2026-10-01 16:34:00.428582+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در الهیه", "amounts": {"raw_amount": 4250000000}}	\N
2793	divar	ga-qIWcC	فروش آپارتمان	حضرت حجت	3800000000	sale	\N	https://divar.ir/v/_/ga-qIWcC	2026-10-01 16:33:01.288784+00	2026-10-01 16:34:00.43327+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در حضرت حجت", "amounts": {"raw_amount": 3800000000}}	\N
2794	divar	ga-uICln	فروش ویلایی ۱۲۵ متری سند تک برگی حاشیه  اصلی۲۰ متر	کوی المهدی	20000000000	sale	\N	https://divar.ir/v/_/ga-uICln	2026-10-01 16:32:26.161927+00	2026-10-01 16:34:00.437426+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "۲۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی المهدی", "amounts": {"raw_amount": 20000000000}}	\N
2795	divar	gaXSsK7J	آپارتمان ۷۰ متری / معبر ۲۰ متری /خ امام رضا / فول	امام رضا (ع)	13000000000	sale	\N	https://divar.ir/v/_/gaXSsK7J	2026-10-01 16:32:25.612554+00	2026-10-01 16:34:00.441916+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۱۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 13000000000}}	\N
2796	divar	gaxmzJEY	بسپار به من خودم  برات بهترین زمین جلدک را میخرم	جاهد شهر	360000000	sale	41	https://divar.ir/v/_/gaxmzJEY	2026-10-01 16:31:34.294712+00	2026-10-01 16:34:00.446453+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳۶۰,۰۰۰,۰۰۰ تومان", "bottom": "مهندس فخیم زاده حسین اباد جلدک خرید فروش  در جاهد شهر", "amounts": {"raw_amount": 360000000}}	\N
2797	divar	ga-q4qe8	116متر/ لوکس &  (اول رحمانیه) واقعی	الهیه	10750000000	sale	44	https://divar.ir/v/_/ga-q4qe8	2026-10-01 16:30:44.860884+00	2026-10-01 16:34:00.450853+00	\N	\N	\N	mashhad	116	\N	\N	\N	{"mid": "۱۰,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رجبیان در الهیه", "amounts": {"raw_amount": 10750000000}}	\N
2891	divar	gaj-t9Nl	همخونه هم خونه	راهنمایی	\N	rent	\N	https://divar.ir/v/_/gaj-t9Nl	2026-10-01 17:03:35.205064+00	2026-10-01 17:05:44.34112+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "در راهنمایی", "amounts": {"اجاره": 5000000}}	\N
2800	divar	ga-q4r8R	آپارتمان 150متر سه خواب شیک سر سه نبش وصفر	الهیه	\N	rent	44	https://divar.ir/v/_/ga-q4r8R	2026-10-01 16:33:30.759563+00	2026-10-01 16:34:00.460629+00	\N	\N	\N	mashhad	150	\N	\N	27000000	{"mid": "اجاره: ۲۷,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در الهیه", "amounts": {"اجاره": 27000000}}	\N
2801	divar	ga-uIJ0H	آبادگران آپارتمان هتلی	آبادگران	\N	rent	\N	https://divar.ir/v/_/ga-uIJ0H	2026-10-01 16:32:42.334454+00	2026-10-01 16:34:00.466051+00	\N	\N	\N	mashhad	\N	\N	\N	50000000	{"mid": "اجاره: ۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آبادگران", "amounts": {"اجاره": 50000000}}	\N
2802	divar	ga-qo4ij	رهن کامل امامت دو خواب شیک و تمیز با پارکینگ	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga-qo4ij	2026-10-01 16:32:29.774739+00	2026-10-01 16:34:00.470129+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در آزادشهر", "amounts": {}}	\N
2803	divar	ga6WiKJP	اجاره آپارتمان شیک و آفتاب‌گیر	الهیه	\N	rent	44	https://divar.ir/v/_/ga6WiKJP	2026-10-01 16:31:47.484177+00	2026-10-01 16:34:00.474453+00	\N	\N	\N	mashhad	\N	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"اجاره": 30000000}}	\N
2804	divar	ga-m4-69	اجاره آپارتمان 75 متری طبقه 18/ فول فرنیش	هفده شهریور	\N	rent	\N	https://divar.ir/v/_/ga-m4-69	2026-10-01 16:31:22.965132+00	2026-10-01 16:34:00.478615+00	\N	\N	\N	mashhad	75	\N	\N	35000000	{"mid": "اجاره: ۳۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفده شهریور", "amounts": {"اجاره": 35000000}}	\N
2805	divar	ga-q4pUY	آپارتمان ۱۸۵متری/تک واحدی/همکف/علویه ۲۱	امیریه	\N	rent	\N	https://divar.ir/v/_/ga-q4pUY	2026-10-01 16:30:42.810282+00	2026-10-01 16:34:00.482678+00	\N	\N	\N	mashhad	185	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن ممتاز ایران در امیریه", "amounts": {}}	\N
2806	divar	ga-qoOne	ویلایی ۱۲۵ متری دو طبقه	مقدم	\N	rent	\N	https://divar.ir/v/_/ga-qoOne	2026-10-01 16:30:24.840943+00	2026-10-01 16:34:00.486917+00	\N	\N	\N	mashhad	125	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "دقایقی پیش در مقدم", "amounts": {"اجاره": 1000}}	\N
2807	divar	ga-q4if3	رهن آپارتمان	الهیه	\N	rent	44	https://divar.ir/v/_/ga-q4if3	2026-10-01 16:30:11.441076+00	2026-10-01 16:34:00.491279+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در الهیه", "amounts": {}}	\N
2808	divar	ga-mY7Bb	رهن اجاره آپارتمان مفتح طلاب	گلشور	\N	rent	\N	https://divar.ir/v/_/ga-mY7Bb	2026-10-01 16:27:31.390248+00	2026-10-01 16:34:00.495242+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گلشور", "amounts": {"اجاره": 100000}}	\N
2809	divar	ga-molRR	فرامرز/ 250 متری / 4 خواب / صفر / فول امکانات	شهید فرامرز عباسی	\N	rent	\N	https://divar.ir/v/_/ga-molRR	2026-10-01 16:26:15.09058+00	2026-10-01 16:34:00.499294+00	\N	\N	\N	mashhad	250	4	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "مسکن بامک بین امامت ۳۶و۳۸ در شهید فرامرز عباسی", "amounts": {"اجاره": 1000}}	\N
2810	divar	ga-mIQMj	85متر/شیک/شریعتی ۳۹/طبقه دوم	شاهد (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-mIQMj	2026-10-01 16:25:04.991814+00	2026-10-01 16:34:00.503466+00	\N	\N	\N	mashhad	85	\N	\N	1500000	{"mid": "اجاره: ۱,۵۰۰,۰۰۰ تومان", "bottom": "مسکن شمس نبش شریعتی ۶ در شاهد (شهرک غرب)", "amounts": {"اجاره": 1500000}}	\N
2819	divar	ga-24Vg6	70 متر آپارتمان	بهمن	2400000000	sale	43	https://divar.ir/v/_/ga-24Vg6	2026-10-01 16:43:27.367142+00	2026-10-01 16:44:36.142956+00	\N	\N	\N	mashhad	70	\N	\N	\N	{"mid": "۲,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهمن", "amounts": {"raw_amount": 2400000000}}	\N
2820	divar	ga-2oLlF	فروش خانه ویلایی ۸۰متری	علی آباد	2150000000	sale	\N	https://divar.ir/v/_/ga-2oLlF	2026-10-01 16:43:20.157813+00	2026-10-01 16:44:36.151466+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۲,۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در علی آباد", "amounts": {"raw_amount": 2150000000}}	\N
2821	divar	gaZOLbuD	آپارتمان 80متری سند آماده/نزدیک اصلی	کوشش	17000000000	sale	\N	https://divar.ir/v/_/gaZOLbuD	2026-10-01 16:43:17.275283+00	2026-10-01 16:44:36.158906+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۱۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در کوشش", "amounts": {"raw_amount": 17000000000}}	\N
2822	divar	gayyJK2w	آپارتمان ۱۲۵ متری/۳خواب	امام رضا (ع)	16400000000	sale	\N	https://divar.ir/v/_/gayyJK2w	2026-10-01 16:43:00.182381+00	2026-10-01 16:44:36.166447+00	\N	\N	\N	mashhad	125	3	\N	\N	{"mid": "۱۶,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در امام رضا (ع)", "amounts": {"raw_amount": 16400000000}}	\N
2823	divar	ga5ezMwb	منزل ویلایی 180متر	قائم	22000000000	sale	36	https://divar.ir/v/_/ga5ezMwb	2026-10-01 16:42:38.455752+00	2026-10-01 16:44:36.172414+00	\N	\N	\N	mashhad	180	\N	\N	\N	{"mid": "۲۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در قائم", "amounts": {"raw_amount": 22000000000}}	\N
2824	divar	ga-2YQzU	خانه ویلایی منزل ماشین رو فروش نزدیک حرم	علی آباد	2000000000	sale	\N	https://divar.ir/v/_/ga-2YQzU	2026-10-01 16:42:33.737564+00	2026-10-01 16:44:36.178771+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در علی آباد", "amounts": {"raw_amount": 2000000000}}	\N
2825	divar	gaipUGwI	آپارتمان ۹۰متری همکف صفر ۲خواب طرحچی۳۳ خین عرب	شهرک امام سجاد	2500000000	sale	21	https://divar.ir/v/_/gaipUGwI	2026-10-01 16:42:23.276179+00	2026-10-01 16:44:36.184488+00	\N	\N	\N	mashhad	90	2	\N	\N	{"mid": "۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک امام سجاد", "amounts": {"raw_amount": 2500000000}}	\N
2826	divar	ga-uY432	ویلایی۲۸۰متری عبادی۲۱زیربنا۲۵۰مترقطعه۲ازحاشیه ملکی	آیت الله کاشانی	32000000000	sale	\N	https://divar.ir/v/_/ga-uY432	2026-10-01 16:41:33.24075+00	2026-10-01 16:44:36.189361+00	\N	\N	\N	mashhad	280	\N	\N	\N	{"mid": "۳۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آیت الله کاشانی", "amounts": {"raw_amount": 32000000000}}	\N
2827	divar	ga-yoq49	فروش خانه طبقه همکف	توس (بلوار توس)	2600000000	sale	\N	https://divar.ir/v/_/ga-yoq49	2026-10-01 16:41:13.435686+00	2026-10-01 16:44:36.193726+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {"raw_amount": 2600000000}}	\N
2828	divar	ga-youCe	110متر 8متر حاشیه	ایثارگران	6200000000	sale	\N	https://divar.ir/v/_/ga-youCe	2026-10-01 16:40:30.196815+00	2026-10-01 16:44:36.197832+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۶,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثارگران", "amounts": {"raw_amount": 6200000000}}	\N
2829	divar	ga922CX-	۱۰۰ متر ۲ خواب مستر فول متریال ، مشاعات لوکس ، حرم	امام رضا (ع)	32000000000	sale	\N	https://divar.ir/v/_/ga922CX-	2026-10-01 16:39:56.073853+00	2026-10-01 16:44:36.201432+00	\N	\N	\N	mashhad	100	2	\N	\N	{"mid": "۳۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن شمس در امام رضا (ع)", "amounts": {"raw_amount": 32000000000}}	\N
2830	divar	ga-y4epV	خونه ۱۲۰ متری مجتمع یاس	مهدی آباد (بلوار توس)	7500000000	sale	\N	https://divar.ir/v/_/ga-y4epV	2026-10-01 16:39:34.679714+00	2026-10-01 16:44:36.205381+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مهدی آباد (بلوار توس)", "amounts": {"raw_amount": 7500000000}}	\N
2831	divar	ga-yIipx	واحد آپارتمانی سند شش دانگ	امیر	7000000000	sale	\N	https://divar.ir/v/_/ga-yIipx	2026-10-01 16:39:09.093599+00	2026-10-01 16:44:36.209946+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امیر", "amounts": {"raw_amount": 7000000000}}	\N
2832	divar	ga-2jtZi	124متری2خواب /دونبش /کاشانی /شمس	شهید هاشمی نژاد	21200000000	sale	\N	https://divar.ir/v/_/ga-2jtZi	2026-10-01 16:38:31.21876+00	2026-10-01 16:44:36.213622+00	\N	\N	\N	mashhad	124	2	\N	\N	{"mid": "۲۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن شمس در شهید هاشمی نژاد", "amounts": {"raw_amount": 21200000000}}	\N
2835	divar	ga-2YVAR	رهن و اجاره آپارتمان 3 خوابه 135متر طبقه اول	هفده شهریور	\N	rent	\N	https://divar.ir/v/_/ga-2YVAR	2026-10-01 16:44:32.543578+00	2026-10-01 16:44:36.222607+00	\N	\N	\N	mashhad	135	3	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در هفده شهریور", "amounts": {"اجاره": 20000000}}	\N
2836	divar	ga-2IrvS	بازسازی لوکس / تخلیه / با امکان قرارداد ۲ ساله	الهیه	\N	rent	44	https://divar.ir/v/_/ga-2IrvS	2026-10-01 16:43:35.198949+00	2026-10-01 16:44:36.226353+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "مسکن ممتاز ایران در الهیه", "amounts": {}}	\N
2837	divar	ga-2YpzE	همخونه خانم	کشاورز	\N	rent	\N	https://divar.ir/v/_/ga-2YpzE	2026-10-01 16:43:23.728641+00	2026-10-01 16:44:36.229579+00	\N	\N	\N	mashhad	\N	\N	\N	50000	{"mid": "اجاره: ۵۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کشاورز", "amounts": {"اجاره": 50000}}	\N
2838	divar	ga1SUFSu	۱۱۰متر/۲خواب/شریعتی/فول امکانات	حسابی جنوبی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga1SUFSu	2026-10-01 16:42:27.878702+00	2026-10-01 16:44:36.233056+00	\N	\N	\N	mashhad	110	2	\N	\N	{"mid": "رهن کامل", "bottom": "گروه مهندسی ساختمانی دیان در حسابی جنوبی (شهرک غرب)", "amounts": {}}	\N
2839	divar	ga-y49YJ	۱۷۵ متر فول امکانات اول هاشمیه	هنرستان	\N	rent	11	https://divar.ir/v/_/ga-y49YJ	2026-10-01 16:41:28.431504+00	2026-10-01 16:44:36.237113+00	\N	\N	\N	mashhad	175	\N	\N	60000000	{"mid": "اجاره: ۶۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرستان", "amounts": {"اجاره": 60000000}}	\N
2840	divar	ga-y4wU3	رهن و اجاره  و فروش منزل مسکونی ویلایی	شترک	\N	rent	\N	https://divar.ir/v/_/ga-y4wU3	2026-10-01 16:40:34.78539+00	2026-10-01 16:44:36.240725+00	\N	\N	\N	mashhad	\N	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شترک", "amounts": {"اجاره": 4000000}}	\N
2841	divar	ga-yIdtw	رهن واجاره ویلایی ۵۰۰ متری خوش لوکیشن	کوه سنگی	\N	rent	\N	https://divar.ir/v/_/ga-yIdtw	2026-10-01 16:38:18.427117+00	2026-10-01 16:44:36.246113+00	\N	\N	\N	mashhad	500	\N	\N	50000000	{"mid": "اجاره: ۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوه سنگی", "amounts": {"اجاره": 50000000}}	\N
2842	divar	ga-mId2O	رهن واجاره60متری بالکیش عالی دسترسی به امکانات	نوده	\N	rent	\N	https://divar.ir/v/_/ga-mId2O	2026-10-01 16:34:24.188093+00	2026-10-01 16:44:36.2494+00	\N	\N	\N	mashhad	60	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوده", "amounts": {"اجاره": 7000000}}	\N
2847	divar	gapSJGVd	آپارتمان ۱۱۲متری  سند دار (فروش فوری)	زمرد	10800000000	sale	\N	https://divar.ir/v/_/gapSJGVd	2026-09-30 05:17:31.242123+00	2026-10-01 16:55:05.314933+00	\N	\N	\N	mashhad	112	\N	\N	\N	{"mid": "۱۰,۸۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در زمرد", "amounts": {"raw_amount": 10800000000}}	\N
2848	divar	ga-CpUBy	آپارتمان ۱۱۷متر فول امکانات تکواحدی غرق نور سیدرضی	آزادشهر	14100000000	sale	\N	https://divar.ir/v/_/ga-CpUBy	2026-10-01 16:54:55.820263+00	2026-10-01 16:55:05.3241+00	\N	\N	\N	mashhad	117	\N	\N	\N	{"mid": "۱۴,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در آزادشهر", "amounts": {"raw_amount": 14100000000}}	\N
2850	divar	ga--oNL9	فروش آپارتمان  125طبرسی 24رجب زاده 18	طبرسی شمالی	2300000000	sale	42	https://divar.ir/v/_/ga--oNL9	2026-10-01 16:52:32.453744+00	2026-10-01 16:55:05.338613+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طبرسی شمالی", "amounts": {"raw_amount": 2300000000}}	\N
2851	divar	ga-yDN8H	فروش زمین در جاده ساغشک به شاندیز	میان ولایت	2000000000	sale	\N	https://divar.ir/v/_/ga-yDN8H	2026-10-01 16:52:20.994246+00	2026-10-01 16:55:05.347074+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 2000000000}}	\N
2852	divar	ga69d8BH	فاز ۲ الهیه نگاه آینده کارشناس اموراراضی فخیم زاده	وکیل‌آباد	700000000	sale	\N	https://divar.ir/v/_/ga69d8BH	2026-10-01 16:52:19.420504+00	2026-10-01 16:55:05.35256+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مهندس فخیم زاده حسین اباد جلدک خرید فروش  در وکیل‌آباد", "amounts": {"raw_amount": 700000000}}	\N
2853	divar	gamm2VUw	۱۰۸۰مترباغ با امکانات کامل سند وتغییرکاربری/سکونت	درزآب	1900000000	sale	\N	https://divar.ir/v/_/gamm2VUw	2026-10-01 16:51:55.31499+00	2026-10-01 16:55:05.35732+00	\N	\N	\N	mashhad	1080	\N	\N	\N	{"mid": "۱,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دفترفروش مجتمع های پردیس در درزآب", "amounts": {"raw_amount": 1900000000}}	\N
2854	divar	ga9Gz0CG	۱۴۵۰ متر زمین ۱۸۰ زیر بنا معاوضه با خودرو	رباط طرق	7500000000	sale	\N	https://divar.ir/v/_/ga9Gz0CG	2026-10-01 16:50:51.382208+00	2026-10-01 16:55:05.362395+00	\N	\N	\N	mashhad	1450	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در رباط طرق", "amounts": {"raw_amount": 7500000000}}	\N
2855	divar	ga-6Yq9V	منزل ویلایی ۶۵ متری دو طبقه مجزا شهرک شیرین	بهشت	6500000000	sale	18	https://divar.ir/v/_/ga-6Yq9V	2026-10-01 16:50:43.247269+00	2026-10-01 16:55:05.366496+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در بهشت", "amounts": {"raw_amount": 6500000000}}	\N
2856	divar	gaqyFJXq	فروش آپارتمان ۱۰۶ متر دوخوابه در هاشمیه ۶۱	هنرستان	11000000000	sale	11	https://divar.ir/v/_/gaqyFJXq	2026-10-01 16:50:24.955172+00	2026-10-01 16:55:05.370447+00	\N	\N	\N	mashhad	106	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن ۱۱ در هنرستان", "amounts": {"raw_amount": 11000000000}}	\N
2857	divar	ganKKld0	قطعات ۴۰۰متری سند دار	توس فردوسی	200000000	sale	\N	https://divar.ir/v/_/ganKKld0	2026-10-01 16:50:23.77356+00	2026-10-01 16:55:05.374763+00	\N	\N	\N	mashhad	400	\N	\N	\N	{"mid": "۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دفتر فروش۰ویلاسازان سرمدی  در توس فردوسی", "amounts": {"raw_amount": 200000000}}	\N
2858	divar	ga-64i12	خانه نقلی قدیمی	جاهد شهر	1280000000	sale	41	https://divar.ir/v/_/ga-64i12	2026-10-01 16:50:21.440801+00	2026-10-01 16:55:05.378686+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۲۸۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"raw_amount": 1280000000}}	\N
2859	divar	ga-2Y3wL	پروژه نهضت ملی  . باتیس بنا	شهرک مهرگان	2000000000	sale	\N	https://divar.ir/v/_/ga-2Y3wL	2026-10-01 16:49:57.158289+00	2026-10-01 16:55:05.382732+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک مهرگان", "amounts": {"raw_amount": 2000000000}}	\N
2860	divar	ga-64zg6	اپارتمان دو خوابه	شهرک بهارستان	3500000000	sale	\N	https://divar.ir/v/_/ga-64zg6	2026-10-01 16:49:54.299072+00	2026-10-01 16:55:05.386792+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک بهارستان", "amounts": {"raw_amount": 3500000000}}	\N
2861	divar	ga-iH4Aq	واحد خوش قیمت خاص ایثار	ایثار	5100000000	sale	\N	https://divar.ir/v/_/ga-iH4Aq	2026-10-01 16:49:48.616364+00	2026-10-01 16:55:05.391342+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۵,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثار", "amounts": {"raw_amount": 5100000000}}	\N
2863	divar	ga6G1WVA	خانه ۵۰متری دربست توس۹۱بصیر۲۱	شهید بصیر	\N	rent	\N	https://divar.ir/v/_/ga6G1WVA	2026-10-01 16:54:51.82336+00	2026-10-01 16:55:05.397758+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "رهن کامل", "bottom": "در شهید بصیر", "amounts": {}}	\N
2864	divar	ga--Y-VK	همخونه	عبادی	\N	rent	\N	https://divar.ir/v/_/ga--Y-VK	2026-10-01 16:54:44.682115+00	2026-10-01 16:55:05.40181+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در عبادی", "amounts": {"اجاره": 1000000}}	\N
2865	divar	ga--40nR	لادن ۸۰متر طبقه اول فول	شهرآرا	\N	rent	3	https://divar.ir/v/_/ga--40nR	2026-10-01 16:53:20.908604+00	2026-10-01 16:55:05.405951+00	\N	\N	\N	mashhad	80	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرآرا", "amounts": {"اجاره": 100000}}	\N
2866	divar	ga-6Yp7O	واحد ۱۰۰ متری رهن و اجاره واقع در ازاد شهر	آزادشهر	\N	rent	\N	https://divar.ir/v/_/ga-6Yp7O	2026-10-01 16:51:03.679902+00	2026-10-01 16:55:05.409936+00	\N	\N	\N	mashhad	100	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آزادشهر", "amounts": {"اجاره": 30000000}}	\N
2867	divar	ga--IZLi	اجاره اپارتمان	آیت الله کاشانی	\N	rent	\N	https://divar.ir/v/_/ga--IZLi	2026-10-01 16:51:00.188199+00	2026-10-01 16:55:05.414062+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آیت الله کاشانی", "amounts": {"اجاره": 1000000}}	\N
2868	divar	ga-6Y9Cu	۱۳۰	هفت تیر (آب و برق)	\N	rent	\N	https://divar.ir/v/_/ga-6Y9Cu	2026-10-01 16:50:29.71206+00	2026-10-01 16:55:05.418164+00	\N	\N	\N	mashhad	\N	\N	\N	34000000	{"mid": "اجاره: ۳۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (آب و برق)", "amounts": {"اجاره": 34000000}}	\N
2869	divar	gaz2Lgyy	اجاره پارکینگ طبرسی شمالی۴	نظام دوست	\N	rent	\N	https://divar.ir/v/_/gaz2Lgyy	2026-10-01 16:46:13.280062+00	2026-10-01 16:55:05.422091+00	\N	\N	\N	mashhad	\N	\N	\N	2500000	{"mid": "اجاره: ۲,۵۰۰,۰۰۰ تومان", "bottom": "در نظام دوست", "amounts": {"اجاره": 2500000}}	\N
2877	divar	ga4uqMM-	500متر زمین پشت دانشگاه آزادگلبهار۱۵میلیون بخش۷	رضاشهر	150000000	sale	\N	https://divar.ir/v/_/ga4uqMM-	2026-09-27 05:36:24.552457+00	2026-10-01 17:05:44.273545+00	\N	\N	\N	mashhad	500	\N	\N	\N	{"mid": "۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در رضاشهر", "amounts": {"raw_amount": 150000000}}	\N
2878	divar	ga-KpnuO	تک واحدی،لوکس،معبر 16 متری ایثار	ایثار	23760000000	sale	\N	https://divar.ir/v/_/ga-KpnuO	2026-10-01 17:05:05.761613+00	2026-10-01 17:05:44.288367+00	\N	\N	\N	mashhad	16	\N	\N	\N	{"mid": "۲۳,۷۶۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در ایثار", "amounts": {"raw_amount": 23760000000}}	\N
2879	divar	ga2SBXZs	آپارتمان ۱۱۵ متری	امام خمینی	11500000000	sale	\N	https://divar.ir/v/_/ga2SBXZs	2026-10-01 17:04:47.343364+00	2026-10-01 17:05:44.292854+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۱۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امام خمینی", "amounts": {"raw_amount": 11500000000}}	\N
2880	divar	ga-K5TP4	فروش ویلایی	نوغان	17500000000	sale	\N	https://divar.ir/v/_/ga-K5TP4	2026-10-01 17:04:01.024889+00	2026-10-01 17:05:44.297668+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوغان", "amounts": {"raw_amount": 17500000000}}	\N
2881	divar	ga8itOm_	زمین ناظریه	میان ولایت	1200000000	sale	\N	https://divar.ir/v/_/ga8itOm_	2026-10-01 17:03:21.66832+00	2026-10-01 17:05:44.302162+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 1200000000}}	\N
2882	divar	ga--4fZB	آپارتمان ۱۰۲ متر امام خمینی ۴۹	امام خمینی	14950000000	sale	\N	https://divar.ir/v/_/ga--4fZB	2026-10-01 17:02:33.263984+00	2026-10-01 17:05:44.306611+00	\N	\N	\N	mashhad	102	\N	\N	\N	{"mid": "۱۴,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در امام خمینی", "amounts": {"raw_amount": 14950000000}}	\N
2883	divar	gavabigh	خانه ویلایی در آرامگاه فردوسی	توس فردوسی	3100000000	sale	\N	https://divar.ir/v/_/gavabigh	2026-10-01 17:02:30.285841+00	2026-10-01 17:05:44.31081+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس فردوسی", "amounts": {"raw_amount": 3100000000}}	\N
2885	divar	ga-GJocv	اپارتمان ۸۰ متری صفر بلوار کریمی	شهید مطهری	4500000000	sale	28	https://divar.ir/v/_/ga-GJocv	2026-10-01 17:01:52.709721+00	2026-10-01 17:05:44.318649+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید مطهری", "amounts": {"raw_amount": 4500000000}}	\N
2886	divar	ga-GZ3eR	منزل 65متری یک خواب	مهدی آباد (بلوار توس)	1400000000	sale	\N	https://divar.ir/v/_/ga-GZ3eR	2026-10-01 17:01:33.001657+00	2026-10-01 17:05:44.322875+00	\N	\N	\N	mashhad	65	\N	\N	\N	{"mid": "۱,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مهدی آباد (بلوار توس)", "amounts": {"raw_amount": 1400000000}}	\N
2887	divar	ga-G5Mvi	خانه ویلایی	توس (بلوار توس)	2470000000	sale	\N	https://divar.ir/v/_/ga-G5Mvi	2026-10-01 17:01:26.007357+00	2026-10-01 17:05:44.326871+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۴۷۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {"raw_amount": 2470000000}}	\N
2888	divar	gaq-U5bv	فروش آپارتمان ۹۰ متری طبقه ۳ و ۴	فردوسی	14000000000	sale	\N	https://divar.ir/v/_/gaq-U5bv	2026-10-01 16:59:02.48475+00	2026-10-01 17:05:44.330517+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۱۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن ۱۱ در فردوسی", "amounts": {"raw_amount": 14000000000}}	\N
2890	divar	ga-Gpudo	رهن واجاره املاک	شهرک ابوذر	\N	rent	24	https://divar.ir/v/_/ga-Gpudo	2026-10-01 17:04:08.226075+00	2026-10-01 17:05:44.337537+00	\N	\N	\N	mashhad	\N	\N	\N	500000	{"mid": "اجاره: ۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک ابوذر", "amounts": {"اجاره": 500000}}	\N
2892	divar	ga-KJBOy	خانه رهن کامل کشمیری	شهید شهریاری	\N	rent	\N	https://divar.ir/v/_/ga-KJBOy	2026-10-01 17:02:04.848067+00	2026-10-01 17:05:44.345173+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید شهریاری", "amounts": {"اجاره": 100000}}	\N
2893	divar	ga-GZ6An	اجاره واحد لوکس ۱۷۸ متری ۳ خواب تک‌واحدی	رضاشهر	\N	rent	\N	https://divar.ir/v/_/ga-GZ6An	2026-10-01 17:02:01.288844+00	2026-10-01 17:05:44.350381+00	\N	\N	\N	mashhad	178	3	\N	70000000	{"mid": "اجاره: ۷۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رضاشهر", "amounts": {"اجاره": 70000000}}	\N
2894	divar	ga-GJtKM	آپارتمان ۱۷۲متری فرامرز۲۹	شهید فرامرز عباسی	\N	rent	\N	https://divar.ir/v/_/ga-GJtKM	2026-10-01 17:00:43.331631+00	2026-10-01 17:05:44.354489+00	\N	\N	\N	mashhad	172	\N	\N	500000000	{"mid": "اجاره: ۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید فرامرز عباسی", "amounts": {"اجاره": 500000000}}	\N
2895	divar	ga-GZWLa	رهن واجاره اپارتمان/ ۸۰ متر/ طبقه ۳پله/ صیاد ۲۳	هفت تیر (آب و برق)	\N	rent	\N	https://divar.ir/v/_/ga-GZWLa	2026-10-01 16:59:13.961556+00	2026-10-01 17:05:44.358465+00	\N	\N	\N	mashhad	80	\N	\N	\N	{"mid": "رهن کامل", "bottom": "بازار مسکن مشهد بین اقبال۱۰و۱۲ در هفت تیر (آب و برق)", "amounts": {}}	\N
2908	divar	ga5OYeZ-	فروش	سمزقند	7000000000	sale	\N	https://divar.ir/v/_/ga5OYeZ-	2026-10-01 19:19:34.900579+00	2026-10-01 19:20:47.393221+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سمزقند", "amounts": {"raw_amount": 7000000000}}	\N
2909	divar	ga--6rol	زمین دور دیوار روستایه نجم شاهنامه	درزآب	1050000000	sale	\N	https://divar.ir/v/_/ga--6rol	2026-10-01 19:18:22.186998+00	2026-10-01 19:20:47.400263+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۰۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در درزآب", "amounts": {"raw_amount": 1050000000}}	\N
2910	divar	ga-qKWzw	زمینهای5هزارمتری شاهنامه گوارشک دیاکو عدالت	چهاربرج	10000000000	sale	\N	https://divar.ir/v/_/ga-qKWzw	2026-10-01 19:16:56.064491+00	2026-10-01 19:20:47.405078+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "سرمایه گذاری ۰۹۰۵۷۶۲۱۵۸۳عدالت۰۹۳۷۴۱۴۱۶۵۵ در چهاربرج", "amounts": {"raw_amount": 10000000000}}	\N
2911	divar	ga-m1TyP	۵۰۰متری مسکونی باغی آب برق گازشاهنامه دیاکو عدالت	درزآب	1750000000	sale	\N	https://divar.ir/v/_/ga-m1TyP	2026-10-01 19:16:16.678582+00	2026-10-01 19:20:47.409185+00	\N	\N	\N	mashhad	500	\N	\N	\N	{"mid": "۱,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در درزآب", "amounts": {"raw_amount": 1750000000}}	\N
2912	divar	ga-CL0Ix	2هزارمتر زعفرون شاهنامه80املاک عدالت سرمایه گذاری	درزآب	660000000	sale	\N	https://divar.ir/v/_/ga-CL0Ix	2026-10-01 19:15:58.32827+00	2026-10-01 19:20:47.41305+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶۶۰,۰۰۰,۰۰۰ تومان", "bottom": "سرمایه گذاری ۰۹۰۵۷۶۲۱۵۸۳عدالت۰۹۳۷۴۱۴۱۶۵۵ در درزآب", "amounts": {"raw_amount": 660000000}}	\N
2913	divar	ga-GrKpb	آپارتمان ۱۰۸ هاشمیه ۷۱(نوزدبهمن)	نیروی هوایی	11500000000	sale	\N	https://divar.ir/v/_/ga-GrKpb	2026-10-01 19:15:50.600989+00	2026-10-01 19:20:47.416749+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نیروی هوایی", "amounts": {"raw_amount": 11500000000}}	\N
2914	divar	ga-yV0Xs	زمین1000مترمسکونی دیوارشده آب برق گازشاهنامه دیاکو	درزآب	3300000000	sale	\N	https://divar.ir/v/_/ga-yV0Xs	2026-10-01 19:15:47.235088+00	2026-10-01 19:20:47.42051+00	\N	\N	\N	mashhad	1000	\N	\N	\N	{"mid": "۳,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در درزآب", "amounts": {"raw_amount": 3300000000}}	\N
2916	divar	ga-maJAW	زمینهای10هزارمتری شاهنامه سرمایه گذاری دیاکو عدالت	چهاربرج	2000000000	sale	\N	https://divar.ir/v/_/ga-maJAW	2026-10-01 19:15:15.271698+00	2026-10-01 19:20:47.426832+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهاربرج", "amounts": {"raw_amount": 2000000000}}	\N
2917	divar	ga-CLmaN	آپارتمان۱۶۰متر صفر در اواسط هاشمیه با حیاط اختصاصی	چهارچشمه	30500000000	sale	\N	https://divar.ir/v/_/ga-CLmaN	2026-10-01 19:13:36.657859+00	2026-10-01 19:20:47.430329+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۳۰,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهارچشمه", "amounts": {"raw_amount": 30500000000}}	\N
2918	divar	ga--Kk_l	همکف دونبش لوکیشن.امکان درب جدا.تهاتر	کوثر	9000000000	sale	13	https://divar.ir/v/_/ga--Kk_l	2026-10-01 19:09:00.464994+00	2026-10-01 19:20:47.433475+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوثر", "amounts": {"raw_amount": 9000000000}}	\N
2919	divar	ga-2qWd6	زمین باغی	فاطمیه	1900000000	sale	30	https://divar.ir/v/_/ga-2qWd6	2026-10-01 19:02:26.761719+00	2026-10-01 19:20:47.437501+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در فاطمیه", "amounts": {"raw_amount": 1900000000}}	\N
2920	divar	gaRoWz9P	شریف و وکیل آباد	شریف	22000000000	sale	\N	https://divar.ir/v/_/gaRoWz9P	2026-10-01 19:01:23.534541+00	2026-10-01 19:20:47.441321+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۲,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شریف", "amounts": {"raw_amount": 22000000000}}	\N
2921	divar	ga8Sbf4_	اپارتمان145متر بامغازه30متری13میلیاردبولوارتوس	شهرک امام هادی (شهرک غرب)	13000000000	sale	38	https://divar.ir/v/_/ga8Sbf4_	2026-10-01 19:00:57.633462+00	2026-10-01 19:20:47.445673+00	\N	\N	\N	mashhad	145	\N	\N	\N	{"mid": "۱۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک امام هادی (شهرک غرب)", "amounts": {"raw_amount": 13000000000}}	\N
2922	divar	ga-uaMPZ	منزل ویلایی ۶۰ متررباط طرق	رباط طرق	3200000000	sale	\N	https://divar.ir/v/_/ga-uaMPZ	2026-10-01 19:00:26.352866+00	2026-10-01 19:20:47.449779+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۳,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در رباط طرق", "amounts": {"raw_amount": 3200000000}}	\N
2923	divar	ga0SB1jS	تک واحدی . الهیه . صفر . روف گاردن . محمدیه	جاهد شهر	26600000000	sale	41	https://divar.ir/v/_/ga0SB1jS	2026-10-01 19:00:12.381751+00	2026-10-01 19:20:47.453522+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۶,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 26600000000}}	\N
2924	divar	ga-26fta	۵۰ متر زمین تجاری فکوری	سرافرازان	7500000000	sale	22	https://divar.ir/v/_/ga-26fta	2026-10-01 19:00:09.147901+00	2026-10-01 19:20:47.456859+00	\N	\N	\N	mashhad	50	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در سرافرازان", "amounts": {"raw_amount": 7500000000}}	\N
2925	divar	ga-2qXQ-	۷۸ متر رو به خیابان کوچه ۲۰ متری صیاد پله ها نرم	هفت تیر (آب و برق)	7250000000	sale	\N	https://divar.ir/v/_/ga-2qXQ-	2026-10-01 18:59:21.907216+00	2026-10-01 19:20:47.460771+00	\N	\N	\N	mashhad	78	\N	\N	\N	{"mid": "۷,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در هفت تیر (آب و برق)", "amounts": {"raw_amount": 7250000000}}	\N
2926	divar	gaymtfHp	ویلای سه طبقه آپارتمان دربست	شهید بهشتی	27000000000	sale	18	https://divar.ir/v/_/gaymtfHp	2026-10-01 18:59:00.362437+00	2026-10-01 19:20:47.465119+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۷,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید بهشتی", "amounts": {"raw_amount": 27000000000}}	\N
2927	divar	Qa5fKhnL	منزل مسکونی  ۱۰۶ متر	کوشش	40000000000	sale	\N	https://divar.ir/v/_/Qa5fKhnL	2026-10-01 18:58:44.271573+00	2026-10-01 19:20:47.470065+00	\N	\N	\N	mashhad	106	\N	\N	\N	{"mid": "۴۰,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کوشش", "amounts": {"raw_amount": 40000000000}}	\N
2929	divar	ga-KrRUW	خانه دربست ۲ طبقه مجزا تمیز پارکینگ دارد	هفده شهریور	\N	rent	\N	https://divar.ir/v/_/ga-KrRUW	2026-10-01 19:19:49.200357+00	2026-10-01 19:20:47.477406+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در هفده شهریور", "amounts": {"اجاره": 100000}}	\N
2930	divar	ga-K7SEW	سوییت ۴۰ متری	کوی المهدی	\N	rent	\N	https://divar.ir/v/_/ga-K7SEW	2026-10-01 19:19:45.234012+00	2026-10-01 19:20:47.481429+00	\N	\N	\N	mashhad	40	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی المهدی", "amounts": {"اجاره": 1000000}}	\N
2931	divar	gaqGVoWC	همخانه	شاهد (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/gaqGVoWC	2026-10-01 19:18:25.800241+00	2026-10-01 19:20:47.485364+00	\N	\N	\N	mashhad	\N	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "در شاهد (شهرک غرب)", "amounts": {"اجاره": 30000000}}	\N
2932	divar	ga-Cr_uc	آپارتمان ۵۴ متری، بسیار دنج و نورگیر.	شهرک ابوذر	\N	rent	24	https://divar.ir/v/_/ga-Cr_uc	2026-10-01 19:14:15.821701+00	2026-10-01 19:20:47.489154+00	\N	\N	\N	mashhad	54	\N	\N	4500000	{"mid": "اجاره: ۴,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک ابوذر", "amounts": {"اجاره": 4500000}}	\N
2933	divar	ga-C73Cr	ویلایی دربست محلی امن و آرام ،سه خواب لوکس	مصلی (کارمندان اول)	\N	rent	\N	https://divar.ir/v/_/ga-C73Cr	2026-10-01 19:14:00.964034+00	2026-10-01 19:20:47.493688+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در مصلی (کارمندان اول)", "amounts": {"اجاره": 100000}}	\N
2935	divar	ga-yqOjG	اپارتمان ۱۲۵متر در مهرمادر	خواجه ربیع	\N	rent	\N	https://divar.ir/v/_/ga-yqOjG	2026-10-01 18:53:58.221944+00	2026-10-01 19:20:47.500109+00	\N	\N	\N	mashhad	125	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "یک ربع پیش در خواجه ربیع", "amounts": {"اجاره": 1000000}}	\N
2936	divar	ga-q6El9	همخونه تریدر یا مدرس انگلیسی میخوام	منزل آباد	\N	rent	\N	https://divar.ir/v/_/ga-q6El9	2026-10-01 18:46:09.438391+00	2026-10-01 19:20:47.504194+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "نیم ساعت پیش در منزل آباد", "amounts": {"اجاره": 5000000}}	\N
2937	divar	ga-eKd_n	همخونه	شهرک شیرین	\N	rent	\N	https://divar.ir/v/_/ga-eKd_n	2026-10-01 18:34:10.779061+00	2026-10-01 19:20:47.508779+00	\N	\N	\N	mashhad	\N	\N	\N	100000	{"mid": "اجاره: ۱۰۰,۰۰۰ تومان", "bottom": "نیم ساعت پیش در شهرک شیرین", "amounts": {"اجاره": 100000}}	\N
2938	divar	ga-eKXud	خانه 55متری	بهمن	\N	rent	43	https://divar.ir/v/_/ga-eKXud	2026-10-01 18:33:31.755071+00	2026-10-01 19:20:47.51299+00	\N	\N	\N	mashhad	55	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "نیم ساعت پیش در بهمن", "amounts": {"اجاره": 6000000}}	\N
2939	divar	ga-WKT_J	یک واحد راه جدابا پارکینگ اختصاصی	سرافرازان	\N	rent	22	https://divar.ir/v/_/ga-WKT_J	2026-10-01 18:31:06.419992+00	2026-10-01 19:20:47.51667+00	\N	\N	\N	mashhad	\N	\N	\N	500000	{"mid": "اجاره: ۵۰۰,۰۰۰ تومان", "bottom": "نیم ساعت پیش در سرافرازان", "amounts": {"اجاره": 500000}}	\N
2941	divar	ga-upHzP	همخونه	تلگرد	\N	rent	\N	https://divar.ir/v/_/ga-upHzP	2026-10-01 18:21:14.235719+00	2026-10-01 19:20:47.523344+00	\N	\N	\N	mashhad	\N	\N	\N	2500000	{"mid": "اجاره: ۲,۵۰۰,۰۰۰ تومان", "bottom": "در تلگرد", "amounts": {"اجاره": 2500000}}	\N
2942	divar	ga5q3-VL	خانه ویلایی شاهنامه ۴۹	چهاربرج	\N	rent	\N	https://divar.ir/v/_/ga5q3-VL	2026-10-01 18:11:08.958871+00	2026-10-01 19:20:47.526896+00	\N	\N	\N	mashhad	\N	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "در چهاربرج", "amounts": {"اجاره": 4000000}}	\N
2943	divar	ga-GK8ox	پیامبر۴۳/ طبقه۳/دوخاب/تخلیه فوری	شهرک امام هادی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-GK8ox	2026-10-01 18:11:04.702006+00	2026-10-01 19:20:47.531676+00	\N	\N	\N	mashhad	\N	\N	\N	8500000	{"mid": "اجاره: ۸,۵۰۰,۰۰۰ تومان", "bottom": "۱ ساعت پیش در شهرک امام هادی (شهرک غرب)", "amounts": {"اجاره": 8500000}}	\N
2944	divar	ga-CaATC	خانه ویلایی اجاره	طبرسی شمالی	\N	rent	42	https://divar.ir/v/_/ga-CaATC	2026-10-01 18:07:10.467495+00	2026-10-01 19:20:47.536147+00	\N	\N	\N	mashhad	\N	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "۱ ساعت پیش در طبرسی شمالی", "amounts": {"اجاره": 3000000}}	\N
2946	divar	ga-SrTsD	فروش آپارتمان ۸۵متری لوکس	علی آباد	2890000000	sale	\N	https://divar.ir/v/_/ga-SrTsD	2026-10-01 19:29:09.683728+00	2026-10-01 19:31:02.097125+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۲,۸۹۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در علی آباد", "amounts": {"raw_amount": 2890000000}}	\N
2947	divar	ga-Obp7d	فروش اپارتمان ۱۰۲متر توس ۸۷ قیمت..تماس	شهید بصیر	5500000000	sale	\N	https://divar.ir/v/_/ga-Obp7d	2026-10-01 19:26:08.866539+00	2026-10-01 19:31:02.104284+00	\N	\N	\N	mashhad	102	\N	\N	\N	{"mid": "۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید بصیر", "amounts": {"raw_amount": 5500000000}}	\N
2948	divar	ga9mWFHV	اپارتمان سنددار نزدیک حرم ، ۱۰۶ متر ۲ خواب ۲ مستر	آیت الله خامنه‌ای	21200000000	sale	\N	https://divar.ir/v/_/ga9mWFHV	2026-10-01 19:23:55.96941+00	2026-10-01 19:31:02.110311+00	\N	\N	\N	mashhad	106	2	\N	\N	{"mid": "۲۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "کارگزاری مسکن شمس در آیت الله خامنه‌ای", "amounts": {"raw_amount": 21200000000}}	\N
2949	divar	ga-KrXRt	آپارتمان صفر/آماده تحویل/با شرایط اقساط/اکبری	آیت الله خامنه‌ای	20750000000	sale	\N	https://divar.ir/v/_/ga-KrXRt	2026-10-01 19:22:50.173153+00	2026-10-01 19:31:02.117548+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲۰,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در آیت الله خامنه‌ای", "amounts": {"raw_amount": 20750000000}}	\N
2950	divar	ga-KLQ5W	خونه ویلایی ۶۰متری ماشین رو واقع درپنجتن۸۳	پنجتن	3400000000	sale	\N	https://divar.ir/v/_/ga-KLQ5W	2026-10-01 19:21:12.973277+00	2026-10-01 19:31:02.123311+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۳,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پنجتن", "amounts": {"raw_amount": 3400000000}}	\N
2951	divar	ga-2KnF3	جهاد فاز یک پلاک ۵۲۴۹	الهیه	300000000	sale	44	https://divar.ir/v/_/ga-2KnF3	2026-10-01 19:20:46.186147+00	2026-10-01 19:31:02.128407+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"raw_amount": 300000000}}	\N
2967	divar	ga-SLB1E	نسترن ۷تیر	نیروی هوایی	\N	rent	\N	https://divar.ir/v/_/ga-SLB1E	2026-10-01 19:27:55.457428+00	2026-10-01 19:31:02.177338+00	\N	\N	\N	mashhad	\N	\N	\N	40000000	{"mid": "اجاره: ۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نیروی هوایی", "amounts": {"اجاره": 40000000}}	\N
2982	divar	ga-ebelw	آپارتمان ۵۵ متری یوسفیه	یوسفیه (شهرک غرب)	3050000000	sale	38	https://divar.ir/v/_/ga-ebelw	2026-10-01 19:46:07.171146+00	2026-10-01 19:46:17.239822+00	\N	\N	\N	mashhad	55	\N	\N	\N	{"mid": "۳,۰۵۰,۰۰۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در یوسفیه (شهرک غرب)", "amounts": {"raw_amount": 3050000000}}	\N
2983	divar	gaSKvX__	آپارتمان ۱۹۰متر سند آماده علویه	الهیه	14900000000	sale	44	https://divar.ir/v/_/gaSKvX__	2026-10-01 19:45:42.383442+00	2026-10-01 19:46:17.252655+00	\N	\N	\N	mashhad	190	\N	\N	\N	{"mid": "۱۴,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 14900000000}}	\N
2984	divar	ga664JWw	هوم یار/آپارتمان ۱۱۵متری /اول رحمانیه	الهیه	12650000000	sale	44	https://divar.ir/v/_/ga664JWw	2026-10-01 19:45:29.193597+00	2026-10-01 19:46:17.257702+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۱۲,۶۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 12650000000}}	\N
2986	divar	ga-6651H	۳ دستگاه ویلایی ۲ طبقه نوساز تخلیه	سیس‌آباد	3500000000	sale	\N	https://divar.ir/v/_/ga-6651H	2026-10-01 19:44:51.674809+00	2026-10-01 19:46:17.266315+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سیس‌آباد", "amounts": {"raw_amount": 3500000000}}	\N
2987	divar	gaqmmAwM	واحد ۶۰ متری اقتصادی خیابان وحید طلاب	وحید	2100000000	sale	33	https://divar.ir/v/_/gaqmmAwM	2026-10-01 19:43:53.214471+00	2026-10-01 19:46:17.270068+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۲,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در وحید", "amounts": {"raw_amount": 2100000000}}	\N
2988	divar	ga-C73xx	پنت هوس ۱۶۰متری /شیک /طلاب /مسکن الماس	ایثار	12050000000	sale	\N	https://divar.ir/v/_/ga-C73xx	2026-10-01 19:43:47.821742+00	2026-10-01 19:46:17.273859+00	\N	\N	\N	mashhad	160	\N	\N	\N	{"mid": "۱۲,۰۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن الماس(پاشا)بین ایثار۱۷و۱۹ در ایثار", "amounts": {"raw_amount": 12050000000}}	\N
2989	divar	QakThIzs	۴۰۰متری۴۵۰متری۵۰۰متری۵۵۰متری۶۰۰متری ملکی	عبادی	300000000	sale	\N	https://divar.ir/v/_/QakThIzs	2026-10-01 19:43:43.573366+00	2026-10-01 19:46:17.277317+00	\N	\N	\N	mashhad	400	\N	\N	\N	{"mid": "۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه سرمایه گذاری ویلاسازان در عبادی", "amounts": {"raw_amount": 300000000}}	\N
2990	divar	ga4qryTm	فروش خانه ویلایی	کلاته برفی	7500000000	sale	\N	https://divar.ir/v/_/ga4qryTm	2026-10-01 19:43:32.481772+00	2026-10-01 19:46:17.280911+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کلاته برفی", "amounts": {"raw_amount": 7500000000}}	\N
2991	divar	gahCYSz4	آپارتمان ۱۰۳متر ی فروشی	شهرک لشکر (شهرک غرب)	11000000000	sale	38	https://divar.ir/v/_/gahCYSz4	2026-10-01 19:40:27.521748+00	2026-10-01 19:46:17.284641+00	\N	\N	\N	mashhad	103	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک لشکر (شهرک غرب)", "amounts": {"raw_amount": 11000000000}}	\N
2992	divar	gaQqic4a	ویلایی فکوری	هفت تیر (نه دره)	8250000000	sale	\N	https://divar.ir/v/_/gaQqic4a	2026-10-01 19:38:45.1272+00	2026-10-01 19:46:17.288168+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در هفت تیر (نه دره)", "amounts": {"raw_amount": 8250000000}}	\N
2994	divar	gayatZLC	واحد سفت کاری شده ۷۳ متر	حضرت حجت	1200000000	sale	\N	https://divar.ir/v/_/gayatZLC	2026-10-01 19:36:16.205596+00	2026-10-01 19:46:17.294521+00	\N	\N	\N	mashhad	73	\N	\N	\N	{"mid": "۱,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در حضرت حجت", "amounts": {"raw_amount": 1200000000}}	\N
2995	divar	gaGCwx-1	فروش باغ ویلا	درزآب	2250000000	sale	\N	https://divar.ir/v/_/gaGCwx-1	2026-10-01 19:36:10.050687+00	2026-10-01 19:46:17.298254+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۲۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 2250000000}}	\N
2996	divar	ga-WrsCT	هنرستان۱۳۵متری هفت تیرمعاوضه با منطقه10*11*12ویلای	هنرستان	33750000000	sale	11	https://divar.ir/v/_/ga-WrsCT	2026-10-01 19:34:48.742867+00	2026-10-01 19:46:17.301529+00	\N	\N	\N	mashhad	135	\N	\N	\N	{"mid": "۳۳,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هنرستان", "amounts": {"raw_amount": 33750000000}}	\N
2997	divar	ga7MOBEC	آپارتمان فروشی	نوده	2100000000	sale	\N	https://divar.ir/v/_/ga7MOBEC	2026-10-01 19:33:50.04233+00	2026-10-01 19:46:17.305357+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در نوده", "amounts": {"raw_amount": 2100000000}}	\N
2998	divar	ga-W7Fdp	تهاتر زمین با خودرو	میان ولایت	807000000	sale	\N	https://divar.ir/v/_/ga-W7Fdp	2026-10-01 19:33:28.037333+00	2026-10-01 19:46:17.30884+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۸۰۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 807000000}}	\N
3000	divar	gaXSiD8t	اجاره منزل ۱۰۰ متری طبقه همکف	جلالیه	\N	rent	\N	https://divar.ir/v/_/gaXSiD8t	2026-10-01 19:45:55.983956+00	2026-10-01 19:46:17.315045+00	\N	\N	\N	mashhad	100	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "در جلالیه", "amounts": {"اجاره": 10000000}}	\N
3001	divar	ga-eb2Ij	اجاره طبقه پایین منزل ویلایی	کوی راد	\N	rent	\N	https://divar.ir/v/_/ga-eb2Ij	2026-10-01 19:44:13.334016+00	2026-10-01 19:46:17.320591+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوی راد", "amounts": {"اجاره": 8000000}}	\N
3002	divar	ga-e7pf7	اجاره، دوخوابه، تک واحدی	ایثار	\N	rent	\N	https://divar.ir/v/_/ga-e7pf7	2026-10-01 19:43:29.673853+00	2026-10-01 19:46:17.324115+00	\N	\N	\N	mashhad	\N	\N	\N	25000000	{"mid": "اجاره: ۲۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثار", "amounts": {"اجاره": 25000000}}	\N
3003	divar	ga-WL9qB	خونه رهن اجاره	شهرآباد	\N	rent	\N	https://divar.ir/v/_/ga-WL9qB	2026-10-01 19:35:25.352957+00	2026-10-01 19:46:17.327741+00	\N	\N	\N	mashhad	\N	\N	\N	4500000	{"mid": "اجاره: ۴,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرآباد", "amounts": {"اجاره": 4500000}}	\N
3004	divar	ga9CzXYh	آگهی هم خانه	سعد آباد	\N	rent	\N	https://divar.ir/v/_/ga9CzXYh	2026-10-01 19:33:20.653388+00	2026-10-01 19:46:17.331624+00	\N	\N	\N	mashhad	\N	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "در سعد آباد", "amounts": {"اجاره": 6000000}}	\N
3005	divar	ga-WLHGl	آپارتمان رهن واجاره	نوده	\N	rent	\N	https://divar.ir/v/_/ga-WLHGl	2026-10-01 19:31:48.903678+00	2026-10-01 19:46:17.339442+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوده", "amounts": {"اجاره": 5000000}}	\N
3015	divar	ga5iXY0I	هم خونه خانوم	حجت	\N	rent	\N	https://divar.ir/v/_/ga5iXY0I	2026-10-01 18:48:57.741888+00	2026-10-01 19:46:17.365342+00	\N	\N	\N	mashhad	\N	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "در حجت", "amounts": {"اجاره": 7000000}}	\N
3019	divar	gaiW8PAb	آپارتمان ۱۱۰متری قابل معاوضه	مهدی آباد (بلوار توس)	5000000000	sale	\N	https://divar.ir/v/_/gaiW8PAb	2026-10-01 19:48:18.472963+00	2026-10-01 19:56:34.993374+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در مهدی آباد (بلوار توس)", "amounts": {"raw_amount": 5000000000}}	\N
3020	divar	ga-irfin	باغ ویلا رضویه	میان ولایت	3100000000	sale	\N	https://divar.ir/v/_/ga-irfin	2026-10-01 19:47:03.793678+00	2026-10-01 19:56:35.001256+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 3100000000}}	\N
3037	divar	ga-q7I3u	آپارتمان رهن و اجاره یوسفیه	یوسفیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-q7I3u	2026-10-01 19:53:13.781265+00	2026-10-01 19:56:35.048838+00	\N	\N	\N	mashhad	\N	\N	\N	12000000	{"mid": "اجاره: ۱۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در یوسفیه (شهرک غرب)", "amounts": {"اجاره": 12000000}}	\N
3038	divar	ga-mbw_O	آپارتمان سپاه ۵۹	شهرک بهارستان	\N	rent	\N	https://divar.ir/v/_/ga-mbw_O	2026-10-01 19:51:34.594217+00	2026-10-01 19:56:35.052633+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک بهارستان", "amounts": {"اجاره": 10000000}}	\N
3039	divar	ga-mrmy6	سوئیت ۴۰ متری بدون اتاق مناسب خانم مسن و تنها	هفت تیر (نه دره)	\N	rent	\N	https://divar.ir/v/_/ga-mrmy6	2026-10-01 19:51:07.780042+00	2026-10-01 19:56:35.056154+00	\N	\N	\N	mashhad	40	\N	\N	8500000	{"mid": "اجاره: ۸,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در هفت تیر (نه دره)", "amounts": {"اجاره": 8500000}}	\N
3040	divar	ga-iL0jW	همخونه هم خانه خانم فقط خانم	الهیه	\N	rent	44	https://divar.ir/v/_/ga-iL0jW	2026-10-01 19:47:34.511276+00	2026-10-01 19:56:35.060168+00	\N	\N	\N	mashhad	\N	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در الهیه", "amounts": {"اجاره": 1000000}}	\N
3041	divar	ga-i7sXU	نیازمند همخونه	چهارچشمه	\N	rent	\N	https://divar.ir/v/_/ga-i7sXU	2026-10-01 19:47:05.494901+00	2026-10-01 19:56:35.064555+00	\N	\N	\N	mashhad	\N	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در چهارچشمه", "amounts": {"اجاره": 7000000}}	\N
3056	divar	gaKq6ZJA	174 متر / سند آماده / تخلیه / مجیدیه 5	جاهد شهر	17500000000	sale	41	https://divar.ir/v/_/gaKq6ZJA	2026-09-20 06:14:37.389374+00	2026-10-01 20:06:57.099263+00	\N	\N	\N	mashhad	174	\N	\N	\N	{"mid": "۱۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 17500000000}}	\N
3058	divar	gau2iqWr	130 متر صفر توس 95 ،	امیرآباد	8000000000	sale	\N	https://divar.ir/v/_/gau2iqWr	2026-10-01 20:03:05.755094+00	2026-10-01 20:06:57.110925+00	\N	\N	\N	mashhad	130	\N	\N	\N	{"mid": "۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امیرآباد", "amounts": {"raw_amount": 8000000000}}	\N
3059	divar	ga_NnQhs	پیامبر اعظم 55) احمدی ، ثنایی، گلریز	توس (بلوار توس)	2750000000	sale	\N	https://divar.ir/v/_/ga_NnQhs	2026-10-01 20:02:33.827345+00	2026-10-01 20:06:57.115919+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۷۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس (بلوار توس)", "amounts": {"raw_amount": 2750000000}}	\N
3060	divar	ga-uL0zn	اپارتمان فروشی رهن اجاره	انصار	7500000000	sale	\N	https://divar.ir/v/_/ga-uL0zn	2026-10-01 20:01:25.682993+00	2026-10-01 20:06:57.11992+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در انصار", "amounts": {"raw_amount": 7500000000}}	\N
3061	divar	gajOCDAk	120 متر زمین مسکونی و تجاری	توس فردوسی	1350000000	sale	\N	https://divar.ir/v/_/gajOCDAk	2026-10-01 20:00:59.820844+00	2026-10-01 20:06:57.123761+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۱,۳۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در توس فردوسی", "amounts": {"raw_amount": 1350000000}}	\N
3062	divar	ga-ubLd1	زمین توس ۱۶۹	کاظم آباد	9000000000	sale	\N	https://divar.ir/v/_/ga-ubLd1	2026-10-01 20:00:13.367507+00	2026-10-01 20:06:57.12753+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کاظم آباد", "amounts": {"raw_amount": 9000000000}}	\N
3063	divar	gaISGIs0	زمین با مجوز ساخت کشف 230 متر	کشف	2900000000	sale	\N	https://divar.ir/v/_/gaISGIs0	2026-10-01 19:58:35.007629+00	2026-10-01 20:06:57.131252+00	\N	\N	\N	mashhad	230	\N	\N	\N	{"mid": "۲,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کشف", "amounts": {"raw_amount": 2900000000}}	\N
3078	divar	ga9WFSeT	آپارتمان ۱۷۰ متری سه خواب نوساز جانباز	جانباز	\N	rent	\N	https://divar.ir/v/_/ga9WFSeT	2026-09-30 18:30:47.583307+00	2026-10-01 20:06:57.173066+00	\N	\N	\N	mashhad	170	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "در جانباز", "amounts": {"اجاره": 20000000}}	\N
3079	divar	gag6kkdK	اجاره ویلایی دربست احمداباد	بهشت	\N	rent	18	https://divar.ir/v/_/gag6kkdK	2026-10-01 20:06:34.20601+00	2026-10-01 20:06:57.178024+00	\N	\N	\N	mashhad	\N	\N	\N	150000000	{"mid": "اجاره: ۱۵۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهشت", "amounts": {"اجاره": 150000000}}	\N
3080	divar	ga3GNhVv	اجاره آپارتمان ۱۴۰متری ۳خواب بسیارتمیز طبرسی شمالی	نظام دوست	\N	rent	\N	https://divar.ir/v/_/ga3GNhVv	2026-10-01 20:03:13.366652+00	2026-10-01 20:06:57.181556+00	\N	\N	\N	mashhad	140	3	\N	14000000	{"mid": "اجاره: ۱۴,۰۰۰,۰۰۰ تومان", "bottom": "در نظام دوست", "amounts": {"اجاره": 14000000}}	\N
3081	divar	ga-yLMd3	اجاره آپارتمان شخصی	خرمشهر	\N	rent	\N	https://divar.ir/v/_/ga-yLMd3	2026-10-01 20:03:03.218004+00	2026-10-01 20:06:57.185263+00	\N	\N	\N	mashhad	\N	\N	\N	7000000	{"mid": "اجاره: ۷,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در خرمشهر", "amounts": {"اجاره": 7000000}}	\N
3082	divar	ga-qr6eg	آپارتمان رهن واجاره	توس (بلوار توس)	\N	rent	\N	https://divar.ir/v/_/ga-qr6eg	2026-10-01 19:56:33.686332+00	2026-10-01 20:06:57.188891+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس (بلوار توس)", "amounts": {"اجاره": 8000000}}	\N
3099	divar	gajZxr44	115 متری سه خوابه	الهیه	15500000000	sale	44	https://divar.ir/v/_/gajZxr44	2026-09-21 08:26:58.595992+00	2026-10-01 20:17:14.277911+00	\N	\N	\N	mashhad	115	\N	\N	\N	{"mid": "۱۵,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در الهیه", "amounts": {"raw_amount": 15500000000}}	\N
3100	divar	ga--LOTb	اپارتمان ۹۵ متری واقع در امام هادی	شهرک امام هادی (شهرک غرب)	5600000000	sale	38	https://divar.ir/v/_/ga--LOTb	2026-10-01 20:15:27.976086+00	2026-10-01 20:17:14.292985+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۵,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک امام هادی (شهرک غرب)", "amounts": {"raw_amount": 5600000000}}	\N
3101	divar	gavSqUsc	ویلایی 2طبقه 300متر زیر بنا خیابان نواب (حرم مطهر)	حرم مطهر رضوی	19000000000	sale	\N	https://divar.ir/v/_/gavSqUsc	2026-10-01 20:13:57.384777+00	2026-10-01 20:17:14.304857+00	\N	\N	\N	mashhad	300	\N	\N	\N	{"mid": "۱۹,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در حرم مطهر رضوی", "amounts": {"raw_amount": 19000000000}}	\N
3102	divar	ga-2b6mQ	فروش خونه ۱۱۰متری. دوخاب	هنرور	8300000000	sale	\N	https://divar.ir/v/_/ga-2b6mQ	2026-10-01 20:12:22.55723+00	2026-10-01 20:17:14.315289+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۸,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "نداماتی در هنرور", "amounts": {"raw_amount": 8300000000}}	\N
3103	divar	ga-2b7dX	آپارتمان ۸۵ متری پارکینگ توس 31 شهرک نوید توس 33	نوید	4500000000	sale	\N	https://divar.ir/v/_/ga-2b7dX	2026-10-01 20:11:42.768274+00	2026-10-01 20:17:14.327768+00	\N	\N	\N	mashhad	85	\N	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوید", "amounts": {"raw_amount": 4500000000}}	\N
3104	divar	gaV2Wajs	95متر صفر 2واحدی برندلوکس منطقه متریال وارداتی	الهیه	11300000000	sale	44	https://divar.ir/v/_/gaV2Wajs	2026-10-01 20:11:26.497936+00	2026-10-01 20:17:14.337562+00	\N	\N	\N	mashhad	95	\N	\N	\N	{"mid": "۱۱,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 11300000000}}	\N
3105	divar	ganVBM50	245متر سازه دوبلکس برند لوکس مجیدیه صفر 4خواب	الهیه	24950000000	sale	44	https://divar.ir/v/_/ganVBM50	2026-10-01 20:11:08.149257+00	2026-10-01 20:17:14.347632+00	\N	\N	\N	mashhad	245	4	\N	\N	{"mid": "۲۴,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رویال نبش رحمانیه ۵ در الهیه", "amounts": {"raw_amount": 24950000000}}	\N
3106	divar	gaJ6tSyB	اپارتمان ۱۷۰ متری احمداباد قائم ۱۲	بهشت	18000000000	sale	18	https://divar.ir/v/_/gaJ6tSyB	2026-10-01 20:07:16.49634+00	2026-10-01 20:17:14.35666+00	\N	\N	\N	mashhad	170	\N	\N	\N	{"mid": "۱۸,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهشت", "amounts": {"raw_amount": 18000000000}}	\N
3107	divar	ga-u7HxU	زمین بایر	تبادکان	625000000	sale	\N	https://divar.ir/v/_/ga-u7HxU	2026-10-01 20:07:04.343687+00	2026-10-01 20:17:14.367739+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶۲۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در تبادکان", "amounts": {"raw_amount": 625000000}}	\N
3116	divar	gaoGGcbx	خانه ۱۰۰متری رهن کامل	شهید قربانی	\N	rent	\N	https://divar.ir/v/_/gaoGGcbx	2026-10-01 20:15:56.937621+00	2026-10-01 20:17:14.436434+00	\N	\N	\N	mashhad	100	\N	\N	1000	{"mid": "اجاره: ۱,۰۰۰ تومان", "bottom": "در شهید قربانی", "amounts": {"اجاره": 1000}}	\N
3117	divar	ga-y6v6x	اجاره اقبال ۱۴ ، نورگیر و تمیز	اقبال	\N	rent	1	https://divar.ir/v/_/ga-y6v6x	2026-10-01 20:12:21.664932+00	2026-10-01 20:17:14.447167+00	\N	\N	\N	mashhad	\N	\N	\N	20000000	{"mid": "اجاره: ۲۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن رضا هنرستان در اقبال", "amounts": {"اجاره": 20000000}}	\N
3118	divar	ga-27wxp	پنج‌تن ۴۷ همکف راه جدا با پارکینگ برای پراید	پنجتن	\N	rent	\N	https://divar.ir/v/_/ga-27wxp	2026-10-01 20:09:28.821624+00	2026-10-01 20:17:14.458623+00	\N	\N	\N	mashhad	\N	\N	\N	6000000	{"mid": "اجاره: ۶,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پنجتن", "amounts": {"اجاره": 6000000}}	\N
3119	divar	ga-2bw_r	مهرمادر	خواجه ربیع	\N	rent	\N	https://divar.ir/v/_/ga-2bw_r	2026-10-01 20:08:40.023698+00	2026-10-01 20:17:14.469893+00	\N	\N	\N	mashhad	\N	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در خواجه ربیع", "amounts": {"اجاره": 3000000}}	\N
3137	divar	ga5ehe3Z	آپارتمان  سند شش دانگ	چهارچشمه	9200000000	sale	\N	https://divar.ir/v/_/ga5ehe3Z	2026-09-27 13:24:17.79511+00	2026-10-01 20:27:36.977169+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۹,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در چهارچشمه", "amounts": {"raw_amount": 9200000000}}	\N
3138	divar	ga1qnCyT	آپارتمان ۸۹ مترفول شاهد۳۸( محدوده چهارراه ورزش)	فرهنگیان (شهرک غرب)	11000000000	sale	37	https://divar.ir/v/_/ga1qnCyT	2026-10-01 20:17:54.91462+00	2026-10-01 20:27:37.004262+00	\N	\N	\N	mashhad	89	\N	\N	\N	{"mid": "۱۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 11000000000}}	\N
3147	divar	ga-CcDy6	اپارتمان ۸۰ متری صفر کلید نخورده و نوساز	حضرت حجت	\N	rent	\N	https://divar.ir/v/_/ga-CcDy6	2026-10-01 20:19:08.177959+00	2026-10-01 20:27:37.072497+00	\N	\N	\N	mashhad	80	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حضرت حجت", "amounts": {"اجاره": 4000000}}	\N
3166	divar	gaxqzFXK	زمین شهر جدید بینالود	بهشت	1300000000	sale	18	https://divar.ir/v/_/gaxqzFXK	2026-09-21 14:08:36.24524+00	2026-10-01 20:37:52.202171+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در بهشت", "amounts": {"raw_amount": 1300000000}}	\N
3167	divar	ga-OczC5	۸۴متر دوخواب اندیشه ۷۴پر نورپارکینگ بی مزاحمت شکار	آزادشهر	5900000000	sale	\N	https://divar.ir/v/_/ga-OczC5	2026-10-01 20:36:08.800514+00	2026-10-01 20:37:52.222428+00	\N	\N	\N	mashhad	84	\N	\N	\N	{"mid": "۵,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در آزادشهر", "amounts": {"raw_amount": 5900000000}}	\N
3168	divar	gakk3XbS	منزل ویلایی لوکس رسالت کشمیری ۴	شهید احمدی روشن	4000000000	sale	\N	https://divar.ir/v/_/gakk3XbS	2026-10-01 20:33:49.700039+00	2026-10-01 20:37:52.232461+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۴,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهید احمدی روشن", "amounts": {"raw_amount": 4000000000}}	\N
3169	divar	ga-OME8j	۲خواب با پارکینگ معاوضه با طلا ودلار وماشین	کشف	3500000000	sale	\N	https://divar.ir/v/_/ga-OME8j	2026-10-01 20:32:11.28656+00	2026-10-01 20:37:52.241431+00	\N	\N	\N	mashhad	\N	2	\N	\N	{"mid": "۳,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کشف", "amounts": {"raw_amount": 3500000000}}	\N
3170	divar	ga-OMBba	اپارتمان دوخواب شیک ومرتب 75متری نظام دوست	نظام دوست	2850000000	sale	\N	https://divar.ir/v/_/ga-OMBba	2026-10-01 20:32:02.925192+00	2026-10-01 20:37:52.249933+00	\N	\N	\N	mashhad	75	\N	\N	\N	{"mid": "۲,۸۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نظام دوست", "amounts": {"raw_amount": 2850000000}}	\N
3171	divar	ga-Csijs	فروش اپارتمان 90متری طبقه همکف	کشف	3600000000	sale	\N	https://divar.ir/v/_/ga-Csijs	2026-10-01 20:30:46.433589+00	2026-10-01 20:37:52.258336+00	\N	\N	\N	mashhad	90	\N	\N	\N	{"mid": "۳,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کشف", "amounts": {"raw_amount": 3600000000}}	\N
3172	divar	ga-eH2xK	آپارتمان سجاد / نیلوفر ۳۰۲ متر برای خاص پسندان	سجاد شهر	96600000000	sale	21	https://divar.ir/v/_/ga-eH2xK	2026-10-01 20:29:41.225642+00	2026-10-01 20:37:52.266404+00	\N	\N	\N	mashhad	302	\N	\N	\N	{"mid": "۹۶,۶۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سجاد شهر", "amounts": {"raw_amount": 96600000000}}	\N
3173	divar	ga-S1Xqu	آپارتمان ۹۸ متری دو خواب مجتمع صادقیه خیام شمالی	صداقیه	7950000000	sale	\N	https://divar.ir/v/_/ga-S1Xqu	2026-10-01 20:28:09.313588+00	2026-10-01 20:37:52.275686+00	\N	\N	\N	mashhad	98	\N	\N	\N	{"mid": "۷,۹۵۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در صداقیه", "amounts": {"raw_amount": 7950000000}}	\N
3176	divar	ga-Oc6fK	آپارتمان ۱۲۰متری با پارکینگ	منزل آباد	\N	rent	\N	https://divar.ir/v/_/ga-Oc6fK	2026-10-01 20:35:02.98487+00	2026-10-01 20:37:52.296201+00	\N	\N	\N	mashhad	120	\N	\N	3000000	{"mid": "اجاره: ۳,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در منزل آباد", "amounts": {"اجاره": 3000000}}	\N
3177	divar	ga-OsFPb	همخونه میشم آقا هستم	استاد یوسفی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-OsFPb	2026-10-01 20:32:47.416722+00	2026-10-01 20:37:52.304868+00	\N	\N	\N	mashhad	\N	\N	\N	5000000	{"mid": "اجاره: ۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در استاد یوسفی (شهرک غرب)", "amounts": {"اجاره": 5000000}}	\N
3178	divar	ga-KcZxg	رهن و اجاره آپارتمان دوخوابه	دوست آباد	\N	rent	\N	https://divar.ir/v/_/ga-KcZxg	2026-10-01 20:28:31.02078+00	2026-10-01 20:37:52.315907+00	\N	\N	\N	mashhad	\N	\N	\N	4000000	{"mid": "اجاره: ۴,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در دوست آباد", "amounts": {"اجاره": 4000000}}	\N
3196	divar	ga9-Nwks	فروش زمین۵۰۰ متری ویلایی شاهنامه/فرصت سرمایه گزاری	دهشک	1860000000	sale	\N	https://divar.ir/v/_/ga9-Nwks	2026-10-01 07:02:01.5506+00	2026-10-01 20:48:16.724461+00	\N	\N	\N	mashhad	500	\N	\N	\N	{"mid": "۱,۸۶۰,۰۰۰,۰۰۰ تومان", "bottom": "در دهشک", "amounts": {"raw_amount": 1860000000}}	\N
3198	divar	gas6F0qy	اپارتمان راهنمایی،۱۶۶ متر،۳خواب ۱ مستر	راهنمایی	35000000000	sale	\N	https://divar.ir/v/_/gas6F0qy	2026-10-01 20:44:13.110216+00	2026-10-01 20:48:16.732057+00	\N	\N	\N	mashhad	166	3	\N	\N	{"mid": "۳۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در راهنمایی", "amounts": {"raw_amount": 35000000000}}	\N
3199	divar	ga-GMaFp	شاهنامه ۶۹ زمین ۱۰۰ متر ملکی با وکالت محضری	توس فردوسی	640000000	sale	\N	https://divar.ir/v/_/ga-GMaFp	2026-10-01 20:44:00.43041+00	2026-10-01 20:48:16.734751+00	\N	\N	\N	mashhad	100	\N	\N	\N	{"mid": "۶۴۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در توس فردوسی", "amounts": {"raw_amount": 640000000}}	\N
3200	divar	ga-WcBMH	خونه ۲خواب ۷۰۰ توس۳۳کشف فوری	کشف	4500000000	sale	\N	https://divar.ir/v/_/ga-WcBMH	2026-10-01 20:41:53.048171+00	2026-10-01 20:48:16.737538+00	\N	\N	\N	mashhad	\N	2	\N	\N	{"mid": "۴,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کشف", "amounts": {"raw_amount": 4500000000}}	\N
3201	divar	ga-Wcbj3	واحد نقلی	ایثارگران	1500000000	sale	\N	https://divar.ir/v/_/ga-Wcbj3	2026-10-01 20:41:49.5228+00	2026-10-01 20:48:16.740278+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثارگران", "amounts": {"raw_amount": 1500000000}}	\N
3209	divar	ga-aMM90	منزل رهن واجاره	سیس‌آباد	\N	rent	\N	https://divar.ir/v/_/ga-aMM90	2026-10-01 20:44:38.881172+00	2026-10-01 20:48:16.753793+00	\N	\N	\N	mashhad	\N	\N	\N	10000000	{"mid": "اجاره: ۱۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در سیس‌آباد", "amounts": {"اجاره": 10000000}}	\N
3210	divar	ga-WcRAd	اجاره ویلایی در بست	ایثار	\N	rent	\N	https://divar.ir/v/_/ga-WcRAd	2026-10-01 20:41:59.219807+00	2026-10-01 20:48:16.75608+00	\N	\N	\N	mashhad	\N	\N	\N	60000000	{"mid": "اجاره: ۶۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در ایثار", "amounts": {"اجاره": 60000000}}	\N
3228	divar	ga8aalaa	زمین مجیدیه بازار خودرو شش دانگ با مجوز ساخت	جاهد شهر	31000000000	sale	41	https://divar.ir/v/_/ga8aalaa	2026-09-30 06:07:43.351402+00	2026-10-01 20:58:38.352601+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳۱,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در جاهد شهر", "amounts": {"raw_amount": 31000000000}}	\N
3230	divar	ga-iMc89	خونه شکار فروش الان معاوضه وتهاتر دارم	کشف	1700000000	sale	\N	https://divar.ir/v/_/ga-iMc89	2026-10-01 20:55:44.470231+00	2026-10-01 20:58:38.35965+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۷۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کشف", "amounts": {"raw_amount": 1700000000}}	\N
3231	divar	ga-icwo4	آپارتمان 95متری 2خواب وام دار	الهیه	10200000000	sale	44	https://divar.ir/v/_/ga-icwo4	2026-10-01 20:55:39.84673+00	2026-10-01 20:58:38.362398+00	\N	\N	\N	mashhad	95	2	\N	\N	{"mid": "۱۰,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "مسکن باران رتبه یک مشهد در الهیه", "amounts": {"raw_amount": 10200000000}}	\N
3232	divar	ga-e8dRx	باغ ویلا	میان ولایت	1100000000	sale	\N	https://divar.ir/v/_/ga-e8dRx	2026-10-01 20:55:00.152457+00	2026-10-01 20:58:38.364741+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در میان ولایت", "amounts": {"raw_amount": 1100000000}}	\N
3233	divar	ga-esXIh	۷۳متری	پایگاه شکاری	6500000000	sale	\N	https://divar.ir/v/_/ga-esXIh	2026-10-01 20:50:25.462701+00	2026-10-01 20:58:38.367657+00	\N	\N	\N	mashhad	73	\N	\N	\N	{"mid": "۶,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در پایگاه شکاری", "amounts": {"raw_amount": 6500000000}}	\N
3234	divar	ga-aM44_	طبقه۳سرجلو رو به خیابان/پرازنور/تخلیه/خوش نقشه	یوسفیه (شهرک غرب)	2400000000	sale	38	https://divar.ir/v/_/ga-aM44_	2026-10-01 20:48:42.230381+00	2026-10-01 20:58:38.369738+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۴۰۰,۰۰۰,۰۰۰ تومان", "bottom": "سید امیرحسین عزیزی در یوسفیه (شهرک غرب)", "amounts": {"raw_amount": 2400000000}}	\N
3244	divar	ga-is9xE	۵۵متری طبقه چهارم سرجلو/تخلیه/آسانسور/یوسفیه۸	یوسفیه (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-is9xE	2026-10-01 20:57:33.163392+00	2026-10-01 20:58:38.391628+00	\N	\N	\N	mashhad	55	\N	\N	3300000	{"mid": "اجاره: ۳,۳۰۰,۰۰۰ تومان", "bottom": "سید امیرحسین عزیزی در یوسفیه (شهرک غرب)", "amounts": {"اجاره": 3300000}}	\N
3245	divar	ga-eMcYn	رهن کامل بهترین موقعیت چاهشک	چاهشک	\N	rent	\N	https://divar.ir/v/_/ga-eMcYn	2026-10-01 20:51:12.724982+00	2026-10-01 20:58:38.394606+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در چاهشک", "amounts": {}}	\N
3246	divar	ga-eshvh	خانه اجاره ای	گاز	\N	rent	\N	https://divar.ir/v/_/ga-eshvh	2026-10-01 20:50:23.126103+00	2026-10-01 20:58:38.397159+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در گاز", "amounts": {"اجاره": 8000000}}	\N
3264	divar	ga-msovS	۹۷ متر رحمانیه با مشخصات خاص	جاهد شهر	13000000000	sale	41	https://divar.ir/v/_/ga-msovS	2026-10-01 21:01:26.273403+00	2026-10-01 21:08:50.779343+00	\N	\N	\N	mashhad	97	\N	\N	\N	{"mid": "۱۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در جاهد شهر", "amounts": {"raw_amount": 13000000000}}	\N
3278	divar	ga-uMKsQ	اجاره اپارتمان 120متری	نوغان	\N	rent	\N	https://divar.ir/v/_/ga-uMKsQ	2026-10-01 21:05:51.83501+00	2026-10-01 21:08:50.808882+00	\N	\N	\N	mashhad	120	\N	\N	15000000	{"mid": "اجاره: ۱۵,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نوغان", "amounts": {"اجاره": 15000000}}	\N
3279	divar	ga-ucAgU	آپارتمان۳۱۷متر/ سجاد-گلشن/ کلاسیک	سجاد شهر	\N	rent	21	https://divar.ir/v/_/ga-ucAgU	2026-10-01 21:05:30.377308+00	2026-10-01 21:08:50.812467+00	\N	\N	\N	mashhad	317	\N	\N	90000000	{"mid": "اجاره: ۹۰,۰۰۰,۰۰۰ تومان", "bottom": "گندمی در سجاد شهر", "amounts": {"اجاره": 90000000}}	\N
3280	divar	gahq7WFx	نیازمندخونه	گلبرگ	\N	rent	\N	https://divar.ir/v/_/gahq7WFx	2026-10-01 21:03:33.608914+00	2026-10-01 21:08:50.815537+00	\N	\N	\N	mashhad	\N	\N	\N	700000	{"mid": "اجاره: ۷۰۰,۰۰۰ تومان", "bottom": "در گلبرگ", "amounts": {"اجاره": 700000}}	\N
3281	divar	ga-mcRZ6	آپارتمان ۸۵ متری رفیعی۳	حسابی جنوبی (شهرک غرب)	\N	rent	38	https://divar.ir/v/_/ga-mcRZ6	2026-10-01 20:59:17.197243+00	2026-10-01 21:08:50.818147+00	\N	\N	\N	mashhad	85	\N	\N	1000000	{"mid": "اجاره: ۱,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در حسابی جنوبی (شهرک غرب)", "amounts": {"اجاره": 1000000}}	\N
3298	divar	gad2SYj4	هوایی ابوطالب طبقه پنجم با پارکینگ و آسانسور	گلبرگ شمالی	3000000000	sale	\N	https://divar.ir/v/_/gad2SYj4	2026-10-01 21:18:54.21779+00	2026-10-01 21:19:07.602216+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۳,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در گلبرگ شمالی", "amounts": {"raw_amount": 3000000000}}	\N
3299	divar	ga-28X5L	آپارتمان  طبقه اول  ۵۵ متری	شهرک بهارستان	3100000000	sale	\N	https://divar.ir/v/_/ga-28X5L	2026-10-01 21:17:37.222367+00	2026-10-01 21:19:07.605954+00	\N	\N	\N	mashhad	55	\N	\N	\N	{"mid": "۳,۱۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک بهارستان", "amounts": {"raw_amount": 3100000000}}	\N
3300	divar	ga-q88ul	تهاتر با ویلای استخرداخل الباقی رو نقدی لازم دارم	نرگس (شهرک غرب)	15000000000	sale	38	https://divar.ir/v/_/ga-q88ul	2026-10-01 21:11:04.302466+00	2026-10-01 21:19:07.609577+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱۵,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در نرگس (شهرک غرب)", "amounts": {"raw_amount": 15000000000}}	\N
3301	divar	ga49BC43	آپارتمان 110 متری دوخواب / لوکس	حرم مطهر رضوی	27500000000	sale	\N	https://divar.ir/v/_/ga49BC43	2026-10-01 21:10:31.676879+00	2026-10-01 21:19:07.612951+00	\N	\N	\N	mashhad	110	\N	\N	\N	{"mid": "۲۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "گروه کارشناسان مسکن اکبری در حرم مطهر رضوی", "amounts": {"raw_amount": 27500000000}}	\N
3333	divar	ga-68Yrr	خانه60متری	طرق	2900000000	sale	\N	https://divar.ir/v/_/ga-68Yrr	2026-10-01 21:24:29.350731+00	2026-10-01 21:29:22.693894+00	\N	\N	\N	mashhad	60	\N	\N	\N	{"mid": "۲,۹۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در طرق", "amounts": {"raw_amount": 2900000000}}	\N
3346	divar	ga-6Mw5L	رهن کامل ۱۰۵ متری خوش نقشه نزدیک حرم	امام رضا (ع)	\N	rent	\N	https://divar.ir/v/_/ga-6Mw5L	2026-10-01 21:21:40.607333+00	2026-10-01 21:29:22.750489+00	\N	\N	\N	mashhad	105	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در امام رضا (ع)", "amounts": {}}	\N
3347	divar	ga-2s3Q7	همخونه	عنصری	\N	rent	\N	https://divar.ir/v/_/ga-2s3Q7	2026-10-01 21:21:25.648411+00	2026-10-01 21:29:22.756635+00	\N	\N	\N	mashhad	\N	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در عنصری", "amounts": {"اجاره": 2000000}}	\N
3348	divar	ga-6cRMU	خونه دربست	رده	\N	rent	\N	https://divar.ir/v/_/ga-6cRMU	2026-10-01 21:19:08.074198+00	2026-10-01 21:29:22.761519+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در رده", "amounts": {"اجاره": 8000000}}	\N
3365	divar	ga0uT53W	فروش باغ توس شاهنامه ۸۰ گوارشک مجتمع نشات	درزآب	2500000000	sale	\N	https://divar.ir/v/_/ga0uT53W	2026-09-29 14:27:17.175311+00	2026-10-01 21:39:37.951933+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در درزآب", "amounts": {"raw_amount": 2500000000}}	\N
3380	divar	ga-GtvpW	خانه اجاره ای	شهرک مهر آباد	\N	rent	\N	https://divar.ir/v/_/ga-GtvpW	2026-10-01 21:33:57.799005+00	2026-10-01 21:39:38.005259+00	\N	\N	\N	mashhad	\N	\N	\N	8000000	{"mid": "اجاره: ۸,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهرک مهر آباد", "amounts": {"اجاره": 8000000}}	\N
3381	divar	ga-CduTH	ویلایی 125 متری جهت انبار	کوشش	\N	rent	\N	https://divar.ir/v/_/ga-CduTH	2026-10-01 21:30:16.95979+00	2026-10-01 21:39:38.010507+00	\N	\N	\N	mashhad	125	\N	\N	30000000	{"mid": "اجاره: ۳۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در کوشش", "amounts": {"اجاره": 30000000}}	\N
3401	divar	gaV2Ibs2	آپارتمان ۱۲۰ متر . صفر کلید نخورده	شهرک امام هادی (شهرک غرب)	7500000000	sale	38	https://divar.ir/v/_/gaV2Ibs2	2026-10-01 21:49:36.725355+00	2026-10-01 21:49:53.026754+00	\N	\N	\N	mashhad	120	\N	\N	\N	{"mid": "۷,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در شهرک امام هادی (شهرک غرب)", "amounts": {"raw_amount": 7500000000}}	\N
3414	divar	ga-St27F	خانه 125متری کشمیری	شهید علی محمدی	\N	rent	\N	https://divar.ir/v/_/ga-St27F	2026-10-01 21:47:26.446949+00	2026-10-01 21:49:53.071955+00	\N	\N	\N	mashhad	125	\N	\N	\N	{"mid": "رهن کامل", "bottom": "دقایقی پیش در شهید علی محمدی", "amounts": {}}	\N
3436	divar	ga-a9Q9G	یک خانه ویلایی	شهید بصیر	1300000000	sale	\N	https://divar.ir/v/_/ga-a9Q9G	2026-10-01 21:58:42.502093+00	2026-10-01 22:00:13.887698+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۱,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید بصیر", "amounts": {"raw_amount": 1300000000}}	\N
3437	divar	gatGlEYY	فروش خانه ۲۵۰ متری،خیابان امام رضا۴۱چهار راه سوم	امام رضا (ع)	72500000000	sale	\N	https://divar.ir/v/_/gatGlEYY	2026-10-01 21:53:07.138651+00	2026-10-01 22:00:13.896785+00	\N	\N	\N	mashhad	250	\N	\N	\N	{"mid": "۷۲,۵۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در امام رضا (ع)", "amounts": {"raw_amount": 72500000000}}	\N
3469	divar	gavaHO8G	فروش فوری خانه مسکونی	کلاکوب	2300000000	sale	\N	https://divar.ir/v/_/gavaHO8G	2026-09-20 06:00:13.115915+00	2026-10-01 22:10:36.868003+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۲,۳۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کلاکوب", "amounts": {"raw_amount": 2300000000}}	\N
3480	divar	ga8WNcHu	اجاره آپارتمان (راه جدا)	فاطمیه	\N	rent	30	https://divar.ir/v/_/ga8WNcHu	2026-10-01 22:01:16.555903+00	2026-10-01 22:10:36.947699+00	\N	\N	\N	mashhad	\N	\N	\N	7500000	{"mid": "اجاره: ۷,۵۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در فاطمیه", "amounts": {"اجاره": 7500000}}	\N
3500	divar	gaky2XJy	۲۲۰متر  حسابی ۲۶  فلاحی ۲۷ عرب ۴	فرهنگیان (شهرک غرب)	22200000000	sale	37	https://divar.ir/v/_/gaky2XJy	2026-10-01 22:15:38.506252+00	2026-10-01 22:20:50.162936+00	\N	\N	\N	mashhad	220	\N	\N	\N	{"mid": "۲۲,۲۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در فرهنگیان (شهرک غرب)", "amounts": {"raw_amount": 22200000000}}	\N
3501	divar	ga4SfUHr	آپارتمان مصلی۳۰ /۵شیرازی	کارمندان دوم	6000000000	sale	\N	https://divar.ir/v/_/ga4SfUHr	2026-10-01 22:13:30.541706+00	2026-10-01 22:20:50.183055+00	\N	\N	\N	mashhad	\N	\N	\N	\N	{"mid": "۶,۰۰۰,۰۰۰,۰۰۰ تومان", "bottom": "در کارمندان دوم", "amounts": {"raw_amount": 6000000000}}	\N
3511	divar	ga-yNPHb	خونه دوطبقه رهن کامل	شهید قربانی	\N	rent	\N	https://divar.ir/v/_/ga-yNPHb	2026-10-01 22:20:23.016004+00	2026-10-01 22:20:50.253683+00	\N	\N	\N	mashhad	\N	\N	\N	10000	{"mid": "اجاره: ۱۰,۰۰۰ تومان", "bottom": "لحظاتی پیش در شهید قربانی", "amounts": {"اجاره": 10000}}	\N
3512	divar	ga-uNEJr	همخوهه	شهید قربانی	\N	rent	\N	https://divar.ir/v/_/ga-uNEJr	2026-10-01 22:13:41.630507+00	2026-10-01 22:20:50.265883+00	\N	\N	\N	mashhad	\N	\N	\N	2000000	{"mid": "اجاره: ۲,۰۰۰,۰۰۰ تومان", "bottom": "دقایقی پیش در شهید قربانی", "amounts": {"اجاره": 2000000}}	\N
\.


--
-- Data for Name: discovery_neighborhoods; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.discovery_neighborhoods (id, name, aliases) FROM stdin;
1	اقبال	\N
2	لادن	\N
3	شهرآرا	\N
4	صیاد شیرازی	\N
5	حافظ	\N
6	صارمی	\N
7	هفت‌تیر	\N
8	پیروزی	\N
9	هاشمیه	\N
10	نیروهوایی	\N
11	هنرستان	\N
12	باهنر	\N
13	کوثر	\N
14	چهارراه چشمه	\N
15	ارشاد	\N
16	آزادگاه	\N
17	بهاران	\N
18	بهشت	\N
19	فلسطین	\N
20	گوهرشاد	\N
21	سجاد	\N
22	سرافرازان	\N
23	عبدالمطلب	\N
24	ابوذر	\N
25	قدس	\N
26	هدایت	\N
27	فکوری	\N
28	شهید مطهری	\N
29	فجر	\N
30	فاطمیه	\N
31	آبکوه	\N
32	رسالت	\N
33	وحید	\N
34	امیرالمومنین	\N
35	مهرآباد	\N
36	قائم	\N
37	فرهنگیان	\N
38	شهرک غرب	\N
39	دانشجو	\N
40	کارگران	\N
41	جاهد شهر	\N
42	طبرسی شمالی	\N
43	بهمن	\N
44	الهیه	\N
45	دانش آموز	\N
\.


--
-- Data for Name: discovery_notification_logs; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.discovery_notification_logs (id, customer_id, channel, body, created_at) FROM stdin;
\.


--
-- Data for Name: filter_presets; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.filter_presets (id, name, params, requested_by, approved, created_at, pending_delete) FROM stdin;
\.


--
-- Data for Name: follow_ups; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.follow_ups (id, user_id, property_id, deal_id, title, description, due_date, status, reminded, done_at, created_at, updated_at, due_time) FROM stdin;
2	1	\N	\N	jjjjj	jjjjjjjjjj	\N	pending	f	\N	2026-09-09 20:17:26.495576+00	2026-09-09 20:17:26.495583+00	\N
3	1	1	\N	jjjj	jjjjjjjjj	\N	pending	f	\N	2026-09-09 20:17:42.124103+00	2026-09-09 20:17:42.124115+00	\N
1	1	4	\N	;;;;;;;;	;;;;;;;;;;;;;;;	2026-09-09	pending	t	\N	2026-09-09 20:17:17.783848+00	2026-09-09 20:18:14.117883+00	\N
4	1	6	\N	.......من	ننننننن	\N	pending	f	\N	2026-09-09 20:22:35.085546+00	2026-09-09 20:22:35.085551+00	\N
5	1	3	\N	مممم	وننننننن	\N	pending	f	\N	2026-09-09 20:22:51.321888+00	2026-09-09 20:22:51.321892+00	\N
6	1	6	\N	تتتتت	ااااا	\N	pending	f	\N	2026-09-09 20:58:04.426162+00	2026-09-09 20:58:04.426168+00	\N
8	1	\N	\N	zzzz	zzzzzzzzz	\N	pending	f	\N	2026-09-11 12:09:38.539468+00	2026-09-11 12:09:38.539472+00	\N
7	1	7	\N	ssss	sssssss	2026-08-25	pending	t	\N	2026-09-11 12:09:31.116702+00	2026-09-11 12:09:40.15008+00	\N
9	1	\N	\N	ثثثثث	ثثثثثثثثثثثثثثثث	2026-09-03	pending	t	\N	2026-09-11 12:25:20.964809+00	2026-09-11 12:39:19.628502+00	\N
10	1	\N	\N	333	3333333	\N	pending	f	\N	2026-09-11 14:01:34.457972+00	2026-09-11 14:01:34.457976+00	\N
12	1	\N	\N	عععععععع	ههههههه	\N	pending	f	\N	2026-09-17 18:10:43.444652+00	2026-09-17 18:10:43.444656+00	\N
13	1	\N	\N	333	3333	\N	pending	f	\N	2026-09-18 15:20:43.908418+00	2026-09-18 15:20:43.908424+00	\N
14	1	\N	\N	بببب	\N	2026-09-14	pending	t	\N	2026-09-18 15:20:55.672903+00	2026-09-18 15:27:27.686953+00	\N
11	5	\N	\N	ttt	ggggggggggggg	\N	done	f	2026-09-18 15:30:41.828776+00	2026-09-11 14:19:23.777297+00	2026-09-18 15:30:41.830441+00	\N
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.notifications (id, user_id, title, body, entity_type, entity_id, is_read, created_at) FROM stdin;
1	3	معامله‌ی شما قطعی شد	معامله #2 قطعی شد — پورسانت 18,666 تومان.	deal	2	f	2026-09-09 17:20:13.934269+00
2	2	معامله‌ی شما قطعی شد	معامله #1 قطعی شد — پورسانت 9,333,333 تومان.	deal	1	f	2026-09-09 17:20:17.122317+00
3	1	📌 پیگیری برای امروز	;;;;;;;; — سررسید: 2026-09-09	follow_up	1	t	2026-09-09 20:18:14.120219+00
4	1	⚠️ پیگیری عقب‌افتاده!	ssss — سررسید: 2026-08-25	follow_up	7	t	2026-09-11 12:09:40.152253+00
5	3	پرداخت پورسانت ثبت شد	برای معامله #2 پرداخت 222 تومانی ثبت شد.	deal	2	f	2026-09-11 12:21:30.361249+00
12	5	پرداخت پورسانت ثبت شد	برای معامله #6 پرداخت 22 تومانی ثبت شد.	deal	6	t	2026-09-11 14:00:45.223333+00
8	5	معامله‌ی شما قطعی شد	معامله #6 قطعی شد — پورسانت 4,888,889 تومان.	deal	6	t	2026-09-11 14:00:16.521674+00
9	5	معامله به «در جریان» برگشت	معامله #6 از حالت قطعی خارج شد.	deal	6	t	2026-09-11 14:00:19.172969+00
10	5	معامله‌ی شما قطعی شد	معامله #6 قطعی شد — پورسانت 4,888,889 تومان.	deal	6	t	2026-09-11 14:00:29.010763+00
11	5	پرداخت پورسانت ثبت شد	برای معامله #6 پرداخت 2,222 تومانی ثبت شد.	deal	6	t	2026-09-11 14:00:38.723619+00
14	1	درخواست حذف فیلتر آماده	«dddd» توسط sss درخواست حذف داده — در مدیریت فیلترها تأیید کن.	preset_delete	4	t	2026-09-11 14:15:11.675828+00
13	1	پیشنهاد فیلتر آمادهٔ جدید	«www» توسط sss پیشنهاد شده — در مدیریت فیلترها تأیید کن.	preset	6	t	2026-09-11 14:15:06.571989+00
7	1	معامله‌ی شما قطعی شد	معامله #4 قطعی شد — پورسانت 333,333,333 تومان.	deal	4	t	2026-09-11 12:41:23.692027+00
6	1	⚠️ پیگیری عقب‌افتاده!	ثثثثث — سررسید: 2026-09-03	follow_up	9	t	2026-09-11 12:39:19.629747+00
15	4	💬 پیام جدید	از admin: صصصصص	chat	1	f	2026-09-13 12:20:30.099177+00
16	5	💬 پیام جدید	از admin: صصصص	chat	1	t	2026-09-13 12:20:37.183322+00
18	5	معامله به «در جریان» برگشت	معامله #6 از حالت قطعی خارج شد.	deal	6	f	2026-09-16 20:18:50.580419+00
19	2	💬 پیام جدید	از admin: یبر	chat	1	f	2026-09-17 08:18:23.190803+00
20	3	💬 پیام جدید	از admin: ااااااا	chat	1	f	2026-09-17 09:09:25.198702+00
21	5	💬 پیام جدید	از admin: ااااااا	chat	1	f	2026-09-17 09:09:30.602461+00
22	5	پرداخت پورسانت ثبت شد	برای معامله #5 پرداخت 333,333 تومانی ثبت شد.	deal	5	f	2026-09-17 18:15:27.443594+00
17	1	💬 پیام جدید	از sss: ضضض	chat	5	t	2026-09-13 12:21:15.647929+00
23	5	معامله‌ی شما قطعی شد	معامله #8 قطعی شد — پورسانت 1,955,555,555,555,555 تومان.	deal	8	f	2026-09-18 15:09:29.759412+00
24	5	پرداخت پورسانت ثبت شد	برای معامله #9 پرداخت 333 تومانی ثبت شد.	deal	9	f	2026-09-18 15:19:51.652429+00
25	1	⚠️ پیگیری عقب‌افتاده!	بببب — سررسید: 2026-09-14	follow_up	14	f	2026-09-18 15:27:27.689232+00
26	2	💬 پیام جدید	از sss: فففففف	chat	5	f	2026-09-18 15:31:29.637282+00
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.properties (id, owner_agent_id, deal_type, status, city, district, address, area_m2, rooms, has_elevator, has_parking, owner_name, owner_phone, contract_end_date, details, notes, created_at, updated_at, version, amenities, expire_notified_at, expire_review_at, property_types, urgent_until, location_url, build_year, total_units, convertible_note, deleted_at) FROM stdin;
2	1	presale	active	بذذذ	ذذذذ	ببببببب	\N	\N	t	t	ببببببببب	ببببب	\N	{"total_price": null, "delivery_date": null}	\N	2026-09-07 15:44:18.677548+00	2026-09-07 15:44:18.677554+00	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3	1	mortgage	active	ttt	vggggggtt	tttt	\N	1	f	f	hhhhh	56784564321	\N	{"deposit_full": 4444444}	tttttttt	2026-09-08 15:37:02.62799+00	2026-09-08 15:38:23.439511+00	2	["tttt", "3eeeeee"]	\N	\N	\N	\N	\N	\N	\N	\N	\N
5	1	sale	active	للل	للللللل	للللللل	\N	\N	f	f	\N	\N	\N	{"price": null, "price_per_m2": null}	\N	2026-09-08 16:10:03.227251+00	2026-09-08 16:10:03.227256+00	1	null	\N	\N	\N	\N	\N	\N	\N	\N	\N
6	1	sale	active	ففففف	ففففف	\N	55555	4	t	t	\N	\N	\N	{"price": null, "price_per_m2": null}	\N	2026-09-08 16:10:03.227257+00	2026-09-08 16:10:03.227257+00	1	null	\N	\N	\N	\N	\N	\N	\N	\N	\N
7	1	presale	active	rrrrrrrrrrr	rr	rrr	55555	\N	f	f	\N	\N	\N	{"total_price": null, "delivery_date": null}	\N	2026-09-08 16:10:03.227258+00	2026-09-08 16:10:03.227259+00	1	null	\N	\N	\N	\N	\N	\N	\N	\N	\N
10	1	sale	sold	ففففف	ففففف	\N	55555	4	t	t	\N	\N	\N	{"price": null, "price_per_m2": null}	\N	2026-09-08 16:10:05.539149+00	2026-09-09 17:20:13.91657+00	1	null	\N	\N	\N	\N	\N	\N	\N	\N	\N
9	1	mortgage	inactive	uuuتت	تتتت	\N	22222	2	f	f	\N	22222222222	\N	{"deposit_full": null}	\N	2026-09-08 16:10:03.22726+00	2026-09-09 20:26:18.83656+00	1	null	\N	\N	\N	\N	\N	\N	\N	\N	\N
8	1	rent	inactive	uuuuu	uu	\N	\N	2	f	f	\N	\N	\N	{"deposit": null, "monthly_rent": null}	\N	2026-09-08 16:10:03.227259+00	2026-09-09 20:26:40.832177+00	1	null	\N	\N	\N	\N	\N	\N	\N	\N	\N
1	1	sale	sold	تهران	۶	رغفرانیه ۱	8	3	t	t	صشسش	\N	\N	{"price": 2222222222222222}	ثبیزی	2026-09-07 15:39:00.963663+00	2026-09-11 12:41:23.683336+00	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12	5	sale	active	aaa	aaaaaa	aaaaaa	\N	\N	f	f	\N	\N	\N	{"price": null}	\N	2026-09-11 14:15:32.032633+00	2026-09-11 14:15:32.032636+00	1	[]	\N	\N	\N	\N	\N	\N	\N	\N	\N
13	5	presale	active	aaaaa	\N	\N	\N	\N	f	t	\N	9053213280	\N	{"total_price": 222222, "delivery_date": null}	\N	2026-09-11 14:17:30.685473+00	2026-09-11 14:17:30.685477+00	1	null	\N	\N	\N	\N	\N	\N	\N	\N	\N
14	5	presale	active	bbbb	\N	\N	\N	\N	f	t	\N	9053213280	\N	{"total_price": 444, "delivery_date": null}	\N	2026-09-11 14:17:30.685478+00	2026-09-11 14:17:30.685478+00	1	null	\N	\N	\N	\N	\N	\N	\N	\N	\N
15	5	rent	active	fff	\N	\N	\N	4	f	f	r	\N	\N	{"deposit": 333, "monthly_rent": null}	\N	2026-09-11 14:17:30.685479+00	2026-09-11 14:17:30.685479+00	1	null	\N	\N	\N	\N	\N	\N	\N	\N	\N
16	5	rent	active	vvv	\N	\N	\N	\N	f	f	\N	\N	\N	{"deposit": 444, "monthly_rent": null}	\N	2026-09-11 14:17:30.68548+00	2026-09-11 14:17:30.685481+00	1	null	\N	\N	\N	\N	\N	\N	\N	\N	\N
17	5	mortgage	active	rrrr	ffff	ffffff	44	\N	f	f	\N	\N	\N	{"deposit_full": null}	\N	2026-09-11 14:17:30.685481+00	2026-09-11 14:17:30.685481+00	1	null	\N	\N	\N	\N	\N	\N	\N	\N	\N
11	1	rent	active	uuuuu	uu	\N	\N	2	f	f	\N	\N	2026-09-13	{"deposit": null, "monthly_rent": null}	\N	2026-09-08 16:10:05.539153+00	2026-09-15 15:39:27.792775+00	4	[]	\N	\N	\N	\N	\N	\N	\N	\N	\N
18	5	rent	active	ببب	بببب	بببببببب	33	20	t	t	ل	9999999999	2025-10-09	{"deposit": 333333, "monthly_rent": 333}	بببببب	2026-09-11 14:23:11.087922+00	2026-09-16 20:14:54.580002+00	2	["\\u0642\\u0642"]	\N	\N	\N	\N	\N	\N	\N	\N	\N
4	1	sale	active	غغغغ	نتتتتت	\N	9	\N	f	f	اااااااا	\N	\N	{"price": null}	\N	2026-09-08 15:38:09.562603+00	2026-09-16 20:18:50.556225+00	1	["\\u0627\\u0627\\u0627\\u0627"]	\N	\N	\N	\N	\N	\N	\N	\N	\N
19	1	mortgage	sold	قققققق	ققققققق	ققققققققق	111	3	t	t	للللللل	1111111111	\N	{"deposit_full": 111111111111}	ققققققققق	2026-09-17 07:57:51.718081+00	2026-09-18 15:09:29.542304+00	1	["\\u0644\\u0644\\u0644", "\\u0644\\u0644\\u0644\\u0644"]	\N	\N	["old_house", "land", "demolishable", "workshop", "educational", "garden", "industrial", "other"]	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: property_favorites; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.property_favorites (id, user_id, property_id, created_at) FROM stdin;
\.


--
-- Data for Name: property_images; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.property_images (id, property_id, stored_filename, original_filename, content_type, created_at) FROM stdin;
1	11	20f9efe3368447acb7f344bcf8143fee.jpg	download (1).jpg	image/jpeg	2026-09-08 16:47:38.580324+00
2	11	f34a3c4da7cf496bbc515ddabb5d4076.jpg	download.jpg	image/jpeg	2026-09-08 16:47:38.580333+00
4	12	c3351a44e591488595ce5da98521ebbd.png	Screenshot 2026-09-02 150038.png	image/png	2026-09-11 14:15:39.913026+00
5	19	81bcb1be56a34678b4e39d2f64e4c4d5.jpg	download.jpg	image/jpeg	2026-09-17 07:58:01.611494+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.users (id, username, full_name, hashed_password, role, is_active, token_version, created_at, phone, failed_attempts, locked_until, commission_rates) FROM stdin;
1	admin	admin	$2b$12$V87XnEW8T4YRtth2fQhirOuOydmk9Go/kl6Kx3TcpL3rlSOdHwN1W	admin	t	0	2026-09-07 14:57:31.83504+00	\N	0	\N	\N
2	تینا	x	$2b$12$8cVoRIg6sFn7sX.BfSJzZupj5FUED0ZwGB17QmXRly5ZtQqpE0maS	agent	t	1	2026-09-08 16:54:26.759073+00	09053213280	0	\N	{"sale": 45.0, "rent": 42.0, "presale": 44.0, "mortgage": 40.0}
3	ضضض	ضضض	$2b$12$Ki9H5m5qpCofYFqBayts2uvs8WqTZihuZflglJ.va43biCW1bYdxy	agent	t	1	2026-09-08 16:55:26.775551+00	\N	0	\N	\N
4	jjj	lllllll	$2b$12$E3CtG0VKz55o91cTF9Gh5e/Z/EFC9WztkExVX9QH5eIxJ7ONKrWsC	agent	t	0	2026-09-09 20:16:52.642961+00	\N	0	\N	\N
5	sss	sss	$2b$12$5F5VC78b9gKKEc/6Mdb1NOkvody1cfBAiHtrWqlbJv0JyNMgx2P6O	agent	t	1	2026-09-11 12:09:15.361008+00	\N	0	\N	\N
\.


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 157, true);


--
-- Name: bot_faq_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.bot_faq_id_seq', 24, true);


--
-- Name: chat_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.chat_messages_id_seq', 15, true);


--
-- Name: client_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.client_requests_id_seq', 7, true);


--
-- Name: commission_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.commission_payments_id_seq', 6, true);


--
-- Name: deals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.deals_id_seq', 9, true);


--
-- Name: discovery_listings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.discovery_listings_id_seq', 3530, true);


--
-- Name: discovery_neighborhoods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.discovery_neighborhoods_id_seq', 45, true);


--
-- Name: discovery_notification_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.discovery_notification_logs_id_seq', 1, false);


--
-- Name: filter_presets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.filter_presets_id_seq', 40, true);


--
-- Name: follow_ups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.follow_ups_id_seq', 14, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.notifications_id_seq', 26, true);


--
-- Name: properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.properties_id_seq', 19, true);


--
-- Name: property_favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.property_favorites_id_seq', 1, false);


--
-- Name: property_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.property_images_id_seq', 5, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: bot_faq bot_faq_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.bot_faq
    ADD CONSTRAINT bot_faq_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: client_requests client_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.client_requests
    ADD CONSTRAINT client_requests_pkey PRIMARY KEY (id);


--
-- Name: commission_payments commission_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.commission_payments
    ADD CONSTRAINT commission_payments_pkey PRIMARY KEY (id);


--
-- Name: deals deals_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_pkey PRIMARY KEY (id);


--
-- Name: discovery_listings discovery_listings_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.discovery_listings
    ADD CONSTRAINT discovery_listings_pkey PRIMARY KEY (id);


--
-- Name: discovery_neighborhoods discovery_neighborhoods_name_key; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.discovery_neighborhoods
    ADD CONSTRAINT discovery_neighborhoods_name_key UNIQUE (name);


--
-- Name: discovery_neighborhoods discovery_neighborhoods_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.discovery_neighborhoods
    ADD CONSTRAINT discovery_neighborhoods_pkey PRIMARY KEY (id);


--
-- Name: discovery_notification_logs discovery_notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.discovery_notification_logs
    ADD CONSTRAINT discovery_notification_logs_pkey PRIMARY KEY (id);


--
-- Name: filter_presets filter_presets_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.filter_presets
    ADD CONSTRAINT filter_presets_pkey PRIMARY KEY (id);


--
-- Name: follow_ups follow_ups_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.follow_ups
    ADD CONSTRAINT follow_ups_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_favorites property_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.property_favorites
    ADD CONSTRAINT property_favorites_pkey PRIMARY KEY (id);


--
-- Name: property_images property_images_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.property_images
    ADD CONSTRAINT property_images_pkey PRIMARY KEY (id);


--
-- Name: discovery_listings uq_discovery_listing_source_ext; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.discovery_listings
    ADD CONSTRAINT uq_discovery_listing_source_ext UNIQUE (source, external_id);


--
-- Name: property_favorites uq_user_property_favorite; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.property_favorites
    ADD CONSTRAINT uq_user_property_favorite UNIQUE (user_id, property_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_chat_messages_receiver_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_chat_messages_receiver_id ON public.chat_messages USING btree (receiver_id);


--
-- Name: ix_chat_messages_sender_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_chat_messages_sender_id ON public.chat_messages USING btree (sender_id);


--
-- Name: ix_client_requests_owner_agent_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_client_requests_owner_agent_id ON public.client_requests USING btree (owner_agent_id);


--
-- Name: ix_client_requests_status; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_client_requests_status ON public.client_requests USING btree (status);


--
-- Name: ix_commission_payments_deal_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_commission_payments_deal_id ON public.commission_payments USING btree (deal_id);


--
-- Name: ix_deals_agent_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_deals_agent_id ON public.deals USING btree (agent_id);


--
-- Name: ix_deals_property_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_deals_property_id ON public.deals USING btree (property_id);


--
-- Name: ix_deals_status; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_deals_status ON public.deals USING btree (status);


--
-- Name: ix_follow_ups_due_date; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_follow_ups_due_date ON public.follow_ups USING btree (due_date);


--
-- Name: ix_follow_ups_status; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_follow_ups_status ON public.follow_ups USING btree (status);


--
-- Name: ix_follow_ups_user_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_follow_ups_user_id ON public.follow_ups USING btree (user_id);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_properties_city; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_properties_city ON public.properties USING btree (city);


--
-- Name: ix_properties_contract_end_date; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_properties_contract_end_date ON public.properties USING btree (contract_end_date);


--
-- Name: ix_properties_deal_type; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_properties_deal_type ON public.properties USING btree (deal_type);


--
-- Name: ix_properties_owner_agent_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_properties_owner_agent_id ON public.properties USING btree (owner_agent_id);


--
-- Name: ix_properties_status; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_properties_status ON public.properties USING btree (status);


--
-- Name: ix_property_favorites_property_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_property_favorites_property_id ON public.property_favorites USING btree (property_id);


--
-- Name: ix_property_favorites_user_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_property_favorites_user_id ON public.property_favorites USING btree (user_id);


--
-- Name: ix_property_images_property_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_property_images_property_id ON public.property_images USING btree (property_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: chat_messages chat_messages_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES public.users(id);


--
-- Name: chat_messages chat_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: client_requests client_requests_owner_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.client_requests
    ADD CONSTRAINT client_requests_owner_agent_id_fkey FOREIGN KEY (owner_agent_id) REFERENCES public.users(id);


--
-- Name: commission_payments commission_payments_deal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.commission_payments
    ADD CONSTRAINT commission_payments_deal_id_fkey FOREIGN KEY (deal_id) REFERENCES public.deals(id);


--
-- Name: deals deals_agent2_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_agent2_id_fkey FOREIGN KEY (agent2_id) REFERENCES public.users(id);


--
-- Name: deals deals_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id);


--
-- Name: deals deals_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: discovery_listings discovery_listings_converted_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.discovery_listings
    ADD CONSTRAINT discovery_listings_converted_by_user_id_fkey FOREIGN KEY (converted_by_user_id) REFERENCES public.users(id);


--
-- Name: discovery_listings discovery_listings_converted_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.discovery_listings
    ADD CONSTRAINT discovery_listings_converted_property_id_fkey FOREIGN KEY (converted_property_id) REFERENCES public.properties(id);


--
-- Name: discovery_listings discovery_listings_neighborhood_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.discovery_listings
    ADD CONSTRAINT discovery_listings_neighborhood_id_fkey FOREIGN KEY (neighborhood_id) REFERENCES public.discovery_neighborhoods(id);


--
-- Name: filter_presets filter_presets_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.filter_presets
    ADD CONSTRAINT filter_presets_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id);


--
-- Name: follow_ups follow_ups_deal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.follow_ups
    ADD CONSTRAINT follow_ups_deal_id_fkey FOREIGN KEY (deal_id) REFERENCES public.deals(id);


--
-- Name: follow_ups follow_ups_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.follow_ups
    ADD CONSTRAINT follow_ups_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: follow_ups follow_ups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.follow_ups
    ADD CONSTRAINT follow_ups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: properties properties_owner_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_owner_agent_id_fkey FOREIGN KEY (owner_agent_id) REFERENCES public.users(id);


--
-- Name: property_favorites property_favorites_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.property_favorites
    ADD CONSTRAINT property_favorites_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: property_favorites property_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.property_favorites
    ADD CONSTRAINT property_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: property_images property_images_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.property_images
    ADD CONSTRAINT property_images_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 8svyU3alhCXPrMSje0vYJOrqJhlkxqdkvg1Ys6IMIHHmqJYbcVcKLbWQAZ9zsky

