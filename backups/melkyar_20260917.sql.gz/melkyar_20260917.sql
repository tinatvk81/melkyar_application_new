--
-- PostgreSQL database dump
--

\restrict sionsyqJktTXgzIAVR5vu3T3KYmnRHNsWYdbnEqg9XYFuzlxsKAONvNYX6LGGO7

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dealstatus; Type: TYPE; Schema: public; Owner: melkyar_app
--

CREATE TYPE public.dealstatus AS ENUM (
    'pending',
    'finalized',
    'canceled'
);


ALTER TYPE public.dealstatus OWNER TO melkyar_app;

--
-- Name: dealtype; Type: TYPE; Schema: public; Owner: melkyar_app
--

CREATE TYPE public.dealtype AS ENUM (
    'sale',
    'presale',
    'rent',
    'mortgage'
);


ALTER TYPE public.dealtype OWNER TO melkyar_app;

--
-- Name: followupstatus; Type: TYPE; Schema: public; Owner: melkyar_app
--

CREATE TYPE public.followupstatus AS ENUM (
    'pending',
    'done',
    'canceled'
);


ALTER TYPE public.followupstatus OWNER TO melkyar_app;

--
-- Name: propertystatus; Type: TYPE; Schema: public; Owner: melkyar_app
--

CREATE TYPE public.propertystatus AS ENUM (
    'active',
    'inactive',
    'sold'
);


ALTER TYPE public.propertystatus OWNER TO melkyar_app;

--
-- Name: requeststatus; Type: TYPE; Schema: public; Owner: melkyar_app
--

CREATE TYPE public.requeststatus AS ENUM (
    'open',
    'closed'
);


ALTER TYPE public.requeststatus OWNER TO melkyar_app;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: melkyar_app
--

CREATE TYPE public.userrole AS ENUM (
    'admin',
    'agent'
);


ALTER TYPE public.userrole OWNER TO melkyar_app;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.activity_logs (
    id integer NOT NULL,
    user_id integer NOT NULL,
    action character varying(64) NOT NULL,
    entity_type character varying(64) NOT NULL,
    entity_id integer,
    detail character varying(500),
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.activity_logs OWNER TO melkyar_app;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_logs_id_seq OWNER TO melkyar_app;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO melkyar_app;

--
-- Name: bot_faq; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.bot_faq (
    id integer NOT NULL,
    question character varying(300) NOT NULL,
    answer text NOT NULL
);


ALTER TABLE public.bot_faq OWNER TO melkyar_app;

--
-- Name: bot_faq_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.bot_faq_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bot_faq_id_seq OWNER TO melkyar_app;

--
-- Name: bot_faq_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.bot_faq_id_seq OWNED BY public.bot_faq.id;


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.chat_messages (
    id integer NOT NULL,
    sender_id integer NOT NULL,
    receiver_id integer NOT NULL,
    body text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone
);


ALTER TABLE public.chat_messages OWNER TO melkyar_app;

--
-- Name: chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.chat_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_messages_id_seq OWNER TO melkyar_app;

--
-- Name: chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.chat_messages_id_seq OWNED BY public.chat_messages.id;


--
-- Name: client_requests; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.client_requests (
    id integer NOT NULL,
    owner_agent_id integer NOT NULL,
    customer_name character varying(128) NOT NULL,
    customer_phone character varying(32),
    deal_type character varying(16) NOT NULL,
    city character varying(64),
    district character varying(64),
    min_area double precision,
    max_area double precision,
    min_rooms integer,
    max_price integer,
    notes text,
    status public.requeststatus DEFAULT 'open'::public.requeststatus NOT NULL,
    created_at timestamp with time zone
);


ALTER TABLE public.client_requests OWNER TO melkyar_app;

--
-- Name: client_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.client_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.client_requests_id_seq OWNER TO melkyar_app;

--
-- Name: client_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.client_requests_id_seq OWNED BY public.client_requests.id;


--
-- Name: commission_payments; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.commission_payments (
    id integer NOT NULL,
    deal_id integer NOT NULL,
    amount integer NOT NULL,
    paid_date date,
    note character varying(500),
    receipt_path character varying(255),
    created_at timestamp with time zone,
    kind character varying(16) DEFAULT 'to_agent'::character varying NOT NULL
);


ALTER TABLE public.commission_payments OWNER TO melkyar_app;

--
-- Name: commission_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.commission_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.commission_payments_id_seq OWNER TO melkyar_app;

--
-- Name: commission_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.commission_payments_id_seq OWNED BY public.commission_payments.id;


--
-- Name: deals; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.deals (
    id integer NOT NULL,
    property_id integer NOT NULL,
    agent_id integer NOT NULL,
    deal_amount integer NOT NULL,
    commission_percent double precision NOT NULL,
    commission_amount integer NOT NULL,
    status public.dealstatus DEFAULT 'pending'::public.dealstatus NOT NULL,
    contract_date date,
    finalized_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.deals OWNER TO melkyar_app;

--
-- Name: deals_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.deals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.deals_id_seq OWNER TO melkyar_app;

--
-- Name: deals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.deals_id_seq OWNED BY public.deals.id;


--
-- Name: filter_presets; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.filter_presets (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    params json NOT NULL,
    requested_by integer NOT NULL,
    approved boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone,
    pending_delete boolean DEFAULT false NOT NULL
);


ALTER TABLE public.filter_presets OWNER TO melkyar_app;

--
-- Name: filter_presets_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.filter_presets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.filter_presets_id_seq OWNER TO melkyar_app;

--
-- Name: filter_presets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.filter_presets_id_seq OWNED BY public.filter_presets.id;


--
-- Name: follow_ups; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.follow_ups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    property_id integer,
    deal_id integer,
    title character varying(200) NOT NULL,
    description text,
    due_date date,
    status public.followupstatus DEFAULT 'pending'::public.followupstatus NOT NULL,
    reminded boolean DEFAULT false NOT NULL,
    done_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    due_time character varying(5)
);


ALTER TABLE public.follow_ups OWNER TO melkyar_app;

--
-- Name: follow_ups_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.follow_ups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.follow_ups_id_seq OWNER TO melkyar_app;

--
-- Name: follow_ups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.follow_ups_id_seq OWNED BY public.follow_ups.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(200) NOT NULL,
    body text,
    entity_type character varying(32),
    entity_id integer,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone
);


ALTER TABLE public.notifications OWNER TO melkyar_app;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO melkyar_app;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: properties; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.properties (
    id integer NOT NULL,
    owner_agent_id integer NOT NULL,
    deal_type public.dealtype NOT NULL,
    status public.propertystatus NOT NULL,
    city character varying(64) NOT NULL,
    district character varying(64),
    address character varying(255),
    area_m2 double precision,
    rooms integer,
    has_elevator boolean NOT NULL,
    has_parking boolean NOT NULL,
    owner_name character varying(128),
    owner_phone character varying(32),
    contract_end_date date,
    details jsonb NOT NULL,
    notes character varying(2000),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    amenities json,
    expire_notified_at timestamp with time zone,
    expire_review_at date,
    property_types json
);


ALTER TABLE public.properties OWNER TO melkyar_app;

--
-- Name: properties_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.properties_id_seq OWNER TO melkyar_app;

--
-- Name: properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.properties_id_seq OWNED BY public.properties.id;


--
-- Name: property_images; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.property_images (
    id integer NOT NULL,
    property_id integer NOT NULL,
    stored_filename character varying(128) NOT NULL,
    original_filename character varying(255),
    content_type character varying(64) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.property_images OWNER TO melkyar_app;

--
-- Name: property_images_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.property_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.property_images_id_seq OWNER TO melkyar_app;

--
-- Name: property_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.property_images_id_seq OWNED BY public.property_images.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: melkyar_app
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    full_name character varying(128) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    role public.userrole NOT NULL,
    is_active boolean NOT NULL,
    token_version integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    phone character varying(32),
    failed_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    commission_rates json
);


ALTER TABLE public.users OWNER TO melkyar_app;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: melkyar_app
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO melkyar_app;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: melkyar_app
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: bot_faq id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.bot_faq ALTER COLUMN id SET DEFAULT nextval('public.bot_faq_id_seq'::regclass);


--
-- Name: chat_messages id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.chat_messages ALTER COLUMN id SET DEFAULT nextval('public.chat_messages_id_seq'::regclass);


--
-- Name: client_requests id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.client_requests ALTER COLUMN id SET DEFAULT nextval('public.client_requests_id_seq'::regclass);


--
-- Name: commission_payments id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.commission_payments ALTER COLUMN id SET DEFAULT nextval('public.commission_payments_id_seq'::regclass);


--
-- Name: deals id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.deals ALTER COLUMN id SET DEFAULT nextval('public.deals_id_seq'::regclass);


--
-- Name: filter_presets id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.filter_presets ALTER COLUMN id SET DEFAULT nextval('public.filter_presets_id_seq'::regclass);


--
-- Name: follow_ups id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.follow_ups ALTER COLUMN id SET DEFAULT nextval('public.follow_ups_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: properties id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.properties ALTER COLUMN id SET DEFAULT nextval('public.properties_id_seq'::regclass);


--
-- Name: property_images id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.property_images ALTER COLUMN id SET DEFAULT nextval('public.property_images_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.activity_logs (id, user_id, action, entity_type, entity_id, detail, created_at) FROM stdin;
1	1	login	user	1	\N	2026-09-07 15:28:04.875737+00
2	1	create	property	1	تهران — رغفرانیه ۱	2026-09-07 15:39:00.978183+00
3	1	update	property	1	تهران — رغفرانیه ۱	2026-09-07 15:42:22.348461+00
4	1	create	property	2	بذذذ — ببببببب	2026-09-07 15:44:18.684597+00
5	1	login	user	1	\N	2026-09-08 13:55:53.847504+00
6	1	login	user	1	\N	2026-09-08 14:02:56.806094+00
7	1	login	user	1	\N	2026-09-08 14:04:07.371103+00
8	1	deactivate	property	1	تهران — رغفرانیه ۱	2026-09-08 14:20:10.927176+00
9	1	login	user	1	\N	2026-09-08 15:24:27.565288+00
10	1	login	user	1	\N	2026-09-08 15:35:16.653276+00
11	1	create	property	3	ttt — tttt	2026-09-08 15:37:02.636083+00
12	1	create	property	4	غغغغ — 	2026-09-08 15:38:09.572795+00
13	1	update	property	3	ttt — tttt	2026-09-08 15:38:23.449544+00
14	1	reactivate	property	1	تهران — رغفرانیه ۱	2026-09-08 15:39:16.235022+00
15	1	import_excel	property	\N	5 فایل ثبت شد، 0 خطا، 0 تکراری نادیده گرفته شد	2026-09-08 16:10:03.235389+00
16	1	import_excel	property	\N	2 فایل ثبت شد، 0 خطا، 3 تکراری نادیده گرفته شد	2026-09-08 16:10:05.542955+00
17	1	login	user	1	\N	2026-09-08 16:44:00.299096+00
18	1	login	user	1	\N	2026-09-08 16:47:09.905539+00
19	1	upload_image	property	11	3 عکس اضافه شد	2026-09-08 16:47:38.588803+00
20	1	update	property	11	uuuuu — 	2026-09-08 16:47:45.862625+00
21	1	delete_image	property	11	Screenshot 2026-08-30 193337.png	2026-09-08 16:48:07.697343+00
22	1	update	property	11	uuuuu — 	2026-09-08 16:48:11.783722+00
23	1	update	property	11	uuuuu — 	2026-09-08 16:50:29.713764+00
24	1	deactivate	property	9	uuuتت — 	2026-09-08 16:52:05.988974+00
25	1	reactivate	property	9	uuuتت — 	2026-09-08 16:52:27.527859+00
26	1	create	user	2	تینا (agent)	2026-09-08 16:54:26.765233+00
27	1	reset_password	user	2	تینا	2026-09-08 16:54:42.069901+00
28	1	update_phone	user	2	تینا	2026-09-08 16:54:46.474313+00
29	1	update_phone	user	2	تینا	2026-09-08 16:54:48.590039+00
30	1	update	user	2	درصد پورسانت تینا	2026-09-08 16:55:13.015069+00
31	1	create	user	3	ضضض (agent)	2026-09-08 16:55:26.781207+00
32	1	deactivate	user	3	ضضض	2026-09-08 16:55:30.910505+00
33	1	create	deal	1	معامله 22,222,222 تومان	2026-09-08 17:01:18.516035+00
34	1	finalize	deal	1	قطعی — پورسانت 9,333,333	2026-09-08 17:01:28.972389+00
35	1	activate	user	3	ضضض	2026-09-08 17:02:43.891903+00
36	1	create	deal	2	معامله 44,444 تومان	2026-09-08 17:03:15.134153+00
37	1	create	deal_payment	2	پرداخت 22,222,222 تومان	2026-09-08 17:03:45.597842+00
38	1	login	user	1	\N	2026-09-09 16:23:27.647553+00
39	1	login	user	1	\N	2026-09-09 16:43:15.346991+00
40	1	login	user	1	\N	2026-09-09 17:01:11.350372+00
41	1	login	user	1	\N	2026-09-09 17:01:21.964334+00
42	1	login	user	1	\N	2026-09-09 17:10:53.390275+00
43	1	finalize	deal	2	قطعی — پورسانت 18,666	2026-09-09 17:20:13.925377+00
44	1	finalize	deal	1	قطعی — پورسانت 9,333,333	2026-09-09 17:20:17.118648+00
45	1	create	client_request	1	ض	2026-09-09 17:31:02.893819+00
46	1	login	user	1	\N	2026-09-09 17:41:08.672381+00
47	1	login	user	1	\N	2026-09-09 19:48:58.432007+00
48	1	login	user	1	\N	2026-09-09 20:13:00.296952+00
49	1	login	user	1	\N	2026-09-09 20:16:12.613973+00
50	1	create	user	4	jjj (agent)	2026-09-09 20:16:52.667335+00
51	1	create	follow_up	1	;;;;;;;;	2026-09-09 20:17:17.81619+00
52	1	create	follow_up	2	jjjjj	2026-09-09 20:17:26.504052+00
53	1	create	follow_up	3	jjjj	2026-09-09 20:17:42.146862+00
54	1	create	follow_up	4	.......من	2026-09-09 20:22:35.118882+00
55	1	create	follow_up	5	مممم	2026-09-09 20:22:51.326948+00
56	1	create	client_request	2	د	2026-09-09 20:23:20.387162+00
57	1	deactivate	property	9	uuuتت — 	2026-09-09 20:26:18.841017+00
58	1	deactivate	property	8	uuuuu — 	2026-09-09 20:26:40.836183+00
59	1	login	user	1	\N	2026-09-09 20:55:32.742159+00
60	1	create	follow_up	6	تتتتت	2026-09-09 20:58:04.440146+00
61	1	login	user	1	\N	2026-09-10 20:25:41.978252+00
62	1	login	user	1	\N	2026-09-11 12:08:39.690396+00
63	1	create	user	5	sss (agent)	2026-09-11 12:09:15.368486+00
64	1	create	follow_up	7	ssss	2026-09-11 12:09:31.125748+00
65	1	create	follow_up	8	zzzz	2026-09-11 12:09:38.544475+00
66	1	login	user	1	\N	2026-09-11 12:16:48.694662+00
67	1	create	deal	3	معامله 22,222,222 تومان	2026-09-11 12:19:52.979116+00
68	1	create	deal_payment	2	پرداخت 222 تومان	2026-09-11 12:21:30.355344+00
69	1	create	follow_up	9	ثثثثث	2026-09-11 12:25:20.974357+00
70	1	login	user	1	\N	2026-09-11 12:39:18.426195+00
71	1	create	deal	4	معامله 333,333,333 تومان	2026-09-11 12:39:52.564146+00
72	1	create	deal	5	معامله 3,333,333 تومان	2026-09-11 12:40:08.730412+00
73	1	finalize	deal	4	قطعی — پورسانت 333,333,333	2026-09-11 12:41:23.688977+00
74	1	login	user	1	\N	2026-09-11 12:49:21.571829+00
75	1	login	user	1	\N	2026-09-11 13:13:38.416682+00
76	1	login	user	1	\N	2026-09-11 13:15:02.288789+00
77	1	login	user	1	\N	2026-09-11 13:31:14.313899+00
78	1	login	user	1	\N	2026-09-11 13:57:17.040921+00
79	1	create	deal	6	معامله 22,222,222 تومان	2026-09-11 13:58:18.318438+00
80	1	finalize	deal	6	قطعی — پورسانت 4,888,889	2026-09-11 14:00:16.517463+00
81	1	update	deal	6	بازگشت از قطعی به در جریان	2026-09-11 14:00:19.170993+00
82	1	finalize	deal	6	قطعی — پورسانت 4,888,889	2026-09-11 14:00:29.008879+00
83	1	create	deal_payment	6	پرداخت 2,222 تومان	2026-09-11 14:00:38.719949+00
84	1	create	deal_payment	6	پرداخت 22 تومان	2026-09-11 14:00:45.218337+00
85	1	update	deal_payment	6	رسید پرداخت ثبت/تعویض شد	2026-09-11 14:01:04.906329+00
86	1	create	follow_up	10	333	2026-09-11 14:01:34.465151+00
87	1	login	user	1	\N	2026-09-11 14:12:47.184611+00
88	1	reset_password	user	5	sss	2026-09-11 14:14:11.733502+00
89	5	login	user	5	\N	2026-09-11 14:14:29.765329+00
90	5	create	property	12	aaa — aaaaaa	2026-09-11 14:15:32.037122+00
91	5	upload_image	property	12	1 عکس اضافه شد	2026-09-11 14:15:39.921509+00
92	5	import_excel	property	\N	5 فایل ثبت شد، 1 خطا، 0 تکراری نادیده گرفته شد	2026-09-11 14:17:30.689695+00
93	5	create	follow_up	11	ttt	2026-09-11 14:19:23.783724+00
94	5	create	client_request	3	ققق	2026-09-11 14:19:38.4935+00
95	5	create	property	18	ببب — بببببببب	2026-09-11 14:23:11.091372+00
96	1	login	user	1	\N	2026-09-11 14:23:44.409491+00
97	1	login	user	1	\N	2026-09-11 14:45:01.311853+00
98	1	login	user	1	\N	2026-09-12 12:31:49.875655+00
99	1	login	user	1	\N	2026-09-12 15:59:41.406461+00
100	1	login	user	1	\N	2026-09-13 10:46:12.629238+00
101	1	login	user	1	\N	2026-09-13 11:37:54.606665+00
102	1	login	user	1	\N	2026-09-13 11:42:21.32521+00
103	1	login	user	1	\N	2026-09-13 11:50:20.989751+00
104	1	login	user	1	\N	2026-09-13 11:54:24.344398+00
105	1	login	user	1	\N	2026-09-13 12:01:59.935308+00
106	1	login	user	1	\N	2026-09-13 12:12:11.705141+00
107	5	login	user	5	\N	2026-09-13 12:20:50.724011+00
108	1	login	user	1	\N	2026-09-13 12:21:45.725489+00
109	1	login	user	1	\N	2026-09-13 12:39:19.625311+00
110	1	login	user	1	\N	2026-09-14 13:19:01.23842+00
111	1	login	user	1	\N	2026-09-15 15:04:50.699284+00
112	1	create	client_request	4	gggggggggggggggggggggggggggggggg	2026-09-15 15:33:18.542505+00
113	1	reactivate	property	11	uuuuu — 	2026-09-15 15:39:27.809819+00
114	1	login	user	1	\N	2026-09-16 16:23:53.060258+00
115	1	login	user	1	\N	2026-09-16 16:50:30.421465+00
116	1	login	user	1	\N	2026-09-16 17:02:53.030154+00
117	1	login	user	1	\N	2026-09-16 18:06:45.894145+00
118	1	login	user	1	\N	2026-09-16 18:07:38.076189+00
119	1	login	user	1	\N	2026-09-16 18:22:58.532581+00
120	1	login	user	1	\N	2026-09-16 18:27:30.211504+00
121	1	login	user	1	\N	2026-09-16 18:33:20.286944+00
122	1	login	user	1	\N	2026-09-16 19:55:52.008994+00
123	1	update	property	18	ببب — بببببببب	2026-09-16 20:14:54.594968+00
124	1	update	deal	6	بازگشت از قطعی به در جریان	2026-09-16 20:18:50.570983+00
125	1	login	user	1	\N	2026-09-16 21:22:53.208099+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.alembic_version (version_num) FROM stdin;
a9b0c1d2e3f4
\.


--
-- Data for Name: bot_faq; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.bot_faq (id, question, answer) FROM stdin;
1	فایل جدید ثبت کنم چطور فایل اضافه	از تب «فهرست فایل‌ها» دکمهٔ «افزودن فایل جدید» را بزنید. وارد کردن «شهر» الزامی است؛ بقیهٔ فیلدها اختیاری‌اند. بعد از ذخیره، پنجرهٔ گالری عکس باز می‌شود تا عکس اضافه کنید. تاریخ‌ها شمسی هستند و می‌توانید با کیبورد فارسی تایپ کنید.
2	عکس فایل گالری تصویر آپلود	برای فایل ذخیره‌شده، فرم ویرایش را باز کنید و «گالری تصاویر» را بزنید. تا ۱۰ عکس در هر بار آپلود، هر عکس حداکثر ۸ مگابایت. عکس اول به‌صورت خودکار بندانگشتی کنار فایل در فهرست نمایش داده می‌شود.
3	قیمت هر متر محاسبه	در فرم فایل با نوع معاملهٔ «فروش»: بعد از وارد کردن قیمت و متراژ، «قیمت هر متر» به‌صورت خودکار محاسبه و نمایش داده می‌شود. در اکسل هم ستون قیمت_هر_متر را خالی بگذارید تا خودکار پر شود.
4	امکانات دلخواه استخر سند بالکن چیپ	در فرم فایل، کادر «امکانات دلخواه»: مورد را تایپ کنید و Enter بزنید — به‌شکل چیپ اضافه می‌شود و فعال است. برای حذف، چیپ را انتخاب و «حذف چیپ‌های انتخاب‌شده» را بزنید. آسانسور و پارکینگ جداگانه تیک دارند.
5	تکراری مشابه دو بار	قبل از ذخیره، اگر تلفن مالک یا شهر+آدرس مشابه فایل موجود باشد، هشدار «فایل‌های مشابه» می‌بینید با نام مشاورِ ثبت‌کننده. اگر واقعاً فایل جدید است (مثلاً همان مالک دو ملک دارد)، «Yes» بزنید تا ثبت شود. این هشدار مسدودکننده نیست.
6	غیرفعال حذف فایل آرشیو بازگردانی	فایل‌ها حذف قطعی ندارند! «غیرفعال کردن» یعنی رفتن به بایگانی. در تب «بایگانی» می‌توانید فایل‌های غیرفعال و فروخته‌شده را ببینید و با «بازگردانی» دوباره فعالشان کنید.
7	جستجو سرچ پیدا Ctrl	در فهرست فایل‌ها، کادر «جستجوی آزاد» بالای صفحه: با هر حرف، نتایج زنده آپدیت می‌شوند و متن پیدا شده رنگی هایلایت می‌شود. با Ctrl+F هم می‌توانید مستقیم به کادر بپرید. جست‌وجو در آدرس، توضیحات، نام و تلفن مالک انجام می‌شود.
8	معامله قولنامه ثبت پورسانت حسابداری	در تب «حسابداری پورسانت» (فقط مدیر): «ثبت معامله جدید» ← فایل ملکی + مشاور + مبلغ. درصد پورسانت اگر وارد نشود از درصد پیش‌فرض مشاور خوانده می‌شود. پورسانت فقط بعد از «قطعی‌کردن معامله» رسمی می‌شود.
9	قطعی نهایی بستن معامله	معامله را انتخاب کنید ← «قطعی‌کردن معامله» ← تأیید. فایل ملکی به بایگانی «فروخته‌شده» می‌رود و پورسانت به کارکرد مشاور اضافه می‌شود. معاملهٔ قطعی‌شده قابل ویرایش نیست؛ اگر اشتباه بود، «بازگشت به در جریان» بزنید، اصلاح کنید و دوباره قطعی کنید.
10	پرداخت رسید پول واریز تسویه	معامله را انتخاب کنید ← «پرداخت‌ها» ← «افزودن پرداخت»: مبلغ، تاریخ شمسی، توضیح، و عکس رسید (اختیاری). دو نوع داریم: «پرداخت به مشاور» (بدهی به او) و «دریافت از مشاور» (اگر بیشتر از حقش داده شده). رسید را بعداً هم می‌توانید با «افزودن/تعویض رسید» اضافه کنید.
11	مانده بدهی کارکرد مشاور چقدر	پایین صفحهٔ حسابداری، جدول «مانده پورسانت مشاوران»: کارکرد = مجموع پورسانت معامله‌های قطعی‌شده، پرداخت‌شده = خالص پرداخت‌ها، و مانده = کارکرد منهای پرداخت. خروجی PDF همین جدول هم موجود است.
12	درصد پورسانت تنظیم مشاور درصدش	مدیر: تب «مشاوران و مدیریت» ← کاربر را انتخاب ← «درصد پورسانت» ← برای هر نوع معامله (فروش/اجاره/پیش‌خرید/رهن) درصد جدا بدهید. مثلاً فروش ۴۵٪ و اجاره ۱۰٪. این درصد هنگام ثبت معامله به‌صورت پیش‌فرض پیشنهاد می‌شود ولی قابل تغییر است.
13	قرارداد تمام شود رو به اتمام پایان یادآوری فوری	تب «قراردادهای رو‌به‌اتمام» قراردادهای زیر ۳۰ روز تا پایان را نشان می‌دهد (فوری‌ها زیر ۷ روز با رنگ هشدار). دابل‌کلیک روی هر ردیف = باز شدن فایل برای تماس/تمدید. بعد از ورود به برنامه هم اگر قرارداد فوری داشته باشید، هشدار خودکار می‌بینید.
14	پیگیری روزمره کار یادآوری وظیفه	تب «پیگیری روزمره»: کارهای روزانه‌تان با تاریخ شمسی و ساعت. «پیگیری جدید» بزنید: عنوان، سررسید، ساعت (اختیاری)، و فایل مرتبط. با هر باز شدن برنامه، کارهای امروز و عقب‌افتاده به‌صورت اطلاع‌یه هم می‌آیند. کار تمام‌شده را «✔ انجام شد» بزنید.
15	رمز فراموش کردم ریست پسورد عبور	از مدیر بخواهید: «مشاوران و مدیریت» ← انتخاب حساب شما ← «ریست رمز عبور» ← رمز جدید را به شما می‌گوید. بعد از ریست، باید دوباره وارد شوید.
16	قفل حساب اشتباه تلاش سه بار	اگر ۳ بار رمز اشتباه بزنید، حساب ۲ دقیقه قفل می‌شود و پیام زمان باقی‌مانده می‌بینید. بعد از آن دوباره تلاش کنید. حساب مدیر محدودیتی ندارد.
17	مشاور جدید کاربر حساب بساز	فقط مدیر: تب «مشاوران و مدیریت» ← «افزودن حساب جدید» ← نام کاربری (انگلیسی، بدون فاصله)، نام کامل، رمز اولیه، و تلفن (برای یادآوری پیامکی، اختیاری).
18	درخواست مشتری مشتری دنبال تطبیق منطبق	تب «درخواست مشتری‌ها»: مشتری‌ای که دنبال ملک است را ثبت کنید (نوع معامله، شهر، متراژ، بودجه). بعد دکمهٔ «فایل‌های منطبق» به‌صورت خودکار فایل‌های فعالِ منطبق با شرایطش را نشان می‌دهد. مشاور فقط درخواست‌ها و فایل‌های خودش را می‌بیند؛ مدیر همه را.
19	گزارش خروجی pdf اکسل چاپ	دکمه‌های «خروجی PDF» و «خروجی اکسل» در تب فایل‌ها دقیقاً همان فیلترهای فعلی شما را خروجی می‌دهند. برای قرارداد رسمی: در حسابداری، «چاپ قولنامه رسمی PDF» — متن قرارداد از فایل contract_template.txt خوانده می‌شود که مدیر می‌تواند ویرایشش کند.
21	فیلتر آماده چیپ سایر پیشنهاد	بالای فهرست فایل‌ها، چیپ‌های آماده (فروش، اجاره، متراژ ۱۰۰+ و…). با «سایر +» می‌توانید فیلتر دلخواه بسازید: مدیر مستقیم اضافه می‌کند؛ مشاور پیشنهاد می‌دهد و بعد از تأیید مدیر برای همه نمایش داده می‌شود. حذف چیپ هم با تأیید مدیر است.
22	انقضا فایل قدیمی منقضی	مدیر با «اسکن فایل‌های قدیمی» (در بایگانی) فایل‌های فعالِ قدیمی را پیدا می‌کند؛ به مالکِ هر فایل اطلاع‌یه می‌رود تا خودش تصمیم بگیرد: «تأیید انقضا» (به بایگانی می‌رود) یا «فایل را نگه دار» (۹۰ روز دیگر دوباره پرسیده می‌شود).
23	سلام درود وقت بخیر	سلام! 👋 خوش آمدید. دربارهٔ ملک‌یار هر سؤالی دارید بپرسید — مثلاً بنویسید «فایل جدید» یا «پورسانت» یا «قرارداد». اگر همکاری نیاز به تماس داشت، از لیست مخاطبان انتخابش کنید.
24	ممنوع تشکر مرسی ممنونم عالی	خواهش می‌کنم! 🌷 خوشحالم که کمک کرد. سؤال دیگری بود در خدمتم.
20	چت پیام گفتگو همکار همکارم	همین تب «گفت‌وگو»: از لیست «مخاطبان» همکار را انتخاب کنید و پیام بدهید — همه می‌توانند به همه پیام بدهند. پیام جدید در زنگ اطلاع‌یه‌ها 🔔 بالا-سمت شمارش می‌شود. برای سؤالات متداول، مخاطب «🤖 چت‌بات» را انتخاب کنید.
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.chat_messages (id, sender_id, receiver_id, body, is_read, created_at) FROM stdin;
1	1	4	صصصصص	f	2026-09-13 12:20:30.088201+00
2	1	5	صصصص	t	2026-09-13 12:20:37.17674+00
3	5	1	ضضض	f	2026-09-13 12:21:15.638895+00
\.


--
-- Data for Name: client_requests; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.client_requests (id, owner_agent_id, customer_name, customer_phone, deal_type, city, district, min_area, max_area, min_rooms, max_price, notes, status, created_at) FROM stdin;
1	1	ض	ض	sale	ض	ض	3	33	\N	4444444	لللللل	open	2026-09-09 17:31:02.878147+00
3	5	ققق	\N	sale	\N	\N	22	222	\N	\N	\N	open	2026-09-11 14:19:38.484827+00
4	1	gggggggggggggggggggggggggggggggg	\N	sale	\N	\N	\N	\N	\N	\N	\N	open	2026-09-15 15:33:18.530758+00
\.


--
-- Data for Name: commission_payments; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.commission_payments (id, deal_id, amount, paid_date, note, receipt_path, created_at, kind) FROM stdin;
1	2	22222222	\N	ببببببب	media/receipts/399ebb6afe854398a1b8d356fc9d7467.png	2026-09-08 17:03:45.58695+00	to_agent
2	2	222	2026-08-31	ثثثثثث	\N	2026-09-11 12:21:30.34342+00	from_agent
3	6	2222	\N	\N	\N	2026-09-11 14:00:38.71234+00	to_agent
4	6	22	\N	\N	media/receipts/f5c98d1c206e47dab8f599b6c8aaad52.png	2026-09-11 14:00:45.210033+00	from_agent
\.


--
-- Data for Name: deals; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.deals (id, property_id, agent_id, deal_amount, commission_percent, commission_amount, status, contract_date, finalized_at, notes, created_at, updated_at) FROM stdin;
1	11	2	22222222	42	9333333	finalized	\N	2026-09-09 17:20:17.113804+00	ببببب	2026-09-08 17:01:18.50864+00	2026-09-09 17:20:17.115074+00
3	4	5	22222222	33	7333333	pending	2026-07-22	\N	ثثث	2026-09-11 12:19:52.972371+00	2026-09-11 12:19:52.972375+00
5	1	5	3333333	42	1400000	pending	\N	\N	aaaa	2026-09-11 12:40:08.725397+00	2026-09-11 12:40:08.725401+00
4	1	1	333333333	100	333333333	finalized	\N	2026-09-11 12:41:23.679833+00	aaaaaa	2026-09-11 12:39:52.554676+00	2026-09-11 12:41:23.682011+00
2	10	3	444445555	33	146667033	finalized	2026-09-09	2026-09-09 17:20:13.904227+00	بببببصص	2026-09-08 17:03:15.126601+00	2026-09-11 12:42:34.7787+00
6	4	5	22222222	22	4888889	canceled	2025-09-11	\N	\N	2026-09-11 13:58:18.307113+00	2026-09-16 20:27:07.336628+00
\.


--
-- Data for Name: filter_presets; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.filter_presets (id, name, params, requested_by, approved, created_at, pending_delete) FROM stdin;
\.


--
-- Data for Name: follow_ups; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.follow_ups (id, user_id, property_id, deal_id, title, description, due_date, status, reminded, done_at, created_at, updated_at, due_time) FROM stdin;
2	1	\N	\N	jjjjj	jjjjjjjjjj	\N	pending	f	\N	2026-09-09 20:17:26.495576+00	2026-09-09 20:17:26.495583+00	\N
3	1	1	\N	jjjj	jjjjjjjjj	\N	pending	f	\N	2026-09-09 20:17:42.124103+00	2026-09-09 20:17:42.124115+00	\N
1	1	4	\N	;;;;;;;;	;;;;;;;;;;;;;;;	2026-09-09	pending	t	\N	2026-09-09 20:17:17.783848+00	2026-09-09 20:18:14.117883+00	\N
4	1	6	\N	.......من	ننننننن	\N	pending	f	\N	2026-09-09 20:22:35.085546+00	2026-09-09 20:22:35.085551+00	\N
5	1	3	\N	مممم	وننننننن	\N	pending	f	\N	2026-09-09 20:22:51.321888+00	2026-09-09 20:22:51.321892+00	\N
6	1	6	\N	تتتتت	ااااا	\N	pending	f	\N	2026-09-09 20:58:04.426162+00	2026-09-09 20:58:04.426168+00	\N
8	1	\N	\N	zzzz	zzzzzzzzz	\N	pending	f	\N	2026-09-11 12:09:38.539468+00	2026-09-11 12:09:38.539472+00	\N
7	1	7	\N	ssss	sssssss	2026-08-25	pending	t	\N	2026-09-11 12:09:31.116702+00	2026-09-11 12:09:40.15008+00	\N
9	1	\N	\N	ثثثثث	ثثثثثثثثثثثثثثثث	2026-09-03	pending	t	\N	2026-09-11 12:25:20.964809+00	2026-09-11 12:39:19.628502+00	\N
10	1	\N	\N	333	3333333	\N	pending	f	\N	2026-09-11 14:01:34.457972+00	2026-09-11 14:01:34.457976+00	\N
11	5	\N	\N	ttt	ggggggggggggg	\N	pending	f	\N	2026-09-11 14:19:23.777297+00	2026-09-11 14:19:23.777301+00	\N
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.notifications (id, user_id, title, body, entity_type, entity_id, is_read, created_at) FROM stdin;
1	3	معامله‌ی شما قطعی شد	معامله #2 قطعی شد — پورسانت 18,666 تومان.	deal	2	f	2026-09-09 17:20:13.934269+00
2	2	معامله‌ی شما قطعی شد	معامله #1 قطعی شد — پورسانت 9,333,333 تومان.	deal	1	f	2026-09-09 17:20:17.122317+00
3	1	📌 پیگیری برای امروز	;;;;;;;; — سررسید: 2026-09-09	follow_up	1	t	2026-09-09 20:18:14.120219+00
4	1	⚠️ پیگیری عقب‌افتاده!	ssss — سررسید: 2026-08-25	follow_up	7	t	2026-09-11 12:09:40.152253+00
5	3	پرداخت پورسانت ثبت شد	برای معامله #2 پرداخت 222 تومانی ثبت شد.	deal	2	f	2026-09-11 12:21:30.361249+00
12	5	پرداخت پورسانت ثبت شد	برای معامله #6 پرداخت 22 تومانی ثبت شد.	deal	6	t	2026-09-11 14:00:45.223333+00
8	5	معامله‌ی شما قطعی شد	معامله #6 قطعی شد — پورسانت 4,888,889 تومان.	deal	6	t	2026-09-11 14:00:16.521674+00
9	5	معامله به «در جریان» برگشت	معامله #6 از حالت قطعی خارج شد.	deal	6	t	2026-09-11 14:00:19.172969+00
10	5	معامله‌ی شما قطعی شد	معامله #6 قطعی شد — پورسانت 4,888,889 تومان.	deal	6	t	2026-09-11 14:00:29.010763+00
11	5	پرداخت پورسانت ثبت شد	برای معامله #6 پرداخت 2,222 تومانی ثبت شد.	deal	6	t	2026-09-11 14:00:38.723619+00
14	1	درخواست حذف فیلتر آماده	«dddd» توسط sss درخواست حذف داده — در مدیریت فیلترها تأیید کن.	preset_delete	4	t	2026-09-11 14:15:11.675828+00
13	1	پیشنهاد فیلتر آمادهٔ جدید	«www» توسط sss پیشنهاد شده — در مدیریت فیلترها تأیید کن.	preset	6	t	2026-09-11 14:15:06.571989+00
7	1	معامله‌ی شما قطعی شد	معامله #4 قطعی شد — پورسانت 333,333,333 تومان.	deal	4	t	2026-09-11 12:41:23.692027+00
6	1	⚠️ پیگیری عقب‌افتاده!	ثثثثث — سررسید: 2026-09-03	follow_up	9	t	2026-09-11 12:39:19.629747+00
15	4	💬 پیام جدید	از admin: صصصصص	chat	1	f	2026-09-13 12:20:30.099177+00
17	1	💬 پیام جدید	از sss: ضضض	chat	5	f	2026-09-13 12:21:15.647929+00
16	5	💬 پیام جدید	از admin: صصصص	chat	1	t	2026-09-13 12:20:37.183322+00
18	5	معامله به «در جریان» برگشت	معامله #6 از حالت قطعی خارج شد.	deal	6	f	2026-09-16 20:18:50.580419+00
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.properties (id, owner_agent_id, deal_type, status, city, district, address, area_m2, rooms, has_elevator, has_parking, owner_name, owner_phone, contract_end_date, details, notes, created_at, updated_at, version, amenities, expire_notified_at, expire_review_at, property_types) FROM stdin;
2	1	presale	active	بذذذ	ذذذذ	ببببببب	\N	\N	t	t	ببببببببب	ببببب	\N	{"total_price": null, "delivery_date": null}	\N	2026-09-07 15:44:18.677548+00	2026-09-07 15:44:18.677554+00	1	\N	\N	\N	\N
3	1	mortgage	active	ttt	vggggggtt	tttt	\N	1	f	f	hhhhh	56784564321	\N	{"deposit_full": 4444444}	tttttttt	2026-09-08 15:37:02.62799+00	2026-09-08 15:38:23.439511+00	2	["tttt", "3eeeeee"]	\N	\N	\N
5	1	sale	active	للل	للللللل	للللللل	\N	\N	f	f	\N	\N	\N	{"price": null, "price_per_m2": null}	\N	2026-09-08 16:10:03.227251+00	2026-09-08 16:10:03.227256+00	1	null	\N	\N	\N
6	1	sale	active	ففففف	ففففف	\N	55555	4	t	t	\N	\N	\N	{"price": null, "price_per_m2": null}	\N	2026-09-08 16:10:03.227257+00	2026-09-08 16:10:03.227257+00	1	null	\N	\N	\N
7	1	presale	active	rrrrrrrrrrr	rr	rrr	55555	\N	f	f	\N	\N	\N	{"total_price": null, "delivery_date": null}	\N	2026-09-08 16:10:03.227258+00	2026-09-08 16:10:03.227259+00	1	null	\N	\N	\N
10	1	sale	sold	ففففف	ففففف	\N	55555	4	t	t	\N	\N	\N	{"price": null, "price_per_m2": null}	\N	2026-09-08 16:10:05.539149+00	2026-09-09 17:20:13.91657+00	1	null	\N	\N	\N
9	1	mortgage	inactive	uuuتت	تتتت	\N	22222	2	f	f	\N	22222222222	\N	{"deposit_full": null}	\N	2026-09-08 16:10:03.22726+00	2026-09-09 20:26:18.83656+00	1	null	\N	\N	\N
8	1	rent	inactive	uuuuu	uu	\N	\N	2	f	f	\N	\N	\N	{"deposit": null, "monthly_rent": null}	\N	2026-09-08 16:10:03.227259+00	2026-09-09 20:26:40.832177+00	1	null	\N	\N	\N
1	1	sale	sold	تهران	۶	رغفرانیه ۱	8	3	t	t	صشسش	\N	\N	{"price": 2222222222222222}	ثبیزی	2026-09-07 15:39:00.963663+00	2026-09-11 12:41:23.683336+00	2	\N	\N	\N	\N
12	5	sale	active	aaa	aaaaaa	aaaaaa	\N	\N	f	f	\N	\N	\N	{"price": null}	\N	2026-09-11 14:15:32.032633+00	2026-09-11 14:15:32.032636+00	1	[]	\N	\N	\N
13	5	presale	active	aaaaa	\N	\N	\N	\N	f	t	\N	9053213280	\N	{"total_price": 222222, "delivery_date": null}	\N	2026-09-11 14:17:30.685473+00	2026-09-11 14:17:30.685477+00	1	null	\N	\N	\N
14	5	presale	active	bbbb	\N	\N	\N	\N	f	t	\N	9053213280	\N	{"total_price": 444, "delivery_date": null}	\N	2026-09-11 14:17:30.685478+00	2026-09-11 14:17:30.685478+00	1	null	\N	\N	\N
15	5	rent	active	fff	\N	\N	\N	4	f	f	r	\N	\N	{"deposit": 333, "monthly_rent": null}	\N	2026-09-11 14:17:30.685479+00	2026-09-11 14:17:30.685479+00	1	null	\N	\N	\N
16	5	rent	active	vvv	\N	\N	\N	\N	f	f	\N	\N	\N	{"deposit": 444, "monthly_rent": null}	\N	2026-09-11 14:17:30.68548+00	2026-09-11 14:17:30.685481+00	1	null	\N	\N	\N
17	5	mortgage	active	rrrr	ffff	ffffff	44	\N	f	f	\N	\N	\N	{"deposit_full": null}	\N	2026-09-11 14:17:30.685481+00	2026-09-11 14:17:30.685481+00	1	null	\N	\N	\N
11	1	rent	active	uuuuu	uu	\N	\N	2	f	f	\N	\N	2026-09-13	{"deposit": null, "monthly_rent": null}	\N	2026-09-08 16:10:05.539153+00	2026-09-15 15:39:27.792775+00	4	[]	\N	\N	\N
18	5	rent	active	ببب	بببب	بببببببب	33	20	t	t	ل	9999999999	2025-10-09	{"deposit": 333333, "monthly_rent": 333}	بببببب	2026-09-11 14:23:11.087922+00	2026-09-16 20:14:54.580002+00	2	["\\u0642\\u0642"]	\N	\N	\N
4	1	sale	active	غغغغ	نتتتتت	\N	9	\N	f	f	اااااااا	\N	\N	{"price": null}	\N	2026-09-08 15:38:09.562603+00	2026-09-16 20:18:50.556225+00	1	["\\u0627\\u0627\\u0627\\u0627"]	\N	\N	\N
\.


--
-- Data for Name: property_images; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.property_images (id, property_id, stored_filename, original_filename, content_type, created_at) FROM stdin;
1	11	20f9efe3368447acb7f344bcf8143fee.jpg	download (1).jpg	image/jpeg	2026-09-08 16:47:38.580324+00
2	11	f34a3c4da7cf496bbc515ddabb5d4076.jpg	download.jpg	image/jpeg	2026-09-08 16:47:38.580333+00
4	12	c3351a44e591488595ce5da98521ebbd.png	Screenshot 2026-09-02 150038.png	image/png	2026-09-11 14:15:39.913026+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: melkyar_app
--

COPY public.users (id, username, full_name, hashed_password, role, is_active, token_version, created_at, phone, failed_attempts, locked_until, commission_rates) FROM stdin;
1	admin	admin	$2b$12$V87XnEW8T4YRtth2fQhirOuOydmk9Go/kl6Kx3TcpL3rlSOdHwN1W	admin	t	0	2026-09-07 14:57:31.83504+00	\N	0	\N	\N
2	تینا	x	$2b$12$8cVoRIg6sFn7sX.BfSJzZupj5FUED0ZwGB17QmXRly5ZtQqpE0maS	agent	t	1	2026-09-08 16:54:26.759073+00	09053213280	0	\N	{"sale": 45.0, "rent": 42.0, "presale": 44.0, "mortgage": 40.0}
3	ضضض	ضضض	$2b$12$Ki9H5m5qpCofYFqBayts2uvs8WqTZihuZflglJ.va43biCW1bYdxy	agent	t	1	2026-09-08 16:55:26.775551+00	\N	0	\N	\N
4	jjj	lllllll	$2b$12$E3CtG0VKz55o91cTF9Gh5e/Z/EFC9WztkExVX9QH5eIxJ7ONKrWsC	agent	t	0	2026-09-09 20:16:52.642961+00	\N	0	\N	\N
5	sss	sss	$2b$12$5F5VC78b9gKKEc/6Mdb1NOkvody1cfBAiHtrWqlbJv0JyNMgx2P6O	agent	t	1	2026-09-11 12:09:15.361008+00	\N	0	\N	\N
\.


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 125, true);


--
-- Name: bot_faq_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.bot_faq_id_seq', 24, true);


--
-- Name: chat_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.chat_messages_id_seq', 3, true);


--
-- Name: client_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.client_requests_id_seq', 4, true);


--
-- Name: commission_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.commission_payments_id_seq', 4, true);


--
-- Name: deals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.deals_id_seq', 6, true);


--
-- Name: filter_presets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.filter_presets_id_seq', 40, true);


--
-- Name: follow_ups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.follow_ups_id_seq', 11, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.notifications_id_seq', 18, true);


--
-- Name: properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.properties_id_seq', 18, true);


--
-- Name: property_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.property_images_id_seq', 4, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: melkyar_app
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: bot_faq bot_faq_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.bot_faq
    ADD CONSTRAINT bot_faq_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: client_requests client_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.client_requests
    ADD CONSTRAINT client_requests_pkey PRIMARY KEY (id);


--
-- Name: commission_payments commission_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.commission_payments
    ADD CONSTRAINT commission_payments_pkey PRIMARY KEY (id);


--
-- Name: deals deals_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_pkey PRIMARY KEY (id);


--
-- Name: filter_presets filter_presets_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.filter_presets
    ADD CONSTRAINT filter_presets_pkey PRIMARY KEY (id);


--
-- Name: follow_ups follow_ups_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.follow_ups
    ADD CONSTRAINT follow_ups_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_images property_images_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.property_images
    ADD CONSTRAINT property_images_pkey PRIMARY KEY (id);


--
-- Name: filter_presets uq_filter_presets_name; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.filter_presets
    ADD CONSTRAINT uq_filter_presets_name UNIQUE (name);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_chat_messages_receiver_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_chat_messages_receiver_id ON public.chat_messages USING btree (receiver_id);


--
-- Name: ix_chat_messages_sender_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_chat_messages_sender_id ON public.chat_messages USING btree (sender_id);


--
-- Name: ix_client_requests_owner_agent_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_client_requests_owner_agent_id ON public.client_requests USING btree (owner_agent_id);


--
-- Name: ix_commission_payments_deal_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_commission_payments_deal_id ON public.commission_payments USING btree (deal_id);


--
-- Name: ix_deals_agent_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_deals_agent_id ON public.deals USING btree (agent_id);


--
-- Name: ix_deals_property_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_deals_property_id ON public.deals USING btree (property_id);


--
-- Name: ix_follow_ups_due_date; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_follow_ups_due_date ON public.follow_ups USING btree (due_date);


--
-- Name: ix_follow_ups_user_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_follow_ups_user_id ON public.follow_ups USING btree (user_id);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_properties_city; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_properties_city ON public.properties USING btree (city);


--
-- Name: ix_properties_contract_end_date; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_properties_contract_end_date ON public.properties USING btree (contract_end_date);


--
-- Name: ix_properties_deal_type; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_properties_deal_type ON public.properties USING btree (deal_type);


--
-- Name: ix_properties_owner_agent_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_properties_owner_agent_id ON public.properties USING btree (owner_agent_id);


--
-- Name: ix_properties_status; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_properties_status ON public.properties USING btree (status);


--
-- Name: ix_property_images_property_id; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE INDEX ix_property_images_property_id ON public.property_images USING btree (property_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: melkyar_app
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: chat_messages chat_messages_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES public.users(id);


--
-- Name: chat_messages chat_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: client_requests client_requests_owner_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.client_requests
    ADD CONSTRAINT client_requests_owner_agent_id_fkey FOREIGN KEY (owner_agent_id) REFERENCES public.users(id);


--
-- Name: commission_payments commission_payments_deal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.commission_payments
    ADD CONSTRAINT commission_payments_deal_id_fkey FOREIGN KEY (deal_id) REFERENCES public.deals(id);


--
-- Name: deals deals_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id);


--
-- Name: deals deals_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: filter_presets filter_presets_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.filter_presets
    ADD CONSTRAINT filter_presets_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id);


--
-- Name: follow_ups follow_ups_deal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.follow_ups
    ADD CONSTRAINT follow_ups_deal_id_fkey FOREIGN KEY (deal_id) REFERENCES public.deals(id);


--
-- Name: follow_ups follow_ups_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.follow_ups
    ADD CONSTRAINT follow_ups_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: follow_ups follow_ups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.follow_ups
    ADD CONSTRAINT follow_ups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: properties properties_owner_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_owner_agent_id_fkey FOREIGN KEY (owner_agent_id) REFERENCES public.users(id);


--
-- Name: property_images property_images_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: melkyar_app
--

ALTER TABLE ONLY public.property_images
    ADD CONSTRAINT property_images_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- PostgreSQL database dump complete
--

\unrestrict sionsyqJktTXgzIAVR5vu3T3KYmnRHNsWYdbnEqg9XYFuzlxsKAONvNYX6LGGO7

